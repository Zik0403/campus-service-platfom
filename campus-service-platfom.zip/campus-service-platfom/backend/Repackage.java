import org.springframework.boot.loader.tools.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class Repackage {
    public static void main(String[] args) throws Exception {
        String baseDir = "e:\\校园生活服务小程序\\backend";
        String classesDir = baseDir + "\\target\\classes";
        String depsDir = baseDir + "\\target\\deps";
        String outputJar = baseDir + "\\target\\campus-service-1.0.0.jar";

        System.out.println("Repackaging Spring Boot application...");
        System.out.println("Classes: " + classesDir);
        System.out.println("Deps: " + depsDir);
        System.out.println("Output: " + outputJar);

        JarWriter writer = new JarWriter(new FileOutputStream(outputJar));

        writer.writeManifest(new Manifest() {{
            getMainAttributes().putValue("Main-Class", "org.springframework.boot.loader.launch.JarLauncher");
            getMainAttributes().putValue("Start-Class", "com.campus.service.CampusServiceApplication");
            getMainAttributes().putValue("Spring-Boot-Version", "3.4.1");
        }});

        writer.writeEntries(new FileSystemLoader(new File(classesDir)),
            new LoaderClassesWriter() {
                @Override
                public void writeEntry(String entryName, InputStream inputStream) throws IOException {
                    writer.writeEntry("BOOT-INF/classes/" + entryName, inputStream);
                }
            });

        List<File> libs = new ArrayList<>();
        try (Stream<Path> paths = Files.walk(Paths.get(depsDir))) {
            paths.filter(Files::isRegularFile)
                .filter(p -> p.toString().endsWith(".jar"))
                .forEach(p -> libs.add(p.toFile()));
        }

        for (File lib : libs) {
            String libName = lib.getName();
            try (InputStream is = new FileInputStream(lib)) {
                writer.writeEntry("BOOT-INF/lib/" + libName, is);
            }
            System.out.println("Added lib: " + libName);
        }

        String loaderJar = System.getProperty("user.home") + "\\.m2\\repository\\org\\springframework\\boot\\spring-boot-loader\\3.4.1\\spring-boot-loader-3.4.1.jar";
        System.out.println("Adding loader: " + loaderJar);
        try (InputStream is = new FileInputStream(loaderJar)) {
            writer.writeEntry("org/springframework/boot/loader/", is);
        }

        writer.close();
        System.out.println("Done!");
    }
}