@echo off
cd /d e:\校园生活服务小程序\backend
set JAVA_HOME=C:\Program Files\Java\latest\jdk-25

echo Compiling NoticeController...
"%JAVA_HOME%\bin\javac.exe" -cp target\campus-service-1.0.0.jar -d target\classes src\main\java\com\campus\service\controller\NoticeController.java

echo Done.
pause