-- =============================================
-- 数据丰富化脚本
-- =============================================

USE campus_db;

-- 1. activity表添加credit_reward字段（忽略已存在错误）
-- 先尝试删除（如果存在），再添加
DROP PROCEDURE IF EXISTS add_activity_credit_reward;
DELIMITER $$
CREATE PROCEDURE add_activity_credit_reward()
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN END;
    ALTER TABLE activity ADD COLUMN credit_reward INT NOT NULL DEFAULT 5 COMMENT '签到奖励信用积分' AFTER enroll_count;
END$$
DELIMITER ;
CALL add_activity_credit_reward();
DROP PROCEDURE IF EXISTS add_activity_credit_reward;

-- 2. service_order添加投诉字段
DROP PROCEDURE IF EXISTS add_service_order_complain;
DELIMITER $$
CREATE PROCEDURE add_service_order_complain()
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN END;
    ALTER TABLE service_order ADD COLUMN is_complained TINYINT NOT NULL DEFAULT 0 COMMENT '是否投诉 0否 1是';
    ALTER TABLE service_order ADD COLUMN complain_reason VARCHAR(500) DEFAULT NULL COMMENT '投诉原因';
    ALTER TABLE service_order ADD COLUMN complain_time DATETIME DEFAULT NULL COMMENT '投诉时间';
END$$
DELIMITER ;
CALL add_service_order_complain();
DROP PROCEDURE IF EXISTS add_service_order_complain;

-- 3. second_order添加投诉字段
DROP PROCEDURE IF EXISTS add_second_order_complain;
DELIMITER $$
CREATE PROCEDURE add_second_order_complain()
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN END;
    ALTER TABLE second_order ADD COLUMN is_complained TINYINT NOT NULL DEFAULT 0 COMMENT '是否投诉 0否 1是';
    ALTER TABLE second_order ADD COLUMN complain_reason VARCHAR(500) DEFAULT NULL COMMENT '投诉原因';
    ALTER TABLE second_order ADD COLUMN complain_time DATETIME DEFAULT NULL COMMENT '投诉时间';
END$$
DELIMITER ;
CALL add_second_order_complain();
DROP PROCEDURE IF EXISTS add_second_order_complain;

-- 4. 插入丰富的社团数据（如果已存在则忽略）
INSERT IGNORE INTO club (id, name, logo, intro, leader_id, category, audit_status, status, member_count) VALUES
(1, '计算机协会', NULL, '计算机协会是一个致力于推广计算机技术、培养编程兴趣的学术科技类社团。我们定期举办编程比赛、技术讲座、项目实践等活动，欢迎所有对计算机感兴趣的同学加入！', 1, '学术科技', 2, 1, 120),
(2, '志愿者协会', NULL, '志愿者协会秉承"奉献、友爱、互助、进步"的志愿精神，组织开展各类志愿服务活动，包括社区服务、环境保护、关爱老人等，让爱心在校园传递。', 1, '公益志愿', 2, 1, 200),
(3, '吉他社', NULL, '吉他社是音乐爱好者的聚集地，无论你是零基础还是吉他高手，都能在这里找到志同道合的朋友。我们定期举办吉他教学、校园音乐节、草坪音乐会等活动。', 2, '文化艺术', 2, 1, 85),
(4, '篮球协会', NULL, '篮球协会致力于推广校园篮球运动，组织篮球联赛、三人篮球赛、技巧挑战赛等精彩活动，为热爱篮球的你提供展示自我的舞台。', 2, '体育运动', 2, 1, 150),
(5, '书法协会', NULL, '书法协会传承中华优秀传统文化，开展书法教学、笔会交流、书法展览等活动，让更多同学感受书法之美，修身养性。', 1, '文化艺术', 2, 1, 60),
(6, '创业协会', NULL, '创业协会为有创业梦想的同学提供交流平台，举办创业讲座、创业大赛、企业参访等活动，助力校园创业项目成长。', 2, '学术科技', 2, 1, 95),
(7, '动漫社', NULL, '动漫社是ACG爱好者的乐园，组织漫展参展、Cosplay表演、动漫观影、手绘交流等活动，一起享受二次元的快乐。', 1, '文化艺术', 2, 1, 110),
(8, '羽毛球协会', NULL, '羽毛球协会推广羽毛球运动，定期组织训练、友谊赛、校园羽毛球联赛，强身健体，以球会友。', 2, '体育运动', 2, 1, 130),
(9, '文学社', NULL, '文学社汇聚热爱文学的青年，开展读书分享、诗歌创作、文学讲座、征文比赛等活动，用文字记录青春，用思想碰撞火花。', 1, '文化艺术', 2, 1, 75),
(10, '摄影协会', NULL, '摄影协会用镜头记录美好瞬间，提供摄影技术培训、外拍实践、摄影展览等活动，欢迎所有热爱摄影的同学。', 2, '文化艺术', 2, 1, 90);

-- 5. 插入丰富的社团活动数据
INSERT IGNORE INTO activity (id, club_id, name, poster, location, start_time, end_time, enroll_deadline, description, max_people, enroll_count, credit_reward, audit_status, status) VALUES
(1, 1, 'Python编程入门讲座', NULL, '教3-301', DATE_ADD(NOW(), INTERVAL 3 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 3 DAY), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 2 DAY), '计算机协会特邀资深程序员为大家带来Python编程入门讲座，零基础友好，带你走进编程世界。现场还有小礼品相送！', 100, 45, 5, 2, 1),
(2, 1, '校园编程马拉松', NULL, '实验楼-301', DATE_ADD(NOW(), INTERVAL 7 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 7 DAY), INTERVAL 12 HOUR), DATE_ADD(NOW(), INTERVAL 5 DAY), '24小时编程马拉松挑战赛！组队参赛，从零到一实现你的创意项目。丰厚奖金等你来拿，还有机会获得企业实习推荐。', 60, 32, 15, 2, 1),
(3, 2, '敬老院关爱活动', NULL, '阳光敬老院', DATE_ADD(NOW(), INTERVAL 5 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 5 DAY), INTERVAL 3 HOUR), DATE_ADD(NOW(), INTERVAL 3 DAY), '志愿者协会组织敬老院探访活动，陪老人聊天、表演节目、打扫卫生，用行动传递温暖。参与即可获得志愿时长证明。', 30, 28, 10, 2, 1),
(4, 2, '校园环保日', NULL, '校园内', DATE_ADD(NOW(), INTERVAL 10 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 10 DAY), INTERVAL 4 HOUR), DATE_ADD(NOW(), INTERVAL 8 DAY), '世界环境日特别活动，校园垃圾清理、环保知识宣传、旧物交换市集，一起守护美丽校园。', 200, 80, 8, 2, 1),
(5, 3, '吉他入门教学班', NULL, '大学生活动中心-201', DATE_ADD(NOW(), INTERVAL 2 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 2 DAY), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 1 DAY), '吉他社每周吉他入门教学，从零开始教你弹吉他。自带吉他或借用社团吉他均可，欢迎所有音乐爱好者。', 40, 35, 3, 2, 1),
(6, 3, '校园草地音乐节', NULL, '操场草坪', DATE_ADD(NOW(), INTERVAL 14 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 14 DAY), INTERVAL 5 HOUR), DATE_ADD(NOW(), INTERVAL 10 DAY), '一年一度的校园草地音乐节！多支校园乐队轮番演出，还有现场互动环节。带上你的好朋友，一起享受音乐的夏天！', 500, 320, 5, 2, 1),
(7, 4, '新生篮球赛', NULL, '体育馆', DATE_ADD(NOW(), INTERVAL 4 DAY), DATE_ADD(NOW(), INTERVAL 11 DAY), DATE_ADD(NOW(), INTERVAL 3 DAY), '新生杯篮球联赛开赛！以学院为单位参赛，展示新生风采，争夺校园篮球最高荣誉。', 120, 96, 8, 2, 1),
(8, 4, '三人篮球挑战赛', NULL, '室外篮球场', DATE_ADD(NOW(), INTERVAL 9 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 9 DAY), INTERVAL 8 HOUR), DATE_ADD(NOW(), INTERVAL 7 DAY), '三人制篮球挑战赛，自由组队报名，男女不限。冠军队伍将获得精美奖杯和运动装备。', 64, 48, 6, 2, 1),
(9, 5, '书法入门体验课', NULL, '教2-201', DATE_ADD(NOW(), INTERVAL 3 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 3 DAY), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 2 DAY), '书法协会零基础书法体验课，笔墨纸砚全部免费提供，带你感受中华书法的魅力。', 30, 22, 5, 2, 1),
(10, 5, '校园书法展览', NULL, '图书馆一楼展厅', DATE_ADD(NOW(), INTERVAL 15 DAY), DATE_ADD(NOW(), INTERVAL 22 DAY), DATE_ADD(NOW(), INTERVAL 14 DAY), '校园书法作品展，汇集全校师生优秀书法作品。参观即可获得纪念书签，现场还有书法家题字活动。', 500, 0, 3, 2, 1),
(11, 6, '创业分享会', NULL, '学术报告厅', DATE_ADD(NOW(), INTERVAL 6 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 6 DAY), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 5 DAY), '邀请优秀校友创业者分享创业经历，从0到1的心路历程，还有现场答疑环节。', 200, 150, 5, 2, 1),
(12, 6, '商业计划书大赛', NULL, '大学生活动中心', DATE_ADD(NOW(), INTERVAL 20 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 20 DAY), INTERVAL 8 HOUR), DATE_ADD(NOW(), INTERVAL 15 DAY), '校园商业计划书大赛，展示你的创业idea，专业评委点评指导，冠军项目可获得孵化支持。', 100, 60, 10, 2, 1),
(13, 7, '动漫观影会', NULL, '教1-101', DATE_ADD(NOW(), INTERVAL 2 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 2 DAY), INTERVAL 3 HOUR), DATE_ADD(NOW(), INTERVAL 1 DAY), '每周动漫观影会，本周放映《你的名字》，免费入场，还有零食饮料提供。', 80, 50, 2, 2, 1),
(14, 7, '漫展组团参团', NULL, '会展中心', DATE_ADD(NOW(), INTERVAL 12 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 12 DAY), INTERVAL 8 HOUR), DATE_ADD(NOW(), INTERVAL 10 DAY), '一起去漫展！社团统一购票，享受团购优惠，还有专属Cosplay化妆间。名额有限，先到先得。', 50, 45, 5, 2, 1),
(15, 8, '羽毛球友谊赛', NULL, '体育馆羽毛球场', DATE_ADD(NOW(), INTERVAL 5 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 5 DAY), INTERVAL 4 HOUR), DATE_ADD(NOW(), INTERVAL 4 DAY), '羽毛球协会月度友谊赛，单打双打均可报名，以球会友，共同进步。', 32, 24, 3, 2, 1),
(16, 9, '读书分享会', NULL, '图书馆-302', DATE_ADD(NOW(), INTERVAL 4 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 4 DAY), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 3 DAY), '本月读书分享会主题：《百年孤独》。欢迎读过或想读这本书的同学来一起交流分享。', 20, 15, 3, 2, 1),
(17, 10, '校园风光摄影采风', NULL, '校园内', DATE_ADD(NOW(), INTERVAL 7 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 7 DAY), INTERVAL 3 HOUR), DATE_ADD(NOW(), INTERVAL 6 DAY), '摄影协会组织校园风光采风活动，专业摄影师带队指导，一起发现校园的美。优秀作品将在校园网展出。', 30, 18, 5, 2, 1);

-- 6. 插入丰富的表白墙数据
INSERT IGNORE INTO community_post (id, user_id, post_type, title, content, images, is_anon, audit_status, like_num, comment_num) VALUES
(1, 3, 1, NULL, '致图书馆三楼靠窗总是穿白衬衫的男生：你专注看书的样子真的好好看，每次抬头都能看到你认真的侧脸。鼓起勇气想认识你，如果你看到这条消息，能不能下周同一时间，我穿粉色外套，在图书馆门口等你。', NULL, 1, 2, 128, 32),
(2, 4, 1, NULL, 'To 计算机学院的学长：上次在食堂你帮我捡起了掉落的饭卡，我还没来得及说谢谢你就走了。你穿着灰色卫衣，背着黑色双肩包，笑起来有酒窝。想找到你当面说声谢谢，也想...认识你。', NULL, 1, 2, 256, 45),
(3, 3, 1, NULL, '给每天早上在操场跑步的女孩：你扎着高马尾，跑步的时候特别有活力。我是那个总是和你擦肩而过的男生，鼓起勇气发这条表白墙，想问问能不能一起跑步呀？', NULL, 1, 2, 89, 18),
(4, 4, 1, NULL, '高数课坐我前面的女生：你的马尾辫真好看，每次你转过来问我借橡皮的时候我都特别紧张。其实我橡皮一直都放在你能看到的地方...下次能不能借我一支笔？', NULL, 1, 2, 167, 28),
(5, 3, 1, NULL, '致社团招新时认识的学妹：那天你问我问题的时候眼睛亮晶晶的，我当时就心跳加速了。后来在社团活动中每次见到你都特别开心。学妹，我喜欢你，你愿意做我女朋友吗？', NULL, 1, 2, 203, 56),
(6, 4, 1, NULL, '给我亲爱的室友：大学四年，谢谢你们陪我熬夜赶作业，陪我过生日，陪我一起疯一起闹。马上就要毕业了，真的很舍不得。你们是我大学最珍贵的礼物。', NULL, 0, 2, 312, 67),
(7, 3, 1, NULL, '下雨天借我伞的那个女生：那天雨下得很大，我没带伞被困在教学楼，你撑着伞把我送到宿舍楼下，然后自己又冲进雨里。我连你的名字都不知道，只记得你笑起来很好看。想找到你，把伞还给你，也想...请你吃饭。', NULL, 1, 2, 178, 42),
(8, 4, 2, '考研经验分享 | 双非上岸985，我是怎么做到的', '大家好，我是去年考研上岸的学长。很多学弟学妹问我经验，今天分享一下我的备考心得：\n\n1. 数学一定要早开始，基础打牢\n2. 英语单词每天都要背，坚持到考前\n3. 专业课真题要反复做，摸清出题规律\n4. 政治不用太早，9月份开始完全来得及\n5. 心态很重要，按部就班就是最快的\n\n最后想说，考研这条路很难，但坚持下来的你真的很酷！有问题可以评论区问我～', NULL, 0, 2, 456, 89),
(9, 3, 2, '食堂新出的麻辣香锅也太好吃了吧！', '今天去食堂二楼发现新开了一家麻辣香锅，抱着试试的心态点了一份，结果惊艳到我了！\n\n食材很新鲜，种类也多，我选了肥牛、虾饺、娃娃菜、土豆片...份量超足，微辣的口味刚刚好，香而不腻。\n\n重点是价格还很实惠，一大碗才15块！强烈推荐大家去尝尝，就在食堂二楼最里面那家～', NULL, 0, 2, 234, 56),
(10, 4, 2, '求助！有没有人知道学校附近哪家打印店便宜', '快要毕业了，要打印的东西好多，毕业论文、简历各种材料...\n\n想问问大家学校附近哪家打印店比较便宜呀？最好是能批量打印的那种，价格大概是多少？\n\n如果有知道的同学麻烦评论区告诉我一下，谢谢大家了！', NULL, 0, 2, 78, 23),
(11, 3, 2, '记录一下我的减肥打卡Day30', '不知不觉减肥已经一个月了！来打卡记录一下：\n\n初始体重：65kg\n今日体重：59.8kg\n累计减重：5.2kg\n\n方法其实很简单：\n1. 控制饮食，戒掉奶茶和宵夜\n2. 每天晚上去操场跑3公里\n3. 早睡早起，不熬夜\n\n虽然过程很辛苦，但看到体重秤上的数字一点点下降，真的很有成就感！继续加油！', NULL, 0, 2, 345, 78),
(12, 4, 3, '【兼职】校园奶茶店招聘店员', '学校西门奶茶店招聘兼职店员：\n\n【要求】\n- 在校大学生，男女不限\n- 工作认真负责，有服务意识\n- 每周能工作3天以上\n\n【待遇】\n- 18元/小时，月结\n- 上班期间免费喝奶茶\n- 表现优秀有奖金\n\n【工作内容】\n点单、制作奶茶、收银等\n\n有意向的同学请私信我获取联系方式～', NULL, 0, 2, 156, 34),
(13, 3, 3, '家教兼职 | 初一数学辅导', '找一份家教兼职：\n\n【辅导科目】初一数学\n【学生情况】男生，基础一般，需要巩固基础\n【上课时间】每周六上午2小时\n【上课地点】学生家（学校附近小区，骑车10分钟）\n【薪资】80元/小时，课后结算\n\n【要求】\n- 数学成绩好，有耐心\n- 有家教经验优先\n- 在校大学生均可\n\n有意向的同学请评论区留言，我会联系你的。', NULL, 0, 2, 89, 15);

-- 7. 插入失物招领示例数据
INSERT IGNORE INTO lost_found (id, user_id, type, goods_name, goods_type, location, feature, contact, status) VALUES
(1, 3, 1, '黑色双肩包', '证件卡片', '图书馆三楼', '包内有学生证、钱包、钥匙，包上挂着一个小熊挂件', '13800138001', 1),
(2, 4, 2, 'AirPods Pro耳机', '电子产品', '教2-201教室', '白色耳机盒，有刻字"小明"，左耳有点划痕', '13800138002', 1),
(3, 3, 1, '校园卡', '证件卡片', '食堂一楼', '卡套是蓝色的，上面有个哆啦A梦贴纸', '13800138001', 1),
(4, 4, 2, '一串钥匙', '钥匙配饰', '操场看台上', '大概有5把钥匙，其中一把是铜色的，还有一个小铃铛', '13800138002', 2),
(5, 3, 1, '粉色雨伞', '衣物鞋帽', '教1楼门口', '粉色折叠伞，伞骨有一根有点弯了，伞柄上缠着粉色胶带', '13800138001', 1),
(6, 4, 2, '黑色钱包', '钱包现金', '快递站附近', '黑色长钱包，里面有现金几十块、身份证、银行卡', '13800138002', 1);

-- 8. 插入二手商品示例数据
INSERT IGNORE INTO second_product (id, seller_id, title, category, price, description, images, allow_bargain, valid_day, status) VALUES
(1, 3, '九成新考研数学复习全书', 'book', 35.00, '2025版李永乐考研数学复习全书，只做了前几页，基本全新，笔记很少。考研上岸出，送配套视频课资料。', NULL, 1, 30, 2),
(2, 4, 'iPad 2021 64G', 'digital', 1800.00, 'iPad 2021款 64G 深空灰色，平时用来上网课看剧，保养得很好，无磕碰无划痕。配件齐全，送保护套和钢化膜。', NULL, 1, 15, 2),
(3, 3, '运动跑鞋 42码', 'clothing', 80.00, '李宁运动跑鞋，42码，蓝白配色，只穿了几次，鞋底几乎没有磨损。买大了一码所以出，原价399买的。', NULL, 1, 20, 2),
(4, 4, '台灯 护眼LED', 'life', 45.00, '欧普护眼LED台灯，三档调光，用了半年，功能完好。毕业带不走，便宜出。可调节亮度和色温，学习必备。', NULL, 1, 10, 2),
(5, 3, '电动车 九成新', 'bike', 1200.00, '雅迪电动车，买了一年多，平时上课用，保养得很好。电池续航还能跑40公里，带充电器和头盔。可以试车，诚心要可小刀。', NULL, 1, 30, 2),
(6, 4, '口红 YSL小金条', 'beauty', 120.00, 'YSL小金条口红，色号21号复古正红，只用过3次左右，颜色不适合我。专柜正品，支持验货。', NULL, 0, 15, 2),
(7, 3, '哑铃一对 10kg', 'sports', 60.00, '10kg哑铃一对，包胶材质，不伤地板。健身用了一段时间，现在练更重的了所以出。适合新手居家锻炼。', NULL, 1, 20, 2);

-- 9. 插入维修人员测试账号（角色2=维修人员，密码w12345）
INSERT IGNORE INTO `user` (id, openid, real_name, phone, id_card, password, nickname, role, credit_score, balance, is_auth, is_delete) VALUES
(5, '', '张维修', '13800138555', '110101199001011234', 'eed70691cd38eb3621fd9a21f5c08fad', '张维修', 2, 100, 0.00, 1, 0);
