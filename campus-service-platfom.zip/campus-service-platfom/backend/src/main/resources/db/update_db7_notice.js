// 更新数据库公告内容
// 运行方式: node update_db7_notice.js

const mysql = require('mysql2/promise');

async function updateNoticeData() {
  const connection = await mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'campus_db'
  });

  console.log('连接数据库成功');

  // 先清空旧数据
  await connection.execute('DELETE FROM campus_notice');
  console.log('清空旧公告数据');

  // 插入丰富的公告内容
  const notices = [
    // 校园公告 (noticeType = 1)
    {
      noticeType: 1,
      title: '关于2026年暑假放假安排的通知',
      content: '各位同学：\n\n根据学校教学安排，2026年暑假放假时间如下：\n\n放假时间：2026年7月15日 - 2026年8月31日\n开学时间：2026年9月1日\n\n请各位同学合理安排假期时间，注意假期安全。离校前请做好宿舍安全检查，关闭水电门窗。\n\n祝各位同学假期愉快！\n\n教务处\n2026年7月7日',
      sort: 1,
      status: 1
    },
    {
      noticeType: 1,
      title: '图书馆暑期开放时间调整公告',
      content: '各位读者：\n\n因暑假期间师生人数减少，图书馆开放时间进行调整：\n\n开放时间：每日 9:00 - 17:00\n闭馆时间：每周一闭馆进行内部整理\n\n自习室正常开放，空调全天运行。借阅服务照常进行，线上预约系统保持正常运行。\n\n请提前预约自习座位，避免高峰时段拥挤。\n\n图书馆\n2026年7月6日',
      sort: 2,
      status: 1
    },
    {
      noticeType: 1,
      title: '校园网升级维护通知',
      content: '各位师生：\n\n为提升校园网络服务质量，信息中心将于2026年7月10日进行网络设备升级维护：\n\n维护时间：2026年7月10日 22:00 - 2026年7月11日 06:00\n影响范围：全校范围内网络将暂时中断\n\n请各位师生提前做好网络使用安排，维护期间可使用教学楼公共WiFi应急通道。\n\n感谢您的理解与配合！\n\n信息中心\n2026年7月5日',
      sort: 3,
      status: 1
    },
    {
      noticeType: 1,
      title: '学生宿舍安全用电温馨提示',
      content: '各位同学：\n\n近期发现部分宿舍存在违规使用大功率电器的情况，为确保宿舍用电安全，请各位同学注意以下事项：\n\n1. 禁止使用电热毯、电炉、电饭煲等大功率电器\n2. 充电设备使用完毕请及时拔除\n3. 禁止私拉乱接电线\n4. 空调温度建议设置在26度\n\n宿舍安全事关每位同学的生命财产安全，请大家严格遵守用电规范。发现违规行为将进行相应处理。\n\n宿管中心\n2026年7月4日',
      sort: 4,
      status: 1
    },

    // 活动公告 (noticeType = 2)
    {
      noticeType: 2,
      title: '校园篮球联赛火热报名中',
      content: '各位同学：\n\n2026年校园篮球联赛即日起开始报名！\n\n报名条件：\n1. 在校本科生、研究生均可参加\n2. 以班级或社团为单位组队\n3. 每队人数不少于5人，不超过10人\n\n比赛时间：2026年9月15日 - 2026年10月20日\n报名截止：2026年8月25日\n\n奖励设置：\n冠军队伍：奖金2000元 + 奖杯\n亚军队伍：奖金1000元\n季军队伍：奖金500元\n\n报名时间请携带队伍名单到体育部办公室报名，或在线报名。\n\n体育部\n2026年7月7日',
      sort: 1,
      status: 1
    },
    {
      noticeType: 2,
      title: '校园文化节精彩活动预告',
      content: '各位同学：\n\n2026年校园文化节将于9月举办，以下是精彩活动预告：\n\n活动列表：\n1. 创意市集 - 展示学生手工艺品、创意设计\n2. 音乐节 - 校园乐队现场演出\n3. 电影展映 - 经典影片露天放映\n4. 摄影大赛 - "最美校园"主题摄影比赛\n5. 知识竞赛 - 文史知识大比拼\n\n活动时间：2026年9月10日 - 2026年9月15日\n活动地点：校园文化广场\n\n欢迎各位同学积极参与，展示才艺，丰富校园生活！\n\n学生会\n2026年7月6日',
      sort: 2,
      status: 1
    },
    {
      noticeType: 2,
      title: '暑期社会实践项目招募通知',
      content: '各位同学：\n\n2026年暑期社会实践项目现已开放报名，多个项目等你来参与：\n\n项目列表：\n1. 乡村支教 - 前往山区小学进行为期两周的支教活动\n2. 社区服务 - 参与社区老人关怀、环境清洁等志愿服务\n3. 企业调研 - 深入本地企业进行产业调研\n4. 文化传承 - 参与非物质文化遗产保护项目\n\n报名要求：\n- 具有团队协作精神\n- 有责任心和爱心\n- 能全程参与项目\n\n报名截止：2026年7月15日\n项目补贴：完成项目可获得社会实践证明和部分补贴\n\n团委\n2026年7月5日',
      sort: 3,
      status: 1
    },

    // 优惠公告 (noticeType = 3)
    {
      noticeType: 3,
      title: '校园外卖平台暑期优惠活动',
      content: '各位同学：\n\n校园外卖平台推出暑期专属优惠！\n\n优惠活动：\n1. 新用户首单立减10元\n2. 满30减5，满50减10\n3. 每周三会员日 - 全场8折\n4. 配送费限时优惠 - 满20元免配送费\n\n活动时间：2026年7月10日 - 2026年8月31日\n参与方式：小程序下单自动享受优惠\n\n美食不用等，优惠享不停！\n\n校园外卖平台\n2026年7月7日',
      sort: 1,
      status: 1
    },
    {
      noticeType: 3,
      title: '快递代取服务暑期特惠',
      content: '各位同学：\n\n暑期快递代取服务推出限时特惠：\n\n优惠详情：\n1. 小件快递代取仅需3元/件\n2. 大件快递代取仅需5元/件\n3. 月度会员包 - 30元/月，无限次代取\n4. 团购优惠 - 5件以上享团购价\n\n活动时间：即日起至暑假结束\n服务范围：覆盖全校宿舍区\n\n炎炎夏日，快递送到宿舍门口！\n\n快递代取中心\n2026年7月6日',
      sort: 2,
      status: 1
    },
    {
      noticeType: 3,
      title: '二手市场暑假清仓大促',
      content: '各位同学：\n\n二手市场暑假清仓大促来了！\n\n促销活动：\n1. 教材专区 - 全场5折起\n2. 电子产品 - 笔记本、平板优惠出售\n3. 生活用品 - 电风扇、台灯热销\n4. 体育用品 - 篮球、羽毛球拍特惠\n\n特别推荐：\n毕业生特卖专区 - 离校前低价出售各类物品\n\n活动时间：2026年7月8日 - 2026年7月20日\n参与方式：小程序二手市场板块查看\n\n闲置物品换现金，省钱又环保！\n\n二手市场\n2026年7月5日',
      sort: 3,
      status: 1
    }
  ];

  for (const notice of notices) {
    await connection.execute(
      'INSERT INTO campus_notice (notice_type, title, content, sort, status, is_delete, create_time, update_time) VALUES (?, ?, ?, ?, ?, 0, NOW(), NOW())',
      [notice.noticeType, notice.title, notice.content, notice.sort, notice.status]
    );
    console.log('插入公告:', notice.title);
  }

  console.log('公告数据更新完成！');

  // 查询验证
  const [rows] = await connection.execute('SELECT id, notice_type, title, status FROM campus_notice ORDER BY notice_type, sort');
  console.log('\n当前公告列表:');
  rows.forEach(row => {
    const typeNames = { 1: '公告', 2: '活动', 3: '优惠' };
    console.log(`[${typeNames[row.notice_type]}] ${row.title} (ID: ${row.id})`);
  });

  await connection.end();
}

updateNoticeData().catch(console.error);