ALTER TABLE `user` MODIFY COLUMN `openid` varchar(64) DEFAULT NULL COMMENT '微信唯一openid';
ALTER TABLE `user` ADD COLUMN `password` varchar(64) DEFAULT NULL COMMENT '登录密码MD5加密';

UPDATE `user` SET `password` = '8f3706a48f96d8b75999f1d34997059a' WHERE `student_id` = '2024001001';
UPDATE `user` SET `password` = '2a97516c354b68848cdbd8f54a226a0a' WHERE `student_id` = '2024001002';

UPDATE `user` SET `student_id` = '2024001001', `password` = '8f3706a48f96d8b75999f1d34997059a' WHERE `openid` = 'student1_openid';
UPDATE `user` SET `student_id` = '2024001002', `password` = '2a97516c354b68848cdbd8f54a226a0a' WHERE `openid` = 'student2_openid';
