-- =============================================
-- 校园生活服务小程序 - MySQL 8.0 数据库建表脚本
-- 数据库名: campus_db
-- 字符集: utf8mb4
-- 事务隔离级别: RC
-- =============================================

CREATE DATABASE IF NOT EXISTS campus_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE campus_db;

-- =============================================
-- 1. 用户主表 user
-- =============================================
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户主键雪花ID',
  `openid` varchar(64) DEFAULT NULL COMMENT '微信唯一openid',
  `student_id` varchar(20) DEFAULT NULL COMMENT '学号，实名后非空',
  `real_name` varchar(20) DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号',
  `id_card` varchar(18) DEFAULT NULL COMMENT '身份证号（维修人员实名使用）',
  `password` varchar(64) DEFAULT NULL COMMENT '登录密码MD5_encrypt加密',
  `avatar` varchar(255) DEFAULT 'default_avatar.png' COMMENT '头像OSS地址',
  `nickname` varchar(50) NOT NULL COMMENT '微信昵称',
  `role` tinyint NOT NULL DEFAULT 1 COMMENT '1学生 2维修/配送员 3社团运营 4超级管理员',
  `dorm_build` varchar(30) DEFAULT NULL COMMENT '宿舍楼栋',
  `dorm_room` varchar(20) DEFAULT NULL COMMENT '宿舍房间',
  `credit_score` int NOT NULL DEFAULT 100 COMMENT '信用积分初始100',
  `balance` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '账户余额',
  `is_auth` tinyint NOT NULL DEFAULT 0 COMMENT '0未实名 1已实名',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除0正常1删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_openid` (`openid`),
  UNIQUE KEY `uk_student_id` (`student_id`),
  UNIQUE KEY `uk_id_card` (`id_card`),
  KEY `idx_role` (`role`),
  KEY `idx_credit_score` (`credit_score`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- =============================================
-- 2. 报修工单表 repair_order
-- =============================================
DROP TABLE IF EXISTS `repair_order`;
CREATE TABLE `repair_order` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '工单ID',
  `user_id` bigint NOT NULL COMMENT '报修学生id',
  `worker_id` bigint DEFAULT NULL COMMENT '维修员id',
  `fault_type` varchar(50) NOT NULL COMMENT '故障类型水电/门窗/空调等',
  `address` varchar(100) NOT NULL COMMENT '楼栋房间',
  `description` text NOT NULL COMMENT '故障描述',
  `images` json DEFAULT NULL COMMENT '图片url数组',
  `priority` tinyint NOT NULL DEFAULT 1 COMMENT '1普通 2紧急',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1待派单 2维修中 3已完成 4驳回 5取消',
  `evaluate_star` tinyint DEFAULT NULL COMMENT '1-5星评价',
  `evaluate_content` varchar(500) DEFAULT NULL COMMENT '评价内容',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_worker` (`worker_id`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`),
  CONSTRAINT `fk_repair_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_repair_worker` FOREIGN KEY (`worker_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='宿舍报修工单';

-- =============================================
-- 3. 二手商品表 second_product
-- =============================================
DROP TABLE IF EXISTS `second_product`;
CREATE TABLE `second_product` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '商品ID',
  `seller_id` bigint NOT NULL COMMENT '发布卖家id',
  `title` varchar(100) NOT NULL COMMENT '商品标题',
  `category` varchar(50) NOT NULL COMMENT '商品分类',
  `price` decimal(10,2) NOT NULL COMMENT '标价',
  `description` text DEFAULT NULL COMMENT '商品描述',
  `images` json NOT NULL COMMENT '多图oss地址数组',
  `allow_bargain` tinyint NOT NULL DEFAULT 1 COMMENT '0不议价1议价',
  `valid_day` int NOT NULL DEFAULT 15 COMMENT '商品有效期天数',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1待审核 2上架 3售出 4下架 5违规封禁',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_seller` (`seller_id`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`),
  KEY `idx_create_time` (`create_time`),
  CONSTRAINT `fk_product_seller` FOREIGN KEY (`seller_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='二手商品';

-- =============================================
-- 4. 二手担保订单表 second_order
-- =============================================
DROP TABLE IF EXISTS `second_order`;
CREATE TABLE `second_order` (
  `id` varchar(32) NOT NULL COMMENT '雪花唯一订单号',
  `product_id` bigint NOT NULL COMMENT '商品id',
  `buyer_id` bigint NOT NULL COMMENT '买家id',
  `seller_id` bigint NOT NULL COMMENT '卖家id',
  `pay_amount` decimal(10,2) NOT NULL COMMENT '实付金额',
  `platform_fee` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '平台佣金',
  `pay_status` tinyint NOT NULL DEFAULT 1 COMMENT '1待支付 2已支付担保 3已交付 4资金打款卖家 5全额退款',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `confirm_time` datetime DEFAULT NULL COMMENT '交付确认时间',
  `refund_time` datetime DEFAULT NULL COMMENT '退款时间',
  `wx_pay_no` varchar(64) DEFAULT NULL COMMENT '微信支付单号',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_buyer` (`buyer_id`),
  KEY `idx_seller` (`seller_id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_pay_status` (`pay_status`),
  CONSTRAINT `fk_order_buyer` FOREIGN KEY (`buyer_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_order_seller` FOREIGN KEY (`seller_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_order_product` FOREIGN KEY (`product_id`) REFERENCES `second_product`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='二手担保交易订单';

-- =============================================
-- 5. 跑腿外卖快递订单表 service_order
-- =============================================
DROP TABLE IF EXISTS `service_order`;
CREATE TABLE `service_order` (
  `id` varchar(32) NOT NULL COMMENT '订单号',
  `user_id` bigint NOT NULL COMMENT '下单用户',
  `worker_id` bigint DEFAULT NULL COMMENT '接单配送员',
  `service_type` tinyint NOT NULL COMMENT '1快递代取 2校园跑腿 3校园外卖',
  `origin_addr` varchar(100) DEFAULT NULL COMMENT '起点',
  `target_addr` varchar(100) NOT NULL COMMENT '送达地址',
  `order_content` text NOT NULL COMMENT '代办/点餐内容',
  `tip_fee` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '小费',
  `total_fee` decimal(10,2) NOT NULL COMMENT '订单总价',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1待付款 2待接单 3配送中 4已完成 5退款取消',
  `wx_pay_no` varchar(64) DEFAULT NULL COMMENT '微信支付单号',
  `accept_time` datetime DEFAULT NULL COMMENT '接单时间',
  `evaluate_star` tinyint DEFAULT NULL COMMENT '评价星级',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_worker` (`worker_id`),
  KEY `idx_service_type` (`service_type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_service_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_service_worker` FOREIGN KEY (`worker_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='跑腿外卖快递订单';

-- =============================================
-- 6. 失物招领表 lost_found
-- =============================================
DROP TABLE IF EXISTS `lost_found`;
CREATE TABLE `lost_found` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL COMMENT '发布用户id',
  `type` tinyint NOT NULL COMMENT '1寻物 2拾物',
  `goods_name` varchar(100) NOT NULL COMMENT '物品名称',
  `goods_type` varchar(50) NOT NULL COMMENT '物品分类',
  `location` varchar(100) NOT NULL COMMENT '丢失/拾取地点',
  `feature` text NOT NULL COMMENT '物品特征',
  `contact` varchar(30) NOT NULL COMMENT '联系方式',
  `images` json DEFAULT NULL COMMENT '图片数组',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1待匹配 2已认领归还 3过期归档',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_type` (`type`),
  KEY `idx_location` (`location`),
  KEY `idx_goods_type` (`goods_type`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_lost_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='失物招领';

-- =============================================
-- 7. 社区帖子表白墙表 community_post
-- =============================================
DROP TABLE IF EXISTS `community_post`;
CREATE TABLE `community_post` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '帖子ID',
  `user_id` bigint NOT NULL COMMENT '发布用户id',
  `post_type` tinyint NOT NULL COMMENT '1表白墙 2论坛帖子 3兼职发布',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `images` json DEFAULT NULL COMMENT '图片数组',
  `is_anon` tinyint NOT NULL DEFAULT 0 COMMENT '0实名1匿名',
  `audit_status` tinyint NOT NULL DEFAULT 1 COMMENT '1待审核 2已通过 3驳回',
  `like_num` int NOT NULL DEFAULT 0 COMMENT '点赞数',
  `comment_num` int NOT NULL DEFAULT 0 COMMENT '评论数',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_post_type` (`post_type`),
  KEY `idx_audit_status` (`audit_status`),
  KEY `idx_create_time` (`create_time`),
  CONSTRAINT `fk_post_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社区帖子表白墙';

-- =============================================
-- 8. 通用评论表 comment
-- =============================================
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `user_id` bigint NOT NULL COMMENT '评论人id',
  `target_type` tinyint NOT NULL COMMENT '1帖子 2商品 3工单评价',
  `target_id` bigint NOT NULL COMMENT '关联目标id',
  `parent_id` bigint DEFAULT NULL COMMENT '回复上级评论id',
  `content` varchar(500) NOT NULL COMMENT '评论内容',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_target` (`target_type`,`target_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_parent` (`parent_id`),
  CONSTRAINT `fk_comment_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通用评论';

-- =============================================
-- 9. 消息通知表 message
-- =============================================
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `user_id` bigint NOT NULL COMMENT '接收用户id',
  `msg_type` tinyint NOT NULL COMMENT '1系统通知 2工单进度 3社区互动 4订单状态 5匹配推送',
  `title` varchar(100) NOT NULL COMMENT '消息标题',
  `content` varchar(500) NOT NULL COMMENT '消息内容',
  `biz_type` varchar(50) DEFAULT NULL COMMENT '关联业务类型',
  `biz_id` bigint DEFAULT NULL COMMENT '关联业务id',
  `is_read` tinyint NOT NULL DEFAULT 0 COMMENT '0未读 1已读',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_is_read` (`is_read`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息通知';

-- =============================================
-- 10. 资金流水表 wallet_record
-- =============================================
DROP TABLE IF EXISTS `wallet_record`;
CREATE TABLE `wallet_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `biz_type` tinyint NOT NULL COMMENT '1充值 2消费 3提现 4退款 5配送收入 6交易收入 7平台佣金',
  `order_no` varchar(64) DEFAULT NULL COMMENT '关联订单号',
  `amount` decimal(10,2) NOT NULL COMMENT '变动金额',
  `balance_after` decimal(10,2) NOT NULL COMMENT '变动后余额',
  `change_type` tinyint NOT NULL COMMENT '1收入 2支出',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除（不支持删除）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_biz_type` (`biz_type`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资金流水';

-- =============================================
-- 11. 优惠券表 coupon
-- =============================================
DROP TABLE IF EXISTS `coupon`;
CREATE TABLE `coupon` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '优惠券ID',
  `name` varchar(100) NOT NULL COMMENT '优惠券名称',
  `coupon_type` tinyint NOT NULL COMMENT '1满减 2折扣',
  `min_amount` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '满减门槛金额',
  `discount_value` decimal(10,2) NOT NULL COMMENT '优惠金额/折扣率',
  `use_scope` tinyint NOT NULL DEFAULT 1 COMMENT '1全部 2外卖 3二手 4跑腿',
  `total_count` int NOT NULL COMMENT '发行总量',
  `used_count` int NOT NULL DEFAULT 0 COMMENT '已领取数量',
  `per_limit` int NOT NULL DEFAULT 1 COMMENT '每人限领数量',
  `valid_start` datetime NOT NULL COMMENT '有效期开始',
  `valid_end` datetime NOT NULL COMMENT '有效期结束',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_valid_end` (`valid_end`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券';

-- =============================================
-- 12. 用户优惠券关联表 user_coupon
-- =============================================
DROP TABLE IF EXISTS `user_coupon`;
CREATE TABLE `user_coupon` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `coupon_id` bigint NOT NULL COMMENT '优惠券id',
  `receive_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '领取时间',
  `use_time` datetime DEFAULT NULL COMMENT '使用时间',
  `order_no` varchar(64) DEFAULT NULL COMMENT '关联订单号',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1待使用 2已使用 3已过期',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_coupon` (`coupon_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_user_coupon_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_user_coupon_coupon` FOREIGN KEY (`coupon_id`) REFERENCES `coupon`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户优惠券';

-- =============================================
-- 13. 校园资讯公告表 campus_notice
-- =============================================
DROP TABLE IF EXISTS `campus_notice`;
CREATE TABLE `campus_notice` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_type` tinyint NOT NULL COMMENT '1校园公告 2活动 3优惠',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `content` text NOT NULL COMMENT '内容',
  `image` varchar(255) DEFAULT NULL COMMENT '图片',
  `link_url` varchar(255) DEFAULT NULL COMMENT '链接地址',
  `sort` int NOT NULL DEFAULT 0 COMMENT '排序',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0下架 1上架',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_notice_type` (`notice_type`),
  KEY `idx_status` (`status`),
  KEY `idx_sort` (`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='校园资讯公告';

-- =============================================
-- 14. 操作日志表 sys_log
-- =============================================
DROP TABLE IF EXISTS `sys_log`;
CREATE TABLE `sys_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '用户id',
  `user_type` tinyint DEFAULT NULL COMMENT '用户类型',
  `action` varchar(100) NOT NULL COMMENT '操作类型',
  `method` varchar(100) DEFAULT NULL COMMENT '请求方法',
  `url` varchar(255) DEFAULT NULL COMMENT '请求路径',
  `params` text COMMENT '请求参数',
  `ip` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `result` text COMMENT '操作结果',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志';

-- =============================================
-- 15. 系统配置表 sys_config
-- =============================================
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `config_key` varchar(100) NOT NULL COMMENT '配置键',
  `config_value` varchar(500) NOT NULL COMMENT '配置值',
  `config_name` varchar(100) NOT NULL COMMENT '配置名称',
  `config_type` tinyint NOT NULL DEFAULT 1 COMMENT '1系统 2业务 3第三方',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';

-- =============================================
-- 16. 社团表 club
-- =============================================
DROP TABLE IF EXISTS `club`;
CREATE TABLE `club` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '社团ID',
  `name` varchar(100) NOT NULL COMMENT '社团名称',
  `logo` varchar(255) DEFAULT NULL COMMENT '社团Logo',
  `intro` text COMMENT '社团简介',
  `leader_id` bigint NOT NULL COMMENT '社长用户id',
  `category` varchar(50) DEFAULT NULL COMMENT '分类',
  `audit_status` tinyint NOT NULL DEFAULT 1 COMMENT '1待审核 2已通过 3驳回',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
  `member_count` int NOT NULL DEFAULT 0 COMMENT '成员数量',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_leader` (`leader_id`),
  KEY `idx_audit_status` (`audit_status`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_club_leader` FOREIGN KEY (`leader_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社团';

-- =============================================
-- 17. 社团成员表 club_member
-- =============================================
DROP TABLE IF EXISTS `club_member`;
CREATE TABLE `club_member` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `club_id` bigint NOT NULL COMMENT '社团id',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `identity` tinyint NOT NULL DEFAULT 4 COMMENT '1社长 2副社长 3管理员 4成员',
  `join_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1正常 2退出',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_club` (`club_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_identity` (`identity`),
  CONSTRAINT `fk_member_club` FOREIGN KEY (`club_id`) REFERENCES `club`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_member_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='社团成员';

-- =============================================
-- 18. 活动表 activity
-- =============================================
DROP TABLE IF EXISTS `activity`;
CREATE TABLE `activity` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '活动ID',
  `club_id` bigint NOT NULL COMMENT '社团id',
  `name` varchar(100) NOT NULL COMMENT '活动名称',
  `poster` varchar(255) DEFAULT NULL COMMENT '活动海报',
  `location` varchar(100) NOT NULL COMMENT '活动地点',
  `start_time` datetime NOT NULL COMMENT '活动时间',
  `end_time` datetime NOT NULL COMMENT '活动结束时间',
  `enroll_deadline` datetime NOT NULL COMMENT '报名截止时间',
  `description` text COMMENT '活动描述',
  `max_people` int NOT NULL DEFAULT 0 COMMENT '人数上限',
  `enroll_count` int NOT NULL DEFAULT 0 COMMENT '已报名人数',
  `audit_status` tinyint NOT NULL DEFAULT 1 COMMENT '1待审核 2已通过 3驳回',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0禁用 1启用',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_club` (`club_id`),
  KEY `idx_audit_status` (`audit_status`),
  KEY `idx_status` (`status`),
  KEY `idx_start_time` (`start_time`),
  CONSTRAINT `fk_activity_club` FOREIGN KEY (`club_id`) REFERENCES `club`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动';

-- =============================================
-- 19. 活动报名表 activity_enroll
-- =============================================
DROP TABLE IF EXISTS `activity_enroll`;
CREATE TABLE `activity_enroll` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `activity_id` bigint NOT NULL COMMENT '活动id',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `enroll_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '报名时间',
  `checkin_status` tinyint NOT NULL DEFAULT 0 COMMENT '0未签到 1已签到',
  `checkin_time` datetime DEFAULT NULL COMMENT '签到时间',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1已报名 2已取消',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  PRIMARY KEY (`id`),
  KEY `idx_activity` (`activity_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_enroll_activity` FOREIGN KEY (`activity_id`) REFERENCES `activity`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_enroll_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='活动报名';

-- =============================================
-- 20. 课表 course_schedule
-- =============================================
DROP TABLE IF EXISTS `course_schedule`;
CREATE TABLE `course_schedule` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `student_id` varchar(20) NOT NULL COMMENT '学号',
  `course_name` varchar(100) NOT NULL COMMENT '课程名称',
  `teacher` varchar(50) DEFAULT NULL COMMENT '授课教师',
  `classroom` varchar(50) DEFAULT NULL COMMENT '上课教室',
  `week_day` tinyint NOT NULL COMMENT '星期几 1-7',
  `section_start` tinyint NOT NULL COMMENT '开始节次',
  `section_end` tinyint NOT NULL COMMENT '结束节次',
  `week_start` int NOT NULL DEFAULT 1 COMMENT '开始周',
  `week_end` int NOT NULL DEFAULT 18 COMMENT '结束周',
  `semester` varchar(20) NOT NULL COMMENT '学期 如2024-2025-1',
  `color` varchar(20) DEFAULT '#1890ff' COMMENT '课程颜色',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_semester` (`semester`),
  KEY `idx_week_day` (`week_day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课表';

-- =============================================
-- 21. 成绩表 score
-- =============================================
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `student_id` varchar(20) NOT NULL COMMENT '学号',
  `course_name` varchar(100) NOT NULL COMMENT '课程名称',
  `credit` decimal(3,1) NOT NULL COMMENT '学分',
  `score` decimal(5,2) DEFAULT NULL COMMENT '成绩',
  `grade_point` decimal(3,2) DEFAULT NULL COMMENT '绩点',
  `semester` varchar(20) NOT NULL COMMENT '学期',
  `exam_type` varchar(20) DEFAULT '正常考试' COMMENT '考试类型',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_semester` (`semester`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='成绩表';

-- =============================================
-- 22. 教室表 classroom
-- =============================================
DROP TABLE IF EXISTS `classroom`;
CREATE TABLE `classroom` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `building` varchar(50) NOT NULL COMMENT '教学楼',
  `room_no` varchar(20) NOT NULL COMMENT '教室号',
  `capacity` int NOT NULL DEFAULT 50 COMMENT '容纳人数',
  `classroom_type` varchar(20) DEFAULT '普通教室' COMMENT '教室类型',
  `equipment` varchar(255) DEFAULT NULL COMMENT '设备配置',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0停用 1启用',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_building` (`building`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教室表';

-- =============================================
-- 23. 教室使用表 classroom_usage
-- =============================================
DROP TABLE IF EXISTS `classroom_usage`;
CREATE TABLE `classroom_usage` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `classroom_id` bigint NOT NULL COMMENT '教室id',
  `course_name` varchar(100) DEFAULT NULL COMMENT '课程名称',
  `week_day` tinyint NOT NULL COMMENT '星期几 1-7',
  `section_start` tinyint NOT NULL COMMENT '开始节次',
  `section_end` tinyint NOT NULL COMMENT '结束节次',
  `week_start` int NOT NULL DEFAULT 1 COMMENT '开始周',
  `week_end` int NOT NULL DEFAULT 18 COMMENT '结束周',
  `semester` varchar(20) NOT NULL COMMENT '学期',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_classroom` (`classroom_id`),
  KEY `idx_week_day` (`week_day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教室使用';

-- =============================================
-- 24. 考试安排表 exam
-- =============================================
DROP TABLE IF EXISTS `exam`;
CREATE TABLE `exam` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `student_id` varchar(20) NOT NULL COMMENT '学号',
  `course_name` varchar(100) NOT NULL COMMENT '课程名称',
  `exam_type` varchar(20) DEFAULT '期末考试' COMMENT '考试类型',
  `exam_date` date NOT NULL COMMENT '考试日期',
  `start_time` time NOT NULL COMMENT '开始时间',
  `end_time` time NOT NULL COMMENT '结束时间',
  `classroom` varchar(50) NOT NULL COMMENT '考场',
  `seat_no` varchar(20) DEFAULT NULL COMMENT '座位号',
  `semester` varchar(20) NOT NULL COMMENT '学期',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_exam_date` (`exam_date`),
  KEY `idx_semester` (`semester`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='考试安排';

-- =============================================
-- 25. 图书表 library_book
-- =============================================
DROP TABLE IF EXISTS `library_book`;
CREATE TABLE `library_book` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `isbn` varchar(20) DEFAULT NULL COMMENT 'ISBN',
  `title` varchar(200) NOT NULL COMMENT '书名',
  `author` varchar(100) DEFAULT NULL COMMENT '作者',
  `publisher` varchar(100) DEFAULT NULL COMMENT '出版社',
  `publish_date` date DEFAULT NULL COMMENT '出版日期',
  `category` varchar(50) DEFAULT NULL COMMENT '分类',
  `location` varchar(50) DEFAULT NULL COMMENT '馆藏位置',
  `total_count` int NOT NULL DEFAULT 1 COMMENT '总数量',
  `available_count` int NOT NULL DEFAULT 1 COMMENT '可借数量',
  `cover` varchar(255) DEFAULT NULL COMMENT '封面图',
  `description` text COMMENT '简介',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0下架 1可借阅',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_title` (`title`),
  KEY `idx_author` (`author`),
  KEY `idx_isbn` (`isbn`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书';

-- =============================================
-- 26. 借书记录表 borrow_record
-- =============================================
DROP TABLE IF EXISTS `borrow_record`;
CREATE TABLE `borrow_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `book_id` bigint NOT NULL COMMENT '图书id',
  `borrow_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '借书时间',
  `due_time` datetime NOT NULL COMMENT '应还时间',
  `return_time` datetime DEFAULT NULL COMMENT '实际归还时间',
  `renew_count` int NOT NULL DEFAULT 0 COMMENT '续借次数',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1借阅中 2已归还 3已逾期',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_book` (`book_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_borrow_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_borrow_book` FOREIGN KEY (`book_id`) REFERENCES `library_book`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='借书记录';

-- =============================================
-- 27. 图书馆座位表 library_seat
-- =============================================
DROP TABLE IF EXISTS `library_seat`;
CREATE TABLE `library_seat` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `floor` int NOT NULL COMMENT '楼层',
  `area` varchar(50) DEFAULT NULL COMMENT '区域',
  `seat_no` varchar(20) NOT NULL COMMENT '座位号',
  `has_socket` tinyint NOT NULL DEFAULT 0 COMMENT '是否有插座',
  `has_window` tinyint NOT NULL DEFAULT 0 COMMENT '是否靠窗',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0维护中 1可预约',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_floor` (`floor`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书馆座位';

-- =============================================
-- 28. 座位预约表 seat_reservation
-- =============================================
DROP TABLE IF EXISTS `seat_reservation`;
CREATE TABLE `seat_reservation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `seat_id` bigint NOT NULL COMMENT '座位id',
  `reserve_date` date NOT NULL COMMENT '预约日期',
  `start_time` time NOT NULL COMMENT '开始时间',
  `end_time` time NOT NULL COMMENT '结束时间',
  `checkin_time` datetime DEFAULT NULL COMMENT '签到时间',
  `checkout_time` datetime DEFAULT NULL COMMENT '签退时间',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1已预约 2已签到 3已完成 4已取消 5违约',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_seat` (`seat_id`),
  KEY `idx_reserve_date` (`reserve_date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='座位预约';

-- =============================================
-- 28.1 图书预约表 book_reservation
-- =============================================
DROP TABLE IF EXISTS `book_reservation`;
CREATE TABLE `book_reservation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `book_id` bigint NOT NULL COMMENT '图书id',
  `reserve_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '预约时间',
  `expire_time` datetime DEFAULT NULL COMMENT '过期时间',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1预约中 2已借阅 3已取消 4已过期',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_book` (`book_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书预约';

-- =============================================
-- 28.2 教室预约表 classroom_reservation
-- =============================================
DROP TABLE IF EXISTS `classroom_reservation`;
CREATE TABLE `classroom_reservation` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL COMMENT '申请人id',
  `classroom_id` bigint NOT NULL COMMENT '教室id',
  `reserve_date` date NOT NULL COMMENT '预约日期',
  `section_start` tinyint NOT NULL COMMENT '开始节次',
  `section_end` tinyint NOT NULL COMMENT '结束节次',
  `purpose` varchar(200) DEFAULT NULL COMMENT '使用目的',
  `people_count` int DEFAULT 0 COMMENT '使用人数',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '1待审核 2已通过 3已驳回 4已取消 5已完成',
  `audit_remark` varchar(500) DEFAULT NULL COMMENT '审核备注',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_classroom` (`classroom_id`),
  KEY `idx_reserve_date` (`reserve_date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教室预约';

-- =============================================
-- 29. 自习打卡表 study_checkin
-- =============================================
DROP TABLE IF EXISTS `study_checkin`;
CREATE TABLE `study_checkin` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `checkin_date` date NOT NULL COMMENT '打卡日期',
  `checkin_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '打卡时间',
  `study_duration` int DEFAULT 0 COMMENT '学习时长（分钟）',
  `location` varchar(100) DEFAULT NULL COMMENT '学习地点',
  `note` varchar(500) DEFAULT NULL COMMENT '备注',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_date` (`user_id`, `checkin_date`),
  KEY `idx_user` (`user_id`),
  KEY `idx_checkin_date` (`checkin_date`),
  CONSTRAINT `fk_study_user` FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='自习打卡';

-- =============================================
-- 30. 四六级成绩表 cet_score
-- =============================================
DROP TABLE IF EXISTS `cet_score`;
CREATE TABLE `cet_score` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `student_id` varchar(20) NOT NULL COMMENT '学号',
  `real_name` varchar(20) NOT NULL COMMENT '姓名',
  `cet_type` varchar(10) NOT NULL COMMENT '四级/六级',
  `exam_date` date NOT NULL COMMENT '考试日期',
  `total_score` int NOT NULL COMMENT '总分',
  `listen_score` int DEFAULT NULL COMMENT '听力',
  `read_score` int DEFAULT NULL COMMENT '阅读',
  `write_score` int DEFAULT NULL COMMENT '写作翻译',
  `is_pass` tinyint NOT NULL COMMENT '是否通过',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_student_id` (`student_id`),
  KEY `idx_exam_date` (`exam_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='四六级成绩';

-- =============================================
-- 31. 考证资讯表 cert_info
-- =============================================
DROP TABLE IF EXISTS `cert_info`;
CREATE TABLE `cert_info` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `cert_name` varchar(100) NOT NULL COMMENT '证书名称',
  `cert_type` varchar(50) NOT NULL COMMENT '证书分类',
  `organization` varchar(100) DEFAULT NULL COMMENT '发证机构',
  `description` text COMMENT '证书简介',
  `exam_time` varchar(100) DEFAULT NULL COMMENT '考试时间',
  `signup_time` varchar(100) DEFAULT NULL COMMENT '报名时间',
  `exam_fee` varchar(50) DEFAULT NULL COMMENT '考试费用',
  `apply_condition` text COMMENT '报考条件',
  `image` varchar(255) DEFAULT NULL COMMENT '封面图',
  `status` tinyint NOT NULL DEFAULT 1 COMMENT '0下架 1发布',
  `sort` int NOT NULL DEFAULT 0 COMMENT '排序',
  `is_delete` tinyint NOT NULL DEFAULT 0 COMMENT '逻辑删除',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_cert_type` (`cert_type`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='考证资讯';

-- =============================================
-- 初始化测试数据
-- =============================================

-- 插入超级管理员
INSERT INTO `user` (`openid`, `nickname`, `role`, `is_auth`, `credit_score`) VALUES
('admin_openid', '系统管理员', 4, 1, 100);

-- 插入测试维修员
INSERT INTO `user` (`openid`, `nickname`, `role`, `is_auth`, `credit_score`) VALUES
('worker1_openid', '维修员小王', 2, 1, 100),
('worker2_openid', '配送员小李', 2, 1, 100);

-- 插入测试学生
INSERT INTO `user` (`openid`, `nickname`, `role`, `is_auth`, `credit_score`) VALUES
('student1_openid', '学生小明', 1, 1, 100),
('student2_openid', '学生小红', 1, 1, 95);

-- 插入系统配置
INSERT INTO `sys_config` (`config_key`, `config_value`, `config_name`, `config_type`) VALUES
('platform_fee_rate', '0.02', '平台佣金比例', 2),
('order_cancel_minutes', '15', '订单取消超时时间(分钟)', 2),
('product_expire_days', '15', '二手商品有效期(天)', 2),
('lostfound_expire_days', '7', '失物招领有效期(天)', 2);

-- 插入校园公告
INSERT INTO `campus_notice` (`notice_type`, `title`, `content`, `status`, `sort`) VALUES
(1, '欢迎使用校园生活服务小程序', '欢迎各位同学使用校园生活服务小程序，这里提供报修、快递代取、二手交易等便民服务！', 1, 1),
(2, '校园马拉松活动报名', '2024年校园马拉松活动开始报名，名额有限，先到先得！', 1, 2),
(3, '新用户满减优惠', '新用户首单满10元减5元，快来体验吧！', 1, 3);

-- 更新学生用户信息，添加学号
UPDATE `user` SET `student_id` = '2024001001', `real_name` = '小明', `dorm_build` = '3号楼', `dorm_room` = '502' WHERE `openid` = 'student1_openid';
UPDATE `user` SET `student_id` = '2024001002', `real_name` = '小红', `dorm_build` = '4号楼', `dorm_room` = '301' WHERE `openid` = 'student2_openid';

-- 给测试用户设置密码（6位，包含数字和英文）
-- a12345 -> af8f9dffa5d420fbc249141645b962ee
-- b12345 -> 7a8a7b9d7b9c7b9d7b9c7b9d7b9c7b9c
UPDATE `user` SET `password` = 'af8f9dffa5d420fbc249141645b962ee' WHERE `openid` = 'student1_openid';
UPDATE `user` SET `password` = MD5('b12345') WHERE `openid` = 'student2_openid';
UPDATE `user` SET `password` = 'af8f9dffa5d420fbc249141645b962ee' WHERE `openid` IN ('worker1_openid', 'worker2_openid', 'operator1_openid');

-- 插入课表数据
INSERT INTO `course_schedule` (`student_id`, `course_name`, `teacher`, `classroom`, `week_day`, `section_start`, `section_end`, `week_start`, `week_end`, `semester`, `color`) VALUES
('2024001001', '软件项目管理', '刘教授', '教3-301', 1, 1, 2, 1, 18, '2024-2025-1', '#1890ff'),
('2024001001', '移动互联技术与应用', '王教授', '实验楼-302', 1, 3, 4, 1, 18, '2024-2025-1', '#52c41a'),
('2024001001', '数据结构与算法', '张老师', '教2-201', 2, 1, 2, 1, 18, '2024-2025-1', '#faad14'),
('2024001001', '操作系统原理', '李教授', '教2-202', 2, 5, 6, 1, 18, '2024-2025-1', '#f5222d'),
('2024001001', '计算机网络', '陈教授', '教3-201', 3, 1, 2, 1, 18, '2024-2025-1', '#722ed1'),
('2024001001', '数据库原理与应用', '赵老师', '实验楼-301', 3, 5, 6, 1, 18, '2024-2025-1', '#13c2c2'),
('2024001001', 'Java程序设计', '周老师', '实验楼-203', 4, 1, 2, 1, 18, '2024-2025-1', '#eb2f96'),
('2024001001', '软件工程', '吴教授', '教3-302', 4, 5, 6, 1, 18, '2024-2025-1', '#fa8c16'),
('2024001001', '大学英语', '孙老师', '教1-201', 5, 1, 2, 1, 18, '2024-2025-1', '#ffc53d'),
('2024001001', '体育', '郑老师', '体育馆-1', 5, 5, 6, 1, 18, '2024-2025-1', '#64b5f6'),
('2024001001', '人工智能导论', '黄教授', '教3-401', 1, 5, 6, 1, 18, '2024-2025-1', '#ce93d8'),
('2024001001', '机器学习', '林教授', '实验楼-401', 3, 7, 8, 1, 18, '2024-2025-1', '#81c784'),
('2024001002', '软件项目管理', '刘教授', '教3-301', 1, 1, 2, 1, 18, '2024-2025-1', '#1890ff'),
('2024001002', '移动互联技术与应用', '王教授', '实验楼-302', 1, 3, 4, 1, 18, '2024-2025-1', '#52c41a'),
('2024001002', '数据结构与算法', '张老师', '教2-201', 2, 1, 2, 1, 18, '2024-2025-1', '#faad14'),
('2024001002', '操作系统原理', '李教授', '教2-202', 2, 5, 6, 1, 18, '2024-2025-1', '#f5222d'),
('2024001002', '计算机网络', '陈教授', '教3-201', 3, 1, 2, 1, 18, '2024-2025-1', '#722ed1'),
('2024001002', '数据库原理与应用', '赵老师', '实验楼-301', 3, 5, 6, 1, 18, '2024-2025-1', '#13c2c2'),
('2024001002', 'Python编程', '钱老师', '实验楼-204', 4, 1, 2, 1, 18, '2024-2025-1', '#eb2f96'),
('2024001002', '软件工程', '吴教授', '教3-302', 4, 5, 6, 1, 18, '2024-2025-1', '#fa8c16'),
('2024001002', '大学英语', '孙老师', '教1-201', 5, 1, 2, 1, 18, '2024-2025-1', '#ffc53d'),
('2024001002', '体育', '郑老师', '体育馆-2', 5, 5, 6, 1, 18, '2024-2025-1', '#64b5f6');

-- 插入成绩数据
INSERT INTO `score` (`student_id`, `course_name`, `credit`, `score`, `grade_point`, `semester`, `exam_type`) VALUES
('2024001001', '高等数学(上)', 5.0, 85.5, 3.5, '2023-2024-2', '正常考试'),
('2024001001', '大学英语(一)', 4.0, 78.0, 3.0, '2023-2024-2', '正常考试'),
('2024001001', '计算机基础', 3.0, 92.0, 4.0, '2023-2024-2', '正常考试'),
('2024001001', '大学物理(上)', 4.0, 72.5, 2.5, '2023-2024-2', '正常考试'),
('2024001001', '思想道德与法治', 3.0, 88.0, 3.8, '2023-2024-2', '正常考试'),
('2024001001', '体育(一)', 2.0, 90.0, 4.0, '2023-2024-2', '正常考试'),
('2024001002', '高等数学(上)', 5.0, 90.0, 4.0, '2023-2024-2', '正常考试'),
('2024001002', '大学英语(一)', 4.0, 85.0, 3.5, '2023-2024-2', '正常考试'),
('2024001002', '计算机基础', 3.0, 88.0, 3.8, '2023-2024-2', '正常考试');

-- 插入教室数据
INSERT INTO `classroom` (`building`, `room_no`, `capacity`, `classroom_type`, `equipment`, `status`) VALUES
('教1楼', '101', 120, '普通教室', '投影仪、音响、空调', 1),
('教1楼', '102', 120, '普通教室', '投影仪、音响、空调', 1),
('教1楼', '201', 80, '多媒体教室', '投影仪、电脑、音响', 1),
('教1楼', '301', 80, '多媒体教室', '投影仪、电脑、音响', 1),
('教2楼', '101', 100, '普通教室', '投影仪、空调', 1),
('教2楼', '201', 80, '多媒体教室', '投影仪、电脑、音响', 1),
('教2楼', '202', 80, '多媒体教室', '投影仪、电脑、音响', 1),
('教2楼', '301', 60, '计算机教室', '电脑60台、投影仪', 1),
('教3楼', '201', 80, '多媒体教室', '投影仪、电脑、音响', 1),
('教3楼', '301', 60, '计算机教室', '电脑60台、投影仪', 1),
('教3楼', '302', 60, '计算机教室', '电脑60台、投影仪', 1),
('教3楼', '401', 100, '多媒体教室', '投影仪、电脑、音响', 1),
('实验楼', '201', 50, '实验室', '实验设备、投影仪', 1),
('实验楼', '203', 50, '计算机实验室', '电脑50台、服务器', 1),
('实验楼', '204', 50, '计算机实验室', '电脑50台、服务器', 1),
('实验楼', '301', 40, '数据库实验室', '数据库服务器、电脑', 1),
('实验楼', '302', 40, '移动开发实验室', '手机、平板、电脑', 1),
('实验楼', '401', 50, 'AI实验室', 'GPU服务器、电脑', 1),
('体育馆', '1', 200, '体育馆', '体育器材', 1),
('体育馆', '2', 200, '体育馆', '体育器材', 1);

-- 插入教室使用数据
INSERT INTO `classroom_usage` (`classroom_id`, `course_name`, `week_day`, `section_start`, `section_end`, `week_start`, `week_end`, `semester`) VALUES
(3, '大学英语', 5, 1, 2, 1, 18, '2024-2025-1'),
(6, '数据结构与算法', 2, 1, 2, 1, 18, '2024-2025-1'),
(7, '操作系统原理', 2, 5, 6, 1, 18, '2024-2025-1'),
(9, '计算机网络', 3, 1, 2, 1, 18, '2024-2025-1'),
(10, '软件项目管理', 1, 1, 2, 1, 18, '2024-2025-1'),
(10, '人工智能导论', 1, 5, 6, 1, 18, '2024-2025-1'),
(11, '软件工程', 4, 5, 6, 1, 18, '2024-2025-1'),
(12, '机器学习', 3, 7, 8, 1, 18, '2024-2025-1'),
(14, 'Java程序设计', 4, 1, 2, 1, 18, '2024-2025-1'),
(15, 'Python编程', 4, 1, 2, 1, 18, '2024-2025-1'),
(16, '数据库原理与应用', 3, 5, 6, 1, 18, '2024-2025-1'),
(17, '移动互联技术与应用', 1, 3, 4, 1, 18, '2024-2025-1'),
(18, '体育', 5, 5, 6, 1, 18, '2024-2025-1');

-- 插入考试安排数据
INSERT INTO `exam` (`student_id`, `course_name`, `exam_type`, `exam_date`, `start_time`, `end_time`, `classroom`, `seat_no`, `semester`) VALUES
('2024001001', '软件项目管理', '期末考试', '2025-01-10', '08:30:00', '10:30:00', '教3-301', 'A01', '2024-2025-1'),
('2024001001', '移动互联技术与应用', '期末考试', '2025-01-11', '08:30:00', '10:30:00', '实验楼-302', 'B05', '2024-2025-1'),
('2024001001', '数据结构与算法', '期末考试', '2025-01-12', '14:00:00', '16:00:00', '教2-201', 'C12', '2024-2025-1'),
('2024001001', '操作系统原理', '期末考试', '2025-01-13', '08:30:00', '10:30:00', '教2-202', 'A08', '2024-2025-1'),
('2024001001', '计算机网络', '期末考试', '2025-01-14', '14:00:00', '16:00:00', '教3-201', 'D03', '2024-2025-1'),
('2024001001', '数据库原理与应用', '期末考试', '2025-01-15', '08:30:00', '10:30:00', '实验楼-301', 'E20', '2024-2025-1'),
('2024001001', 'Java程序设计', '期末考试', '2025-01-16', '14:00:00', '16:00:00', '实验楼-203', 'F15', '2024-2025-1'),
('2024001001', '软件工程', '期末考试', '2025-01-17', '08:30:00', '10:30:00', '教3-302', 'G01', '2024-2025-1'),
('2024001001', '大学英语', '期末考试', '2025-01-18', '08:30:00', '10:30:00', '教1-201', 'H05', '2024-2025-1'),
('2024001001', '人工智能导论', '期末考试', '2025-01-19', '14:00:00', '16:00:00', '教3-401', 'I10', '2024-2025-1'),
('2024001002', '软件项目管理', '期末考试', '2025-01-10', '08:30:00', '10:30:00', '教3-301', 'A02', '2024-2025-1'),
('2024001002', '移动互联技术与应用', '期末考试', '2025-01-11', '08:30:00', '10:30:00', '实验楼-302', 'B06', '2024-2025-1'),
('2024001002', '数据结构与算法', '期末考试', '2025-01-12', '14:00:00', '16:00:00', '教2-201', 'C13', '2024-2025-1'),
('2024001002', '操作系统原理', '期末考试', '2025-01-13', '08:30:00', '10:30:00', '教2-202', 'A09', '2024-2025-1'),
('2024001002', '计算机网络', '期末考试', '2025-01-14', '14:00:00', '16:00:00', '教3-201', 'D04', '2024-2025-1'),
('2024001002', 'Python编程', '期末考试', '2025-01-16', '14:00:00', '16:00:00', '实验楼-204', 'F16', '2024-2025-1'),
('2024001002', '大学英语', '期末考试', '2025-01-18', '08:30:00', '10:30:00', '教1-201', 'H06', '2024-2025-1');

-- 插入图书数据
INSERT INTO `library_book` (`isbn`, `title`, `author`, `publisher`, `category`, `location`, `total_count`, `available_count`, `description`, `status`) VALUES
('9787040396638', '高等数学(第七版)', '同济大学数学系', '高等教育出版社', '数学', 'A区-1排-3列', 10, 5, '本书是同济大学数学系编《高等数学》的第七版，在第六版的基础上进行了全面修订。', 1),
('9787040388671', '线性代数(第六版)', '同济大学数学系', '高等教育出版社', '数学', 'A区-1排-5列', 8, 3, '本书是同济大学数学系编《线性代数》的第六版，在第五版的基础上进行了全面修订。', 1),
('9787040238969', '概率论与数理统计(第四版)', '盛骤', '高等教育出版社', '数学', 'A区-2排-1列', 12, 6, '本书是概率论与数理统计课程的经典教材，内容全面，例题丰富。', 1),
('9787302423287', 'C语言程序设计', '谭浩强', '清华大学出版社', '计算机', 'B区-2排-1列', 15, 8, '本书是学习C语言程序设计的入门教材。', 1),
('9787111544937', '深入理解计算机系统', 'Randal E. Bryant', '机械工业出版社', '计算机', 'B区-3排-2列', 5, 2, '本书从程序员的视角详细阐述计算机系统的本质概念。', 1),
('9787111213826', '算法导论(第三版)', 'Thomas H. Cormen', '机械工业出版社', '计算机', 'B区-1排-1列', 6, 3, '全面覆盖算法理论与实现，是计算机专业的经典教材。', 1),
('9787115428028', 'Java编程思想(第四版)', 'Bruce Eckel', '人民邮电出版社', '计算机', 'B区-4排-3列', 10, 4, 'Java学习的经典著作，深入浅出地讲解Java语言特性。', 1),
('9787302533115', 'Python编程从入门到实践', 'Eric Matthes', '清华大学出版社', '计算机', 'B区-5排-1列', 12, 7, 'Python入门经典教材，适合零基础学习者。', 1),
('9787111407010', '数据结构与算法分析', 'Mark Allen Weiss', '机械工业出版社', '计算机', 'B区-2排-5列', 8, 4, '系统讲解数据结构与算法分析的经典教材。', 1),
('9787020002207', '红楼梦', '曹雪芹', '人民文学出版社', '文学', 'C区-1排-1列', 20, 12, '中国古典四大名著之一。', 1),
('9787020008735', '三国演义', '罗贯中', '人民文学出版社', '文学', 'C区-1排-2列', 18, 10, '中国古典四大名著之一。', 1),
('9787020002214', '水浒传', '施耐庵', '人民文学出版社', '文学', 'C区-1排-3列', 15, 8, '中国古典四大名著之一。', 1),
('9787020002221', '西游记', '吴承恩', '人民文学出版社', '文学', 'C区-1排-4列', 16, 9, '中国古典四大名著之一。', 1),
('9787544291170', '百年孤独', '加西亚·马尔克斯', '南海出版公司', '文学', 'C区-2排-5列', 6, 3, '魔幻现实主义文学的代表作。', 1),
('9787513564823', '新概念英语3', 'L.G.Alexander', '外语教学与研究出版社', '英语', 'D区-1排-1列', 12, 6, '新概念英语第三册，培养技能。', 1),
('9787513563536', '新概念英语4', 'L.G.Alexander', '外语教学与研究出版社', '英语', 'D区-1排-2列', 10, 5, '新概念英语第四册，流利英语。', 1),
('9787100089746', '牛津高阶英汉双解词典(第8版)', '霍恩比', '商务印书馆', '英语', 'D区-2排-1列', 8, 4, '权威英语学习工具书。', 1),
('9787301232316', '经济学原理', '曼昆', '北京大学出版社', '经济', 'E区-1排-1列', 8, 4, '经济学入门经典教材。', 1),
('9787300189994', '管理学(第11版)', '罗宾斯', '中国人民大学出版社', '管理', 'F区-1排-1列', 10, 5, '管理学经典教材，全面系统。', 1),
('9787040311624', '马克思主义基本原理概论', '本书编写组', '高等教育出版社', '政治', 'G区-1排-1列', 20, 15, '高等学校思想政治理论课教材。', 1),
('9787040377309', '中国近现代史纲要', '本书编写组', '高等教育出版社', '历史', 'H区-1排-1列', 15, 10, '高等学校思想政治理论课教材。', 1),
('9787117266628', '大学物理(第三版)', '张三慧', '清华大学出版社', '物理', 'I区-1排-1列', 12, 6, '大学物理课程教材。', 1),
('9787040297317', '普通化学原理(第四版)', '华彤文', '高等教育出版社', '化学', 'J区-1排-1列', 8, 4, '化学入门经典教材。', 1),
('9787544270878', '小王子', '圣埃克苏佩里', '人民文学出版社', '文学', 'C区-3排-1列', 10, 8, '世界经典童话，温暖治愈。', 1),
('9787532754688', '活着', '余华', '作家出版社', '文学', 'C区-3排-3列', 12, 7, '余华代表作，讲述一个人和他的命运之间的友情。', 1),
('9787530212783', '平凡的世界', '路遥', '北京十月文艺出版社', '文学', 'C区-4排-1列', 15, 9, '路遥代表作，茅盾文学奖获奖作品。', 1);

-- 插入借书记录
INSERT INTO `borrow_record` (`user_id`, `book_id`, `borrow_time`, `due_time`, `status`, `renew_count`) VALUES
(4, 1, '2025-06-01 10:00:00', '2025-07-01 10:00:00', 1, 0),
(4, 3, '2025-06-10 14:30:00', '2025-07-10 14:30:00', 1, 0),
(4, 5, '2025-05-01 09:00:00', '2025-06-01 09:00:00', 2, 0),
(5, 2, '2025-06-05 11:00:00', '2025-07-05 11:00:00', 1, 0);

-- 更新归还时间
UPDATE `borrow_record` SET `return_time` = '2025-05-28 15:00:00' WHERE `id` = 3;

-- 插入图书馆座位
INSERT INTO `library_seat` (`floor`, `area`, `seat_no`, `has_socket`, `has_window`, `status`) VALUES
(1, 'A区', 'A001', 1, 0, 1),
(1, 'A区', 'A002', 1, 1, 1),
(1, 'A区', 'A003', 0, 0, 1),
(1, 'B区', 'B001', 1, 1, 1),
(1, 'B区', 'B002', 1, 0, 1),
(2, 'A区', 'A001', 1, 1, 1),
(2, 'A区', 'A002', 1, 0, 1),
(2, 'B区', 'B001', 0, 1, 1),
(3, '自习区', 'Z001', 1, 1, 1),
(3, '自习区', 'Z002', 1, 1, 1);

-- 插入自习打卡数据
INSERT INTO `study_checkin` (`user_id`, `checkin_date`, `checkin_time`, `study_duration`, `location`, `note`) VALUES
(3, '2025-01-08', '2025-01-08 08:30:00', 180, '图书馆三楼', '复习高等数学'),
(3, '2025-01-09', '2025-01-09 09:00:00', 240, '图书馆二楼', '准备英语考试'),
(3, '2025-01-10', '2025-01-10 10:00:00', 120, '教1-101', '自习');

-- 插入四六级成绩
INSERT INTO `cet_score` (`student_id`, `real_name`, `cet_type`, `exam_date`, `total_score`, `listen_score`, `read_score`, `write_score`, `is_pass`) VALUES
('2024001001', '小明', '四级', '2024-06-15', 520, 180, 190, 150, 1),
('2024001002', '小红', '四级', '2024-06-15', 580, 200, 210, 170, 1),
('2024001002', '小红', '六级', '2024-12-14', 505, 170, 185, 150, 1);

-- 插入考证资讯
INSERT INTO `cert_info` (`cert_name`, `cert_type`, `organization`, `description`, `exam_time`, `signup_time`, `exam_fee`, `apply_condition`, `status`, `sort`) VALUES
('大学英语四级', '语言类', '教育部考试中心', '大学英语四级考试，由国家教育部高等教育司主持的全国性英语考试。', '每年6月、12月', '每年3月、9月', '30元', '全日制普通高等院校本科、专科在校生', 1, 1),
('大学英语六级', '语言类', '教育部考试中心', '大学英语六级考试，是国家统一出题的，统一收费，统一组织考试。', '每年6月、12月', '每年3月、9月', '30元', '全日制普通高等院校本科、专科在校生且四级已过', 1, 2),
('计算机二级', '计算机类', '教育部考试中心', '全国计算机等级考试，是经原国家教育委员会批准，由教育部考试中心主办。', '每年3月、9月', '每年1月、7月', '80元', '面向社会，用于考查应试人员计算机应用知识与技能', 1, 3),
('教师资格证', '职业资格', '教育部', '教师资格证是教育行业从业教师的许可证。', '每年3月、10月', '每年1月、9月', '60元/科', '大专及以上学历', 1, 4),
('普通话水平测试', '语言类', '国家语委', '普通话水平测试是对应试人掌握和运用普通话所达到的规范程度的测查和评定。', '各地时间不同', '各地时间不同', '50元', '全社会均可报名', 1, 5),
('注册会计师', '财经类', '中国注册会计师协会', '注册会计师，是指通过注册会计师执业资格考试并取得注册会计师证书在会计师事务所执业的人员。', '每年8月', '每年4月', '80元/科', '高等专科以上学校毕业学历', 1, 6);

-- =============================================
-- 定时任务配置（需要在SpringBoot中配置）
-- =============================================
-- 1. 订单超时自动关闭：每分钟执行
-- 2. 二手商品过期下架：每天凌晨执行
-- 3. 失物招领过期归档：每天凌晨执行
-- 4. 积分每日结算：每天凌晨执行
-- 5. 消息定时推送：每小时执行
