-- =============================================
-- 更新脚本 v3：支持学生和维修人员角色区分、接单超时处理
-- =============================================

USE campus_db;

-- 1. 用户表添加身份证号字段
ALTER TABLE `user`
    ADD COLUMN `id_card` VARCHAR(18) DEFAULT NULL COMMENT '身份证号（维修人员实名使用）' AFTER `phone`,
    ADD UNIQUE KEY `uk_id_card` (`id_card`);

-- 2. 服务订单表添加接单时间字段
ALTER TABLE `service_order`
    ADD COLUMN `accept_time` DATETIME DEFAULT NULL COMMENT '接单时间' AFTER `wx_pay_no`;
