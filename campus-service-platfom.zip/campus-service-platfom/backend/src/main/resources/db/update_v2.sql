-- 为失物招领表添加点赞和评论字段
ALTER TABLE `lost_found` ADD COLUMN IF NOT EXISTS `like_num` INT NOT NULL DEFAULT 0 COMMENT '点赞数' AFTER `status`;
ALTER TABLE `lost_found` ADD COLUMN IF NOT EXISTS `comment_num` INT NOT NULL DEFAULT 0 COMMENT '评论数' AFTER `like_num`;

-- 为活动报名表添加签退字段
ALTER TABLE `activity_enroll` ADD COLUMN IF NOT EXISTS `checkout_status` TINYINT NOT NULL DEFAULT 0 COMMENT '0未签退 1已签退' AFTER `checkin_time`;
ALTER TABLE `activity_enroll` ADD COLUMN IF NOT EXISTS `checkout_time` DATETIME DEFAULT NULL COMMENT '签退时间' AFTER `checkout_status`;
