package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.Activity;
import com.campus.service.entity.ActivityEnroll;
import com.campus.service.mapper.ActivityEnrollMapper;
import com.campus.service.mapper.ActivityMapper;
import com.campus.service.service.ActivityEnrollService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 校园活动报名服务实现类。
 * <p>
 * 负责学生活动报名的完整业务处理，包括：
 * <ul>
 *     <li>学生报名、取消报名；</li>
 *     <li>活动签到、签退及积分奖励；</li>
 *     <li>批量签到、批量签退；</li>
 *     <li>查询个人报名记录、活动报名名单、签到统计等。</li>
 * </ul>
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ActivityEnrollServiceImpl extends ServiceImpl<ActivityEnrollMapper, ActivityEnroll> implements ActivityEnrollService {

    /**
     * 活动数据访问对象，用于查询和更新 activity 表。
     */
    private final ActivityMapper activityMapper;

    /**
     * 用户服务，用于签退后给用户发放信用/积分奖励。
     */
    private final UserService userService;

    /**
     * 学生报名参加指定活动。
     * <p>
     * 报名前会校验活动是否存在、是否通过审核、是否在报名时间内、是否还有名额；
     * 如果学生之前取消过报名，则恢复原有报名记录；否则新增一条报名记录。
     * 报名成功后活动已报名人数 +1。
     * </p>
     *
     * @param userId     报名学生用户ID
     * @param activityId 目标活动ID
     * @return 报名成功后的 ActivityEnroll 报名记录
     */
    @Override
    @Transactional
    public ActivityEnroll enroll(Long userId, Long activityId) {
        // 1. 检查活动是否存在且可报名
        // 根据 activityId 从 activity 表查询活动基本信息
        Activity activity = activityMapper.selectById(activityId);
        // 如果活动不存在，提示前端“活动不存在”
        if (activity == null) {
            throw new BusinessException("活动不存在");
        }
        // 如果活动审核状态不是已通过（2 表示通过），禁止报名
        if (activity.getAuditStatus() != 2) {
            throw new BusinessException("活动未通过审核，无法报名");
        }
        // 如果活动状态不是启用（1 表示启用），说明活动已被禁用，禁止报名
        if (activity.getStatus() != 1) {
            throw new BusinessException("活动已禁用，无法报名");
        }
        // 检查报名截止时间：如果当前时间已经超过报名截止时间，则不允许报名
        if (activity.getEnrollDeadline() != null && LocalDateTime.now().isAfter(activity.getEnrollDeadline())) {
            throw new BusinessException("报名已截止");
        }
        // 检查人数限制：maxPeople 大于 0 表示有人数上限
        if (activity.getMaxPeople() > 0) {
            // 统计 activity_enroll 表中该活动状态为正常的已报名人数
            long enrolledCount = this.count(new LambdaQueryWrapper<ActivityEnroll>()
                    // 查询同一活动的报名记录
                    .eq(ActivityEnroll::getActivityId, activityId)
                    // 只统计状态为正常报名的记录（status=1）
                    .eq(ActivityEnroll::getStatus, 1));
            // 如果已报名人数大于等于最大人数，说明名额已满
            if (enrolledCount >= activity.getMaxPeople()) {
                throw new BusinessException("活动名额已满");
            }
        }

        // 2. 检查是否已报名或曾经报名过
        // 查询 activity_enroll 表，看该用户对该活动是否已有记录
        ActivityEnroll existing = this.checkUserEnrolled(userId, activityId);
        if (existing != null) {
            // 如果记录状态为 1，说明当前正在报名中，不允许重复报名
            if (existing.getStatus() == 1) {
                throw new BusinessException("您已报名该活动");
            } else {
                // 之前取消过报名，现在重新报名：恢复报名状态并清空签到签退时间
                // 将报名状态恢复为正常报名（1）
                existing.setStatus(1);
                // 更新报名时间为当前时间
                existing.setEnrollTime(LocalDateTime.now());
                // 重置签到状态为未签到（0）
                existing.setCheckinStatus(0);
                // 清空之前的签到时间
                existing.setCheckinTime(null);
                // 重置签退状态为未签退（0）
                existing.setCheckoutStatus(0);
                // 清空之前的签退时间
                existing.setCheckoutTime(null);
                // 根据主键更新 activity_enroll 表的报名记录
                this.updateById(existing);
                // 更新活动报名人数：在原有计数基础上 +1
                activity.setEnrollCount(activity.getEnrollCount() + 1);
                // 将更新后的报名人数写回 activity 表
                activityMapper.updateById(activity);
                // 记录用户重新报名成功的日志
                log.info("用户重新报名活动: userId={}, activityId={}", userId, activityId);
                // 返回恢复后的报名记录
                return existing;
            }
        }

        // 3. 创建新的报名记录
        // 创建一个新的 ActivityEnroll 实体对象
        ActivityEnroll enroll = new ActivityEnroll();
        // 设置报名记录关联的活动ID
        enroll.setActivityId(activityId);
        // 设置报名学生用户ID
        enroll.setUserId(userId);
        // 设置报名时间为当前时间
        enroll.setEnrollTime(LocalDateTime.now());
        // 初始化签到状态为未签到（0）
        enroll.setCheckinStatus(0);
        // 设置报名状态为正常报名（1）
        enroll.setStatus(1);
        // 调用 save 方法将报名记录插入 activity_enroll 表
        this.save(enroll);

        // 4. 更新活动报名人数
        // 将活动已报名人数在原有基础上 +1
        activity.setEnrollCount(activity.getEnrollCount() + 1);
        // 将更新后的活动数据写回 activity 表
        activityMapper.updateById(activity);
        // 记录用户报名成功的日志
        log.info("用户报名活动成功: userId={}, activityId={}, enrollId={}", userId, activityId, enroll.getId());
        // 返回新创建的报名记录
        return enroll;
    }

    /**
     * 学生取消自己的活动报名。
     * <p>
     * 取消后报名记录状态变为已取消（2），并减少活动已报名人数。
     * </p>
     *
     * @param enrollId 报名记录ID
     * @param userId   当前操作用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void cancelEnroll(Long enrollId, Long userId) {
        // 根据报名记录ID从 activity_enroll 表查询报名记录
        ActivityEnroll enroll = this.getById(enrollId);
        // 如果报名记录不存在，提示前端
        if (enroll == null) {
            throw new BusinessException("报名记录不存在");
        }
        // 校验当前用户是否为该报名记录的本人，防止篡改他人数据
        if (!enroll.getUserId().equals(userId)) {
            throw new BusinessException("无权操作此报名记录");
        }
        // 如果报名状态不是正常报名（1），说明已经取消过，无需重复操作
        if (enroll.getStatus() != 1) {
            throw new BusinessException("报名已取消，无需重复操作");
        }
        // 更新报名状态为已取消（2）
        enroll.setStatus(2);
        // 根据主键更新 activity_enroll 表中的状态字段
        this.updateById(enroll);
        // 根据活动ID查询对应的活动记录，用于更新报名人数
        Activity activity = activityMapper.selectById(enroll.getActivityId());
        // 如果活动存在且已报名人数大于 0，则将人数减 1
        if (activity != null && activity.getEnrollCount() > 0) {
            activity.setEnrollCount(activity.getEnrollCount() - 1);
            // 更新 activity 表的已报名人数
            activityMapper.updateById(activity);
        }
        // 记录取消报名的日志
        log.info("用户取消报名: userId={}, enrollId={}, activityId={}", userId, enrollId, enroll.getActivityId());
    }

    /**
     * 学生对已报名的活动进行签到。
     *
     * @param enrollId 报名记录ID
     * @param userId   当前操作用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void checkin(Long enrollId, Long userId) {
        // 根据报名记录ID查询 activity_enroll 表中的签到记录
        ActivityEnroll enroll = this.getById(enrollId);
        // 如果记录不存在，提示报名记录不存在
        if (enroll == null) {
            throw new BusinessException("报名记录不存在");
        }
        // 校验当前用户是否为报名本人
        if (!enroll.getUserId().equals(userId)) {
            throw new BusinessException("无权操作此报名记录");
        }
        // 如果报名已被取消，则无法进行签到
        if (enroll.getStatus() != 1) {
            throw new BusinessException("报名已取消，无法签到");
        }
        // 如果签到状态已经是已签到（1），防止重复签到
        if (enroll.getCheckinStatus() == 1) {
            throw new BusinessException("已签到，无需重复操作");
        }
        // 将签到状态设置为已签到（1）
        enroll.setCheckinStatus(1);
        // 记录签到时间为当前时间
        enroll.setCheckinTime(LocalDateTime.now());
        // 更新 activity_enroll 表中的签到状态和时间
        this.updateById(enroll);
        // 记录签到成功的日志
        log.info("用户签到成功: userId={}, enrollId={}, activityId={}", userId, enrollId, enroll.getActivityId());
    }

    /**
     * 学生对已签到的活动进行签退，并发放活动积分奖励。
     *
     * @param enrollId 报名记录ID
     * @param userId   当前操作用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void checkout(Long enrollId, Long userId) {
        // 根据报名记录ID查询 activity_enroll 表中的签到签退记录
        ActivityEnroll enroll = this.getById(enrollId);
        // 如果记录不存在，提示报名记录不存在
        if (enroll == null) {
            throw new BusinessException("报名记录不存在");
        }
        // 校验当前用户是否为报名本人
        if (!enroll.getUserId().equals(userId)) {
            throw new BusinessException("无权操作此报名记录");
        }
        // 报名已取消的状态下不能签退
        if (enroll.getStatus() != 1) {
            throw new BusinessException("报名已取消，无法签退");
        }
        // 必须先完成签到，才能签退
        if (enroll.getCheckinStatus() != 1) {
            throw new BusinessException("请先签到，再签退");
        }
        // 如果已经签退过，防止重复签退
        if (enroll.getCheckoutStatus() == 1) {
            throw new BusinessException("已签退，无需重复操作");
        }
        // 将签退状态设置为已签退（1）
        enroll.setCheckoutStatus(1);
        // 记录签退时间为当前时间
        enroll.setCheckoutTime(LocalDateTime.now());
        // 更新 activity_enroll 表中的签退状态和时间
        this.updateById(enroll);

        // 查询活动信息，获取该活动配置的积分奖励值
        Activity activity = activityMapper.selectById(enroll.getActivityId());
        // 默认每次签退奖励 10 积分
        int creditPoints = 10;
        // 如果活动配置了积分且大于 0，则使用活动配置的积分值
        if (activity != null && activity.getCreditPoints() != null && activity.getCreditPoints() > 0) {
            creditPoints = activity.getCreditPoints();
        }
        // 调用用户服务给用户增加信用/积分
        userService.updateCreditScore(userId, creditPoints);

        // 记录签退成功及发放积分的日志
        log.info("用户签退成功: userId={}, enrollId={}, activityId={}, 奖励积分={}", userId, enrollId, enroll.getActivityId(), creditPoints);
    }

    /**
     * 查询指定学生的所有活动报名记录。
     *
     * @param userId 学生用户ID
     * @return 该学生的报名记录列表，按报名时间倒序排列
     */
    @Override
    public List<ActivityEnroll> getUserEnrolls(Long userId) {
        // 查询 activity_enroll 表中 user_id 等于传入用户的所有记录
        return this.list(new LambdaQueryWrapper<ActivityEnroll>()
                // 指定报名学生用户ID
                .eq(ActivityEnroll::getUserId, userId)
                // 按报名时间倒序，最近的报名排在最前面
                .orderByDesc(ActivityEnroll::getEnrollTime));
    }

    /**
     * 查询指定活动的所有正常报名学生名单。
     *
     * @param activityId 活动ID
     * @return 该活动下状态为正常报名的记录列表，按报名时间正序排列
     */
    @Override
    public List<ActivityEnroll> getActivityEnrolls(Long activityId) {
        // 查询 activity_enroll 表中指定活动且状态正常的报名记录
        return this.list(new LambdaQueryWrapper<ActivityEnroll>()
                // 指定活动ID
                .eq(ActivityEnroll::getActivityId, activityId)
                // 只查询状态为正常报名的记录
                .eq(ActivityEnroll::getStatus, 1)
                // 按报名时间正序排列
                .orderByAsc(ActivityEnroll::getEnrollTime));
    }

    /**
     * 统计指定活动的签到情况。
     *
     * @param activityId 活动ID
     * @return 包含报名人数、已签到人数、未签到人数的统计Map
     */
    @Override
    public Map<String, Integer> getCheckinStats(Long activityId) {
        // 创建一个 HashMap，用于存放报名人数、签到人数、未签到人数
        Map<String, Integer> stats = new HashMap<>();
        // 统计 activity_enroll 表中该活动状态为正常报名的人数
        long enrolledCount = this.count(new LambdaQueryWrapper<ActivityEnroll>()
                // 指定活动ID
                .eq(ActivityEnroll::getActivityId, activityId)
                // 只统计正常报名记录
                .eq(ActivityEnroll::getStatus, 1));
        // 统计 activity_enroll 表中该活动已签到的人数
        long checkedCount = this.count(new LambdaQueryWrapper<ActivityEnroll>()
                // 指定活动ID
                .eq(ActivityEnroll::getActivityId, activityId)
                // 只统计正常报名记录
                .eq(ActivityEnroll::getStatus, 1)
                // 只统计签到状态为已签到的记录
                .eq(ActivityEnroll::getCheckinStatus, 1));
        // 将报名人数放入返回结果
        stats.put("enrolledCount", (int) enrolledCount);
        // 将已签到人数放入返回结果
        stats.put("checkedCount", (int) checkedCount);
        // 计算未签到人数：总报名人数减去已签到人数
        stats.put("uncheckedCount", (int) (enrolledCount - checkedCount));
        // 返回签到统计结果
        return stats;
    }

    /**
     * 批量为指定活动的多名学生签到。
     * <p>
     * 仅活动发起人或社团管理员有权限执行批量签到。
     * </p>
     *
     * @param activityId 活动ID
     * @param userIds    需要签到的学生用户ID列表
     * @param operatorId 操作人用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void batchCheckin(Long activityId, List<Long> userIds, Long operatorId) {
        // 如果传入的用户ID列表为空，直接返回，不执行后续操作
        if (userIds == null || userIds.isEmpty()) {
            return;
        }
        // 验证操作权限：先查询活动信息
        Activity activity = activityMapper.selectById(activityId);
        // 如果活动不存在，提示前端
        if (activity == null) {
            throw new BusinessException("活动不存在");
        }
        // 标记当前操作人是否具有操作权限
        boolean hasPermission = false;
        // 个人活动：如果活动类型为个人活动（2）且操作人是发起人，则拥有权限
        if (activity.getActivityType() == 2 && activity.getOrganizerId().equals(operatorId)) {
            hasPermission = true;
        }
        // 社团活动：如果活动类型为社团活动（1）且有关联社团ID，则默认拥有权限（后续可细化社团管理员检查）
        if (activity.getActivityType() == 1 && activity.getClubId() != null) {
            // 这里需要检查是否是社团管理员，暂时简化处理
            hasPermission = true; // 后续可添加社团管理员检查
        }
        // 如果没有权限，抛出业务异常
        if (!hasPermission) {
            throw new BusinessException("您没有权限操作此活动");
        }
        // 批量更新 activity_enroll 表中指定活动、指定用户、正常报名记录的签到状态
        this.update(new LambdaUpdateWrapper<ActivityEnroll>()
                // 限定为当前活动
                .eq(ActivityEnroll::getActivityId, activityId)
                // 只更新正常报名的记录
                .eq(ActivityEnroll::getStatus, 1)
                // 只更新传入用户ID列表中的学生
                .in(ActivityEnroll::getUserId, userIds)
                // 将签到状态设置为已签到（1）
                .set(ActivityEnroll::getCheckinStatus, 1)
                // 将签到时间设置为当前时间
                .set(ActivityEnroll::getCheckinTime, LocalDateTime.now()));
        // 记录批量签到成功的日志
        log.info("批量签到成功: activityId={}, userCount={}, operatorId={}", activityId, userIds.size(), operatorId);
    }

    /**
     * 批量为指定活动的多名学生签退，并发放积分奖励。
     * <p>
     * 仅活动发起人或社团管理员有权限执行批量签退。
     * </p>
     *
     * @param activityId 活动ID
     * @param userIds    需要签退的学生用户ID列表
     * @param operatorId 操作人用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void batchCheckout(Long activityId, List<Long> userIds, Long operatorId) {
        // 如果传入的用户ID列表为空，直接返回，不执行后续操作
        if (userIds == null || userIds.isEmpty()) {
            return;
        }
        // 验证操作权限：先查询活动信息
        Activity activity = activityMapper.selectById(activityId);
        // 如果活动不存在，提示前端
        if (activity == null) {
            throw new BusinessException("活动不存在");
        }
        // 标记当前操作人是否具有操作权限
        boolean hasPermission = false;
        // 个人活动：如果活动类型为个人活动（2）且操作人是发起人，则拥有权限
        if (activity.getActivityType() == 2 && activity.getOrganizerId().equals(operatorId)) {
            hasPermission = true;
        }
        // 社团活动：如果活动类型为社团活动（1）且有关联社团ID，则默认拥有权限
        if (activity.getActivityType() == 1 && activity.getClubId() != null) {
            hasPermission = true;
        }
        // 如果没有权限，抛出业务异常
        if (!hasPermission) {
            throw new BusinessException("您没有权限操作此活动");
        }
        // 批量更新签退状态并发放积分
        // 如果活动配置了积分则使用配置值，否则默认 10 积分
        int creditPoints = activity.getCreditPoints() != null ? activity.getCreditPoints() : 10;
        // 遍历需要签退的学生用户ID列表
        for (Long userId : userIds) {
            // 查询 activity_enroll 表中该活动、该用户、正常报名且已签到的单条记录
            ActivityEnroll enroll = this.getOne(new LambdaQueryWrapper<ActivityEnroll>()
                    // 指定活动ID
                    .eq(ActivityEnroll::getActivityId, activityId)
                    // 指定学生用户ID
                    .eq(ActivityEnroll::getUserId, userId)
                    // 只处理正常报名记录
                    .eq(ActivityEnroll::getStatus, 1)
                    // 只处理已经签到的记录
                    .eq(ActivityEnroll::getCheckinStatus, 1));
            // 如果记录存在且尚未签退，则执行签退并发放积分
            if (enroll != null && enroll.getCheckoutStatus() != 1) {
                // 设置签退状态为已签退（1）
                enroll.setCheckoutStatus(1);
                // 记录签退时间为当前时间
                enroll.setCheckoutTime(LocalDateTime.now());
                // 更新 activity_enroll 表中的签退信息
                this.updateById(enroll);
                // 调用用户服务为该学生增加积分
                userService.updateCreditScore(userId, creditPoints);
            }
        }
        // 记录批量签退成功的日志
        log.info("批量签退成功: activityId={}, userCount={}, operatorId={}", activityId, userIds.size(), operatorId);
    }

    /**
     * 切换活动的签到开关状态。
     * <p>
     * 当前版本仅校验操作权限并记录日志，未持久化到 activity 表，
     * 后续可扩展为更新 activity 表的 checkin_enabled 字段。
     * </p>
     *
     * @param activityId 活动ID
     * @param enabled    是否开启签到
     * @param operatorId 操作人用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void toggleCheckin(Long activityId, Boolean enabled, Long operatorId) {
        // 查询活动信息，用于后续权限校验
        Activity activity = activityMapper.selectById(activityId);
        // 如果活动不存在，提示前端
        if (activity == null) {
            throw new BusinessException("活动不存在");
        }
        // 验证操作权限
        boolean hasPermission = false;
        // 个人活动：如果活动类型为个人活动（2）且操作人是发起人，则拥有权限
        if (activity.getActivityType() == 2 && activity.getOrganizerId().equals(operatorId)) {
            hasPermission = true;
        }
        // 社团活动：如果活动类型为社团活动（1）且有关联社团ID，则默认拥有权限
        if (activity.getActivityType() == 1 && activity.getClubId() != null) {
            hasPermission = true;
        }
        // 如果没有权限，抛出业务异常
        if (!hasPermission) {
            throw new BusinessException("您没有权限操作此活动");
        }
        // 暂时不修改活动状态，只记录日志
        // 后续可添加 checkinEnabled 字段到 Activity 表
        log.info("签到控制切换: activityId={}, enabled={}, operatorId={}", activityId, enabled, operatorId);
    }

    /**
     * 检查指定学生是否对某活动已有报名记录。
     *
     * @param userId     学生用户ID
     * @param activityId 活动ID
     * @return 如果存在报名记录则返回该记录，否则返回 null
     */
    @Override
    public ActivityEnroll checkUserEnrolled(Long userId, Long activityId) {
        // 查询 activity_enroll 表中 user_id 和 activity_id 同时匹配的单条记录
        return this.getOne(new LambdaQueryWrapper<ActivityEnroll>()
                // 指定学生用户ID
                .eq(ActivityEnroll::getUserId, userId)
                // 指定活动ID
                .eq(ActivityEnroll::getActivityId, activityId)
                // 使用 LIMIT 1 限制只返回一条，提高查询效率
                .last("LIMIT 1"));
    }
}
