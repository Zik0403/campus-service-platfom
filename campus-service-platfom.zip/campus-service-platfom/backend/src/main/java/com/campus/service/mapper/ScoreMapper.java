package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Score;
import org.apache.ibatis.annotations.Mapper;

/**
 * 学生成绩数据访问接口。
 *
 * <p>操作的数据库表为学生成绩表，对应实体类为 {@link Score}。
 * 主要负责学生课程成绩的增删改查，例如查询某位学生某门课程的成绩、绩点等。</p>
 */
@Mapper
public interface ScoreMapper extends BaseMapper<Score> {
}
