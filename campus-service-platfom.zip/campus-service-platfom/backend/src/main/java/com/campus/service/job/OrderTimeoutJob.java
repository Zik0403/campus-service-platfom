package com.campus.service.job;

import com.campus.service.service.SecondOrderService;
import com.campus.service.service.ServiceOrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * 订单超时检查定时任务。
 * <p>
 * 职责：按照固定频率扫描校园生活服务中的服务订单与二手订单，
 * 将超过规定时间仍未支付的订单自动取消，释放相关资源。
 * </p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OrderTimeoutJob {

    /**
     * 服务订单业务服务：处理跑腿、代取快递等服务类订单。
     */
    private final ServiceOrderService serviceOrderService;

    /**
     * 二手订单业务服务：处理闲置物品交易类订单。
     */
    private final SecondOrderService secondOrderService;

    /**
     * 每 5 分钟执行一次订单超时检查。
     * <p>
     * 分别调用服务订单和二手订单的取消超时订单方法，
     * 两类订单独立捕获异常，避免一种订单异常影响另一种订单的处理。
     * </p>
     */
    @Scheduled(fixedRate = 5 * 60 * 1000)
    public void checkTimeoutOrders() {
        // 记录日志：标记本次定时任务开始执行
        log.info("开始执行订单超时检查任务");

        // 尝试取消超时的服务订单（如跑腿、代取等）
        try {
            serviceOrderService.cancelTimeoutOrders();
        } catch (Exception e) {
            // 如果服务订单处理出现异常，记录错误日志但不中断后续流程
            log.error("服务订单超时处理异常", e);
        }

        // 尝试取消超时的二手交易订单
        try {
            secondOrderService.cancelTimeoutOrders();
        } catch (Exception e) {
            // 如果二手订单处理出现异常，记录错误日志但不中断流程
            log.error("二手订单超时处理异常", e);
        }

        // 记录日志：标记本次定时任务执行完成
        log.info("订单超时检查任务执行完成");
    }
}
