package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.Club;
import com.campus.service.entity.ClubMember;
import com.campus.service.mapper.ClubMapper;
import com.campus.service.mapper.ClubMemberMapper;
import com.campus.service.service.ClubMemberService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 校园社团成员服务实现类。
 * <p>
 * 负责学生加入、退出社团的完整流程，以及社团内部成员身份管理，包括：
 * <ul>
 *     <li>学生申请加入社团；</li>
 *     <li>社长/管理员审核入社申请（通过/驳回）；</li>
 *     <li>移除成员、设置成员身份（社长/副社长/管理员/普通成员）；</li>
 *     <li>学生主动退出社团、取消待审核申请；</li>
 *     <li>查询社团成员、个人社团列表、待审核申请等。</li>
 * </ul>
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ClubMemberServiceImpl extends ServiceImpl<ClubMemberMapper, ClubMember> implements ClubMemberService {

    /**
     * 社团数据访问对象，用于更新社团成员数及社长信息。
     */
    private final ClubMapper clubMapper;

    /**
     * 学生申请加入指定社团。
     * <p>
     * 申请前会校验社团是否存在、是否通过审核、是否已禁用；
     * 校验学生是否已加入或已申请；
     * 限制每人最多同时申请或加入 3 个社团。
     * </p>
     *
     * @param userId 申请学生用户ID
     * @param clubId 目标社团ID
     * @return 申请成功后的 ClubMember 成员记录
     */
    @Override
    @Transactional
    public ClubMember applyJoin(Long userId, Long clubId) {
        // 1. 检查社团是否存在且可加入
        // 根据 clubId 从 club 表查询社团基本信息
        Club club = clubMapper.selectById(clubId);
        // 如果社团不存在，提示前端“社团不存在”
        if (club == null) {
            throw new BusinessException("社团不存在");
        }
        // 如果社团审核状态不是已通过（2 表示通过），禁止加入
        if (club.getAuditStatus() != 2) {
            throw new BusinessException("社团未通过审核，无法加入");
        }
        // 如果社团状态不是启用（1 表示启用），说明社团已被禁用，禁止加入
        if (club.getStatus() != 1) {
            throw new BusinessException("社团已禁用，无法加入");
        }

        // 2. 检查是否已申请或已是成员
        // 查询 club_member 表，看该用户对该社团是否已有记录
        ClubMember existing = this.checkUserInClub(userId, clubId);
        if (existing != null) {
            // 如果记录状态为 1，说明已经是正式成员，不能重复申请
            if (existing.getStatus() == 1) {
                throw new BusinessException("您已是该社团成员");
            }
            // 如果记录状态为 0，说明已有待审核申请，不能重复提交
            if (existing.getStatus() == 0) {
                throw new BusinessException("您的入社申请正在审核中");
            }
            // 状态为 2（已退出），可以重新申请加入
            // 将状态恢复为待审核（0）
            existing.setStatus(0); // 待审核状态
            // 更新申请时间为当前时间
            existing.setJoinTime(LocalDateTime.now());
            // 重新申请时默认身份为普通成员（4）
            existing.setIdentity(4); // 申请加入默认为成员身份
            // 根据主键更新 club_member 表中的申请记录
            this.updateById(existing);
            // 记录用户重新申请加入社团的日志
            log.info("用户重新申请加入社团: userId={}, clubId={}", userId, clubId);
            // 返回更新后的申请记录
            return existing;
        }

        // 3. 检查是否已申请或已加入超过 3 个社团（包含待审核）
        // 统计 club_member 表中该用户状态为待审核（0）或正式成员（1）的记录数
        long activeCount = this.count(new LambdaQueryWrapper<ClubMember>()
                // 指定学生用户ID
                .eq(ClubMember::getUserId, userId)
                // 状态在 0（待审核）或 1（正式成员）之间
                .in(ClubMember::getStatus, 0, 1));
        // 如果已经达到 3 个，则不允许再申请，防止学生加入过多社团
        if (activeCount >= 3) {
            throw new BusinessException("每人最多只能申请或加入3个社团");
        }

        // 4. 创建新的入社申请记录（status=0 表示待审核）
        // 创建一个新的 ClubMember 实体对象
        ClubMember member = new ClubMember();
        // 设置成员记录关联的社团ID
        member.setClubId(clubId);
        // 设置申请学生用户ID
        member.setUserId(userId);
        // 设置默认身份为普通成员（4）
        member.setIdentity(4); // 申请加入默认为普通成员
        // 设置申请时间为当前时间
        member.setJoinTime(LocalDateTime.now());
        // 设置状态为待审核（0），等待社长/管理员审批
        member.setStatus(0); // 待审核状态
        // 调用 save 方法将申请记录插入 club_member 表
        this.save(member);
        // 记录用户申请加入社团的日志
        log.info("用户申请加入社团: userId={}, clubId={}, memberId={}", userId, clubId, member.getId());
        // 返回新创建的申请记录
        return member;
    }

    /**
     * 社长/管理员通过学生的入社申请。
     * <p>
     * 通过后将学生状态更新为正式成员，并将社团成员数 +1。
     * </p>
     *
     * @param memberId   待审核的成员记录ID
     * @param approverId 审核人用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void approveJoin(Long memberId, Long approverId) {
        // 根据成员记录ID从 club_member 表查询入社申请记录
        ClubMember member = this.getById(memberId);
        // 如果申请记录不存在，提示前端
        if (member == null) {
            throw new BusinessException("申请记录不存在");
        }
        // 检查审核人是否有权限：必须是该社团管理员（社长/副社长/管理员）
        if (!this.isClubAdmin(approverId, member.getClubId())) {
            throw new BusinessException("您不是社团管理员，无法审核");
        }
        // 只有状态为待审核（0）的申请才能被通过
        if (member.getStatus() != 0) {
            throw new BusinessException("申请已审核或已退出，无需重复操作");
        }
        // 更新成员状态为正式成员（1）
        member.setStatus(1);
        // 设置正式加入时间为当前时间
        member.setJoinTime(LocalDateTime.now());
        // 根据主键更新 club_member 表中的状态
        this.updateById(member);
        // 更新社团成员数：先查询 club 表中对应的社团记录
        Club club = clubMapper.selectById(member.getClubId());
        if (club != null) {
            // 将社团成员数在原有基础上 +1
            club.setMemberCount(club.getMemberCount() + 1);
            // 将更新后的成员数写回 club 表
            clubMapper.updateById(club);
        }
        // 记录审核通过入社申请的日志
        log.info("审核通过入社申请: memberId={}, approverId={}", memberId, approverId);
    }

    /**
     * 社长/管理员驳回学生的入社申请。
     *
     * @param memberId   待审核的成员记录ID
     * @param approverId 审核人用户ID，用于权限校验
     * @param reason     驳回原因
     */
    @Override
    @Transactional
    public void rejectJoin(Long memberId, Long approverId, String reason) {
        // 根据成员记录ID从 club_member 表查询入社申请记录
        ClubMember member = this.getById(memberId);
        // 如果申请记录不存在，提示前端
        if (member == null) {
            throw new BusinessException("申请记录不存在");
        }
        // 检查审核人是否为该社团管理员
        if (!this.isClubAdmin(approverId, member.getClubId())) {
            throw new BusinessException("您不是社团管理员，无法审核");
        }
        // 只有状态为待审核（0）的申请才能被驳回
        if (member.getStatus() != 0) {
            throw new BusinessException("申请已审核或已退出，无需重复操作");
        }
        // 驳回申请：将状态标记为已退出（2）
        member.setStatus(2);
        // 更新 club_member 表中的状态
        this.updateById(member);
        // 记录驳回入社申请的日志
        log.info("驳回入社申请: memberId={}, approverId={}, reason={}", memberId, approverId, reason);
    }

    /**
     * 社长/管理员将指定成员移出社团。
     *
     * @param memberId   待移除的成员记录ID
     * @param operatorId 操作人用户ID，用于权限校验
     */
    @Override
    @Transactional
    public void removeMember(Long memberId, Long operatorId) {
        // 根据成员记录ID从 club_member 表查询成员记录
        ClubMember member = this.getById(memberId);
        // 如果成员记录不存在，提示前端
        if (member == null) {
            throw new BusinessException("成员记录不存在");
        }
        // 检查操作人是否为该社团管理员
        if (!this.isClubAdmin(operatorId, member.getClubId())) {
            throw new BusinessException("您不是社团管理员，无法移除成员");
        }
        // 只有状态为正式成员（1）的成员才能被移除
        if (member.getStatus() != 1) {
            throw new BusinessException("该成员已退出或待审核，无需移除");
        }
        // 社长（identity=1）不能被直接移除，需要先转让社长身份
        if (member.getIdentity() == 1) {
            throw new BusinessException("社长不能被移除，请先转让社长身份");
        }
        // 移除成员：将状态标记为已退出（2）
        member.setStatus(2);
        // 更新 club_member 表中的状态
        this.updateById(member);
        // 更新社团成员数：先查询 club 表中对应的社团记录
        Club club = clubMapper.selectById(member.getClubId());
        // 如果社团存在且成员数大于 0，则将成员数减 1
        if (club != null && club.getMemberCount() > 0) {
            club.setMemberCount(club.getMemberCount() - 1);
            // 将更新后的成员数写回 club 表
            clubMapper.updateById(club);
        }
        // 记录移除社团成员的日志
        log.info("移除社团成员: memberId={}, operatorId={}", memberId, operatorId);
    }

    /**
     * 社长设置社团成员的身份。
     * <p>
     * 若将某成员设为社长，则当前社长自动降级为副社长，并更新 club 表的社长ID。
     * </p>
     *
     * @param memberId  待设置身份的成员记录ID
     * @param operatorId 操作人用户ID，必须是现任社长
     * @param identity  目标身份：1 社长、2 副社长、3 管理员、4 普通成员
     */
    @Override
    @Transactional
    public void setIdentity(Long memberId, Long operatorId, Integer identity) {
        // 根据成员记录ID从 club_member 表查询目标成员记录
        ClubMember member = this.getById(memberId);
        // 如果成员记录不存在，提示前端
        if (member == null) {
            throw new BusinessException("成员记录不存在");
        }
        // 只有社长可以设置成员身份：先查询操作人在该社团的成员记录
        ClubMember operator = this.checkUserInClub(operatorId, member.getClubId());
        // 如果操作人不是该社团成员，或者身份不是社长（1），则无权操作
        if (operator == null || operator.getIdentity() != 1) {
            throw new BusinessException("只有社长可以设置成员身份");
        }
        // 只有正式成员（1）才能被设置身份
        if (member.getStatus() != 1) {
            throw new BusinessException("该成员已退出或待审核，无法设置身份");
        }
        // 如果要设置为社长（identity=1），需要先转让当前社长的身份
        if (identity == 1) {
            // 当前社长降级为副社长（2）
            operator.setIdentity(2); // 当前社长变为副社长
            // 更新 club_member 表中当前操作人的身份
            this.updateById(operator);
            // 更新社团社长ID：查询 club 表中对应的社团记录
            Club club = clubMapper.selectById(member.getClubId());
            if (club != null) {
                // 将社团负责人修改为新的社长用户ID
                club.setLeaderId(member.getUserId());
                // 将更新后的社长信息写回 club 表
                clubMapper.updateById(club);
            }
        }
        // 设置目标成员的新身份
        member.setIdentity(identity);
        // 更新 club_member 表中目标成员的身份
        this.updateById(member);
        // 记录设置成员身份的日志
        log.info("设置成员身份: memberId={}, operatorId={}, newIdentity={}", memberId, operatorId, identity);
    }

    /**
     * 学生主动退出指定社团。
     *
     * @param clubId 社团ID
     * @param userId 当前操作用户ID
     */
    @Override
    @Transactional
    public void quitClub(Long clubId, Long userId) {
        // 查询 club_member 表中该用户在该社团的成员记录
        ClubMember member = this.checkUserInClub(userId, clubId);
        // 如果记录不存在，说明不是该社团成员
        if (member == null) {
            throw new BusinessException("您不是该社团成员");
        }
        // 如果状态已经是已退出（2），无需重复退出
        if (member.getStatus() == 2) {
            throw new BusinessException("您已退出该社团");
        }
        // 社长（identity=1）不能直接退出，需要先转让社长身份
        if (member.getIdentity() == 1) {
            throw new BusinessException("社长不能退出，请先转让社长身份");
        }
        // 退出社团：将状态标记为已退出（2）
        member.setStatus(2);
        // 更新 club_member 表中的状态
        this.updateById(member);
        // 更新社团成员数：只在已加入状态（1）时减少成员数
        if (member.getStatus() == 1) {
            // 查询 club 表中对应的社团记录
            Club club = clubMapper.selectById(clubId);
            // 如果社团存在且成员数大于 0，则将成员数减 1
            if (club != null && club.getMemberCount() > 0) {
                club.setMemberCount(club.getMemberCount() - 1);
                // 将更新后的成员数写回 club 表
                clubMapper.updateById(club);
            }
        }
        // 记录成员退出社团的日志
        log.info("成员退出社团: userId={}, clubId={}", userId, clubId);
    }

    /**
     * 学生取消对待审核入社申请的申请。
     *
     * @param clubId 社团ID
     * @param userId 当前操作用户ID
     */
    @Override
    @Transactional
    public void cancelApply(Long clubId, Long userId) {
        // 查询 club_member 表中该用户在该社团的申请记录
        ClubMember member = this.checkUserInClub(userId, clubId);
        // 如果记录不存在，提示前端
        if (member == null) {
            throw new BusinessException("申请记录不存在");
        }
        // 只有状态为待审核（0）的申请才能被取消
        if (member.getStatus() != 0) {
            throw new BusinessException("只能取消待审核的申请");
        }
        // 取消申请：将状态标记为已退出（2）
        member.setStatus(2);
        // 更新 club_member 表中的状态
        this.updateById(member);
        // 记录用户取消入社申请的日志
        log.info("用户取消入社申请: userId={}, clubId={}", userId, clubId);
    }

    /**
     * 查询指定社团的正式成员列表。
     *
     * @param clubId 社团ID
     * @return 该社团下状态为正式成员的记录列表，按身份正序排列
     */
    @Override
    public List<ClubMember> getClubMembers(Long clubId) {
        // 查询 club_member 表中指定社团且状态为正式成员的记录
        return this.list(new LambdaQueryWrapper<ClubMember>()
                // 指定社团ID
                .eq(ClubMember::getClubId, clubId)
                // 只查询状态为正式成员（1）的记录
                .eq(ClubMember::getStatus, 1)
                // 按身份正序排列，社长排在最前面
                .orderByAsc(ClubMember::getIdentity));
    }

    /**
     * 查询指定学生已加入的所有社团列表。
     *
     * @param userId 学生用户ID
     * @return 该学生已加入的社团成员记录列表，按加入时间倒序排列
     */
    @Override
    public List<ClubMember> getUserClubs(Long userId) {
        // 查询 club_member 表中该学生且状态为正式成员的记录
        return this.list(new LambdaQueryWrapper<ClubMember>()
                // 指定学生用户ID
                .eq(ClubMember::getUserId, userId)
                // 只查询状态为正式成员（1）的记录
                .eq(ClubMember::getStatus, 1)
                // 按加入时间倒序排列，最近加入的社团排在最前面
                .orderByDesc(ClubMember::getJoinTime));
    }

    /**
     * 查询指定学生所有未退出的社团相关记录（包括待审核和正式成员）。
     *
     * @param userId 学生用户ID
     * @return 该学生所有未退出社团的记录列表，按加入时间倒序排列
     */
    @Override
    public List<ClubMember> getUserAllApplications(Long userId) {
        // 查询 club_member 表中该学生且状态不是已退出（2）的记录
        return this.list(new LambdaQueryWrapper<ClubMember>()
                // 指定学生用户ID
                .eq(ClubMember::getUserId, userId)
                // 排除状态为已退出（2）的记录
                .ne(ClubMember::getStatus, 2)
                // 按加入时间倒序排列
                .orderByDesc(ClubMember::getJoinTime));
    }

    /**
     * 查询指定社团的待审核入社申请列表。
     *
     * @param clubId 社团ID
     * @return 该社团下状态为待审核的申请列表，按申请时间倒序排列
     */
    @Override
    public List<ClubMember> getPendingApplications(Long clubId) {
        // 查询 club_member 表中指定社团且状态为待审核（0）的记录
        return this.list(new LambdaQueryWrapper<ClubMember>()
                // 指定社团ID
                .eq(ClubMember::getClubId, clubId)
                // 只查询状态为待审核（0）的记录
                .eq(ClubMember::getStatus, 0)
                // 按加入时间倒序排列，最新的申请排在最前面
                .orderByDesc(ClubMember::getJoinTime));
    }

    /**
     * 检查指定用户在指定社团的成员记录。
     *
     * @param userId 学生用户ID
     * @param clubId 社团ID
     * @return 如果存在记录则返回该记录，否则返回 null
     */
    @Override
    public ClubMember checkUserInClub(Long userId, Long clubId) {
        // 查询 club_member 表中 user_id 和 club_id 同时匹配的单条记录
        return this.getOne(new LambdaQueryWrapper<ClubMember>()
                // 指定学生用户ID
                .eq(ClubMember::getUserId, userId)
                // 指定社团ID
                .eq(ClubMember::getClubId, clubId)
                // 使用 LIMIT 1 限制只返回一条，提高查询效率
                .last("LIMIT 1"));
    }

    /**
     * 判断指定用户是否为指定社团的管理员。
     * <p>
     * 社长（1）、副社长（2）、管理员（3）均视为管理员。
     * </p>
     *
     * @param userId 用户ID
     * @param clubId 社团ID
     * @return 是管理员返回 true，否则返回 false
     */
    @Override
    public boolean isClubAdmin(Long userId, Long clubId) {
        // 查询该用户在该社团的成员记录
        ClubMember member = this.checkUserInClub(userId, clubId);
        // 如果记录不存在或不是正式成员，则不是管理员
        if (member == null || member.getStatus() != 1) {
            return false;
        }
        // identity 为 1 社长、2 副社长、3 管理员，均视为管理员身份
        return member.getIdentity() != null && member.getIdentity() <= 3;
    }
}
