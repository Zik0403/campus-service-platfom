package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.SysConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 系统配置数据访问接口。
 *
 * <p>操作的数据库表为系统配置表，对应实体类为 {@link SysConfig}。
 * 主要负责系统运行参数的配置信息查询，例如根据配置键查询对应的配置值。</p>
 */
@Mapper
public interface SysConfigMapper extends BaseMapper<SysConfig> {

    /**
     * 根据配置键查询系统配置。
     *
     * @param configKey 配置键，例如系统开关、参数名等
     * @return 对应的系统配置记录，不存在时返回 null
     */
    SysConfig selectByKey(@Param("configKey") String configKey);
}
