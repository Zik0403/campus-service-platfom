package com.campus.service.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * JWT 工具类，负责校园生活服务小程序用户登录凭证的生成与解析。
 * <p>
 * 整体职责：
 * <ul>
 *   <li>用户登录成功后，根据用户 ID、微信 openid、角色信息生成 JWT Token；</li>
 *   <li>后续请求到达后端时，解析并校验请求头中的 Token，确认用户身份与权限。</li>
 * </ul>
 * Token 默认有效期由 {@code jwt.expiration} 配置控制，签名密钥由 {@code jwt.secret} 配置提供。
 * </p>
 */
@Slf4j
@Component
public class JwtUtils {

    /**
     * JWT 签名密钥字符串，从 application.yml 的 {@code jwt.secret} 读取。
     * <p>该密钥用于对 Token 进行签名和验证，必须保密且长度足够。</p>
     */
    @Value("${jwt.secret}")
    private String secret;

    /**
     * Token 有效期（毫秒），从 application.yml 的 {@code jwt.expiration} 读取。
     * <p>例如配置为 604800000 表示 Token 自生成时刻起 7 天内有效。</p>
     */
    @Value("${jwt.expiration}")
    private Long expiration;

    /**
     * 根据配置的密钥字符串生成 HMAC-SHA 签名密钥对象。
     *
     * @return 用于签名和验证 JWT 的 {@link SecretKey}
     */
    private SecretKey getSigningKey() {
        // 将字符串密钥按照 UTF-8 编码转换为字节数组
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        // 使用 JJWT 提供的工具方法生成符合 HMAC-SHA 要求的 SecretKey
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * 生成 JWT Token。
     * <p>
     * 登录成功时调用，将用户关键信息封装到 Token 中返回给小程序端，
     * 小程序后续请求需在请求头携带该 Token。
     * </p>
     *
     * @param userId 用户唯一标识
     * @param openid 微信用户 openid
     * @param role   用户角色（如 1-学生、2-工作人员、3-运营、4-管理员）
     * @return 签名后的 JWT 字符串
     */
    public String generateToken(Long userId, String openid, Integer role) {
        // 创建声明（claims）映射，用于存放需要写入 Token 的用户信息
        Map<String, Object> claims = new HashMap<>();
        // 将用户 ID 放入声明，后续可通过 Token 反查当前登录用户
        claims.put("userId", userId);
        // 将<-WEIXIN-> 放入声明，用于关联微信账号
        claims.put("openid", openid);
        // 将用户角色放入声明，用于权限控制
        claims.put("role", role);
        // 使用 JJWT 构建器组装 Token：设置声明、签发时间、过期时间、签名，最后压缩为字符串
        return Jwts.builder()
                .claims(claims)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(getSigningKey())
                .compact();
    }

    /**
     * 解析 JWT Token，获取其中保存的全部声明信息。
     *
     * @param token 请求头中携带的 JWT 字符串
     * @return 解析后的 {@link Claims} 对象，包含 userId、openid、role 等信息
     * @throws ExpiredJwtException 当 Token 已过期时抛出
     * @throws JwtException        当 Token 签名无效、格式错误等情况下抛出
     */
    public Claims parseToken(String token) {
        try {
            // 创建 JWT 解析器，并设置用于验证签名的密钥
            return Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    // 解析已签名的 Token，并获取其载荷（payload）部分
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (ExpiredJwtException e) {
            // Token 超过有效期，记录警告日志后继续抛出异常，由拦截器处理未授权逻辑
            log.warn("Token已过期: {}", e.getMessage());
            throw e;
        } catch (JwtException e) {
            // Token 被篡改、签名错误或格式异常，记录警告日志后继续抛出异常
            log.warn("Token解析失败: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * 验证 Token 是否有效。
     *
     * @param token 待验证的 JWT 字符串
     * @return 解析成功返回 {@code true}；过期、签名错误或其他异常返回 {@code false}
     */
    public boolean validateToken(String token) {
        try {
            // 调用 parseToken 进行解析与校验，若未抛异常则说明 Token 有效
            parseToken(token);
            return true;
        } catch (Exception e) {
            // 解析过程中出现任何异常均视为 Token 无效
            return false;
        }
    }

    /**
     * 从 Token 中提取用户 ID。
     *
     * @param token 请求头中携带的 JWT 字符串
     * @return 当前登录用户的 ID
     */
    public Long getUserId(String token) {
        // 先解析 Token 获取全部声明
        Claims claims = parseToken(token);
        // 从声明中取出 userId 并转换为 Long 类型
        return Long.valueOf(claims.get("userId").toString());
    }

    /**
     * 从 Token 中提取用户角色。
     *
     * @param token 请求头中携带的 JWT 字符串
     * @return 当前登录用户的角色编码
     */
    public Integer getRole(String token) {
        // 先解析 Token 获取全部声明
        Claims claims = parseToken(token);
        // 从声明中取出 role 并转换为 Integer 类型
        return Integer.valueOf(claims.get("role").toString());
    }

    /**
     * 从 Token 中提取微信 openid。
     *
     * @param token 请求头中携带的 JWT 字符串
     * @return 当前登录用户对应的微信 openid
     */
    public String getOpenid(String token) {
        // 先解析 Token 获取全部声明
        Claims claims = parseToken(token);
        // 从声明中取出 openid 并转换为字符串返回
        return claims.get("openid").toString();
    }

    /**
     * 判断 Token 是否已过期。
     *
     * @param token 待判断的 JWT 字符串
     * @return 已过期返回 {@code true}，未过期返回 {@code false}
     */
    public boolean isTokenExpired(String token) {
        try {
            // 解析 Token 获取声明
            Claims claims = parseToken(token);
            // 将 Token 声明中的过期时间与当前系统时间比较，判断是否已经过期
            return claims.getExpiration().before(new Date());
        } catch (ExpiredJwtException e) {
            // 解析器明确抛出过期异常，直接判定为已过期
            return true;
        }
    }

    /**
     * 获取 Token 的过期时间。
     * <p>
     * 登出加入黑名单时需要知道 Token 何时自然过期，
     * 以便 Redis 黑名单 Key 能跟随 Token 一起过期，避免长期占用内存。
     * </p>
     *
     * @param token JWT Token 字符串
     * @return Token 的过期时间
     */
    public Date getExpirationDate(String token) {
        // 解析 Token 获取声明，从中取出过期时间
        Claims claims = parseToken(token);
        return claims.getExpiration();
    }
}
