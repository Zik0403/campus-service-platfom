package com.campus.service.service;

import com.campus.service.entity.ServiceOrder;
import com.campus.service.handler.OrderWebSocketHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * 订单变更 WebSocket 推送服务。
 * <p>
 * 负责把订单状态变更事件封装为统一格式的 JSON 消息，
 * 并通过 {@link OrderWebSocketHandler} 推送给订单的下单人和接单人。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderWebSocketPushService {

    /**
     * JSON 序列化工具，用于构造推送消息体。
     */
    private final ObjectMapper objectMapper;

    /**
     * 订单创建事件标识。
     */
    public static final String EVENT_CREATE = "CREATE";

    /**
     * 订单支付事件标识。
     */
    public static final String EVENT_PAY = "PAY";

    /**
     * 订单接单事件标识。
     */
    public static final String EVENT_ACCEPT = "ACCEPT";

    /**
     * 开始配送事件标识。
     */
    public static final String EVENT_START = "START";

    /**
     * 订单完成事件标识。
     */
    public static final String EVENT_COMPLETE = "COMPLETE";

    /**
     * 订单取消/退款事件标识。
     */
    public static final String EVENT_CANCEL = "CANCEL";

    /**
     * 订单评价事件标识。
     */
    public static final String EVENT_EVALUATE = "EVALUATE";

    /**
     * 订单投诉事件标识。
     */
    public static final String EVENT_COMPLAIN = "COMPLAIN";

    /**
     * 接单员退回订单事件标识。
     */
    public static final String EVENT_RETURN = "RETURN";

    /**
     * 推送订单变更消息。
     * <p>
     * 消息会推送给下单人（userId）和当前接单人（workerId），
     * 只有当前在线的用户才能收到实时推送。
     * </p>
     *
     * @param order 变更后的服务订单对象
     * @param event 事件类型，如 CREATE、PAY、ACCEPT 等
     */
    public void pushOrderUpdate(ServiceOrder order, String event) {
        if (order == null) {
            return;
        }
        // 构造统一的消息体
        Map<String, Object> message = new HashMap<>();
        message.put("event", event);
        message.put("orderId", order.getId());
        message.put("status", order.getStatus());
        message.put("serviceType", order.getServiceType());
        message.put("updateTime", order.getUpdateTime());
        // 如果存在评价星级，也一并推送
        if (order.getEvaluateStar() != null) {
            message.put("evaluateStar", order.getEvaluateStar());
        }

        // 将消息体序列化为 JSON 字符串
        String json;
        try {
            json = objectMapper.writeValueAsString(message);
        } catch (Exception e) {
            log.error("订单变更消息序列化失败：orderId={}", order.getId(), e);
            return;
        }

        // 推送给下单人
        if (order.getUserId() != null) {
            OrderWebSocketHandler.sendMessageToUser(order.getUserId(), json);
        }
        // 推送给接单人（如果已分配）
        if (order.getWorkerId() != null) {
            OrderWebSocketHandler.sendMessageToUser(order.getWorkerId(), json);
        }

        log.debug("订单变更推送完成：orderId={}, event={}", order.getId(), event);
    }
}
