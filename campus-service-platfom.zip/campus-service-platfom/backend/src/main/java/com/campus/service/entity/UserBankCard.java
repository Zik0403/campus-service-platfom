package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 用户银行卡表。
 * 存储用户绑定的银行卡信息，用于钱包提现收款，
 * 记录卡号、开户行、脱敏卡号、是否默认等字段。
 */
@Data
@TableName("user_bank_card") // 指定对应的数据库表名为 user_bank_card
public class UserBankCard {

    /**
     * 银行卡记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 绑定用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 银行名称，如“中国工商银行”“中国建设银行”。
     */
    private String bankName;

    /**
     * 完整银行卡号，提现时使用（生产环境应加密存储）。
     */
    private String cardNumber;

    /**
     * 脱敏后的银行卡号，如“6222 **** **** 1234”，用于前端展示。
     */
    private String cardNumberMask;

    /**
     * 银行卡密码或预留信息，根据业务需要校验（生产环境应加密存储）。
     */
    private String cardPassword;

    /**
     * 是否默认卡：0 否、1 是。提现时优先使用默认卡。
     */
    private Integer isDefault;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充默认值（配合 MetaObjectHandler）
    private Integer isDelete;

    /**
     * 创建时间，记录银行卡首次绑定时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录银行卡信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
