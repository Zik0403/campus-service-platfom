package com.campus.service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;

/**
 * 用户账号密码登录入参 DTO。
 * <p>
 * 用于替代 {@link java.util.Map} 接收登录参数，配合 JSR-303 注解
 * 在 Controller 层完成参数校验，避免非法请求进入业务层。
 * </p>
 *
 * @author campus-service
 */
@Data
public class UserLoginDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 登录账号，支持学号、手机号或身份证号。
     */
    @NotBlank(message = "登录账号不能为空")
    @Size(max = 64, message = "登录账号长度不能超过64位")
    private String account;

    /**
     * 登录密码。
     */
    @NotBlank(message = "登录密码不能为空")
    @Size(min = 6, max = 32, message = "登录密码长度必须在6到32位之间")
    private String password;
}
