package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.ClubMember;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 社团成员数据访问接口。
 *
 * <p>操作的数据库表为社团成员表，对应实体类为 {@link ClubMember}。
 * 主要负责社团成员关系的查询，例如查询某社团的成员、某用户加入了哪些社团、以及用户在社团中的身份。</p>
 */
@Mapper
public interface ClubMemberMapper extends BaseMapper<ClubMember> {

    /**
     * 根据社团 ID 查询该社团的所有成员。
     *
     * @param clubId 社团 ID
     * @return 该社团的成员列表
     */
    List<ClubMember> selectByClubId(@Param("clubId") Long clubId);

    /**
     * 根据用户 ID 查询该用户加入的所有社团。
     *
     * @param userId 用户 ID
     * @return 该用户的社团成员记录列表
     */
    List<ClubMember> selectByUserId(@Param("userId") Long userId);

    /**
     * 查询某个用户在某个社团中的成员身份。
     *
     * @param clubId 社团 ID
     * @param userId 用户 ID
     * @return 如果该用户在该社团中则返回成员记录，否则返回 null
     */
    ClubMember selectUserClubRole(@Param("clubId") Long clubId, @Param("userId") Long userId);
}
