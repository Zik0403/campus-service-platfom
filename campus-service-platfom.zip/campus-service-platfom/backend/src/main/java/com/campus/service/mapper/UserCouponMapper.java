package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.UserCoupon;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 用户优惠券数据访问接口。
 *
 * <p>操作的数据库表为用户优惠券表，对应实体类为 {@link UserCoupon}。
 * 主要负责用户已领取优惠券的查询，例如查询某用户的所有优惠券、查询某用户当前可用的优惠券。</p>
 */
@Mapper
public interface UserCouponMapper extends BaseMapper<UserCoupon> {

    /**
     * 根据用户 ID 查询该用户领取的所有优惠券。
     *
     * @param userId 用户 ID
     * @return 该用户的优惠券列表
     */
    List<UserCoupon> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据用户 ID 查询该用户当前可用的优惠券。
     *
     * @param userId 用户 ID
     * @return 该用户可用的优惠券列表
     */
    List<UserCoupon> selectAvailableByUserId(@Param("userId") Long userId);
}
