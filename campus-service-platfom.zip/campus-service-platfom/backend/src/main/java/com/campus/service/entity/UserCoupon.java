package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 用户优惠券表。
 * 记录用户领取的优惠券实例，包括领取时间、使用时间、关联订单与状态，
 * 支撑小程序端卡券包展示、下单抵扣与过期提醒。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("user_coupon") // 指定对应的数据库表名为 user_coupon
public class UserCoupon implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 用户优惠券主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 所属用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 优惠券模板 ID，关联 coupon 表。
     */
    private Long couponId;

    /**
     * 领取时间，用户领取优惠券的时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime receiveTime;

    /**
     * 使用时间，用户下单使用该优惠券的时间。
     */
    private LocalDateTime useTime;

    /**
     * 关联订单号，记录该优惠券被用于哪笔订单。
     */
    private String orderNo;

    /**
     * 优惠券状态：1 待使用、2 已使用、3 已过期。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联优惠券模板对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private Coupon coupon;
}
