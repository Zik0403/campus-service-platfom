package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.WalletRecord;

import java.util.List;

/**
 * 钱包资金流水服务接口。
 * 负责记录并查询用户在校园生活服务平台中的钱包资金变动明细，
 * 例如充值、消费、退款、配送收入、交易收入等，方便用户核对账目。
 */
public interface WalletRecordService extends IService<WalletRecord> {

    /**
     * 查询某位学生的钱包资金流水记录。
     * @param userId 用户ID
     * @return 该用户的资金流水列表
     */
    List<WalletRecord> getUserRecords(Long userId);
}
