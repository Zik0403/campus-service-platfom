package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.CourseSchedule;
import org.apache.ibatis.annotations.Mapper;

/**
 * 课程表数据访问接口。
 *
 * <p>操作的数据库表为课程表，对应实体类为 {@link CourseSchedule}。
 * 主要负责学生个人课程安排信息的增删改查，例如查询某位学生每周有哪些课。</p>
 */
@Mapper
public interface CourseScheduleMapper extends BaseMapper<CourseSchedule> {
}
