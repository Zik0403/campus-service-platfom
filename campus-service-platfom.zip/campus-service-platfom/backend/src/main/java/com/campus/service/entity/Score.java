package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 学生成绩表。
 * 存储学生各学期课程成绩，包括课程名称、学分、分数、绩点、学期与考试类型，
 * 支撑小程序端成绩查询、绩点统计与学业分析。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("score") // 指定对应的数据库表名为 score
public class Score implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 成绩记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 学号，标识该成绩记录属于哪位学生。
     */
    private String studentId;

    /**
     * 课程名称，即考试科目。
     */
    private String courseName;

    /**
     * 课程学分，用于绩点与加权平均分计算。
     */
    private BigDecimal credit;

    /**
     * 课程得分，通常为百分制成绩。
     */
    private BigDecimal score;

    /**
     * 课程绩点，根据学校绩点规则由百分制成绩换算得到。
     */
    private BigDecimal gradePoint;

    /**
     * 学期，如“2025-2026-1”。
     */
    private String semester;

    /**
     * 考试类型，如“正常考试”“补考”“重修”。
     */
    private String examType;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录成绩数据首次同步/录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录成绩数据最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
