package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.CampusNotice;

import java.util.List;

/**
 * 校园公告服务接口。
 * 负责向学生展示学校或平台发布的各类公告信息，支持按公告类型筛选，
 * 例如教务通知、活动通知、失物招领置顶等。
 */
public interface CampusNoticeService extends IService<CampusNotice> {

    /**
     * 查询所有已经上架的校园公告。
     * @return 上架公告列表
     */
    List<CampusNotice> getOnlineNotices();

    /**
     * 按公告类型查询已上架的校园公告。
     * @param noticeType 公告类型（例如：1教务通知 2活动通知 3系统公告等）
     * @return 该类型下的上架公告列表
     */
    List<CampusNotice> getOnlineNoticesByType(Integer noticeType);

    /**
     * 带缓存查询：获取全部已上线校园公告列表。
     * @return 已上线的校园公告列表
     */
    List<CampusNotice> getOnlineNoticesWithCache();

    /**
     * 带缓存查询：按类型获取已上线校园公告列表。
     * @param noticeType 公告类型
     * @return 指定类型下已上线的校园公告列表
     */
    List<CampusNotice> getOnlineNoticesByTypeWithCache(Integer noticeType);

    /**
     * 清除校园公告相关的所有缓存。
     */
    void evictNoticeCache();

    /**
     * 预加载校园公告缓存。
     */
    void warmNoticeCache();
}
