package com.campus.service.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * OSS 对象存储配置属性。
 * <p>
 * 与 {@code application.yml} 中的 {@code oss.*} 配置项绑定，
 * 用于腾讯云 COS 上传时读取 endpoint、访问密钥、bucket 等信息。
 * </p>
 *
 * @author campus-service
 */
@Data
@ConfigurationProperties(prefix = "oss")
public class OssProperties {

    /**
     * COS 服务端点，例如 https://cos.ap-guangzhou.myqcloud.com。
     */
    private String endpoint;

    /**
     * 腾讯云访问密钥 ID（SecretId）。
     */
    private String accessKey;

    /**
     * 腾讯云访问密钥 Key（SecretKey）。
     */
    private String secretKey;

    /**
     * 存储桶名称。
     */
    private String bucket;

    /**
     * 文件访问域名，用于拼接上传后的可访问 URL。
     */
    private String domain;
}
