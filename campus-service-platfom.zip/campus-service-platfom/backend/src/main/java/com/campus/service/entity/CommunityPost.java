package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 社区帖子表白墙表。
 * 存储学生发布的表白墙、论坛帖子、兼职信息等内容，支持匿名发布、点赞、评论与审核，
 * 是校园社区互动与学生交流的核心数据表。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("community_post") // 指定对应的数据库表名为 community_post
public class CommunityPost implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 帖子主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 发布用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 帖子类型：1 表白墙、2 论坛帖子、3 兼职发布。
     */
    private Integer postType;

    /**
     * 帖子标题，展示在列表与详情页。
     */
    private String title;

    /**
     * 帖子正文内容。
     */
    private String content;

    /**
     * 帖子配图数组，通常以 JSON 或逗号分隔的 OSS 地址存储。
     */
    private String images;

    /**
     * 是否匿名：0 实名显示发布者、1 匿名展示。
     */
    private Integer isAnon;

    /**
     * 审核状态：1 待审核、2 已通过、3 驳回。
     * 帖子发布前需经审核防止违规内容。
     */
    private Integer auditStatus;

    /**
     * 点赞数，其他学生点赞时递增。
     */
    private Integer likeNum;

    /**
     * 评论数，有用户评论或删除评论时维护。
     */
    private Integer commentNum;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录帖子首次发布时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联发布者用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User user;

    // ========== 业务方法：枚举值转中文名称 ==========

    /**
     * 根据 postType 字段值获取帖子类型中文名称。
     *
     * @return 帖子类型名称，如“表白墙”“论坛帖子”“兼职发布”
     */
    public String getPostTypeName() {
        // 根据帖子类型编码返回对应的中文描述，便于前端直接展示
        return switch (postType) {
            case 1 -> "表白墙";
            case 2 -> "论坛帖子";
            case 3 -> "兼职发布";
            default -> "未知";
        };
    }
}
