package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.StudyCheckin;
import org.apache.ibatis.annotations.Mapper;

/**
 * 学习打卡数据访问接口。
 *
 * <p>操作的数据库表为学习打卡表，对应实体类为 {@link StudyCheckin}。
 * 主要负责学生学习打卡记录的增删改查，例如记录每天自习打卡、累计学习时长等。</p>
 */
@Mapper
public interface StudyCheckinMapper extends BaseMapper<StudyCheckin> {
}
