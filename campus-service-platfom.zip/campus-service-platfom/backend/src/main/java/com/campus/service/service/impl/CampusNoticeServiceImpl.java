package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.cache.CacheKeyConstant;
import com.campus.service.common.cache.CacheProtectionService;
import com.campus.service.entity.CampusNotice;
import com.campus.service.mapper.CampusNoticeMapper;
import com.campus.service.service.CampusNoticeService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;

/**
 * 校园公告服务实现类。
 * <p>
 * 负责向学生展示学校发布的各类公告信息，包括：
 * <ul>
 *     <li>查询当前已上线的全部公告列表；</li>
 *     <li>按公告类型（如通知、活动、教务等）查询已上线公告。</li>
 * </ul>
 * 公告数据由管理员在后台维护，学生端仅查看状态为“上线”的公告。
 * </p>
 *
 * @author campus-service
 */
@Service
@RequiredArgsConstructor
public class CampusNoticeServiceImpl extends ServiceImpl<CampusNoticeMapper, CampusNotice> implements CampusNoticeService {

    /**
     * 查询当前已上线的全部校园公告列表。
     * <p>
     * 仅返回状态为“上线”（status=1）的公告，按排序值正序、创建时间倒序排列。
     * </p>
     *
     * @return 已上线的校园公告列表
     */
    @Override
    public List<CampusNotice> getOnlineNotices() {
        // 查询 campus_notice 表中状态为上线的公告
        return list(new LambdaQueryWrapper<CampusNotice>()
                // 只查询状态为上线的公告（status=1 表示上线，学生可见）
                .eq(CampusNotice::getStatus, 1)
                // 按排序值正序排列，sort 值越小展示越靠前
                .orderByAsc(CampusNotice::getSort)
                // 排序值相同的情况下，按创建时间倒序，最新的公告排在前面
                .orderByDesc(CampusNotice::getCreateTime));
    }

    /**
     * 根据公告类型查询当前已上线的校园公告列表。
     *
     * @param noticeType 公告类型，如 1 通知、2 活动等，具体含义由业务字典定义
     * @return 指定类型下已上线的校园公告列表
     */
    @Override
    public List<CampusNotice> getOnlineNoticesByType(Integer noticeType) {
        // 查询 campus_notice 表中指定类型且状态为上线的公告
        return list(new LambdaQueryWrapper<CampusNotice>()
                // 指定公告类型条件
                .eq(CampusNotice::getNoticeType, noticeType)
                // 只查询状态为上线的公告
                .eq(CampusNotice::getStatus, 1)
                // 按排序值正序排列
                .orderByAsc(CampusNotice::getSort)
                // 排序值相同的情况下按创建时间倒序排列
                .orderByDesc(CampusNotice::getCreateTime));
    }

    /**
     * Redis 缓存模板，用于热点公告数据的读取与写入。
     * <p>
     * 由 Spring 自动注入，key 使用 String 序列化，value 使用 JSON 序列化。
     * </p>
     */
    private final RedisTemplate<String, Object> redisTemplate;

    /**
     * 缓存防护服务，提供缓存穿透、击穿、雪崩保护能力。
     */
    private final CacheProtectionService cacheProtectionService;

    /**
     * 缓存过期时间，公告数据变化不频繁，默认缓存 30 分钟。
     */
    private static final Duration NOTICE_CACHE_TTL = Duration.ofMinutes(30);

    /**
     * 带缓存的查询：获取全部已上线校园公告列表。
     * <p>
     * 先尝试从 Redis 读取；如果缓存命中则直接返回，避免访问数据库；
     * 如果缓存未命中，再调用 {@link #getOnlineNotices()} 查询数据库，
     * 并把结果写入 Redis，设置 30 分钟过期时间。
     * </p>
     *
     * @return 已上线的校园公告列表
     */
    public List<CampusNotice> getOnlineNoticesWithCache() {
        // 构造本次查询对应的 Redis Key
        String cacheKey = CacheKeyConstant.NOTICE_ONLINE_LIST;
        // 先尝试从 Redis 中读取缓存的公告列表
        @SuppressWarnings("unchecked")
        List<CampusNotice> cachedList = (List<CampusNotice>) redisTemplate.opsForValue().get(cacheKey);
        if (cachedList != null) {
            // 缓存命中，直接返回，无需访问数据库
            return cachedList;
        }
        // 缓存未命中，查询数据库获取最新公告列表
        List<CampusNotice> notices = getOnlineNotices();
        // 将查询结果写入 Redis，设置过期时间，避免缓存长期不更新
        redisTemplate.opsForValue().set(cacheKey, notices, NOTICE_CACHE_TTL);
        return notices;
    }

    /**
     * 带缓存的查询：按类型获取已上线校园公告列表。
     * <p>
     * 与 {@link #getOnlineNoticesByType(Integer)} 逻辑一致，只是增加 Redis 缓存层。
     * 不同公告类型使用不同的 Redis Key，避免类型数据相互覆盖。
     * </p>
     *
     * @param noticeType 公告类型
     * @return 指定类型下已上线的校园公告列表
     */
    public List<CampusNotice> getOnlineNoticesByTypeWithCache(Integer noticeType) {
        // 根据公告类型构造唯一缓存 Key
        String cacheKey = CacheKeyConstant.noticeOnlineTypeKey(noticeType);
        // 先尝试从 Redis 读取该类型的公告缓存
        @SuppressWarnings("unchecked")
        List<CampusNotice> cachedList = (List<CampusNotice>) redisTemplate.opsForValue().get(cacheKey);
        if (cachedList != null) {
            // 缓存命中直接返回
            return cachedList;
        }
        // 缓存未命中，回源查询数据库
        List<CampusNotice> notices = getOnlineNoticesByType(noticeType);
        // 写入 Redis 并设置过期时间
        redisTemplate.opsForValue().set(cacheKey, notices, NOTICE_CACHE_TTL);
        return notices;
    }

    /**
     * 清除校园公告相关的所有缓存。
     * <p>
     * 当管理员在后台新增、修改、删除或上下架公告时调用，
     * 保证学生端下次访问时读取到最新数据。
     * </p>
     */
    public void evictNoticeCache() {
        // 删除全部已上线公告列表缓存
        redisTemplate.delete(CacheKeyConstant.NOTICE_ONLINE_LIST);
        // 删除按类型缓存的公告列表（匹配 notice:online:type:* 模式）
        // Spring Data Redis 不支持直接按模式删除，这里先查出所有匹配的 Key 再批量删除
        java.util.Set<String> typeKeys = redisTemplate.keys(CacheKeyConstant.NOTICE_ONLINE_TYPE_PREFIX + "*");
        if (typeKeys != null && !typeKeys.isEmpty()) {
            redisTemplate.delete(typeKeys);
        }
    }

    /**
     * 预加载校园公告缓存。
     * <p>
     * 应用启动或手动触发时，把热点公告数据提前写入 Redis，
     * 避免用户首次访问时产生缓存穿透。
     * </p>
     */
    public void warmNoticeCache() {
        // 预热全部已上线公告列表缓存
        List<CampusNotice> allNotices = getOnlineNotices();
        redisTemplate.opsForValue().set(CacheKeyConstant.NOTICE_ONLINE_LIST, allNotices, NOTICE_CACHE_TTL);
    }

    /**
     * 带三重防护的查询：获取全部已上线校园公告列表。
     * <p>
     * 在 {@link #getOnlineNoticesWithCache()} 基础上增加缓存穿透、缓存击穿、缓存雪崩保护：
     * <ul>
     *   <li>数据库无数据时写入空值占位，防止缓存穿透；</li>
     *   <li>热点 Key 过期时使用分布式锁单线程重建，防止缓存击穿；</li>
     *   <li>过期时间增加随机偏移，防止大量 Key 同时过期造成雪崩。</li>
     * </ul>
     * </p>
     *
     * @return 已上线的校园公告列表
     */
    public List<CampusNotice> getOnlineNoticesWithCacheProtected() {
        // 使用缓存防护服务读取列表，未命中时自动调用 getOnlineNotices() 回源
        return cacheProtectionService.getListWithProtection(
                CacheKeyConstant.NOTICE_ONLINE_LIST,
                this::getOnlineNotices,
                NOTICE_CACHE_TTL,
                CampusNotice.class);
    }

    /**
     * 带三重防护的查询：按类型获取已上线校园公告列表。
     *
     * @param noticeType 公告类型
     * @return 指定类型下已上线的校园公告列表
     */
    public List<CampusNotice> getOnlineNoticesByTypeWithCacheProtected(Integer noticeType) {
        // 根据公告类型构造唯一缓存 Key
        String cacheKey = CacheKeyConstant.noticeOnlineTypeKey(noticeType);
        // 使用缓存防护服务读取该类型公告列表
        return cacheProtectionService.getListWithProtection(
                cacheKey,
                () -> getOnlineNoticesByType(noticeType),
                NOTICE_CACHE_TTL,
                CampusNotice.class);
    }
}
