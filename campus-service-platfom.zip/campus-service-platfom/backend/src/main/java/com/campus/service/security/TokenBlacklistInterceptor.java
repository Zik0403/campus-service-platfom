package com.campus.service.security;

import com.campus.service.common.cache.TokenBlacklistConstant;
import com.campus.service.common.exception.BusinessException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import java.time.Duration;
import java.util.Date;

/**
 * Token 黑名单拦截器。
 * <p>
 * 负责在请求进入 Controller 之前校验当前 Token 是否已被加入 Redis 黑名单。
 * 用户登出后，原 Token 会被放入黑名单并保留至 Token 自然过期，
 * 防止登出后的 Token 继续访问受保护资源。
 * </p>
 * <p>
 * 该拦截器在 {@link AuthInterceptor} 之后执行（order 值更大），
 * 先由 {@link AuthInterceptor} 完成 Token 格式与签名校验，
 * 再由本拦截器完成黑名单校验。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TokenBlacklistInterceptor implements HandlerInterceptor {

    /**
     * Redis 缓存模板，用于读取黑名单记录。
     */
    private final RedisTemplate<String, Object> redisTemplate;

    /**
     * JWT 工具类，用于解析 Token 剩余有效期。
     */
    private final JwtUtils jwtUtils;

    /**
     * 在 Controller 方法执行前校验 Token 是否在黑名单中。
     *
     * @param request  当前 HTTP 请求对象
     * @param response 当前 HTTP 响应对象
     * @param handler  即将执行的处理器
     * @return 校验通过返回 {@code true}，黑名单中的 Token 抛出未授权异常
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 对于浏览器预检请求（OPTIONS），直接放行
        if ("OPTIONS".equals(request.getMethod())) {
            return true;
        }

        // 从请求头中提取 Token
        String token = extractToken(request);
        // 如果请求没有携带 Token，则不需要校验黑名单，直接放行
        // 后续由 AuthInterceptor 负责拦截未登录请求
        if (!StringUtils.hasText(token)) {
            return true;
        }

        // 构造该 Token 在 Redis 黑名单中的 Key
        String blacklistKey = TokenBlacklistConstant.blacklistKey(token);
        // 查询 Redis 中是否存在该 Token 的黑名单记录
        Boolean inBlacklist = redisTemplate.hasKey(blacklistKey);
        if (Boolean.TRUE.equals(inBlacklist)) {
            // Token 已在黑名单中，说明用户已登出，拒绝访问
            log.warn("Token 已被加入黑名单，拒绝访问: uri={}", request.getRequestURI());
            throw BusinessException.UNAUTHORIZED;
        }

        // Token 不在黑名单中，放行请求
        return true;
    }

    /**
     * 从 HTTP 请求头中提取 Bearer Token。
     *
     * @param request 当前 HTTP 请求对象
     * @return 提取到的 Token 字符串；若请求头为空或格式不正确则返回 {@code null}
     */
    private String extractToken(HttpServletRequest request) {
        // 读取请求头 Authorization 字段
        String bearerToken = request.getHeader("Authorization");
        // 判断请求头是否有内容且以 "Bearer " 开头
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            // 去掉前缀，只保留 Token 字符串
            return bearerToken.substring(7);
        }
        return null;
    }

    /**
     * 将指定 Token 加入 Redis 黑名单。
     * <p>
     * 登出时调用该方法，黑名单过期时间设置为 Token 剩余有效期，
     * 避免 Redis 中长期保留无效黑名单记录。
     * </p>
     *
     * @param token JWT Token 字符串
     */
    public void addToBlacklist(String token) {
        if (!StringUtils.hasText(token)) {
            return;
        }
        // 构造黑名单缓存 Key
        String blacklistKey = TokenBlacklistConstant.blacklistKey(token);
        // 计算 Token 剩余有效期作为黑名单过期时间
        Duration ttl = calculateTokenTtl(token);
        // 将 Token 加入黑名单，value 用占位值 "1" 即可
        redisTemplate.opsForValue().set(blacklistKey, TokenBlacklistConstant.BLACKLIST_VALUE, ttl);
        log.info("Token 已加入黑名单，过期时间: {} 秒", ttl.getSeconds());
    }

    /**
     * 计算 Token 的剩余有效时间。
     *
     * @param token JWT Token 字符串
     * @return Token 剩余有效期；若解析失败则返回默认兜底时间
     */
    private Duration calculateTokenTtl(String token) {
        try {
            // 解析 Token 的过期时间
            Date expiration = jwtUtils.getExpirationDate(token);
            // 计算当前时间到过期时间的差值
            long remainMillis = expiration.getTime() - System.currentTimeMillis();
            if (remainMillis > 0) {
                return Duration.ofMillis(remainMillis);
            }
        } catch (Exception e) {
            log.warn("解析 Token 过期时间失败: {}", e.getMessage());
        }
        // 解析失败或 Token 已过期，使用默认兜底过期时间
        return TokenBlacklistConstant.DEFAULT_BLACKLIST_TTL;
    }
}
