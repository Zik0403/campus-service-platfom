package com.campus.service.converter;

import com.campus.service.dto.UserLoginDTO;
import com.campus.service.dto.UserRegisterStudentDTO;
import com.campus.service.dto.UserRegisterWorkerDTO;
import com.campus.service.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

/**
 * 用户实体与 DTO 转换映射器。
 * <p>
 * 使用 MapStruct 在编译期自动生成类型安全的转换代码，
 * 用于登录、注册等场景下的 DTO 到 {@link User} 实体转换。
 * </p>
 *
 * @author campus-service
 */
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface UserConverter {

    /**
     * 学生注册 DTO 转换为 User 实体。
     *
     * @param dto 学生注册入参 DTO
     * @return 用户实体对象
     */
    User registerStudentDtoToEntity(UserRegisterStudentDTO dto);

    /**
     * 维修人员/工作人员注册 DTO 转换为 User 实体。
     *
     * @param dto 工作人员注册入参 DTO
     * @return 用户实体对象
     */
    User registerWorkerDtoToEntity(UserRegisterWorkerDTO dto);

    /**
     * 登录 DTO 转换为 User 实体。
     * <p>
     * 登录 DTO 中的 account 字段（学号/手机号）在 User 实体中没有对应字段，
     * 因此通过 {@code unmappedTargetPolicy = IGNORE} 忽略未映射属性。
     * </p>
     *
     * @param dto 登录入参 DTO
     * @return 用户实体对象
     */
    User loginDtoToEntity(UserLoginDTO dto);

    /**
     * User 实体转换为登录 DTO。
     *
     * @param user 用户实体对象
     * @return 登录响应 DTO
     */
    UserLoginDTO entityToLoginDto(User user);
}
