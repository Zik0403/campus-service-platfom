package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.ClubMember;

import java.util.List;

/**
 * 社团成员服务接口。
 * 负责学生加入社团的全流程管理：提交入社申请、社团负责人审核、设置成员身份、
 * 成员退出，以及查询社团成员、申请记录和权限校验等。
 */
public interface ClubMemberService extends IService<ClubMember> {

    /**
     * 学生申请加入指定社团。
     * @param userId 申请加入的学生用户ID
     * @param clubId 目标社团ID
     * @return 生成的入社申请记录，状态通常为待审核
     */
    ClubMember applyJoin(Long userId, Long clubId);

    /**
     * 社团负责人审核通过入社申请。
     * @param memberId 入社申请记录ID
     * @param approverId 审核人用户ID（一般为社团负责人）
     */
    void approveJoin(Long memberId, Long approverId);

    /**
     * 社团负责人驳回入社申请。
     * @param memberId 入社申请记录ID
     * @param approverId 审核人用户ID
     * @param reason 驳回原因
     */
    void rejectJoin(Long memberId, Long approverId, String reason);

    /**
     * 社团负责人将指定成员移出社团。
     * @param memberId 成员记录ID
     * @param operatorId 执行操作的用户ID
     */
    void removeMember(Long memberId, Long operatorId);

    /**
     * 社团负责人设置成员在社团中的身份。
     * @param memberId 成员记录ID
     * @param operatorId 执行操作的用户ID
     * @param identity 成员身份（例如：1社长 2副社长 3管理员 4普通成员）
     */
    void setIdentity(Long memberId, Long operatorId, Integer identity);

    /**
     * 学生主动退出社团。
     * @param clubId 社团ID
     * @param userId 当前操作用户ID
     */
    void quitClub(Long clubId, Long userId);

    /**
     * 学生在申请待审核期间取消入社申请。
     * @param clubId 社团ID
     * @param userId 当前操作用户ID
     */
    void cancelApply(Long clubId, Long userId);

    /**
     * 查询某个社团的所有成员列表。
     * @param clubId 社团ID
     * @return 该社团的成员列表
     */
    List<ClubMember> getClubMembers(Long clubId);

    /**
     * 查询某位学生加入的所有社团记录。
     * @param userId 学生用户ID
     * @return 该学生的社团成员记录列表
     */
    List<ClubMember> getUserClubs(Long userId);

    /**
     * 查询某位学生的全部社团申请记录，包括待审核、已通过、已退出等状态。
     * @param userId 学生用户ID
     * @return 该学生的全部社团申请记录列表
     */
    List<ClubMember> getUserAllApplications(Long userId);

    /**
     * 查询某个社团下所有待审核的入社申请。
     * @param clubId 社团ID
     * @return 待审核的入社申请列表
     */
    List<ClubMember> getPendingApplications(Long clubId);

    /**
     * 检查某位学生是否属于指定社团。
     * @param userId 学生用户ID
     * @param clubId 社团ID
     * @return 成员记录；如果不是该社团成员则返回null
     */
    ClubMember checkUserInClub(Long userId, Long clubId);

    /**
     * 检查某位学生是否是社团管理员（社长、副社长或管理员）。
     * @param userId 学生用户ID
     * @param clubId 社团ID
     * @return true表示是社团管理员，false表示不是
     */
    boolean isClubAdmin(Long userId, Long clubId);
}
