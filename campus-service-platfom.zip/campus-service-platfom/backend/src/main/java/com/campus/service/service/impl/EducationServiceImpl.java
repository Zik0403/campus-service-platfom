package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.*;
import com.campus.service.mapper.*;
import com.campus.service.service.EducationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 教务教学服务实现类。
 * <p>
 * 负责校园场景中与教学相关的核心业务，包括学生课表查询、成绩查询与绩点统计、
 * 考试安排查询、空教室/占用教室查询以及教室预约与取消等功能。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class EducationServiceImpl extends ServiceImpl<CourseScheduleMapper, CourseSchedule> implements EducationService {

    /** 学生成绩数据访问对象，用于查询 score 成绩表 */
    private final ScoreMapper scoreMapper;
    /** 教室信息数据访问对象，用于查询 classroom 教室表 */
    private final ClassroomMapper classroomMapper;
    /** 教室课表占用数据访问对象，用于查询 classroom_usage 教室使用表 */
    private final ClassroomUsageMapper classroomUsageMapper;
    /** 考试安排数据访问对象，用于查询 exam 考试表 */
    private final ExamMapper examMapper;
    /** 教室预约记录数据访问对象，用于查询 classroom_reservation 教室预约表 */
    private final ClassroomReservationMapper classroomReservationMapper;

    /**
     * 根据学生编号和学期查询个人课表。
     * <p>
     * 返回该学生在指定学期内的所有课程安排，结果按星期和开始节次升序排列，
     * 方便学生按时间顺序查看课表。
     * </p>
     *
     * @param studentId 学生编号，用于精确匹配课表记录中的学生
     * @param semester  学期标识，例如 2024-2025-1
     * @return 该学生的课表列表
     */
    @Override
    public List<CourseSchedule> getCourseSchedule(String studentId, String semester) {
        // 使用 MyBatis-Plus 的 Lambda 查询构造课表查询条件
        return list(new LambdaQueryWrapper<CourseSchedule>()
                // 按学生ID精确查询，只返回当前学生的课表
                .eq(CourseSchedule::getStudentId, studentId)
                // 按学期精确查询，只返回指定学期的课表
                .eq(CourseSchedule::getSemester, semester)
                // 按星期升序排列，方便从周一到周日展示
                .orderByAsc(CourseSchedule::getWeekDay)
                // 按开始节次升序排列，方便同一天内按时间先后展示
                .orderByAsc(CourseSchedule::getSectionStart));
    }

    /**
     * 根据学生编号和学期查询成绩列表。
     *
     * @param studentId 学生编号
     * @param semester  学期标识
     * @return 该学生在指定学期的成绩列表，按分数降序排列
     */
    @Override
    public List<Score> getScoreList(String studentId, String semester) {
        // 构造成绩查询条件，按学生ID和学期精确查询
        return scoreMapper.selectList(new LambdaQueryWrapper<Score>()
                // 精确匹配学生编号
                .eq(Score::getStudentId, studentId)
                // 精确匹配学期
                .eq(Score::getSemester, semester)
                // 按分数降序排列，方便先看到高分课程
                .orderByDesc(Score::getScore));
    }

    /**
     * 统计学生的成绩概况。
     * <p>
     * 汇总该学生所有学期的成绩信息，计算总学分、平均分、平均绩点、通过门数与总门数。
     * 如果没有任何成绩记录，则返回全部为零的默认值。
     * </p>
     *
     * @param studentId 学生编号
     * @return 包含成绩统计指标的结果Map
     */
    @Override
    public Map<String, Object> getScoreSummary(String studentId) {
        // 查询该学生的所有成绩记录，不限制学期
        List<Score> allScores = scoreMapper.selectList(new LambdaQueryWrapper<Score>()
                // 精确匹配学生编号，获取该学生全部历史成绩
                .eq(Score::getStudentId, studentId));

        // 创建结果容器，用于存放各项统计指标
        Map<String, Object> result = new HashMap<>();
        // 判断该学生是否没有任何成绩记录
        if (allScores.isEmpty()) {
            // 没有成绩时，总学分置为 0
            result.put("totalCredit", 0);
            // 没有成绩时，平均分数置为 0
            result.put("avgScore", 0);
            // 没有成绩时，平均绩点置为 0
            result.put("avgGradePoint", 0);
            // 没有成绩时，通过门数置为 0
            result.put("passedCount", 0);
            // 没有成绩时，总门数置为 0
            result.put("totalCount", 0);
            // 返回默认值，避免后续计算出现空指针
            return result;
        }

        // 汇总所有课程学分，用于计算总学分
        BigDecimal totalCredit = allScores.stream()
                // 取出每条成绩记录的学分字段
                .map(Score::getCredit)
                // 将学分逐个相加，初始值为 0
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // 计算平均分，只统计有具体分数的课程
        double avgScore = allScores.stream()
                // 过滤掉分数为空的成绩记录
                .filter(s -> s.getScore() != null)
                // 将 BigDecimal 分数转为 double 进行平均计算
                .mapToDouble(s -> s.getScore().doubleValue())
                // 求平均值
                .average()
                // 如果没有有效分数则返回 0
                .orElse(0);

        // 计算平均绩点，只统计有绩点的课程
        double avgGradePoint = allScores.stream()
                // 过滤掉绩点为空的成绩记录
                .filter(s -> s.getGradePoint() != null)
                // 将 BigDecimal 绩点转为 double
                .mapToDouble(s -> s.getGradePoint().doubleValue())
                // 求平均值
                .average()
                // 如果没有有效绩点则返回 0
                .orElse(0);

        // 统计分数大于等于 60 分的课程数量，即通过门数
        long passedCount = allScores.stream()
                // 过滤出分数非空且大于等于 60 分的记录
                .filter(s -> s.getScore() != null && s.getScore().compareTo(new BigDecimal("60")) >= 0)
                // 统计通过的课程数量
                .count();

        // 将总学分放入结果
        result.put("totalCredit", totalCredit);
        // 将平均分格式化为保留两位小数的字符串后放入结果
        result.put("avgScore", String.format("%.2f", avgScore));
        // 将平均绩点格式化为保留两位小数的字符串后放入结果
        result.put("avgGradePoint", String.format("%.2f", avgGradePoint));
        // 将通过门数放入结果
        result.put("passedCount", passedCount);
        // 将总课程门数放入结果
        result.put("totalCount", allScores.size());

        // 返回成绩统计结果
        return result;
    }

    /**
     * 查询指定条件下的空教室。
     * <p>
     * 根据教学楼、星期、节次查询当前可用的空教室。系统会排除课程占用和已审批/待审批的教室预约。
     * 如果未传入星期或节次，则仅返回符合教学楼条件的全部可用教室。
     * </p>
     *
     * @param building 教学楼名称，支持模糊匹配，可为空
     * @param weekDay  星期几，例如 1 表示周一
     * @param section  节次
     * @return 符合条件的空教室列表
     */
    @Override
    public List<Classroom> getEmptyClassrooms(String building, Integer weekDay, Integer section) {
        // 查询所有状态正常的教室，若传入教学楼则按教学楼模糊匹配
        List<Classroom> classrooms = classroomMapper.selectList(new LambdaQueryWrapper<Classroom>()
                // 只查询状态为正常的教室
                .eq(Classroom::getStatus, 1)
                // 如果教学楼参数不为空，则按教学楼名称模糊查询
                .like(building != null && !building.isEmpty(), Classroom::getBuilding, building));

        // 如果没有传入星期或节次，无法判断占用情况，直接返回全部可用教室
        if (weekDay == null || section == null) {
            return classrooms;
        }

        // 查询该星期、该节次下被课程占用的教室使用记录
        List<ClassroomUsage> usages = classroomUsageMapper.selectList(new LambdaQueryWrapper<ClassroomUsage>()
                // 精确匹配星期几
                .eq(ClassroomUsage::getWeekDay, weekDay)
                // 课程开始节次小于等于目标节次，说明目标节次在课程范围内
                .le(ClassroomUsage::getSectionStart, section)
                // 课程结束节次大于等于目标节次，说明目标节次在课程范围内
                .ge(ClassroomUsage::getSectionEnd, section)
                // 固定查询当前学期的教室使用数据
                .eq(ClassroomUsage::getSemester, "2024-2025-1"));

        // 收集被课程占用的教室ID集合
        Set<Long> usedClassroomIds = usages.stream()
                // 从教室使用记录中提取教室ID
                .map(ClassroomUsage::getClassroomId)
                // 收集为 Set，方便后续快速判断是否包含
                .collect(Collectors.toSet());

        // 获取今天的日期
        LocalDate today = LocalDate.now();
        // 根据星期几计算最近一个对应星期的日期，作为预约查询的目标日期
        LocalDate targetDate = today.plusDays((weekDay - (today.getDayOfWeek().getValue() == 0 ? 7 : today.getDayOfWeek().getValue()) + 7) % 7);

        // 查询目标日期、目标节次下处于有效状态的教室预约记录
        List<ClassroomReservation> reservations = classroomReservationMapper.selectList(
                new LambdaQueryWrapper<ClassroomReservation>()
                        // 精确匹配目标预约日期
                        .eq(ClassroomReservation::getReserveDate, targetDate)
                        // 预约开始节次小于等于目标节次
                        .le(ClassroomReservation::getSectionStart, section)
                        // 预约结束节次大于等于目标节次
                        .ge(ClassroomReservation::getSectionEnd, section)
                        // 状态为待审批或已通过的有效预约
                        .in(ClassroomReservation::getStatus, 1, 2));

        // 遍历预约记录，将被预约的教室ID也加入占用集合
        for (ClassroomReservation reservation : reservations) {
            // 把当前预约所占用的教室ID加入集合
            usedClassroomIds.add(reservation.getClassroomId());
        }

        // 从全部可用教室中过滤掉被课程或预约占用的教室，返回剩余的空教室
        return classrooms.stream()
                // 只保留不在占用集合中的教室
                .filter(c -> !usedClassroomIds.contains(c.getId()))
                // 将过滤结果收集为列表
                .collect(Collectors.toList());
    }

    /**
     * 查询指定条件下的占用教室详情。
     * <p>
     * 返回在指定教学楼、星期、节次下被课程或预约占用的教室列表，并附带占用原因、
     * 课程名称或预约人等信息，方便管理员或学生查看教室占用情况。
     * </p>
     *
     * @param building 教学楼名称，支持模糊匹配，可为空
     * @param weekDay  星期几
     * @param section  节次
     * @return 占用教室详情列表，每项为一个 Map
     */
    @Override
    public List<Map<String, Object>> getOccupiedClassrooms(String building, Integer weekDay, Integer section) {
        // 创建结果列表，用于存放占用教室的详细信息
        List<Map<String, Object>> result = new ArrayList<>();
        // 如果没有传入星期或节次，无法判断占用情况，直接返回空列表
        if (weekDay == null || section == null) {
            return result;
        }

        // 构造教室查询条件，查询所有状态正常的教室
        LambdaQueryWrapper<Classroom> classroomWrapper = new LambdaQueryWrapper<Classroom>()
                // 只查询状态正常的教室
                .eq(Classroom::getStatus, 1)
                // 如果传入教学楼则按名称模糊查询
                .like(building != null && !building.isEmpty(), Classroom::getBuilding, building);
        // 执行教室列表查询
        List<Classroom> allClassrooms = classroomMapper.selectList(classroomWrapper);

        // 查询课程占用记录
        List<ClassroomUsage> usages = classroomUsageMapper.selectList(new LambdaQueryWrapper<ClassroomUsage>()
                // 匹配星期几
                .eq(ClassroomUsage::getWeekDay, weekDay)
                // 目标节次在课程开始和结束节次之间
                .le(ClassroomUsage::getSectionStart, section)
                .ge(ClassroomUsage::getSectionEnd, section)
                // 固定学期
                .eq(ClassroomUsage::getSemester, "2024-2025-1"));
        // 将课程占用记录转换为以教室ID为键的Map，方便后续查找
        Map<Long, ClassroomUsage> usageMap = usages.stream()
                // 使用教室ID作为键，占用记录作为值
                .collect(Collectors.toMap(ClassroomUsage::getClassroomId, u -> u, (a, b) -> a));

        // 获取当前日期
        LocalDate today = LocalDate.now();
        // 计算目标日期
        LocalDate targetDate = today.plusDays((weekDay - (today.getDayOfWeek().getValue() == 0 ? 7 : today.getDayOfWeek().getValue()) + 7) % 7);

        // 查询有效状态的目标日期教室预约记录
        List<ClassroomReservation> reservations = classroomReservationMapper.selectList(
                new LambdaQueryWrapper<ClassroomReservation>()
                        // 匹配目标预约日期
                        .eq(ClassroomReservation::getReserveDate, targetDate)
                        // 目标节次在预约时间段内
                        .le(ClassroomReservation::getSectionStart, section)
                        .ge(ClassroomReservation::getSectionEnd, section)
                        // 只查询待审批或已通过的有效预约
                        .in(ClassroomReservation::getStatus, 1, 2));
        // 将预约记录转换为以教室ID为键的Map
        Map<Long, ClassroomReservation> reservationMap = reservations.stream()
                // 使用教室ID作为键，预约记录作为值
                .collect(Collectors.toMap(ClassroomReservation::getClassroomId, r -> r, (a, b) -> a));

        // 创建占用教室ID集合，合并课程占用和预约占用的教室ID
        Set<Long> occupiedIds = new HashSet<>();
        // 将所有课程占用的教室ID加入集合
        occupiedIds.addAll(usageMap.keySet());
        // 将所有预约占用的教室ID加入集合
        occupiedIds.addAll(reservationMap.keySet());

        // 遍历全部教室，只处理被占用的教室
        for (Classroom c : allClassrooms) {
            // 判断当前教室是否在占用集合中
            if (occupiedIds.contains(c.getId())) {
                // 创建单个占用教室的详情Map
                Map<String, Object> item = new HashMap<>();
                // 放入教室ID
                item.put("id", c.getId());
                // 放入教学楼名称
                item.put("building", c.getBuilding());
                // 放入教室房间号
                item.put("roomNo", c.getRoomNo());
                // 放入教室容量
                item.put("capacity", c.getCapacity());
                // 放入教室类型，如普通教室、多媒体教室等
                item.put("classroomType", c.getClassroomType());
                // 放入教室设备信息
                item.put("equipment", c.getEquipment());
                // 尝试获取该教室的课程占用信息
                ClassroomUsage u = usageMap.get(c.getId());
                // 尝试获取该教室的预约占用信息
                ClassroomReservation r = reservationMap.get(c.getId());
                // 如果存在课程占用
                if (u != null) {
                    // 标记占用原因为课程占用
                    item.put("reason", "课程占用");
                    // 放入课程名称
                    item.put("courseName", u.getCourseName());
                // 否则如果存在预约占用
                } else if (r != null) {
                    // 标记占用原因为已被预约
                    item.put("reason", "已被预约");
                    // 放入预约人用户ID
                    item.put("reserverId", r.getUserId());
                    // 放入预约用途说明
                    item.put("purpose", r.getPurpose());
                }
                // 将当前占用教室详情加入结果列表
                result.add(item);
            }
        }
        // 返回占用教室详情列表
        return result;
    }

    /**
     * 根据学生编号和学期查询考试安排列表。
     *
     * @param studentId 学生编号
     * @param semester  学期标识
     * @return 考试安排列表，按考试日期和开始时间升序排列
     */
    @Override
    public List<Exam> getExamList(String studentId, String semester) {
        // 构造考试查询条件，按学生和学期查询
        return examMapper.selectList(new LambdaQueryWrapper<Exam>()
                // 精确匹配学生编号
                .eq(Exam::getStudentId, studentId)
                // 精确匹配学期
                .eq(Exam::getSemester, semester)
                // 按考试日期升序排列
                .orderByAsc(Exam::getExamDate)
                // 同一天按开考时间升序排列
                .orderByAsc(Exam::getStartTime));
    }

    /**
     * 查询指定用户的教室预约记录。
     * <p>
     * 返回该用户提交的所有教室预约申请，并为每条记录填充对应的教室详情。
     * </p>
     *
     * @param userId 用户编号
     * @return 教室预约记录列表，按创建时间降序排列
     */
    @Override
    public List<ClassroomReservation> getClassroomReservations(Long userId) {
        // 查询该用户的所有教室预约记录，按创建时间倒序展示最新预约
        List<ClassroomReservation> reservations = classroomReservationMapper.selectList(
                new LambdaQueryWrapper<ClassroomReservation>()
                        // 精确匹配用户ID
                        .eq(ClassroomReservation::getUserId, userId)
                        // 按创建时间降序排列
                        .orderByDesc(ClassroomReservation::getCreateTime));
        // 遍历预约记录，为每条记录关联查询对应的教室详情
        for (ClassroomReservation reservation : reservations) {
            // 根据教室ID查询教室信息，并设置到预约记录中
            reservation.setClassroom(classroomMapper.selectById(reservation.getClassroomId()));
        }
        // 返回填充好教室信息的预约列表
        return reservations;
    }

    /**
     * 提交教室预约申请。
     * <p>
     * 校验教室是否存在且可预约、使用人数是否超过容量、目标时段是否与其他预约冲突、
     * 用户是否已有有效预约，校验通过后生成待审批的教室预约记录。
     * </p>
     *
     * @param userId       预约人用户编号
     * @param classroomId  目标教室编号
     * @param reserveDate  预约日期，字符串格式
     * @param sectionStart 开始节次
     * @param sectionEnd   结束节次
     * @param purpose      预约用途
     * @param peopleCount  使用人数
     * @return 创建成功的教室预约记录
     */
    @Override
    @Transactional
    public ClassroomReservation reserveClassroom(Long userId, Long classroomId, String reserveDate,
                                                  Integer sectionStart, Integer sectionEnd,
                                                  String purpose, Integer peopleCount) {
        // 根据教室ID查询教室基本信息
        Classroom classroom = classroomMapper.selectById(classroomId);
        // 判断教室是否存在
        if (classroom == null) {
            // 教室不存在，抛出未找到异常
            throw BusinessException.notFound("教室不存在");
        }
        // 判断教室状态是否为可预约
        if (classroom.getStatus() != 1) {
            // 教室状态异常，不可预约
            throw new BusinessException("教室不可预约");
        }
        // 如果传入了使用人数，判断是否超过教室最大容量
        if (peopleCount != null && peopleCount > classroom.getCapacity()) {
            // 使用人数超过容量，不允许预约
            throw new BusinessException("使用人数超过教室容量");
        }
        // 将预约日期字符串解析为 LocalDate 对象
        LocalDate date = LocalDate.parse(reserveDate);

        // 查询目标教室、目标日期、有效状态下与当前预约时间段冲突的记录数
        Long conflictCount = classroomReservationMapper.selectCount(
                new LambdaQueryWrapper<ClassroomReservation>()
                        // 同一教室
                        .eq(ClassroomReservation::getClassroomId, classroomId)
                        // 同一日期
                        .eq(ClassroomReservation::getReserveDate, date)
                        // 待审批或已通过的有效预约
                        .in(ClassroomReservation::getStatus, 1, 2)
                        // 新预约开始节次早于已有预约结束节次，可能存在重叠
                        .lt(ClassroomReservation::getSectionStart, sectionEnd)
                        // 新预约结束节次晚于已有预约开始节次，可能存在重叠
                        .gt(ClassroomReservation::getSectionEnd, sectionStart));
        // 如果存在冲突记录
        if (conflictCount > 0) {
            // 说明该时段已被占用，抛出业务异常
            throw new BusinessException("该时段教室已被预约");
        }

        // 查询该用户当前处于有效状态的教室预约数量
        Long userActiveCount = classroomReservationMapper.selectCount(
                new LambdaQueryWrapper<ClassroomReservation>()
                        // 精确匹配用户ID
                        .eq(ClassroomReservation::getUserId, userId)
                        // 待审批或已通过状态
                        .in(ClassroomReservation::getStatus, 1, 2));
        // 如果用户已经存在有效预约
        if (userActiveCount > 0) {
            // 提示用户先取消后再预约
            throw new BusinessException("您已有有效教室预约，请先取消后再预约");
        }

        // 创建新的教室预约实体对象
        ClassroomReservation reservation = new ClassroomReservation();
        // 设置预约人用户ID
        reservation.setUserId(userId);
        // 设置预约的教室ID
        reservation.setClassroomId(classroomId);
        // 设置预约日期
        reservation.setReserveDate(date);
        // 设置开始节次
        reservation.setSectionStart(sectionStart);
        // 设置结束节次
        reservation.setSectionEnd(sectionEnd);
        // 设置预约用途
        reservation.setPurpose(purpose);
        // 设置使用人数
        reservation.setPeopleCount(peopleCount);
        // 设置预约状态为待审批
        reservation.setStatus(2);
        // 设置未删除标记
        reservation.setIsDelete(0);
        // 将预约记录插入 classroom_reservation 表
        classroomReservationMapper.insert(reservation);
        // 将教室信息设置到预约记录中，方便返回给前端展示
        reservation.setClassroom(classroom);
        // 记录预约成功的日志
        log.info("教室预约成功: reservationId={}, userId={}, classroomId={}", reservation.getId(), userId, classroomId);
        // 返回创建成功的预约记录
        return reservation;
    }

    /**
     * 取消教室预约。
     * <p>
     * 校验预约记录存在、当前用户有权限操作且状态允许取消，
     * 校验通过后将预约状态更新为已取消。
     * </p>
     *
     * @param userId        当前操作用户编号
     * @param reservationId 要取消的预约记录编号
     */
    @Override
    @Transactional
    public void cancelClassroomReservation(Long userId, Long reservationId) {
        // 根据预约ID查询预约记录
        ClassroomReservation reservation = classroomReservationMapper.selectById(reservationId);
        // 判断预约记录是否存在
        if (reservation == null) {
            // 预约记录不存在，抛出未找到异常
            throw BusinessException.notFound("预约记录不存在");
        }
        // 判断当前用户是否为该预约的提交人
        if (!reservation.getUserId().equals(userId)) {
            // 不是本人提交，无权限操作
            throw BusinessException.forbidden("无权限操作");
        }
        // 判断预约状态是否为可取消的状态，只有待审批或已通过才能取消
        if (reservation.getStatus() != 1 && reservation.getStatus() != 2) {
            // 当前状态不允许取消
            throw new BusinessException("当前状态不可取消");
        }
        // 将预约状态设置为已取消
        reservation.setStatus(4);
        // 更新 classroom_reservation 表中的预约记录
        classroomReservationMapper.updateById(reservation);
        // 记录取消预约的日志
        log.info("取消教室预约: reservationId={}, userId={}", reservationId, userId);
    }
}
