package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.SysLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 系统操作日志数据访问接口。
 *
 * <p>操作的数据库表为系统日志表，对应实体类为 {@link SysLog}。
 * 主要负责记录用户或系统关键操作的日志查询，例如按用户查询操作记录、按操作类型查询日志。</p>
 */
@Mapper
public interface SysLogMapper extends BaseMapper<SysLog> {

    /**
     * 根据用户 ID 查询该用户的操作日志。
     *
     * @param userId 用户 ID
     * @return 该用户的操作日志列表
     */
    List<SysLog> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据操作类型查询日志。
     *
     * @param action 操作类型，例如登录、下单、发布等
     * @return 该类型的操作日志列表
     */
    List<SysLog> selectByAction(@Param("action") String action);
}
