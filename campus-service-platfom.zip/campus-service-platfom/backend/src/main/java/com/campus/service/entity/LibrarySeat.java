package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 图书馆座位表。
 * 存储图书馆各楼层区域座位的基本信息与设施属性，
 * 是座位预约、签到、空座查询的数据基础。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("library_seat") // 指定对应的数据库表名为 library_seat
public class LibrarySeat implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 座位主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 楼层，如 1、2、3。
     */
    private Integer floor;

    /**
     * 区域名称，如“自习区 A”“静音区”。
     */
    private String area;

    /**
     * 座位编号，如“A-01”。
     */
    private String seatNo;

    /**
     * 是否有电源插座：0 无、1 有。
     */
    private Integer hasSocket;

    /**
     * 是否靠窗：0 否、1 是。
     */
    private Integer hasWindow;

    /**
     * 座位状态：0 不可用、1 可用，控制是否开放预约。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录座位信息首次录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录座位信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
