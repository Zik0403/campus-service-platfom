package com.campus.service.config;

import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.region.Region;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * OSS 对象存储配置类。
 * <p>
 * 根据 {@link OssProperties} 中的腾讯云 COS 配置初始化 COSClient，
 * 供头像上传等文件上传功能使用。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Configuration
@EnableConfigurationProperties(OssProperties.class)
public class OssConfig {

    /**
     * 创建腾讯云 COS 客户端。
     * <p>
     * 从 endpoint 中解析出 Region，例如 https://cos.ap-guangzhou.myqcloud.com
     * 会解析出 ap-guangzhou。
     * </p>
     *
     * @param ossProperties OSS 配置属性
     * @return 腾讯云 COS 客户端
     */
    @Bean
    public COSClient cosClient(OssProperties ossProperties) {
        // 构造访问凭证
        COSCredentials credentials = new BasicCOSCredentials(ossProperties.getAccessKey(), ossProperties.getSecretKey());
        // 从 endpoint 解析出 region 名称
        String regionName = extractRegion(ossProperties.getEndpoint());
        // 创建客户端配置，指定 Region
        ClientConfig clientConfig = new ClientConfig(new Region(regionName));
        // 返回 COS 客户端
        return new COSClient(credentials, clientConfig);
    }

    /**
     * 从 COS Endpoint 中解析出 Region。
     * <p>
     * 支持的格式：
     * <ul>
     *   <li>https://cos.ap-guangzhou.myqcloud.com</li>
     *   <li>http://cos.ap-beijing.myqcloud.com</li>
     * </ul>
     * 解析失败时默认返回 ap-guangzhou。
     * </p>
     *
     * @param endpoint COS 服务端点
     * @return Region 名称
     */
    private String extractRegion(String endpoint) {
        if (endpoint == null || endpoint.isEmpty()) {
            return "ap-guangzhou";
        }
        // 去掉协议头
        String host = endpoint.replaceFirst("https?://", "");
        // 去掉末尾斜杠
        host = host.replaceFirst("/$", "");
        // 期望格式为 cos.{region}.myqcloud.com
        if (host.startsWith("cos.")) {
            int start = host.indexOf('.') + 1;
            int end = host.indexOf(".myqcloud.com");
            if (end > start) {
                return host.substring(start, end);
            }
        }
        // 解析失败时使用默认 Region
        log.warn("无法从 endpoint 解析 Region，使用默认值：endpoint={}", endpoint);
        return "ap-guangzhou";
    }
}
