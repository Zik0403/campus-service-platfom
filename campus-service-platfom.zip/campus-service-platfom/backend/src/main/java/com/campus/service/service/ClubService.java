package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.Club;

import java.util.List;

/**
 * 社团服务接口。
 * 负责校园社团的创建、审核、分类浏览与搜索：学生可申请创建社团，管理员审核通过后，
 * 其他学生即可按分类浏览、搜索并加入感兴趣的社团。
 */
public interface ClubService extends IService<Club> {

    /**
     * 学生申请创建新社团。
     * @param userId 申请人用户ID
     * @param name 社团名称
     * @param logo 社团Logo图片地址
     * @param intro 社团简介
     * @param category 社团分类（例如：文艺、体育、学术、公益等）
     * @return 创建后的社团对象，通常处于待审核状态
     */
    Club createClub(Long userId, String name, String logo, String intro, String category);

    /**
     * 管理员审核社团创建申请。
     * @param clubId 社团ID
     * @param auditStatus 审核状态（例如：0待审核 1通过 2拒绝）
     */
    void auditClub(Long clubId, Integer auditStatus);

    /**
     * 查询所有已经审核通过的社团列表。
     * @return 已审核社团列表
     */
    List<Club> getAuditedClubs();

    /**
     * 按分类查询已审核通过的社团。
     * @param category 社团分类
     * @return 该分类下的社团列表
     */
    List<Club> getClubsByCategory(String category);

    /**
     * 根据关键词搜索社团（名称或简介匹配）。
     * @param keyword 搜索关键词
     * @return 符合条件的社团列表
     */
    List<Club> searchClubs(String keyword);

    /**
     * 查询某个社团的详细信息。
     * @param clubId 社团ID
     * @return 社团详情对象
     */
    Club getClubDetail(Long clubId);
}
