package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.ClassroomUsage;
import org.apache.ibatis.annotations.Mapper;

/**
 * 教室使用情况数据访问接口。
 *
 * <p>操作的数据库表为教室使用记录表，对应实体类为 {@link ClassroomUsage}。
 * 主要负责记录教室实际使用情况的增删改查，例如某教室某时间段是否被占用。</p>
 */
@Mapper
public interface ClassroomUsageMapper extends BaseMapper<ClassroomUsage> {
}
