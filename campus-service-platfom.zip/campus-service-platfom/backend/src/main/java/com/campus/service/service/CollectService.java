package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.Collect;

import java.util.List;

/**
 * 收藏服务接口。
 * 负责学生在校园生活服务平台中的收藏行为：可以收藏感兴趣的二手商品、失物招领、
 * 帖子等内容，也可以取消收藏并查看自己的收藏列表。
 */
public interface CollectService extends IService<Collect> {

    /**
     * 用户收藏指定目标内容。
     * @param userId 操作用户ID
     * @param targetType 收藏目标类型（例如：1二手商品 2失物招领 3帖子等）
     * @param targetId 收藏目标内容的ID
     */
    void addCollect(Long userId, Integer targetType, Long targetId);

    /**
     * 用户取消对指定目标内容的收藏。
     * @param userId 操作用户ID
     * @param targetType 收藏目标类型
     * @param targetId 收藏目标内容的ID
     */
    void removeCollect(Long userId, Integer targetType, Long targetId);

    /**
     * 判断用户是否已经收藏指定目标内容。
     * @param userId 操作用户ID
     * @param targetType 收藏目标类型
     * @param targetId 收藏目标内容的ID
     * @return true表示已收藏，false表示未收藏
     */
    boolean isCollected(Long userId, Integer targetType, Long targetId);

    /**
     * 查询某位用户的全部收藏记录。
     * @param userId 用户ID
     * @return 该用户的收藏记录列表
     */
    List<Collect> getUserCollects(Long userId);
}
