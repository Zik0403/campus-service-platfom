package com.campus.service.controller;

import com.campus.service.entity.ClubMember;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.ClubMemberService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 社团成员控制器
 */
@RestController
@RequestMapping("/member")
@RequiredArgsConstructor
public class ClubMemberController {

    private final ClubMemberService memberService;

    /**
     * 申请加入社团
     */
    @PostMapping("/join")
    public R<ClubMember> applyJoin(HttpServletRequest request, 
                                    @RequestBody(required = false) java.util.Map<String, Object> body,
                                    @RequestParam(required = false) Long clubId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long targetClubId = clubId;
        if (targetClubId == null && body != null) {
            Object clubIdObj = body.get("clubId");
            if (clubIdObj != null) {
                targetClubId = Long.parseLong(clubIdObj.toString());
            }
        }
        if (targetClubId == null) {
            return R.error("缺少社团ID");
        }
        ClubMember member = memberService.applyJoin(userId, targetClubId);
        return R.success(member);
    }

    /**
     * 审核通过入社申请
     */
    @PostMapping("/approve")
    public R<Void> approveJoin(HttpServletRequest request, 
                               @RequestBody(required = false) java.util.Map<String, Object> body,
                               @RequestParam(required = false) Long memberId) {
        Long approverId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long targetMemberId = memberId;
        if (targetMemberId == null && body != null) {
            Object memberIdObj = body.get("memberId");
            if (memberIdObj != null) {
                targetMemberId = Long.parseLong(memberIdObj.toString());
            }
        }
        if (targetMemberId == null) {
            return R.error("缺少成员ID");
        }
        memberService.approveJoin(targetMemberId, approverId);
        return R.success();
    }

    /**
     * 驳回入社申请
     */
    @PostMapping("/reject")
    public R<Void> rejectJoin(HttpServletRequest request,
                               @RequestBody(required = false) java.util.Map<String, Object> body,
                               @RequestParam(required = false) Long memberId,
                               @RequestParam(required = false) String reason) {
        Long approverId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long targetMemberId = memberId;
        String targetReason = reason;
        if (targetMemberId == null && body != null) {
            Object memberIdObj = body.get("memberId");
            if (memberIdObj != null) {
                targetMemberId = Long.parseLong(memberIdObj.toString());
            }
            Object reasonObj = body.get("reason");
            if (reasonObj != null) {
                targetReason = reasonObj.toString();
            }
        }
        if (targetMemberId == null) {
            return R.error("缺少成员ID");
        }
        memberService.rejectJoin(targetMemberId, approverId, targetReason);
        return R.success();
    }

    /**
     * 移除成员
     */
    @PostMapping("/remove")
    public R<Void> removeMember(HttpServletRequest request, 
                                @RequestBody(required = false) java.util.Map<String, Object> body,
                                @RequestParam(required = false) Long memberId) {
        Long operatorId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long targetMemberId = memberId;
        if (targetMemberId == null && body != null) {
            Object memberIdObj = body.get("memberId");
            if (memberIdObj != null) {
                targetMemberId = Long.parseLong(memberIdObj.toString());
            }
        }
        if (targetMemberId == null) {
            return R.error("缺少成员ID");
        }
        memberService.removeMember(targetMemberId, operatorId);
        return R.success();
    }

    /**
     * 设置成员身份
     */
    @PutMapping("/identity")
    public R<Void> setIdentity(HttpServletRequest request,
                                @RequestParam Long memberId,
                                @RequestParam Integer identity) {
        Long operatorId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        memberService.setIdentity(memberId, operatorId, identity);
        return R.success();
    }

    /**
     * 成员退出社团
     */
    @PostMapping("/quit")
    public R<Void> quitClub(HttpServletRequest request, 
                            @RequestBody(required = false) java.util.Map<String, Object> body,
                            @RequestParam(required = false) Long clubId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long targetClubId = clubId;
        if (targetClubId == null && body != null) {
            Object clubIdObj = body.get("clubId");
            if (clubIdObj != null) {
                targetClubId = Long.parseLong(clubIdObj.toString());
            }
        }
        if (targetClubId == null) {
            return R.error("缺少社团ID");
        }
        memberService.quitClub(targetClubId, userId);
        return R.success();
    }

    /**
     * 取消入社申请
     */
    @PostMapping("/cancel")
    public R<Void> cancelApply(HttpServletRequest request, 
                               @RequestBody(required = false) java.util.Map<String, Object> body,
                               @RequestParam(required = false) Long clubId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long targetClubId = clubId;
        if (targetClubId == null && body != null) {
            Object clubIdObj = body.get("clubId");
            if (clubIdObj != null) {
                targetClubId = Long.parseLong(clubIdObj.toString());
            }
        }
        if (targetClubId == null) {
            return R.error("缺少社团ID");
        }
        memberService.cancelApply(targetClubId, userId);
        return R.success();
    }

    /**
     * 获取社团成员列表
     */
    @GetMapping("/list")
    public R<List<ClubMember>> getClubMembers(@RequestParam Long clubId) {
        return R.success(memberService.getClubMembers(clubId));
    }

    /**
     * 获取我加入的社团列表
     */
    @GetMapping("/my/clubs")
    public R<List<ClubMember>> getUserClubs(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(memberService.getUserClubs(userId));
    }

    /**
     * 获取我的所有社团申请记录（包含待审核、已通过、已拒绝）
     */
    @GetMapping("/my/applications")
    public R<List<ClubMember>> getUserApplications(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(memberService.getUserAllApplications(userId));
    }

    /**
     * 获取待审核的入社申请列表
     */
    @GetMapping("/pending")
    public R<List<ClubMember>> getPendingApplications(@RequestParam Long clubId) {
        return R.success(memberService.getPendingApplications(clubId));
    }

    /**
     * 检查用户是否是社团成员
     */
    @GetMapping("/check")
    public R<ClubMember> checkUserInClub(HttpServletRequest request, @RequestParam Long clubId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        ClubMember member = memberService.checkUserInClub(userId, clubId);
        return R.success(member);
    }
}