package com.campus.service.controller;

import com.campus.service.entity.*;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.LibraryService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/library")
@RequiredArgsConstructor
public class LibraryController {

    private final LibraryService libraryService;

    @GetMapping("/book/search")
    public R<List<LibraryBook>> searchBooks(@RequestParam(required = false) String keyword,
                                             @RequestParam(required = false) String category) {
        return R.success(libraryService.searchBooks(keyword, category));
    }

    @GetMapping("/book/detail")
    public R<LibraryBook> getBookDetail(@RequestParam Long id) {
        return R.success(libraryService.getBookDetail(id));
    }

    @GetMapping("/borrow/list")
    public R<List<BorrowRecord>> getBorrowRecords(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(libraryService.getBorrowRecords(userId));
    }

    @PostMapping("/borrow/add")
    public R<BorrowRecord> borrowBook(HttpServletRequest request,
                                       @RequestBody(required = false) java.util.Map<String, Object> body,
                                       @RequestParam(required = false) Long bookId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (bookId == null && body != null && body.get("bookId") != null) {
            bookId = Long.valueOf(body.get("bookId").toString());
        }
        return R.success(libraryService.borrowBook(userId, bookId));
    }

    @PostMapping("/borrow/return")
    public R<Void> returnBook(HttpServletRequest request,
                               @RequestBody(required = false) java.util.Map<String, Object> body,
                               @RequestParam(required = false) Long recordId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (recordId == null && body != null && body.get("recordId") != null) {
            recordId = Long.valueOf(body.get("recordId").toString());
        }
        libraryService.returnBook(userId, recordId);
        return R.success();
    }

    @PostMapping("/borrow/renew")
    public R<Void> renewBook(HttpServletRequest request,
                              @RequestBody(required = false) java.util.Map<String, Object> body,
                              @RequestParam(required = false) Long recordId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (recordId == null && body != null && body.get("recordId") != null) {
            recordId = Long.valueOf(body.get("recordId").toString());
        }
        libraryService.renewBook(userId, recordId);
        return R.success();
    }

    @GetMapping("/reservation/list")
    public R<List<BookReservation>> getBookReservations(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(libraryService.getBookReservations(userId));
    }

    @PostMapping("/reservation/add")
    public R<BookReservation> reserveBook(HttpServletRequest request,
                                           @RequestBody(required = false) java.util.Map<String, Object> body,
                                           @RequestParam(required = false) Long bookId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (bookId == null && body != null && body.get("bookId") != null) {
            bookId = Long.valueOf(body.get("bookId").toString());
        }
        return R.success(libraryService.reserveBook(userId, bookId));
    }

    @PostMapping("/reservation/cancel")
    public R<Void> cancelBookReservation(HttpServletRequest request,
                                          @RequestBody(required = false) java.util.Map<String, Object> body,
                                          @RequestParam(required = false) Long reservationId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (reservationId == null && body != null && body.get("reservationId") != null) {
            reservationId = Long.valueOf(body.get("reservationId").toString());
        }
        libraryService.cancelBookReservation(userId, reservationId);
        return R.success();
    }

    @GetMapping("/seat/list")
    public R<List<LibrarySeat>> getSeatList(@RequestParam(required = false) Integer floor,
                                             @RequestParam(required = false) String hasSocket,
                                             @RequestParam(required = false) String hasWindow) {
        return R.success(libraryService.getSeatList(floor, hasSocket, hasWindow));
    }

    @PostMapping("/seat/reserve")
    public R<SeatReservation> reserveSeat(HttpServletRequest request,
                                           @RequestBody java.util.Map<String, Object> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long seatId = Long.valueOf(params.get("seatId").toString());
        String reserveDate = (String) params.get("reserveDate");
        String startTime = (String) params.get("startTime");
        String endTime = (String) params.get("endTime");
        return R.success(libraryService.reserveSeat(userId, seatId, reserveDate, startTime, endTime));
    }

    @GetMapping("/seat/my-reservations")
    public R<List<SeatReservation>> getMyReservations(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(libraryService.getMyReservations(userId));
    }

    @PostMapping("/seat/cancel")
    public R<Void> cancelReservation(HttpServletRequest request,
                                      @RequestBody(required = false) java.util.Map<String, Object> body,
                                      @RequestParam(required = false) Long reservationId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (reservationId == null && body != null && body.get("reservationId") != null) {
            reservationId = Long.valueOf(body.get("reservationId").toString());
        }
        libraryService.cancelReservation(userId, reservationId);
        return R.success();
    }

    @PostMapping("/seat/checkin")
    public R<Void> checkinSeat(HttpServletRequest request,
                                 @RequestBody(required = false) java.util.Map<String, Object> body,
                                 @RequestParam(required = false) Long reservationId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (reservationId == null && body != null && body.get("reservationId") != null) {
            reservationId = Long.valueOf(body.get("reservationId").toString());
        }
        libraryService.checkinSeat(userId, reservationId);
        return R.success();
    }

    @PostMapping("/seat/checkout")
    public R<Void> checkoutSeat(HttpServletRequest request,
                                  @RequestBody(required = false) java.util.Map<String, Object> body,
                                  @RequestParam(required = false) Long reservationId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (reservationId == null && body != null && body.get("reservationId") != null) {
            reservationId = Long.valueOf(body.get("reservationId").toString());
        }
        libraryService.checkoutSeat(userId, reservationId);
        return R.success();
    }

    @PostMapping("/study/checkin")
    public R<StudyCheckin> studyCheckin(HttpServletRequest request,
                                         @RequestBody java.util.Map<String, Object> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String location = (String) params.get("location");
        String note = (String) params.get("note");
        return R.success(libraryService.studyCheckin(userId, location, note));
    }

    @GetMapping("/study/list")
    public R<List<StudyCheckin>> getStudyCheckinList(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(libraryService.getStudyCheckinList(userId));
    }

    @GetMapping("/study/statistics")
    public R<Map<String, Object>> getStudyStatistics(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(libraryService.getStudyStatistics(userId));
    }
}
