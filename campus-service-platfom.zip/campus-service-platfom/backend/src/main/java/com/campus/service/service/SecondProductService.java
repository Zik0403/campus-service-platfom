package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.SecondProduct;

import java.util.List;

/**
 * 二手商品服务接口。
 * 负责校园二手市场商品的全生命周期管理：学生可以发布闲置物品，
 * 管理员审核通过后商品上架，支持按分类浏览、搜索、上下架、编辑和删除。
 */
public interface SecondProductService extends IService<SecondProduct> {

    /**
     * 学生发布一件二手商品。
     * @param sellerId 卖家用户ID
     * @param title 商品标题
     * @param category 商品分类（例如：书籍、电子产品、生活用品等）
     * @param price 商品价格
     * @param description 商品详细描述
     * @param images 商品图片地址，多张图片通常以逗号分隔
     * @param allowBargain 是否允许议价（1允许 0不允许）
     * @param validDay 商品有效天数
     * @return 发布后的二手商品对象
     */
    SecondProduct createProduct(Long sellerId, String title, String category, String price,
                                 String description, String images, Integer allowBargain, Integer validDay);

    /**
     * 卖家修改自己发布的二手商品信息。
     * @param productId 商品ID
     * @param userId 当前操作用户ID
     * @param title 商品标题
     * @param category 商品分类
     * @param price 商品价格
     * @param description 商品详细描述
     * @param images 商品图片地址
     * @param allowBargain 是否允许议价
     */
    void updateProduct(Long productId, Long userId, String title, String category,
                       String price, String description, String images, Integer allowBargain);

    /**
     * 管理员审核二手商品是否可以展示。
     * @param productId 商品ID
     * @param auditStatus 审核状态（例如：0待审核 1通过 2拒绝）
     */
    void auditProduct(Long productId, Integer auditStatus);

    /**
     * 卖家将已审核通过的商品重新上架。
     * @param productId 商品ID
     * @param userId 当前操作用户ID
     */
    void onlineProduct(Long productId, Long userId);

    /**
     * 卖家将商品暂时下架。
     * @param productId 商品ID
     * @param userId 当前操作用户ID
     */
    void offlineProduct(Long productId, Long userId);

    /**
     * 卖家删除自己发布的二手商品。
     * @param productId 商品ID
     * @param userId 当前操作用户ID
     */
    void deleteProduct(Long productId, Long userId);

    /**
     * 查询某件二手商品的详细信息。
     * @param productId 商品ID
     * @return 商品详情对象
     */
    SecondProduct getProductDetail(Long productId);

    /**
     * 查询某位卖家发布的所有二手商品。
     * @param sellerId 卖家用户ID
     * @return 该卖家的商品列表
     */
    List<SecondProduct> getSellerProducts(Long sellerId);

    /**
     * 按分类查询已上架的二手商品列表。
     * @param category 商品分类
     * @return 该分类下的商品列表
     */
    List<SecondProduct> getProductsByCategory(String category);

    /**
     * 根据关键词搜索已上架的二手商品。
     * @param keyword 搜索关键词
     * @return 符合条件的商品列表
     */
    List<SecondProduct> searchProducts(String keyword);

    /**
     * 查询所有待管理员审核的二手商品。
     * @return 待审核商品列表
     */
    List<SecondProduct> getPendingAuditProducts();

    /**
     * 查询已经超过有效期的二手商品。
     * @return 过期商品列表
     */
    List<SecondProduct> getExpiredProducts();
}
