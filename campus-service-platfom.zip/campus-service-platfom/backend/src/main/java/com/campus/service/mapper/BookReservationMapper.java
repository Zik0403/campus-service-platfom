package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.BookReservation;
import org.apache.ibatis.annotations.Mapper;

/**
 * 图书预约数据访问接口。
 *
 * <p>操作的数据库表为图书预约表，对应实体类为 {@link BookReservation}。
 * 主要负责图书馆中用户对图书预约记录的增删改查，例如学生提前预约想借阅的图书。</p>
 */
@Mapper
public interface BookReservationMapper extends BaseMapper<BookReservation> {
}
