package com.campus.service.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.service.entity.Club;
import com.campus.service.entity.ClubMember;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.ClubMemberService;
import com.campus.service.service.ClubService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/club")
@RequiredArgsConstructor
public class ClubController {

    private final ClubService clubService;
    private final ClubMemberService clubMemberService;

    /**
     * 获取社团列表
     */
    @GetMapping("/list")
    public R<List<Club>> getClubList(@RequestParam(required = false) String category,
                                   @RequestParam(required = false) String keyword) {
        if (keyword != null && !keyword.isEmpty()) {
            return R.success(clubService.searchClubs(keyword));
        }
        if (category != null && !category.isEmpty()) {
            return R.success(clubService.getClubsByCategory(category));
        }
        return R.success(clubService.getAuditedClubs());
    }

    /**
     * 获取社团详情
     */
    @GetMapping("/detail")
    public R<Club> getClubDetail(@RequestParam Long clubId) {
        return R.success(clubService.getClubDetail(clubId));
    }

    /**
     * 申请创建社团
     */
    @PostMapping("/create")
    public R<Club> createClub(HttpServletRequest request,
                               @RequestParam String name,
                               @RequestParam(required = false) String logo,
                               @RequestParam(required = false) String intro,
                               @RequestParam(required = false) String category) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Club club = clubService.createClub(userId, name, logo, intro, category);
        return R.success(club);
    }

    /**
     * 更新社团信息
     */
    @PutMapping("/update")
    public R<Void> updateClub(HttpServletRequest request,
                               @RequestParam Long clubId,
                               @RequestParam(required = false) String name,
                               @RequestParam(required = false) String logo,
                               @RequestParam(required = false) String intro,
                               @RequestParam(required = false) String category) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        // 校验是否是社团管理员
        if (!clubMemberService.isClubAdmin(userId, clubId)) {
            return R.error("您不是社团管理员，无法修改社团信息");
        }
        Club club = clubService.getById(clubId);
        if (club == null) {
            return R.error("社团不存在");
        }
        if (name != null) club.setName(name);
        if (logo != null) club.setLogo(logo);
        if (intro != null) club.setIntro(intro);
        if (category != null) club.setCategory(category);
        clubService.updateById(club);
        return R.success();
    }

    /**
     * 审核社团（管理员操作）
     */
    @PostMapping("/audit")
    public R<Void> auditClub(@RequestParam Long clubId, @RequestParam Integer auditStatus) {
        clubService.auditClub(clubId, auditStatus);
        return R.success();
    }

    /**
     * 获取我管理的社团列表（我是社长/副社长/管理员的社团）
     */
    @GetMapping("/my/list")
    public R<List<Club>> getMyClubs(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        List<ClubMember> members = clubMemberService.getUserClubs(userId);
        // 筛选出身份为管理员（identity<=3）的社团
        List<Long> clubIds = members.stream()
                .filter(m -> m.getIdentity() != null && m.getIdentity() <= 3)
                .map(ClubMember::getClubId)
                .collect(Collectors.toList());
        if (clubIds.isEmpty()) {
            return R.success(List.of());
        }
        List<Club> clubs = clubService.listByIds(clubIds);
        return R.success(clubs);
    }

    /**
     * 获取待审核的社团列表（管理员操作）
     */
    @GetMapping("/pending")
    public R<List<Club>> getPendingClubs() {
        return R.success(clubService.list(new LambdaQueryWrapper<Club>()
                .eq(Club::getAuditStatus, 1)
                .orderByDesc(Club::getCreateTime)));
    }
}
