package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.Coupon;

import java.util.List;

/**
 * 优惠券服务接口。
 * 负责校园生活服务平台中的优惠券发放与领取：平台发布可领取的优惠券，
 * 学生可领取优惠券并在下单时使用，也可查看自己已领取的优惠券列表。
 */
public interface CouponService extends IService<Coupon> {

    /**
     * 查询当前可领取的优惠券列表。
     * @return 可领取优惠券列表
     */
    List<Coupon> getAvailableCoupons();

    /**
     * 用户领取指定优惠券。
     * @param userId 领取用户ID
     * @param couponId 优惠券ID
     */
    void receiveCoupon(Long userId, Long couponId);

    /**
     * 查询某位用户已领取的所有优惠券。
     * @param userId 用户ID
     * @return 该用户的优惠券列表
     */
    List<Coupon> getUserCoupons(Long userId);
}
