package com.campus.service.config;

import com.campus.service.handler.OrderWebSocketHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

/**
 * WebSocket 配置类。
 * <p>
 * 启用 Spring WebSocket 功能，并将 {@link OrderWebSocketHandler} 注册到指定路径，
 * 使前端可以通过长连接实时接收订单状态变更推送。
 * </p>
 * <p>
 * 连接地址（需加上 server.servlet.context-path）：{@code /api/ws/order?userId=xxx}
 * </p>
 *
 * @author campus-service
 */
@Configuration
@EnableWebSocket
@RequiredArgsConstructor
public class WebSocketConfig implements WebSocketConfigurer {

    /**
     * 订单变更 WebSocket 处理器，由 Spring 自动注入。
     */
    private final OrderWebSocketHandler orderWebSocketHandler;

    /**
     * 注册 WebSocket 处理器及连接路径。
     * <p>
     * 允许所有来源访问，便于小程序本地调试；生产环境可按需限制域名。
     * </p>
     *
     * @param registry WebSocket 处理器注册表
     */
    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // 将订单 WebSocket 处理器注册到 /ws/order 路径
        registry.addHandler(orderWebSocketHandler, "/ws/order")
                // 允许跨域，方便微信小程序开发和本地调试
                .setAllowedOrigins("*");
    }
}
