package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * 图书馆座位预约表。
 * 记录学生对图书馆座位的预约时段、签到签退时间与预约状态，
 * 支撑座位资源预约、到场签到、超时释放与违规统计。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("seat_reservation") // 指定对应的数据库表名为 seat_reservation
public class SeatReservation implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 座位预约主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 预约用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 预约座位 ID，关联 library_seat 表。
     */
    private Long seatId;

    /**
     * 预约日期。
     */
    private LocalDate reserveDate;

    /**
     * 预约开始时间。
     */
    private LocalTime startTime;

    /**
     * 预约结束时间。
     */
    private LocalTime endTime;

    /**
     * 签到时间，学生到达座位后扫码签到的时间。
     */
    private LocalDateTime checkinTime;

    /**
     * 签退时间，学生离开座位后扫码签退的时间。
     */
    private LocalDateTime checkoutTime;

    /**
     * 预约状态：1 预约中、2 已签到、3 已签退、4 已取消、5 超时释放等。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录预约首次提交时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录预约记录最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    /**
     * 关联座位对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private LibrarySeat seat;
}
