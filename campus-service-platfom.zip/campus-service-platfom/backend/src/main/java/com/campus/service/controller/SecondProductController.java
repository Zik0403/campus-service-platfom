package com.campus.service.controller;

import com.campus.service.entity.SecondProduct;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.SecondProductService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/product")
@RequiredArgsConstructor
public class SecondProductController {

    private final SecondProductService productService;

    private String getStr(Map<String, Object> body, String key, String defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        return v != null ? v.toString() : defaultValue;
    }

    private Long getLong(Map<String, Object> body, String key, Long defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Long.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    private Integer getInt(Map<String, Object> body, String key, Integer defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Integer.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    /**
     * 发布商品
     */
    @PostMapping("/create")
    public R<SecondProduct> createProduct(HttpServletRequest request,
                                           @RequestBody(required = false) Map<String, Object> body,
                                           @RequestParam(required = false) String title,
                                           @RequestParam(required = false) String category,
                                           @RequestParam(required = false) String price,
                                           @RequestParam(required = false) String description,
                                           @RequestParam(required = false) String images,
                                           @RequestParam(required = false) Integer allowBargain,
                                           @RequestParam(required = false) Integer validDay) {
        Long sellerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String t = title != null ? title : getStr(body, "title", null);
        String c = category != null ? category : getStr(body, "category", null);
        String p = price != null ? price : getStr(body, "price", null);
        String d = description != null ? description : getStr(body, "desc", getStr(body, "description", null));
        String imgs = images != null ? images : getStr(body, "images", null);
        Integer ab = allowBargain != null ? allowBargain : getInt(body, "allowBargain", 1);
        Integer vd = validDay != null ? validDay : getInt(body, "validDay", 15);
        SecondProduct product = productService.createProduct(sellerId, t, c, p, d, imgs, ab, vd);
        return R.success(product);
    }

    /**
     * 更新商品
     */
    @PutMapping("/update")
    public R<Void> updateProduct(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) Long productId,
                                  @RequestParam(required = false) String title,
                                  @RequestParam(required = false) String category,
                                  @RequestParam(required = false) String price,
                                  @RequestParam(required = false) String description,
                                  @RequestParam(required = false) String images,
                                  @RequestParam(required = false) Integer allowBargain) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long pid = productId != null ? productId : getLong(body, "productId", null);
        String t = title != null ? title : getStr(body, "title", null);
        String c = category != null ? category : getStr(body, "category", null);
        String p = price != null ? price : getStr(body, "price", null);
        String d = description != null ? description : getStr(body, "description", null);
        String imgs = images != null ? images : getStr(body, "images", null);
        Integer ab = allowBargain != null ? allowBargain : getInt(body, "allowBargain", null);
        productService.updateProduct(pid, userId, t, c, p, d, imgs, ab);
        return R.success();
    }

    /**
     * 审核商品
     */
    @PostMapping("/audit")
    public R<Void> auditProduct(@RequestBody(required = false) Map<String, Object> body,
                                 @RequestParam(required = false) Long productId,
                                 @RequestParam(required = false) Integer auditStatus) {
        Long pid = productId != null ? productId : getLong(body, "productId", null);
        Integer as = auditStatus != null ? auditStatus : getInt(body, "auditStatus", null);
        productService.auditProduct(pid, as);
        return R.success();
    }

    /**
     * 上架商品
     */
    @PostMapping("/online")
    public R<Void> onlineProduct(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) Long productId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long pid = productId != null ? productId : getLong(body, "productId", null);
        productService.onlineProduct(pid, userId);
        return R.success();
    }

    /**
     * 下架商品
     */
    @PostMapping("/offline")
    public R<Void> offlineProduct(HttpServletRequest request,
                                   @RequestBody(required = false) Map<String, Object> body,
                                   @RequestParam(required = false) Long productId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long pid = productId != null ? productId : getLong(body, "productId", null);
        productService.offlineProduct(pid, userId);
        return R.success();
    }

    /**
     * 删除商品
     */
    @DeleteMapping("/delete")
    public R<Void> deleteProduct(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) Long productId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long pid = productId != null ? productId : getLong(body, "productId", null);
        productService.deleteProduct(pid, userId);
        return R.success();
    }

    /**
     * 获取商品详情
     */
    @GetMapping("/detail")
    public R<SecondProduct> getProductDetail(@RequestParam Long productId) {
        return R.success(productService.getProductDetail(productId));
    }

    /**
     * 获取卖家商品列表
     */
    @GetMapping("/seller/list")
    public R<List<SecondProduct>> getSellerProducts(HttpServletRequest request) {
        Long sellerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(productService.getSellerProducts(sellerId));
    }

    /**
     * 按分类获取商品列表
     */
    @GetMapping("/list")
    public R<List<SecondProduct>> getProductsByCategory(@RequestParam(required = false) String category) {
        if (category != null && !category.isEmpty()) {
            return R.success(productService.getProductsByCategory(category));
        }
        return R.success(productService.list());
    }

    /**
     * 搜索商品
     */
    @GetMapping("/search")
    public R<List<SecondProduct>> searchProducts(@RequestParam String keyword) {
        return R.success(productService.searchProducts(keyword));
    }
}
