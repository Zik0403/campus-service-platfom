package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Activity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 校园活动数据访问接口。
 *
 * <p>操作的数据库表为活动表，对应实体类为 {@link Activity}。
 * 主要负责社团发布活动的查询，包括按社团查询活动、查询可报名的活动、以及查询待审核的活动。</p>
 */
@Mapper
public interface ActivityMapper extends BaseMapper<Activity> {

    /**
     * 根据社团 ID 查询该社团发布的所有活动。
     *
     * @param clubId 社团 ID
     * @return 该社团的活动列表，没有活动时返回空列表
     */
    List<Activity> selectByClubId(@Param("clubId") Long clubId);

    /**
     * 查询已经审核通过、启用且未过期的活动列表。
     *
     * @return 当前可参与的活动列表
     */
    List<Activity> selectAvailableActivities();

    /**
     * 查询所有待审核的活动。
     *
     * @return 待管理员审核的活动列表
     */
    List<Activity> selectPendingAudit();
}
