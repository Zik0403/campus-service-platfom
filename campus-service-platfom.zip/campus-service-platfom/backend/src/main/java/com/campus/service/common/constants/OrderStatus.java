package com.campus.service.common.constants;

/**
 * 校园生活服务项目订单/状态常量类。
 * 集中定义报修工单、跑腿/外卖/快递订单、二手交易、失物招领、社区帖子审核、二手商品等业务模块中
 * 使用的状态编码及对应的中文名称转换、合法性校验方法，便于业务代码统一引用和维护。
 */
public class OrderStatus {

    // ========== 报修工单状态（repair_order 表 status 字段） ==========
    /** 报修工单状态：1 待派单，学生提交报修后等待管理员/系统派单 */
    public static final int REPAIR_PENDING = 1;
    /** 报修工单状态：2 维修中，维修员已接单并上门维修 */
    public static final int REPAIR_PROCESSING = 2;
    /** 报修工单状态：3 已完成，维修结束且用户确认 */
    public static final int REPAIR_COMPLETED = 3;
    /** 报修工单状态：4 已驳回，管理员审核不通过或无法维修 */
    public static final int REPAIR_REJECTED = 4;
    /** 报修工单状态：5 已取消，学生主动取消或超时未处理 */
    public static final int REPAIR_CANCELLED = 5;

    // ========== 跑腿/外卖/快递订单状态（service_order 表 status 字段） ==========
    /** 服务订单状态：1 待付款，用户已下单但尚未支付 */
    public static final int ORDER_UNPAID = 1;
    /** 服务订单状态：2 待接单，已付款等待配送员接单 */
    public static final int ORDER_UNPICKED = 2;
    /** 服务订单状态：3 配送中，配送员已接单并正在配送 */
    public static final int ORDER_DELIVERING = 3;
    /** 服务订单状态：4 已完成，订单配送/服务结束 */
    public static final int ORDER_COMPLETED = 4;
    /** 服务订单状态：5 退款/取消，用户取消或申请退款后的终态 */
    public static final int ORDER_REFUND = 5;

    // ========== 二手订单支付状态（second_order 表 pay_status 字段） ==========
    /** 二手订单支付状态：1 待支付，买家下单后尚未付款 */
    public static final int PAY_UNPAID = 1;
    /** 二手订单支付状态：2 已支付担保，买家付款后资金由平台暂时托管 */
    public static final int PAY_PAID = 2;
    /** 二手订单支付状态：3 已交付，卖家已发货/线下交付商品 */
    public static final int PAY_DELIVERED = 3;
    /** 二手订单支付状态：4 资金打款卖家，买家确认收货后平台将款项打给卖家 */
    public static final int PAY_TRANSFERRED = 4;
    /** 二手订单支付状态：5 全额退款，交易取消或纠纷处理后退款给买家 */
    public static final int PAY_REFUND = 5;

    // ========== 失物招领状态（lost_found 表 status 字段） ==========
    /** 失物招领状态：1 待匹配，信息发布后等待失主/拾取者联系 */
    public static final int LOST_PENDING = 1;
    /** 失物招领状态：2 已认领归还，物品已确认归还给失主 */
    public static final int LOST_CLAIMED = 2;
    /** 失物招领状态：3 过期归档，长期未匹配自动归档 */
    public static final int LOST_EXPIRED = 3;

    // ========== 社区帖子审核状态（community_post 表 audit_status 字段） ==========
    /** 社区帖子审核状态：1 待审核，帖子提交后等待运营人员审核 */
    public static final int AUDIT_PENDING = 1;
    /** 社区帖子审核状态：2 已通过，审核通过对外展示 */
    public static final int AUDIT_PASSED = 2;
    /** 社区帖子审核状态：3 驳回，内容违规或不符合规范 */
    public static final int AUDIT_REJECTED = 3;

    // ========== 二手商品状态（second_product 表 status 字段） ==========
    /** 二手商品状态：1 待审核，用户发布商品后等待平台审核 */
    public static final int PRODUCT_PENDING = 1;
    /** 二手商品状态：2 上架，审核通过正在出售 */
    public static final int PRODUCT_ONLINE = 2;
    /** 二手商品状态：3 售出，商品已卖出 */
    public static final int PRODUCT_SOLD = 3;
    /** 二手商品状态：4 下架，卖家主动下架或超过有效期 */
    public static final int PRODUCT_OFFLINE = 4;
    /** 二手商品状态：5 违规封禁，被运营人员判定违规后下架 */
    public static final int PRODUCT_BANNED = 5;

    /**
     * 根据报修工单状态编码获取对应的中文名称。
     *
     * @param status 报修工单状态编码
     * @return 中文状态名称，如“待派单”“维修中”；不匹配时返回“未知”
     */
    public static String getRepairStatusName(int status) {
        // 使用 switch 表达式匹配状态编码，返回对应中文描述
        return switch (status) {
            case REPAIR_PENDING -> "待派单";
            case REPAIR_PROCESSING -> "维修中";
            case REPAIR_COMPLETED -> "已完成";
            case REPAIR_REJECTED -> "已驳回";
            case REPAIR_CANCELLED -> "已取消";
            default -> "未知";
        };
    }

    /**
     * 根据跑腿/外卖/快递订单状态编码获取对应的中文名称。
     *
     * @param status 服务订单状态编码
     * @return 中文状态名称，如“待付款”“配送中”；不匹配时返回“未知”
     */
    public static String getOrderStatusName(int status) {
        // 使用 switch 表达式匹配状态编码，返回对应中文描述
        return switch (status) {
            case ORDER_UNPAID -> "待付款";
            case ORDER_UNPICKED -> "待接单";
            case ORDER_DELIVERING -> "配送中";
            case ORDER_COMPLETED -> "已完成";
            case ORDER_REFUND -> "已取消/退款";
            default -> "未知";
        };
    }

    /**
     * 校验报修工单状态编码是否在合法范围内。
     *
     * @param status 待校验的状态编码
     * @return true 表示状态合法；false 表示状态非法
     */
    public static boolean isValidRepairStatus(int status) {
        // 报修状态编码为 1-5 的连续整数，直接通过区间判断合法性
        return status >= REPAIR_PENDING && status <= REPAIR_CANCELLED;
    }

    /**
     * 校验跑腿/外卖/快递订单状态编码是否在合法范围内。
     *
     * @param status 待校验的状态编码
     * @return true 表示状态合法；false 表示状态非法
     */
    public static boolean isValidOrderStatus(int status) {
        // 服务订单状态编码为 1-5 的连续整数，直接通过区间判断合法性
        return status >= ORDER_UNPAID && status <= ORDER_REFUND;
    }
}
