package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 学生课表表。
 * 存储学生个人课程安排，包括课程名称、教师、教室、星期、节次、起止周与学期，
 * 支撑小程序端课表展示、空教室查询与上课提醒。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("course_schedule") // 指定对应的数据库表名为 course_schedule
public class CourseSchedule implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 课表记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 学号，标识该课表记录属于哪位学生。
     */
    private String studentId;

    /**
     * 课程名称，如“线性代数”“数据结构”。
     */
    private String courseName;

    /**
     * 授课教师姓名。
     */
    private String teacher;

    /**
     * 上课教室，如“第一教学楼 302”。
     */
    private String classroom;

    /**
     * 星期几，取值 1-7 分别代表周一至周日。
     */
    private Integer weekDay;

    /**
     * 开始节次，表示课程从第几节课开始。
     */
    private Integer sectionStart;

    /**
     * 结束节次，表示课程到第几节课结束。
     */
    private Integer sectionEnd;

    /**
     * 开始周次，表示课程从学期第几周开始。
     */
    private Integer weekStart;

    /**
     * 结束周次，表示课程到学期第几周结束。
     */
    private Integer weekEnd;

    /**
     * 学期，如“2025-2026-1”，表示学年与上下学期。
     */
    private String semester;

    /**
     * 课程颜色，用于课表 UI 区分不同课程。
     */
    private String color;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录课表数据首次同步/录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录课表数据最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
