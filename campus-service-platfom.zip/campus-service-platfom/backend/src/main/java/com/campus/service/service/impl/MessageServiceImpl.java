package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.entity.Message;
import com.campus.service.mapper.MessageMapper;
import com.campus.service.service.MessageService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 消息通知服务实现类。
 * <p>
 * 负责校园系统内的用户消息通知业务处理，包括发送系统消息、业务消息、
 * 查询未读消息、标记单条或全部消息为已读以及查询用户的全部消息列表等功能。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class MessageServiceImpl extends ServiceImpl<MessageMapper, Message> implements MessageService {

    /**
     * 向指定用户发送一条消息通知。
     *
     * @param userId  接收消息的用户ID
     * @param msgType 消息类型（如系统通知、业务提醒等）
     * @param title   消息标题
     * @param content 消息正文内容
     * @param bizType 关联业务类型（如帖子、失物招领等，可选）
     * @param bizId   关联业务记录ID（可选）
     */
    @Override
    public void sendMessage(Long userId, Integer msgType, String title, String content, String bizType, Long bizId) {
        // 创建一个新的消息实体对象
        Message message = new Message();
        // 设置消息接收用户ID
        message.setUserId(userId);
        // 设置消息类型，区分系统通知或业务通知
        message.setMsgType(msgType);
        // 设置消息标题
        message.setTitle(title);
        // 设置消息正文内容
        message.setContent(content);
        // 设置关联业务类型，便于点击消息跳转到对应业务页面
        message.setBizType(bizType);
        // 设置关联业务记录ID
        message.setBizId(bizId);
        // 新消息默认未读（0表示未读）
        message.setIsRead(0);
        // 将消息数据插入 message 表
        save(message);
        // 记录消息发送日志，便于后续排查与审计
        log.info("发送消息: userId={}, type={}, title={}", userId, msgType, title);
    }

    /**
     * 查询指定用户的全部未读消息，按创建时间倒序排列。
     *
     * @param userId 用户ID
     * @return 未读消息列表
     */
    @Override
    public List<Message> getUnreadMessages(Long userId) {
        // 构造查询条件：接收用户ID匹配、已读状态为未读、按创建时间倒序，从 message 表查询
        return list(new LambdaQueryWrapper<Message>()
                .eq(Message::getUserId, userId)
                .eq(Message::getIsRead, 0)
                .orderByDesc(Message::getCreateTime));
    }

    /**
     * 将指定消息标记为已读，仅允许消息的接收者本人操作。
     *
     * @param userId    当前操作用户ID
     * @param messageId 消息ID
     */
    @Override
    public void markAsRead(Long userId, Long messageId) {
        // 根据消息ID从 message 表查询消息记录
        Message message = getById(messageId);
        // 若消息存在且接收者为当前用户，则更新为已读状态
        if (message != null && message.getUserId().equals(userId)) {
            // 将已读状态设置为1（已读）
            message.setIsRead(1);
            // 更新 message 表中对应记录的已读状态
            updateById(message);
        }
    }

    /**
     * 将指定用户的全部未读消息一键标记为已读。
     *
     * @param userId 用户ID
     */
    @Override
    public void markAllAsRead(Long userId) {
        // 构造查询条件：接收用户ID匹配、已读状态为未读，从 message 表查询所有未读消息
        List<Message> unreadMessages = list(new LambdaQueryWrapper<Message>()
                .eq(Message::getUserId, userId)
                .eq(Message::getIsRead, 0));
        // 遍历所有未读消息，将其状态修改为已读
        for (Message msg : unreadMessages) {
            msg.setIsRead(1);
        }
        // 如果存在未读消息，批量更新 message 表中的已读状态
        if (!unreadMessages.isEmpty()) {
            updateBatchById(unreadMessages);
        }
    }

    /**
     * 查询指定用户的全部消息（包含已读与未读），按创建时间倒序排列。
     *
     * @param userId 用户ID
     * @return 用户消息列表
     */
    @Override
    public List<Message> getUserMessages(Long userId) {
        // 构造查询条件：接收用户ID匹配，并按创建时间倒序，从 message 表查询
        return list(new LambdaQueryWrapper<Message>()
                .eq(Message::getUserId, userId)
                .orderByDesc(Message::getCreateTime));
    }
}
