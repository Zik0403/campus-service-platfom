package com.campus.service.common.cache;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * Redis 缓存防护工具类。
 * <p>
 * 在原有热点缓存的基础上，统一提供以下三种经典问题的防护能力：
 * <ul>
 *   <li><b>缓存穿透</b>：数据库也查不到数据时，向 Redis 写入空值/空列表并设置短 TTL，
 *       避免恶意请求持续打穿缓存访问数据库；</li>
 *   <li><b>缓存击穿</b>：热点 Key 过期瞬间，使用分布式锁保证只有一个线程回源重建缓存，
 *       其他线程短暂自旋等待，避免大量并发同时请求数据库；</li>
 *   <li><b>缓存雪崩</b>：为缓存 Key 设置基础 TTL 的基础上增加随机偏移量，
 *       让大量 Key 不会在同一时刻同时过期。</li>
 * </ul>
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CacheProtectionService {

    /**
     * Redis 缓存模板，用于缓存读写与分布式锁操作。
     */
    private final RedisTemplate<String, Object> redisTemplate;

    /**
     * 分布式锁 Key 前缀。
     */
    private static final String LOCK_PREFIX = "lock:cache:";

    /**
     * 空值占位对象，用于标识数据库中不存在对应数据。
     */
    private static final String EMPTY_PLACEHOLDER = "EMPTY";

    /**
     * 空值/空列表的短 TTL，用于缓存穿透场景，默认 5 分钟。
     */
    private static final Duration EMPTY_TTL = Duration.ofMinutes(5);

    /**
     * 自旋等待的最大次数。
     */
    private static final int MAX_RETRY = 5;

    /**
     * 每次自旋等待的毫秒数。
     */
    private static final long RETRY_SLEEP_MS = 100L;

    /**
     * 从缓存中读取列表数据，并具备穿透、击穿、雪崩三重防护。
     * <p>
     * 适用于公告列表、活动列表等热点数据查询场景。
     * </p>
     *
     * @param cacheKey    Redis 缓存 Key
     * @param loader      数据库回源加载器
     * @param baseTtl     基础缓存过期时间
     * @param elementType 列表元素类型，用于日志和调试
     * @param <T>         列表元素泛型
     * @return 数据库或缓存中的列表数据
     */
    @SuppressWarnings("unchecked")
    public <T> List<T> getListWithProtection(String cacheKey, Supplier<List<T>> loader, Duration baseTtl, Class<T> elementType) {
        // 第一次尝试从 Redis 读取缓存
        Object cached = redisTemplate.opsForValue().get(cacheKey);
        if (cached != null) {
            // 如果是空值占位，说明数据库中无数据，直接返回空列表（防护缓存穿透）
            if (EMPTY_PLACEHOLDER.equals(cached)) {
                log.debug("缓存穿透防护命中：key={}，返回空列表", cacheKey);
                return Collections.emptyList();
            }
            // 缓存命中，直接返回缓存列表
            return (List<T>) cached;
        }

        // 缓存未命中，需要竞争分布式锁来回源
        String lockKey = LOCK_PREFIX + cacheKey;
        Boolean locked = redisTemplate.opsForValue().setIfAbsent(lockKey, "1", Duration.ofSeconds(10));

        if (Boolean.TRUE.equals(locked)) {
            // 抢到锁，执行回源并写入缓存
            try {
                // 二次检查：加锁成功后再次读取缓存，防止其他线程已经重建完成
                cached = redisTemplate.opsForValue().get(cacheKey);
                if (cached != null) {
                    return EMPTY_PLACEHOLDER.equals(cached) ? Collections.emptyList() : (List<T>) cached;
                }

                // 回源查询数据库
                List<T> data = loader.get();
                // 设置随机 TTL，防止大量 Key 同时过期造成雪崩
                Duration ttl = randomizeTtl(baseTtl);

                if (data == null || data.isEmpty()) {
                    // 数据库也没有数据，写入空值占位，避免缓存穿透
                    redisTemplate.opsForValue().set(cacheKey, EMPTY_PLACEHOLDER, EMPTY_TTL);
                    log.debug("缓存穿透防护：key={} 数据库无数据，写入空值占位", cacheKey);
                    return Collections.emptyList();
                }

                // 写入正常缓存数据
                redisTemplate.opsForValue().set(cacheKey, data, ttl);
                log.debug("缓存重建成功：key={}，ttl={}s，size={}", cacheKey, ttl.getSeconds(), data.size());
                return data;
            } finally {
                // 释放分布式锁
                redisTemplate.delete(lockKey);
            }
        }

        // 没抢到锁，说明其他线程正在回源，自旋等待后重新读取缓存
        for (int i = 0; i < MAX_RETRY; i++) {
            try {
                TimeUnit.MILLISECONDS.sleep(RETRY_SLEEP_MS);
            } catch (InterruptedException e) {
                // 恢复中断状态，防止影响上层逻辑
                Thread.currentThread().interrupt();
                break;
            }
            cached = redisTemplate.opsForValue().get(cacheKey);
            if (cached != null) {
                return EMPTY_PLACEHOLDER.equals(cached) ? Collections.emptyList() : (List<T>) cached;
            }
        }

        // 自旋后仍未命中，降级直接查询数据库，保证接口可用性
        log.warn("缓存击穿自旋未命中，降级回源：key={}", cacheKey);
        return loader.get();
    }

    /**
     * 在基础 TTL 上增加一个随机偏移量，避免缓存雪崩。
     * <p>
     * 随机偏移范围为 0 到 5 分钟（300 秒），大量热点 Key 的过期时间会分散开。
     * </p>
     *
     * @param baseTtl 基础过期时间
     * @return 随机化后的过期时间
     */
    private Duration randomizeTtl(Duration baseTtl) {
        // 在基础 TTL 上增加 0~300 秒的随机偏移
        long extraSeconds = ThreadLocalRandom.current().nextInt(300);
        return baseTtl.plusSeconds(extraSeconds);
    }
}
