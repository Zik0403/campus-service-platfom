package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * 考试安排表。
 * 存储学生的考试信息，包括考试科目、类型、日期、时间、考场、座位号与学期，
 * 支撑小程序端考试安排查询与考前提醒。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("exam") // 指定对应的数据库表名为 exam
public class Exam implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 考试安排主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 学号，标识该考试安排属于哪位学生。
     */
    private String studentId;

    /**
     * 课程名称，即考试科目。
     */
    private String courseName;

    /**
     * 考试类型，如“期中”“期末”“补考”“重修”。
     */
    private String examType;

    /**
     * 考试日期。
     */
    private LocalDate examDate;

    /**
     * 考试开始时间。
     */
    private LocalTime startTime;

    /**
     * 考试结束时间。
     */
    private LocalTime endTime;

    /**
     * 考试教室/考场。
     */
    private String classroom;

    /**
     * 座位号，学生在该考场的具体座位。
     */
    private String seatNo;

    /**
     * 学期，如“2025-2026-1”。
     */
    private String semester;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录考试数据首次同步/录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录考试数据最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
