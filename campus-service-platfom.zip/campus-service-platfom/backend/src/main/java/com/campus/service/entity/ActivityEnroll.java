package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 活动报名表。
 * 记录学生报名参加活动的关联关系，以及签到、签退、取消等状态，
 * 是活动签到、信用积分发放与参与统计的数据基础。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("activity_enroll") // 指定对应的数据库表名为 activity_enroll
public class ActivityEnroll implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 报名记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 活动 ID，关联 activity 表。
     */
    private Long activityId;

    /**
     * 报名用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 报名时间，学生提交报名申请的时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime enrollTime;

    /**
     * 签到状态：0 未签到、1 已签到。
     */
    private Integer checkinStatus;

    /**
     * 签到时间，学生到达现场扫码签到的时间。
     */
    private LocalDateTime checkinTime;

    /**
     * 签退状态：0 未签退、1 已签退。
     */
    private Integer checkoutStatus;

    /**
     * 签退时间，活动结束离场扫码签退的时间。
     */
    private LocalDateTime checkoutTime;

    /**
     * 报名状态：1 已报名、2 已取消。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;
}
