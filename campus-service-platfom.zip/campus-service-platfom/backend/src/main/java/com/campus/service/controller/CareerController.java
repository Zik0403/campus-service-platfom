package com.campus.service.controller;

import com.campus.service.entity.CetScore;
import com.campus.service.entity.CertInfo;
import com.campus.service.entity.User;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.CareerService;
import com.campus.service.service.UserService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/career")
@RequiredArgsConstructor
public class CareerController {

    private final CareerService careerService;
    private final UserService userService;

    @GetMapping("/cet/list")
    public R<List<CetScore>> getCetScores(HttpServletRequest request,
                                           @RequestParam(required = false) String cetType) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        User user = userService.getById(userId);
        if (user == null || user.getStudentId() == null) {
            return R.fail("请先完成实名认证");
        }
        return R.success(careerService.getCetScores(user.getStudentId(), cetType));
    }

    @GetMapping("/cert/list")
    public R<List<CertInfo>> getCertList(@RequestParam(required = false) String certType) {
        return R.success(careerService.getCertList(certType));
    }

    @GetMapping("/cert/detail")
    public R<CertInfo> getCertDetail(@RequestParam Long id) {
        return R.success(careerService.getCertDetail(id));
    }
}
