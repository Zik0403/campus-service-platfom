package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.constants.RoleConstants;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.ServiceOrder;
import com.campus.service.entity.User;
import com.campus.service.mapper.ServiceOrderMapper;
import com.campus.service.service.ServiceOrderService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 校园服务订单业务实现类。
 * <p>
 * 负责校园跑腿/服务类订单的完整生命周期管理，包括代取快递、代买饭、打印资料等校园服务场景。
 * 核心业务涵盖：用户下单、余额支付、学生接单、开始配送、完成订单、取消退款、用户评价、
 * 订单投诉以及超时未支付/超时未完成的自动处理。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ServiceOrderServiceImpl extends ServiceImpl<ServiceOrderMapper, ServiceOrder> implements ServiceOrderService {

    private final UserService userService;

    /**
     * 将金额字符串转换为 BigDecimal，过滤掉非数字和小数点字符。
     *
     * @param moneyStr 原始金额字符串，可能包含货币符号或为空
     * @return 解析后的金额，若为空或非法则返回 0
     */
    private BigDecimal parseMoney(String moneyStr) {
        // 若金额字符串为空，表示没有费用，直接返回 0
        if (moneyStr == null || moneyStr.isEmpty()) {
            return BigDecimal.ZERO;
        }
        // 过滤字符串中的非数字和非小数点字符，保留纯金额数字
        String cleaned = moneyStr.replaceAll("[^0-9.]", "");
        // 过滤后若为空，说明没有有效数字，返回 0
        if (cleaned.isEmpty()) {
            return BigDecimal.ZERO;
        }
        // 将清洗后的字符串转换为 BigDecimal 金额对象
        return new BigDecimal(cleaned);
    }

    /**
     * 用户创建服务订单。
     *
     * @param userId      下单用户 ID
     * @param serviceType 服务类型（如代取快递、代买饭等）
     * @param originAddr  取货/起始地址
     * @param targetAddr  送达/目标地址
     * @param orderContent 订单需求描述
     * @param tipFee      小费金额字符串
     * @param totalFee    订单总金额字符串
     * @return 创建成功后的服务订单对象
     */
    @Override
    @Transactional
    public ServiceOrder createOrder(Long userId, Integer serviceType, String originAddr, String targetAddr,
                                    String orderContent, String tipFee, String totalFee) {
        // 校验用户是否已完成实名认证，未认证则不允许下单
        userService.checkUserAuth(userId);
        // 校验用户是否已设置支付密码，未设置则抛异常提示先设置
        if (!userService.hasPayPassword(userId)) {
            throw new BusinessException("请先设置支付密码后再下单");
        }
        // 创建一个新的服务订单实体对象
        ServiceOrder order = new ServiceOrder();
        // 生成订单编号：当前时间戳 + 4 位随机数，保证唯一性
        order.setId(String.valueOf(System.currentTimeMillis()) + (int) (Math.random() * 10000));
        // 设置下单用户 ID
        order.setUserId(userId);
        // 设置服务类型，如代取快递、代买饭等
        order.setServiceType(serviceType);
        // 设置取货/起始地址
        order.setOriginAddr(originAddr);
        // 设置送达/目标地址
        order.setTargetAddr(targetAddr);
        // 设置订单具体需求内容
        order.setOrderContent(orderContent);
        // 设置小费金额，并做金额字符串清洗
        order.setTipFee(parseMoney(tipFee));
        // 设置订单总金额，并做金额字符串清洗
        order.setTotalFee(parseMoney(totalFee));
        // 设置订单状态为待支付
        order.setStatus(OrderStatus.ORDER_UNPAID);
        // 调用 ServiceImpl 提供的 save 方法，将订单插入 service_order 表
        save(order);
        // 记录订单创建日志，方便后续排查
        log.info("创建服务订单: orderId={}, userId={}, type={}", order.getId(), userId, serviceType);
        // 返回创建成功的订单对象
        return order;
    }

    /**
     * 用户使用账户余额支付服务订单。
     *
     * @param orderId    待支付的订单 ID
     * @param wxPayNo    微信支付流水号
     * @param payPassword 用户支付密码
     */
    @Override
    @Transactional
    public void payOrder(String orderId, String wxPayNo, String payPassword) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验订单状态是否为待支付，只有待支付订单才能继续支付
        if (order.getStatus() != OrderStatus.ORDER_UNPAID) {
            throw BusinessException.orderStatusError();
        }
        // 根据订单中的用户 ID 查询下单用户信息
        User user = userService.getById(order.getUserId());
        // 若用户不存在，抛出用户不存在的业务异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 校验用户是否已绑定银行卡，未绑定则提示先绑定
        if (!userService.hasBankCard(order.getUserId())) {
            throw new BusinessException("请先绑定银行卡后再支付");
        }
        // 校验用户是否已设置支付密码
        if (user.getPayPassword() == null || user.getPayPassword().isEmpty()) {
            throw new BusinessException("请先设置支付密码");
        }
        // 校验请求中是否传入了支付密码
        if (payPassword == null || payPassword.isEmpty()) {
            throw new BusinessException("请输入支付密码");
        }
        // 校验支付密码是否正确
        if (!userService.verifyPayPassword(order.getUserId(), payPassword)) {
            throw new BusinessException("支付密码错误，请重新输入");
        }
        // 计算实际需支付的总额：订单金额 + 小费
        BigDecimal totalAmount = order.getTotalFee().add(order.getTipFee());
        // 校验用户余额是否足够支付订单总额
        if (user.getBalance().compareTo(totalAmount) < 0) {
            throw new BusinessException("账户余额不足，请先充值");
        }
        // 扣除用户账户余额，交易类型 2 表示支付扣款
        userService.updateBalance(order.getUserId(), totalAmount.negate(), 2);
        // 将订单状态更新为待接单
        order.setStatus(OrderStatus.ORDER_UNPICKED);
        // 记录微信支付流水号
        order.setWxPayNo(wxPayNo);
        // 更新 service_order 表中的订单状态与支付信息
        updateById(order);
        // 记录支付成功日志
        log.info("服务订单支付成功: orderId={}, amount={}", orderId, totalAmount);
    }

    /**
     * 学生（接单员）接取服务订单。
     *
     * @param orderId 订单 ID
     * @param workerId 接单学生用户 ID
     */
    @Override
    @Transactional
    public void workerAccept(String orderId, Long workerId) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 根据接单学生 ID 查询用户信息
        User worker = userService.getById(workerId);
        // 若学生用户不存在，抛出用户不存在的业务异常
        if (worker == null) {
            throw BusinessException.userNotFound();
        }
        // 校验接单者角色是否为学生，只有学生可以接服务订单
        if (worker.getRole() != RoleConstants.ROLE_STUDENT) {
            throw new BusinessException("只有学生可以接服务订单");
        }
        // 校验学生是否已完成实名认证
        if (worker.getIsAuth() == 0) {
            throw new BusinessException("请先完成实名认证");
        }
        // 校验接单者不能是订单发布者自己，避免自己接自己的单
        if (order.getUserId().equals(workerId)) {
            throw new BusinessException("不能接自己的订单");
        }
        // 校验订单状态是否为待接单，只有待接单状态才能被接取
        if (order.getStatus() != OrderStatus.ORDER_UNPICKED) {
            throw BusinessException.orderStatusError();
        }
        // 设置订单的接单学生 ID
        order.setWorkerId(workerId);
        // 将订单状态更新为配送中
        order.setStatus(OrderStatus.ORDER_DELIVERING);
        // 记录接单时间
        order.setAcceptTime(LocalDateTime.now());
        // 更新 service_order 表中的订单信息
        updateById(order);
        // 记录学生接单日志
        log.info("学生接单: orderId={}, studentId={}", orderId, workerId);
    }

    /**
     * 接单员开始配送服务订单。
     *
     * @param orderId 订单 ID
     */
    @Override
    @Transactional
    public void startDelivery(String orderId) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验订单状态是否为配送中，只有配送中才能开始配送
        if (order.getStatus() != OrderStatus.ORDER_DELIVERING) {
            throw BusinessException.orderStatusError();
        }
        // 记录开始配送日志
        log.info("开始配送: orderId={}", orderId);
    }

    /**
     * 接单员完成服务订单，并将报酬计入接单员余额。
     *
     * @param orderId  订单 ID
     * @param workerId 完成订单的接单员 ID
     */
    @Override
    @Transactional
    public void completeOrder(String orderId, Long workerId) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验订单状态是否为配送中，只有配送中订单才能完成
        if (order.getStatus() != OrderStatus.ORDER_DELIVERING) {
            throw BusinessException.orderStatusError();
        }
        // 若指定了接单员 ID，则校验当前操作人是否为该订单的接单者
        if (workerId != null && order.getWorkerId() != null && !order.getWorkerId().equals(workerId)) {
            throw BusinessException.roleNotAllowed();
        }
        // 将订单状态更新为已完成
        order.setStatus(OrderStatus.ORDER_COMPLETED);
        // 更新 service_order 表中的订单状态
        updateById(order);
        // 若订单存在接单员，则将订单金额 + 小费作为收入计入接单员余额
        if (order.getWorkerId() != null) {
            // 计算接单员收入：订单金额 + 小费
            BigDecimal income = order.getTotalFee().add(order.getTipFee());
            // 增加接单员账户余额，交易类型 5 表示服务收入
            userService.updateBalance(order.getWorkerId(), income, 5);
        }
        // 记录订单完成日志
        log.info("服务订单完成: orderId={}", orderId);
    }

    /**
     * 用户取消服务订单，已支付订单将原路退款。
     *
     * @param orderId 订单 ID
     * @param userId  操作用户 ID
     */
    @Override
    @Transactional
    public void cancelOrder(String orderId, Long userId) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为订单发布者，只有本人能取消
        if (!order.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验订单状态，已完成或已退款的订单不允许再次取消
        if (order.getStatus() == OrderStatus.ORDER_COMPLETED || order.getStatus() == OrderStatus.ORDER_REFUND) {
            throw BusinessException.orderStatusError();
        }
        // 判断订单是否已经支付：存在微信支付流水号即视为已支付
        boolean hasPaid = order.getWxPayNo() != null && !order.getWxPayNo().isEmpty();
        // 将订单状态更新为已退款（取消即退款）
        order.setStatus(OrderStatus.ORDER_REFUND);
        // 更新 service_order 表中的订单状态
        updateById(order);
        // 若订单已支付，则将订单金额 + 小费退回给用户余额，交易类型 4 表示退款
        if (hasPaid) {
            userService.updateBalance(order.getUserId(), order.getTotalFee().add(order.getTipFee()), 4);
        }
        // 记录用户取消订单日志
        log.info("用户取消服务订单: orderId={}, userId={}", orderId, userId);
    }

    /**
     * 用户申请服务订单退款。
     *
     * @param orderId 订单 ID
     * @param userId  申请退款的用户 ID
     */
    @Override
    @Transactional
    public void refundOrder(String orderId, Long userId) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为订单发布者
        if (!order.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验订单状态，已完成或已退款的订单不允许退款
        if (order.getStatus() == OrderStatus.ORDER_COMPLETED || order.getStatus() == OrderStatus.ORDER_REFUND) {
            throw BusinessException.orderStatusError();
        }
        // 若订单已被接单且处于配送中，则不允许退款，需联系客服处理
        if (order.getWorkerId() != null && order.getStatus() == OrderStatus.ORDER_DELIVERING) {
            throw new BusinessException("配送中无法退款，请联系客服");
        }
        // 判断订单是否已经支付
        boolean hasPaid = order.getWxPayNo() != null && !order.getWxPayNo().isEmpty();
        // 将订单状态更新为已退款
        order.setStatus(OrderStatus.ORDER_REFUND);
        // 更新 service_order 表中的订单状态
        updateById(order);
        // 若订单已支付，则将订单金额 + 小费退回用户余额
        if (hasPaid) {
            userService.updateBalance(order.getUserId(), order.getTotalFee().add(order.getTipFee()), 4);
        }
        // 记录退款日志
        log.info("服务订单退款: orderId={}", orderId);
    }

    /**
     * 用户对已完成的服务订单进行评价，并影响接单员信用分。
     *
     * @param orderId 订单 ID
     * @param userId  评价用户 ID
     * @param star    评价星级（1-5）
     */
    @Override
    @Transactional
    public void evaluate(String orderId, Long userId, Integer star) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为订单发布者
        if (!order.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验订单状态是否为已完成，只有已完成订单才能评价
        if (order.getStatus() != OrderStatus.ORDER_COMPLETED) {
            throw BusinessException.orderStatusError();
        }
        // 设置订单评价星级
        order.setEvaluateStar(star);
        // 更新 service_order 表中的评价信息
        updateById(order);
        // 若订单存在接单员且评价星级有效，则根据星级调整接单员信用分
        if (order.getWorkerId() != null && star != null) {
            // 4-5 星加 2 分，3 星不变，1-2 星扣 2 分
            int creditChange = star >= 4 ? 2 : (star >= 3 ? 0 : -2);
            // 更新接单员信用积分
            userService.updateCreditScore(order.getWorkerId(), creditChange);
        }
        // 记录用户评价日志
        log.info("用户评价服务订单: orderId={}, star={}", orderId, star);
    }

    /**
     * 用户对服务订单发起投诉。
     *
     * @param orderId 订单 ID
     * @param userId  投诉用户 ID
     * @param reason  投诉原因
     */
    @Override
    @Transactional
    public void complainOrder(String orderId, Long userId, String reason) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为订单发布者
        if (!order.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验订单是否已被投诉，避免重复提交
        if (order.getIsComplained() != null && order.getIsComplained() == 1) {
            throw new BusinessException("该订单已投诉，请勿重复提交");
        }
        // 设置订单投诉标识为已投诉
        order.setIsComplained(1);
        // 记录投诉原因
        order.setComplainReason(reason);
        // 记录投诉提交时间
        order.setComplainTime(LocalDateTime.now());
        // 更新 service_order 表中的投诉信息
        updateById(order);
        // 记录用户投诉日志
        log.info("用户投诉服务订单: orderId={}, userId={}, reason={}", orderId, userId, reason);
    }

    /**
     * 查询服务订单详情，并填充下单人与接单人信息。
     *
     * @param orderId 订单 ID
     * @param userId  当前查看用户 ID
     * @return 包含用户信息的订单详情对象
     */
    @Override
    public ServiceOrder getOrderDetail(String orderId, Long userId) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 查询当前查看用户信息
        User currentUser = userService.getById(userId);
        // 判断当前用户是否为订单发布者
        boolean isOwner = order.getUserId().equals(userId);
        // 判断当前用户是否为订单接单者
        boolean isWorker = order.getWorkerId() != null && order.getWorkerId().equals(userId);
        // 若当前用户既不是发布者也不是接单者，且不是管理员，则无权查看
        if (!isOwner && !isWorker && currentUser.getRole() != RoleConstants.ROLE_ADMIN) {
            throw BusinessException.forbidden();
        }
        // 填充订单发布者用户信息
        order.setUser(userService.getById(order.getUserId()));
        // 若订单存在接单者，则填充接单者用户信息
        if (order.getWorkerId() != null) {
            order.setWorker(userService.getById(order.getWorkerId()));
        }
        // 返回订单详情
        return order;
    }

    /**
     * 查询指定用户发布的服务订单列表。
     *
     * @param userId      用户 ID
     * @param serviceType 服务类型筛选条件，可为空
     * @return 该用户发布的服务订单列表
     */
    @Override
    public List<ServiceOrder> getUserOrders(Long userId, Integer serviceType) {
        // 构建 service_order 表查询条件：按用户 ID 筛选并按创建时间倒序
        LambdaQueryWrapper<ServiceOrder> wrapper = new LambdaQueryWrapper<ServiceOrder>()
                .eq(ServiceOrder::getUserId, userId)
                .orderByDesc(ServiceOrder::getCreateTime);
        // 若传入了服务类型，则追加服务类型等值条件
        if (serviceType != null) {
            wrapper.eq(ServiceOrder::getServiceType, serviceType);
        }
        // 执行查询并返回订单列表
        return list(wrapper);
    }

    /**
     * 查询指定接单员接取的服务订单列表。
     *
     * @param workerId 接单员用户 ID
     * @return 该接单员的服务订单列表
     */
    @Override
    public List<ServiceOrder> getWorkerOrders(Long workerId) {
        // 构建 service_order 表查询条件：按接单员 ID 筛选并按创建时间倒序，返回订单列表
        return list(new LambdaQueryWrapper<ServiceOrder>()
                .eq(ServiceOrder::getWorkerId, workerId)
                .orderByDesc(ServiceOrder::getCreateTime));
    }

    /**
     * 查询待接单的服务订单列表（接单大厅使用）。
     *
     * @param serviceType    服务类型筛选条件，可为空
     * @param excludeUserId  需要排除的用户 ID（通常为用户自己），可为空
     * @return 待接单的服务订单列表
     */
    @Override
    public List<ServiceOrder> getPendingOrders(Integer serviceType, Long excludeUserId) {
        // 构建 service_order 表查询条件：状态为待接单，并按创建时间倒序
        LambdaQueryWrapper<ServiceOrder> wrapper = new LambdaQueryWrapper<ServiceOrder>()
                .eq(ServiceOrder::getStatus, OrderStatus.ORDER_UNPICKED)
                .orderByDesc(ServiceOrder::getCreateTime);
        // 若传入了服务类型，则追加服务类型等值条件
        if (serviceType != null) {
            wrapper.eq(ServiceOrder::getServiceType, serviceType);
        }
        // 若需要排除指定用户，则追加用户 ID 不等于条件，避免看到自己发布的订单
        if (excludeUserId != null) {
            wrapper.ne(ServiceOrder::getUserId, excludeUserId);
        }
        // 执行查询并返回待接单订单列表
        return list(wrapper);
    }

    /**
     * 接单员退回已接取的服务订单。
     *
     * @param orderId 订单 ID
     * @param workerId 接单员用户 ID
     */
    @Override
    @Transactional
    public void workerReturnOrder(String orderId, Long workerId) {
        // 根据订单 ID 查询 service_order 表中的订单信息
        ServiceOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为该订单的接单者
        if (order.getWorkerId() == null || !order.getWorkerId().equals(workerId)) {
            throw new BusinessException("不是订单接单者，无法退回");
        }
        // 校验订单状态是否为配送中，只有配送中订单才能退回
        if (order.getStatus() != OrderStatus.ORDER_DELIVERING) {
            throw BusinessException.orderStatusError();
        }
        // 清空订单的接单者 ID，表示无人接单
        order.setWorkerId(null);
        // 将订单状态恢复为待接单
        order.setStatus(OrderStatus.ORDER_UNPICKED);
        // 清空接单时间
        order.setAcceptTime(null);
        // 更新 service_order 表中的订单信息
        updateById(order);
        // 记录接单员退回订单日志
        log.info("接单者退回订单: orderId={}, workerId={}", orderId, workerId);
    }

    /**
     * 自动处理超时服务订单。
     * <p>
     * 1. 超过 15 分钟未支付的订单自动取消；
     * 2. 接单后超过 30 分钟未完成的订单自动退款给用户，并扣除接单者信用分。
     * </p>
     */
    @Override
    @Transactional
    public void cancelTimeoutOrders() {
        // 获取当前系统时间，用于计算超时阈值
        LocalDateTime now = LocalDateTime.now();

        // 1. 超时未支付订单自动取消（15 分钟）
        // 查询 service_order 表中状态为待支付且创建时间早于 15 分钟前的订单
        List<ServiceOrder> unpaidOrders = list(new LambdaQueryWrapper<ServiceOrder>()
                .eq(ServiceOrder::getStatus, OrderStatus.ORDER_UNPAID)
                .lt(ServiceOrder::getCreateTime, now.minusMinutes(15)));
        // 遍历所有超时未支付订单，将其状态更新为已退款
        for (ServiceOrder order : unpaidOrders) {
            // 将订单状态设置为已退款（超时未支付视为取消）
            order.setStatus(OrderStatus.ORDER_REFUND);
            // 更新 service_order 表中的订单状态
            updateById(order);
            // 记录超时未支付订单自动取消日志
            log.info("超时未支付订单自动取消: orderId={}", order.getId());
        }

        // 2. 已接单超时未完成自动退款并扣信用分（30 分钟）
        // 查询 service_order 表中状态为配送中且接单时间早于 30 分钟前的订单
        List<ServiceOrder> deliveringOrders = list(new LambdaQueryWrapper<ServiceOrder>()
                .eq(ServiceOrder::getStatus, OrderStatus.ORDER_DELIVERING)
                .lt(ServiceOrder::getAcceptTime, now.minusMinutes(30)));
        // 遍历所有接单超时订单，自动退款并扣减接单者信用分
        for (ServiceOrder order : deliveringOrders) {
            // 将订单状态设置为已退款
            order.setStatus(OrderStatus.ORDER_REFUND);
            // 更新 service_order 表中的订单状态
            updateById(order);
            // 退款给用户：将订单金额 + 小费退回用户余额，交易类型 4 表示退款
            userService.updateBalance(order.getUserId(), order.getTotalFee().add(order.getTipFee()), 4);
            // 扣除接单者信用积分，超时未完成扣 5 分
            if (order.getWorkerId() != null) {
                userService.updateCreditScore(order.getWorkerId(), -5);
            }
            // 记录接单超时自动退款并扣信用分日志
            log.info("接单超时自动退款并扣信用分: orderId={}, workerId={}", order.getId(), order.getWorkerId());
        }
    }
}
