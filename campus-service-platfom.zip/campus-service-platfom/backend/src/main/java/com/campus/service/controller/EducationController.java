package com.campus.service.controller;

import com.campus.service.entity.*;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.EducationService;
import com.campus.service.service.UserService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/education")
@RequiredArgsConstructor
public class EducationController {

    private final EducationService educationService;
    private final UserService userService;

    @GetMapping("/course/list")
    public R<List<CourseSchedule>> getCourseSchedule(HttpServletRequest request,
                                                      @RequestParam(required = false) String semester) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        User user = userService.getById(userId);
        if (user == null || user.getStudentId() == null) {
            return R.fail("请先完成实名认证");
        }
        if (semester == null || semester.isEmpty()) {
            semester = "2024-2025-1";
        }
        return R.success(educationService.getCourseSchedule(user.getStudentId(), semester));
    }

    @GetMapping("/score/list")
    public R<List<Score>> getScoreList(HttpServletRequest request,
                                        @RequestParam(required = false) String semester) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        User user = userService.getById(userId);
        if (user == null || user.getStudentId() == null) {
            return R.fail("请先完成实名认证");
        }
        if (semester == null || semester.isEmpty()) {
            semester = "2023-2024-2";
        }
        return R.success(educationService.getScoreList(user.getStudentId(), semester));
    }

    @GetMapping("/score/summary")
    public R<Map<String, Object>> getScoreSummary(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        User user = userService.getById(userId);
        if (user == null || user.getStudentId() == null) {
            return R.fail("请先完成实名认证");
        }
        return R.success(educationService.getScoreSummary(user.getStudentId()));
    }

    @GetMapping("/classroom/empty")
    public R<List<Classroom>> getEmptyClassrooms(@RequestParam(required = false) String building,
                                                  @RequestParam(required = false) Integer weekDay,
                                                  @RequestParam(required = false) Integer section) {
        return R.success(educationService.getEmptyClassrooms(building, weekDay, section));
    }

    @GetMapping("/classroom/occupied")
    public R<List<Map<String, Object>>> getOccupiedClassrooms(@RequestParam(required = false) String building,
                                                                @RequestParam(required = false) Integer weekDay,
                                                                @RequestParam(required = false) Integer section) {
        return R.success(educationService.getOccupiedClassrooms(building, weekDay, section));
    }

    @GetMapping("/classroom/reservation/list")
    public R<List<ClassroomReservation>> getClassroomReservations(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(educationService.getClassroomReservations(userId));
    }

    @PostMapping("/classroom/reserve")
    public R<ClassroomReservation> reserveClassroom(HttpServletRequest request,
                                                     @RequestBody java.util.Map<String, Object> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long classroomId = Long.valueOf(params.get("classroomId").toString());
        String reserveDate = (String) params.get("reserveDate");
        Integer sectionStart = Integer.valueOf(params.get("sectionStart").toString());
        Integer sectionEnd = Integer.valueOf(params.get("sectionEnd").toString());
        String purpose = params.get("purpose") != null ? params.get("purpose").toString() : null;
        Integer peopleCount = params.get("peopleCount") != null ? Integer.valueOf(params.get("peopleCount").toString()) : null;
        return R.success(educationService.reserveClassroom(userId, classroomId, reserveDate,
                sectionStart, sectionEnd, purpose, peopleCount));
    }

    @PostMapping("/classroom/cancel")
    public R<Void> cancelClassroomReservation(HttpServletRequest request,
                                               @RequestBody(required = false) java.util.Map<String, Object> body,
                                               @RequestParam(required = false) Long reservationId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (reservationId == null && body != null && body.get("reservationId") != null) {
            reservationId = Long.valueOf(body.get("reservationId").toString());
        }
        educationService.cancelClassroomReservation(userId, reservationId);
        return R.success();
    }

    @GetMapping("/exam/list")
    public R<List<Exam>> getExamList(HttpServletRequest request,
                                      @RequestParam(required = false) String semester) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        User user = userService.getById(userId);
        if (user == null || user.getStudentId() == null) {
            return R.fail("请先完成实名认证");
        }
        if (semester == null || semester.isEmpty()) {
            semester = "2024-2025-1";
        }
        return R.success(educationService.getExamList(user.getStudentId(), semester));
    }
}
