package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 教室预约申请表。
 * 记录学生或社团申请使用教室的请求，包括预约日期、节次、用途、人数与审批结果，
 * 用于教室资源冲突检测与管理员审批管理。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("classroom_reservation") // 指定对应的数据库表名为 classroom_reservation
public class ClassroomReservation implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 预约记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 预约申请人 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 预约教室 ID，关联 classroom 表。
     */
    private Long classroomId;

    /**
     * 预约使用日期。
     */
    private LocalDate reserveDate;

    /**
     * 开始节次，如第 1 节、第 3 节，表示预约从哪节课开始。
     */
    private Integer sectionStart;

    /**
     * 结束节次，表示预约到哪节课结束。
     */
    private Integer sectionEnd;

    /**
     * 预约用途说明，如“社团例会”“班会”“考试复习”。
     */
    private String purpose;

    /**
     * 预计使用人数，用于判断教室容量是否足够。
     */
    private Integer peopleCount;

    /**
     * 审批状态：1 待审批、2 已通过、3 驳回等。
     */
    private Integer status;

    /**
     * 审批备注，管理员审批时填写的通过/驳回原因。
     */
    private String auditRemark;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录预约申请首次提交时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录预约记录最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    /**
     * 关联教室对象，查询时通过联表或单独查询组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private Classroom classroom;
}
