package com.campus.service.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

/**
 * 全局接口日志切面。
 * <p>
 * 负责记录所有 Controller 接口的请求 URL、请求方式、入参、出参以及执行耗时。
 * 通过 AOP 统一拦截，避免在每个 Controller 方法里重复写日志代码，也方便后续对接口性能进行监控。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class WebLogAspect {

    /**
     * JSON 序列化工具，用于把入参、出参对象打印成可读的 JSON 字符串。
     */
    private final ObjectMapper objectMapper;

    /**
     * 定义切入点：拦截 com.campus.service.controller 包及其子包下所有类的所有方法。
 * <p>
     * 该包下所有 Controller 接口都会被统一记录日志，包括新增和已有的接口。
     * </p>
     */
    @Pointcut("execution(* com.campus.service.controller..*.*(..))")
    public void controllerPointcut() {
        // 切入点声明，无需业务逻辑
    }

    /**
     * 环绕通知：在 Controller 方法执行前后记录请求与响应信息，并计算耗时。
     * <p>
     * 1. 方法执行前打印请求 URL、HTTP 方法、客户端 IP、请求入参；
     * 2. 方法执行后打印响应结果和执行耗时（毫秒）；
     * 3. 如果方法抛出异常，也会记录异常信息并继续抛出，由全局异常处理器处理。
     * </p>
     *
     * @param joinPoint AOP 连接点，可获取目标方法签名和入参
     * @return 目标方法的原始返回值
     * @throws Throwable 目标方法抛出的异常原样向上抛出
     */
    @Around("controllerPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        // 获取当前请求的 HttpServletRequest 对象
        HttpServletRequest request = getCurrentRequest();
        // 记录方法开始时间，用于计算执行耗时
        long startTime = System.currentTimeMillis();

        // 获取请求 URI 和 HTTP 方法
        String uri = request != null ? request.getRequestURI() : "unknown";
        String method = request != null ? request.getMethod() : "unknown";

        // 将方法入参转换为可打印的字符串列表，避免直接打印文件流
        List<String> paramList = extractParamStrings(joinPoint.getArgs());

        // 打印请求开始日志
        log.info("[接口请求] URI={}, Method={}, Params={}", uri, method, paramList);

        Object result;
        try {
            // 执行目标 Controller 方法
            result = joinPoint.proceed();
        } catch (Throwable e) {
            // 记录异常日志，包含异常类型和提示信息
            log.error("[接口异常] URI={}, Method={}, Cost={}ms, Error={}",
                    uri, method, System.currentTimeMillis() - startTime, e.getMessage(), e);
            // 继续抛出异常，保证原有异常处理逻辑不变
            throw e;
        }

        // 计算方法执行耗时
        long costTime = System.currentTimeMillis() - startTime;
        // 将返回值序列化为 JSON 字符串，便于查看接口出参
        String responseStr = toJsonString(result);

        // 打印请求完成日志，包含响应结果和耗时
        log.info("[接口响应] URI={}, Method={}, Cost={}ms, Result={}", uri, method, costTime, responseStr);

        return result;
    }

    /**
     * 从 Spring 的请求上下文获取当前 HttpServletRequest。
     *
     * @return 当前请求对象；如果不在 Web 请求上下文则返回 null
     */
    private HttpServletRequest getCurrentRequest() {
        // 获取当前线程绑定的请求属性
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes == null) {
            return null;
        }
        // 返回当前 HTTP 请求对象
        return attributes.getRequest();
    }

    /**
     * 提取方法入参的可打印字符串列表。
     * <p>
     * 对于 {@link MultipartFile} 类型的文件参数，只打印文件名和大小，避免输出二进制内容；
     * 对于 HttpServletRequest、HttpServletResponse 等 Servlet 对象，跳过不打印；
     * 其他对象尝试序列化为 JSON 字符串。
     * </p>
     *
     * @param args 方法入参数组
     * @return 可打印的字符串列表
     */
    private List<String> extractParamStrings(Object[] args) {
        List<String> list = new ArrayList<>();
        if (args == null) {
            return list;
        }
        for (Object arg : args) {
            if (arg == null) {
                list.add("null");
                continue;
            }
            // 文件参数只记录文件名和大小，不输出二进制内容
            if (arg instanceof MultipartFile) {
                MultipartFile file = (MultipartFile) arg;
                list.add("MultipartFile{name=" + file.getOriginalFilename() + ", size=" + file.getSize() + "}");
                continue;
            }
            // Servlet 原生对象不打印
            if (arg instanceof jakarta.servlet.ServletRequest || arg instanceof jakarta.servlet.ServletResponse) {
                list.add(arg.getClass().getSimpleName());
                continue;
            }
            // 其他对象序列化为 JSON
            list.add(toJsonString(arg));
        }
        return list;
    }

    /**
     * 将任意对象序列化为 JSON 字符串，序列化失败时回退到 toString。
     *
     * @param obj 待序列化对象
     * @return JSON 字符串或对象的 toString 结果
     */
    private String toJsonString(Object obj) {
        if (obj == null) {
            return "null";
        }
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            // JSON 序列化失败时回退到 toString，避免日志打印异常
            return obj.toString();
        }
    }
}
