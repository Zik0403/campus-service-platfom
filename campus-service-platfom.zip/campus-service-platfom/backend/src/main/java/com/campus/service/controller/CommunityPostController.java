package com.campus.service.controller;

import com.campus.service.entity.CommunityPost;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.CommunityPostService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/post")
@RequiredArgsConstructor
public class CommunityPostController {

    private final CommunityPostService postService;

    private String getStr(Map<String, Object> body, String key, String defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        return v != null ? v.toString() : defaultValue;
    }

    private Long getLong(Map<String, Object> body, String key, Long defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Long.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    private Integer getInt(Map<String, Object> body, String key, Integer defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Integer.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    /**
     * 发布帖子
     */
    @PostMapping("/create")
    public R<CommunityPost> createPost(HttpServletRequest request,
                                        @RequestBody(required = false) Map<String, Object> body,
                                        @RequestParam(required = false) Integer postType,
                                        @RequestParam(required = false) String title,
                                        @RequestParam(required = false) String content,
                                        @RequestParam(required = false) String images,
                                        @RequestParam(required = false) Integer isAnon) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Integer pt = postType != null ? postType : getInt(body, "postType", null);
        String t = title != null ? title : getStr(body, "title", null);
        String c = content != null ? content : getStr(body, "content", null);
        String imgs = images != null ? images : getStr(body, "images", null);
        Integer ia = isAnon != null ? isAnon : getInt(body, "isAnon", 0);
        return R.success(postService.createPost(userId, pt, t, c, imgs, ia));
    }

    /**
     * 审核帖子
     */
    @PostMapping("/audit")
    public R<Void> auditPost(@RequestBody(required = false) Map<String, Object> body,
                              @RequestParam(required = false) Long postId,
                              @RequestParam(required = false) Integer auditStatus) {
        Long pid = postId != null ? postId : getLong(body, "postId", null);
        Integer as = auditStatus != null ? auditStatus : getInt(body, "auditStatus", null);
        postService.auditPost(pid, as);
        return R.success();
    }

    /**
     * 点赞帖子
     */
    @PostMapping("/like")
    public R<Void> likePost(HttpServletRequest request,
                             @RequestBody(required = false) Map<String, Object> body,
                             @RequestParam(required = false) Long postId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long pid = postId != null ? postId : getLong(body, "postId", null);
        postService.likePost(pid, userId);
        return R.success();
    }

    /**
     * 获取帖子详情
     */
    @GetMapping("/detail")
    public R<CommunityPost> getPostDetail(@RequestParam Long postId) {
        return R.success(postService.getPostDetail(postId));
    }

    /**
     * 获取用户帖子列表
     */
    @GetMapping("/my/list")
    public R<List<CommunityPost>> getUserPosts(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(postService.getUserPosts(userId));
    }

    /**
     * 按类型获取已审核帖子列表
     */
    @GetMapping("/list")
    public R<List<CommunityPost>> getPostsByType(@RequestParam(required = false) Integer postType) {
        return R.success(postService.getPostsByType(postType));
    }

    /**
     * 搜索帖子
     */
    @GetMapping("/search")
    public R<List<CommunityPost>> searchPosts(@RequestParam String keyword) {
        return R.success(postService.searchPosts(keyword));
    }
}
