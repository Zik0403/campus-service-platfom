package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.LostFound;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 失物招领数据访问接口。
 *
 * <p>操作的数据库表为失物招领表，对应实体类为 {@link LostFound}。
 * 主要负责校园失物招领信息的查询，例如查询某用户发布的失物/招领、按类型查询、
 * 智能匹配同一地点同类物品以及查询待匹配且已过期的记录。</p>
 */
@Mapper
public interface LostFoundMapper extends BaseMapper<LostFound> {

    /**
     * 根据用户 ID 查询该用户发布的失物或招领记录。
     *
     * @param userId 用户 ID
     * @return 该用户发布的失物招领记录列表
     */
    List<LostFound> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据类型查询失物招领记录。
     *
     * @param type 记录类型，例如失物或招领
     * @return 指定类型的失物招领记录列表
     */
    List<LostFound> selectByType(@Param("type") Integer type);

    /**
     * 智能匹配候选记录：在同一地点、同类物品中查找可能的匹配项。
     *
     * @param location 物品遗失或发现的地点
     * @param goodsType 物品类型，例如钱包、手机、书籍等
     * @param excludeUserId 需要排除的用户 ID，避免匹配到自己的记录
     * @return 可能匹配的失物招领候选列表
     */
    List<LostFound> selectMatchCandidates(@Param("location") String location, @Param("goodsType") String goodsType, @Param("excludeUserId") Long excludeUserId);

    /**
     * 查询待匹配且已经超过有效期的记录。
     *
     * @return 待匹配且已过期的记录列表
     */
    List<LostFound> selectExpiredPending();
}
