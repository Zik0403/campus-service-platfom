package com.campus.service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;

/**
 * 维修人员注册入参 DTO。
 * <p>
 * 封装维修/配送人员注册时必填字段，通过 JSR-303 注解校验
 * 手机号、身份证号、密码等格式。
 * </p>
 *
 * @author campus-service
 */
@Data
public class UserRegisterWorkerDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 真实姓名。
     */
    @NotBlank(message = "真实姓名不能为空")
    @Size(max = 32, message = "真实姓名长度不能超过32位")
    private String realName;

    /**
     * 手机号。
     */
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    /**
     * 身份证号。
     */
    @NotBlank(message = "身份证号不能为空")
    @Pattern(regexp = "(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)", message = "身份证号格式不正确")
    private String idCard;

    /**
     * 登录密码。
     */
    @NotBlank(message = "登录密码不能为空")
    @Size(min = 6, max = 32, message = "登录密码长度必须在6到32位之间")
    private String password;
}
