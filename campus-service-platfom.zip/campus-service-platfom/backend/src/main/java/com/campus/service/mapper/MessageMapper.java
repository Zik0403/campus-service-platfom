package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Message;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 站内消息数据访问接口。
 *
 * <p>操作的数据库表为消息表，对应实体类为 {@link Message}。
 * 主要负责用户站内消息的查询与状态更新，例如查询未读消息、标记单条或全部消息为已读。</p>
 */
@Mapper
public interface MessageMapper extends BaseMapper<Message> {

    /**
     * 根据用户 ID 查询该用户的所有未读消息。
     *
     * @param userId 用户 ID
     * @return 该用户的未读消息列表
     */
    List<Message> selectUnreadByUserId(@Param("userId") Long userId);

    /**
     * 将指定用户的一条消息标记为已读。
     *
     * @param userId 用户 ID，用于确保只能修改自己的消息
     * @param id 消息 ID
     * @return 受影响的数据行数，成功标记返回 1，否则返回 0
     */
    int markAsRead(@Param("userId") Long userId, @Param("id") Long id);

    /**
     * 将指定用户的所有未读消息标记为已读。
     *
     * @param userId 用户 ID
     * @return 受影响的数据行数
     */
    int markAllAsRead(@Param("userId") Long userId);
}
