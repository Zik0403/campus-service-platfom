package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 大学英语四六级成绩表。
 * 存储学生 CET-4/CET-6 考试成绩，包括总分与各单项分，用于教务数据同步与学生成绩查询。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("cet_score") // 指定对应的数据库表名为 cet_score
public class CetScore implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 成绩记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 学号，关联学生身份与教务系统数据。
     */
    private String studentId;

    /**
     * 真实姓名，与学号一起确认成绩归属。
     */
    private String realName;

    /**
     * 考试类型，如“CET4”“CET6”。
     */
    private String cetType;

    /**
     * 考试日期。
     */
    private LocalDate examDate;

    /**
     * 总分，英语四六级考试最终得分。
     */
    private Integer totalScore;

    /**
     * 听力单项分数。
     */
    private Integer listenScore;

    /**
     * 阅读单项分数。
     */
    private Integer readScore;

    /**
     * 写作与翻译单项分数。
     */
    private Integer writeScore;

    /**
     * 是否通过：0 未通过、1 已通过。
     * 通常 CET4/6 以 425 分为及格线。
     */
    private Integer isPass;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录成绩数据首次同步/录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;
}
