package com.campus.service.common.cache;

import java.time.Duration;

/**
 * Token 黑名单缓存 Key 常量类。
 * <p>
 * 用户主动登出后，将其当前 JWT Token 加入 Redis 黑名单，
 * 在 Token 自然过期之前，该 Token 无法再访问受保护接口。
 * </p>
 * <p>
 * Key 命名规范：{@code token:blacklist:{token}}，value 固定为 "1"。
 * 黑名单缓存过期时间跟随 JWT 过期时间，避免 Redis 中堆积无效数据。
 * </p>
 *
 * @author campus-service
 */
public final class TokenBlacklistConstant {

    /**
     * 私有构造方法，防止外部实例化。
     */
    private TokenBlacklistConstant() {
    }

    /**
     * Token 黑名单 Key 前缀。
     */
    public static final String TOKEN_BLACKLIST_PREFIX = "token:blacklist:";

    /**
     * 黑名单缓存占位值。
     */
    public static final String BLACKLIST_VALUE = "1";

    /**
     * 构建某个 Token 对应的黑名单缓存 Key。
     *
     * @param token JWT Token 字符串
     * @return 黑名单缓存 Key
     */
    public static String blacklistKey(String token) {
        return TOKEN_BLACKLIST_PREFIX + token;
    }

    /**
     * 黑名单默认兜底过期时间。
     * <p>
     * 当无法解析 Token 过期时间时使用，设置为 24 小时，
     * 正常情况下应以 JWT 实际剩余有效期为准。
     * </p>
     */
    public static final Duration DEFAULT_BLACKLIST_TTL = Duration.ofHours(24);
}
