package com.campus.service.controller;

import com.campus.service.dto.UserLoginDTO;
import com.campus.service.dto.UserRegisterStudentDTO;
import com.campus.service.dto.UserRegisterWorkerDTO;
import com.campus.service.entity.User;
import com.campus.service.security.JwtUtils;
import com.campus.service.service.UserService;
import com.campus.service.vo.R;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * 基于 DTO + JSR-303 校验的用户认证控制器。
 * <p>
 * 本类与 {@link UserController} 并存，提供类型安全、带参数校验的登录与注册接口，
 * 用于演示 DTO 入参和 {@link jakarta.validation.Valid} 校验在项目中的实际用法。
 * </p>
 *
 * @author campus-service
 */
@RestController
@RequestMapping("/user/dto")
@RequiredArgsConstructor
public class UserDtoController {

    /**
     * 用户服务，处理登录、注册等业务逻辑。
     */
    private final UserService userService;

    /**
     * JWT 工具类，用于生成登录 Token。
     */
    private final JwtUtils jwtUtils;

    /**
     * 学生/维修人员账号密码登录（DTO 版本）。
     * <p>
     * 使用 {@link UserLoginDTO} 接收参数，并通过 {@link Valid} 触发 JSR-303 校验。
     * 校验失败时由 {@link com.campus.service.common.exception.GlobalExceptionHandler}
     * 统一捕获并返回 400 错误提示。
     * </p>
     *
     * @param loginDTO 登录入参 DTO
     * @return 包含 Token 和用户信息的成功响应
     */
    @PostMapping("/login")
    public R<Map<String, Object>> login(@Valid @RequestBody UserLoginDTO loginDTO) {
        // 调用 Service 层完成账号密码校验
        User user = userService.loginByPassword(loginDTO.getAccount(), loginDTO.getPassword());
        // 校验通过后生成 JWT Token
        String token = jwtUtils.generateToken(user.getId(), user.getOpenid(), user.getRole());
        // 组装返回数据
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userInfo", user);
        return R.success(data);
    }

    /**
     * 学生用户注册（DTO 版本）。
     *
     * @param registerDTO 学生注册入参 DTO
     * @return 包含 Token 和用户信息的成功响应
     */
    @PostMapping("/register/student")
    public R<Map<String, Object>> registerStudent(@Valid @RequestBody UserRegisterStudentDTO registerDTO) {
        // 调用 Service 层完成学生注册
        User user = userService.registerStudent(
                registerDTO.getStudentId(),
                registerDTO.getRealName(),
                registerDTO.getPhone(),
                registerDTO.getPassword(),
                registerDTO.getDormBuild(),
                registerDTO.getDormRoom());
        // 注册成功后直接生成登录 Token，实现注册即登录
        String token = jwtUtils.generateToken(user.getId(), user.getOpenid(), user.getRole());
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userInfo", user);
        return R.success(data);
    }

    /**
     * 维修人员注册（DTO 版本）。
     *
     * @param registerDTO 维修人员注册入参 DTO
     * @return 包含 Token 和用户信息的成功响应
     */
    @PostMapping("/register/worker")
    public R<Map<String, Object>> registerWorker(@Valid @RequestBody UserRegisterWorkerDTO registerDTO) {
        // 调用 Service 层完成维修人员注册
        User user = userService.registerWorker(
                registerDTO.getRealName(),
                registerDTO.getPhone(),
                registerDTO.getIdCard(),
                registerDTO.getPassword());
        // 注册成功后直接生成登录 Token
        String token = jwtUtils.generateToken(user.getId(), user.getOpenid(), user.getRole());
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userInfo", user);
        return R.success(data);
    }
}
