package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.ServiceOrder;

import java.util.List;

/**
 * 校园跑腿/服务订单服务接口。
 * 负责校园生活服务平台中快递代取、跑腿代办、外卖配送等即时服务订单的全流程：
 * 用户下单并支付，配送员接单、开始配送、完成配送，支持取消、退款、评价与投诉。
 */
public interface ServiceOrderService extends IService<ServiceOrder> {

    /**
     * 用户创建一笔服务订单（快递代取、跑腿代办或外卖配送）。
     * @param userId 下单用户ID
     * @param serviceType 服务类型（例如：1快递代取 2跑腿代办 3外卖配送）
     * @param originAddr 取货地址或服务起点
     * @param targetAddr 送货地址或服务终点
     * @param orderContent 订单内容描述（例如：取件码、物品描述等）
     * @param tipFee 小费金额
     * @param totalFee 订单总金额
     * @return 创建后的服务订单
     */
    ServiceOrder createOrder(Long userId, Integer serviceType, String originAddr, String targetAddr,
                              String orderContent, String tipFee, String totalFee);

    /**
     * 用户支付已创建的服务订单。
     * @param orderId 订单号
     * @param wxPayNo 微信支付流水号
     * @param payPassword 用户支付密码
     */
    void payOrder(String orderId, String wxPayNo, String payPassword);

    /**
     * 配送员抢单并接单。
     * @param orderId 订单号
     * @param workerId 配送员用户ID
     */
    void workerAccept(String orderId, Long workerId);

    /**
     * 配送员开始配送服务。
     * @param orderId 订单号
     */
    void startDelivery(String orderId);

    /**
     * 配送员完成配送服务。
     * @param orderId 订单号
     * @param workerId 配送员用户ID
     */
    void completeOrder(String orderId, Long workerId);

    /**
     * 用户在配送开始前取消自己的服务订单。
     * @param orderId 订单号
     * @param userId 当前操作用户ID
     */
    void cancelOrder(String orderId, Long userId);

    /**
     * 用户申请服务订单退款。
     * @param orderId 订单号
     * @param userId 当前操作用户ID
     */
    void refundOrder(String orderId, Long userId);

    /**
     * 用户对已完成的服务订单进行评价。
     * @param orderId 订单号
     * @param userId 评价用户ID
     * @param star 评分星级（例如：1-5星）
     */
    void evaluate(String orderId, Long userId, Integer star);

    /**
     * 用户对服务过程存在问题时发起投诉。
     * @param orderId 订单号
     * @param userId 投诉用户ID
     * @param reason 投诉原因
     */
    void complainOrder(String orderId, Long userId, String reason);

    /**
     * 查询某笔服务订单的详情。
     * @param orderId 订单号
     * @param userId 当前查看用户ID
     * @return 订单详情对象
     */
    ServiceOrder getOrderDetail(String orderId, Long userId);

    /**
     * 查询某位用户的服务订单列表。
     * @param userId 用户ID
     * @param serviceType 服务类型，用于筛选特定类型的订单
     * @return 该用户的服务订单列表
     */
    List<ServiceOrder> getUserOrders(Long userId, Integer serviceType);

    /**
     * 查询某位配送员的所有服务订单。
     * @param workerId 配送员用户ID
     * @return 该配送员的服务订单列表
     */
    List<ServiceOrder> getWorkerOrders(Long workerId);

    /**
     * 查询抢单大厅中待接单的服务订单。
     * @param serviceType 服务类型，用于筛选特定类型的订单
     * @param excludeUserId 需要排除的用户ID
     * @return 待接单订单列表
     */
    List<ServiceOrder> getPendingOrders(Integer serviceType, Long excludeUserId);

    /**
     * 取消超过规定时间仍未支付的服务订单。
     */
    void cancelTimeoutOrders();

    /**
     * 配送员因特殊情况放弃已接的订单。
     * @param orderId 订单号
     * @param workerId 配送员用户ID
     */
    void workerReturnOrder(String orderId, Long workerId);
}
