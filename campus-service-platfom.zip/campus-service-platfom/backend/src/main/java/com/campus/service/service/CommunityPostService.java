package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.CommunityPost;

import java.util.List;

/**
 * 校园社区帖子服务接口。
 * 负责学生社区互动模块：学生可以发布学习求助、二手交易、校园问答、失物招领等帖子，
 * 支持点赞、审核、分类浏览、搜索以及评论数统计。
 */
public interface CommunityPostService extends IService<CommunityPost> {

    /**
     * 学生发布新帖子。
     * @param userId 发帖用户ID
     * @param postType 帖子类型（例如：1学习求助 2二手交易 3校园问答 4失物招领等）
     * @param title 帖子标题
     * @param content 帖子正文内容
     * @param images 帖子配图地址，多张图片通常以逗号分隔
     * @param isAnon 是否匿名发帖（1匿名 0实名）
     * @return 发布后的帖子对象
     */
    CommunityPost createPost(Long userId, Integer postType, String title, String content,
                             String images, Integer isAnon);

    /**
     * 管理员审核帖子是否可以展示。
     * @param postId 帖子ID
     * @param auditStatus 审核状态（例如：0待审核 1通过 2拒绝）
     */
    void auditPost(Long postId, Integer auditStatus);

    /**
     * 用户对帖子点赞或取消点赞。
     * @param postId 帖子ID
     * @param userId 当前操作用户ID
     */
    void likePost(Long postId, Long userId);

    /**
     * 查询某个帖子的详细信息。
     * @param postId 帖子ID
     * @return 帖子详情对象
     */
    CommunityPost getPostDetail(Long postId);

    /**
     * 查询某位用户发布的所有帖子。
     * @param userId 用户ID
     * @return 该用户的帖子列表
     */
    List<CommunityPost> getUserPosts(Long userId);

    /**
     * 按帖子类型查询已审核通过的帖子列表。
     * @param postType 帖子类型
     * @return 该类型下的帖子列表
     */
    List<CommunityPost> getPostsByType(Integer postType);

    /**
     * 查询所有待审核的帖子列表。
     * @return 待审核帖子列表
     */
    List<CommunityPost> getPendingAuditPosts();

    /**
     * 根据关键词搜索已审核的帖子。
     * @param keyword 搜索关键词
     * @return 符合条件的帖子列表
     */
    List<CommunityPost> searchPosts(String keyword);

    /**
     * 当帖子新增一条评论时，增加该帖子的评论数量。
     * @param postId 帖子ID
     */
    void incrementCommentNum(Long postId);
}
