package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 社团表。
 * 存储校园社团的基础信息，包括社团名称、Logo、简介、社长、分类、审核状态与成员数量，
 * 支撑小程序端社团展示、成员管理、活动发布等社团运营功能。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("club") // 指定对应的数据库表名为 club
public class Club implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 社团主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 社团名称，展示在社团列表与详情页。
     */
    private String name;

    /**
     * 社团 Logo 图片地址。
     */
    private String logo;

    /**
     * 社团简介，介绍社团宗旨、活动方向、招新信息等。
     */
    private String intro;

    /**
     * 社长用户 ID，关联 user 表，作为社团最高管理者。
     */
    private Long leaderId;

    /**
     * 社团分类，如“学术科技”“文化艺术”“体育健身”“公益实践”。
     */
    private String category;

    /**
     * 审核状态：1 待审核、2 已通过、3 驳回。
     * 新社团注册或信息变更后需管理员审核。
     */
    private Integer auditStatus;

    /**
     * 社团状态：0 禁用、1 启用，控制是否在前端展示与开展活动。
     */
    private Integer status;

    /**
     * 成员数量，加入/退出社团时维护，用于社团热度展示。
     */
    private Integer memberCount;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录社团首次创建时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录社团信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
