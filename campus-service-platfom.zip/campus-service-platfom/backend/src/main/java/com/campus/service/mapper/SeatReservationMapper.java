package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.SeatReservation;
import org.apache.ibatis.annotations.Mapper;

/**
 * 图书馆座位预约数据访问接口。
 *
 * <p>操作的数据库表为座位预约表，对应实体类为 {@link SeatReservation}。
 * 主要负责学生对图书馆座位的预约记录的增删改查，例如预约某个座位、取消预约等。</p>
 */
@Mapper
public interface SeatReservationMapper extends BaseMapper<SeatReservation> {
}
