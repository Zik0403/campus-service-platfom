package com.campus.service.converter;

import com.campus.service.dto.ServiceOrderCreateDTO;
import com.campus.service.entity.ServiceOrder;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

/**
 * 服务订单实体与 DTO 转换映射器。
 * <p>
 * 使用 MapStruct 在编译期自动生成 {@link ServiceOrderCreateDTO} 到 {@link ServiceOrder} 的转换代码，
 * 用于 DTO 版本下单接口中的对象映射。
 * </p>
 *
 * @author campus-service
 */
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ServiceOrderConverter {

    /**
     * 服务订单创建 DTO 转换为 ServiceOrder 实体。
     * <p>
     * DTO 中的金额字段为 {@code BigDecimal}，与实体字段类型一致，可直接映射；
     * 订单号、用户 ID、状态等需要在业务层后续设置，因此忽略未映射属性。
     * </p>
     *
     * @param dto 服务订单创建入参 DTO
     * @return 服务订单实体对象
     */
    ServiceOrder createDtoToEntity(ServiceOrderCreateDTO dto);
}
