package com.campus.service.config;

import com.campus.service.job.OrderTimeoutQuartzJob;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import javax.sql.DataSource;
import java.util.Properties;

/**
 * Quartz 持久化定时任务配置类。
 * <p>
 * 配置基于 JDBC JobStore 的持久化调度器，将任务、触发器信息保存到数据库，
 * 支持应用重启后任务不丢失，也支持集群环境下通过数据库锁避免重复触发。
 * </p>
 * <p>
 * 本配置会覆盖 Spring Boot 默认的内存调度器（QuartzAutoConfiguration），
 * 启用后需要先在数据库执行 {@code sql/quartz_persistence.sql} 创建 Quartz 表。
 * </p>
 *
 * @author campus-service
 */
@Configuration
@RequiredArgsConstructor
public class QuartzConfig {

    /**
     * Spring 数据源，Quartz 通过它读写任务持久化表。
     */
    private final DataSource dataSource;

    /**
     * 配置订单超时检查 JobDetail。
     * <p>
     * JobDetail 描述任务的元数据，包括任务类、名称、是否持久化等。
     * </p>
     *
     * @return Quartz JobDetail
     */
    @Bean
    public JobDetailFactoryBean orderTimeoutJobDetail() {
        JobDetailFactoryBean factory = new JobDetailFactoryBean();
        // 指定任务类为 OrderTimeoutQuartzJob
        factory.setJobClass(OrderTimeoutQuartzJob.class);
        // 任务名称，保存到 QRTZ_JOB_DETAILS 表
        factory.setName("orderTimeoutJob");
        // 任务分组
        factory.setGroup("CAMPUS_SERVICE");
        // 任务是否持久化：没有触发器关联时也保留在数据库中
        factory.setDurability(true);
        // 应用恢复时是否重新执行任务
        factory.setRequestsRecovery(true);
        return factory;
    }

    /**
     * 配置订单超时检查触发器。
     * <p>
     * 每 5 分钟触发一次，与原有 {@code @Scheduled(fixedRate = 5 * 60 * 1000)} 频率保持一致。
     * </p>
     *
     * @param jobDetail 订单超时 JobDetail
     * @return Quartz CronTrigger
     */
    @Bean
    public CronTriggerFactoryBean orderTimeoutTrigger(JobDetailFactoryBean jobDetail) {
        CronTriggerFactoryBean factory = new CronTriggerFactoryBean();
        // 关联对应的 JobDetail
        factory.setJobDetail(jobDetail.getObject());
        // 触发器名称
        factory.setName("orderTimeoutTrigger");
        // 触发器分组
        factory.setGroup("CAMPUS_SERVICE");
        // 每 5 分钟执行一次：秒 分 时 日 月 周 年
        factory.setCronExpression("0 0/5 * * * ?");
        return factory;
    }

    /**
     * 配置持久化的 Quartz Scheduler。
     * <p>
     * 使用 JDBC JobStore 将任务状态持久化到 MySQL，
     * 并设置集群模式，使多个应用实例共享数据库锁，避免重复执行。
     * </p>
     *
     * @param jobDetail 订单超时 JobDetail
     * @param trigger   订单超时触发器
     * @return Quartz SchedulerFactoryBean
     */
    @Bean
    public SchedulerFactoryBean quartzSchedulerFactoryBean(JobDetailFactoryBean jobDetail,
                                                            CronTriggerFactoryBean trigger) {
        SchedulerFactoryBean factory = new SchedulerFactoryBean();
        // 指定数据源，Quartz 通过该数据源操作 QRTZ_ 系列表
        factory.setDataSource(dataSource);
        // 配置 Quartz 属性
        factory.setQuartzProperties(quartzProperties());
        // 注册 JobDetail
        factory.setJobDetails(jobDetail.getObject());
        // 注册触发器
        factory.setTriggers(trigger.getObject());
        // 应用关闭时等待任务执行完成再停止调度器
        factory.setWaitForJobsToCompleteOnShutdown(true);
        // 启动时是否覆盖已有的 JobDetail 和 Trigger 定义
        factory.setOverwriteExistingJobs(true);
        return factory;
    }

    /**
     * 构造 Quartz 运行所需的属性。
     * <p>
     * 关键配置：
     * <ul>
     *   <li>JobStore 使用 JDBC 事务模式；</li>
     *   <li>MySQL 使用 StdJDBCDelegate；</li>
     *   <li>开启集群模式，避免多节点重复触发。</li>
     * </ul>
     * </p>
     *
     * @return Quartz 配置属性
     */
    private Properties quartzProperties() {
        Properties props = new Properties();
        // 调度器实例名称
        props.put("org.quartz.scheduler.instanceName", "CampusPersistentScheduler");
        // 实例 ID 自动生成
        props.put("org.quartz.scheduler.instanceId", "AUTO");

        // 线程池配置
        props.put("org.quartz.threadPool.class", "org.quartz.simpl.SimpleThreadPool");
        props.put("org.quartz.threadPool.threadCount", "5");
        props.put("org.quartz.threadPool.threadPriority", "5");

        // JobStore 配置：使用数据库存储
        props.put("org.quartz.jobStore.class", "org.quartz.impl.jdbcjobstore.JobStoreTX");
        // MySQL 驱动委托类
        props.put("org.quartz.jobStore.driverDelegateClass", "org.quartz.impl.jdbcjobstore.StdJDBCDelegate");
        // 表前缀
        props.put("org.quartz.jobStore.tablePrefix", "QRTZ_");
        // 是否使用属性存储 JobDataMap（false 表示使用 BLOB）
        props.put("org.quartz.jobStore.useProperties", "false");
        // 集群模式，多节点共享数据库锁
        props.put("org.quartz.jobStore.isClustered", "true");
        // 集群节点间检查频率（毫秒）
        props.put("org.quartz.jobStore.clusterCheckinInterval", "20000");
        // 事务隔离级别：读已提交
        props.put("org.quartz.jobStore.txIsolationLevelSerializable", "false");

        // Misfire 阈值（毫秒）
        props.put("org.quartz.jobStore.misfireThreshold", "60000");
        return props;
    }
}
