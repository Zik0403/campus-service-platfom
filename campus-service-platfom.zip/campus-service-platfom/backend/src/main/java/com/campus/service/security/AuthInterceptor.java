package com.campus.service.security;

import com.campus.service.common.constants.RoleConstants;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.User;
import com.campus.service.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * JWT 认证拦截器，用于拦截进入校园生活服务后端的 HTTP 请求，验证用户是否已登录。
 * <p>
 * 整体职责：
 * <ul>
 *   <li>从请求头 {@code Authorization} 中提取 Bearer Token；</li>
 *   <li>调用 {@link JwtUtils} 解析 Token，获取用户 ID 与角色；</li>
 *   <li>将解析出的身份信息设置到请求属性中，供后续 Controller 层使用；</li>
 *   <li>Token 缺失、过期或解析失败时抛出未授权异常，阻止请求继续执行。</li>
 * </ul>
 * </p>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AuthInterceptor implements HandlerInterceptor {

    /**
     * JWT 工具类，负责 Token 的解析与校验。
     */
    private final JwtUtils jwtUtils;

    /**
     * 请求属性中存放当前登录用户 ID 的键名。
     */
    public static final String USER_ID_KEY = "userId";

    /**
     * 请求属性中存放当前登录用户角色编码的键名。
     */
    public static final String USER_ROLE_KEY = "userRole";

    /**
     * 请求属性中存放当前登录用户完整对象的键名（预留）。
     */
    public static final String USER_KEY = "currentUser";

    /**
     * 在 Controller 方法执行前进行登录校验。
     *
     * @param request  当前 HTTP 请求对象
     * @param response 当前 HTTP 响应对象
     * @param handler  即将执行的处理器（Controller 方法）
     * @return 校验通过返回 {@code true}，允许继续执行；否则抛出异常
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 对于浏览器预检请求（OPTIONS），直接放行，避免跨域校验被拦截
        if ("OPTIONS".equals(request.getMethod())) {
            return true;
        }

        // 从请求头中提取 Bearer Token
        String token = extractToken(request);
        // 如果请求头中没有携带 Token，说明用户未登录，抛出 401 未授权异常
        if (token == null) {
            throw BusinessException.UNAUTHORIZED;
        }

        try {
            // 如果是特殊的 guest Token，直接赋予默认游客身份（用于调试或开放接口占位）
            if ("guest".equals(token)) {
                // 将默认用户 ID 设置到请求属性中
                request.setAttribute(USER_ID_KEY, 1L);
                // 将默认学生角色设置到请求属性中
                request.setAttribute(USER_ROLE_KEY, 1);
            } else {
                // 调用 JWT 工具类解析 Token，获取当前登录用户 ID
                Long userId = jwtUtils.getUserId(token);
                // 调用 JWT 工具类解析 Token，获取当前登录用户角色
                Integer role = jwtUtils.getRole(token);
                // 将用户 ID 存入请求属性，Controller 可通过 request.getAttribute 获取当前登录人
                request.setAttribute(USER_ID_KEY, userId);
                // 将用户角色存入请求属性，Controller 可通过 request.getAttribute 获取当前角色
                request.setAttribute(USER_ROLE_KEY, role);
            }
        } catch (Exception e) {
            // Token 解析失败（如过期、被篡改），记录警告日志后抛出未授权异常
            log.warn("JWT解析失败: {}", e.getMessage());
            throw BusinessException.UNAUTHORIZED;
        }

        // 校验通过，放行请求，继续进入 Controller
        return true;
    }

    /**
     * 从 HTTP 请求头中提取 Bearer Token。
     *
     * @param request 当前 HTTP 请求对象
     * @return 提取到的 Token 字符串；若请求头为空或格式不正确则返回 {@code null}
     */
    private String extractToken(HttpServletRequest request) {
        // 读取请求头 Authorization 字段的值
        String bearerToken = request.getHeader("Authorization");
        // 判断请求头是否有内容，并且以 "Bearer " 开头（注意末尾有一个空格）
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            // 去掉前缀 "Bearer "，只保留后面的 Token 字符串
            return bearerToken.substring(7);
        }
        // 请求头格式不符合要求，返回 null 表示未获取到 Token
        return null;
    }
}
