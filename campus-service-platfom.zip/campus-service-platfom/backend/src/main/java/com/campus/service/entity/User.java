package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 用户表。
 * 存储微信小程序用户、维修员、社团运营、管理员等所有账号的基础信息、角色、宿舍、实名与资产信息，
 * 是整个校园生活服务小程序账号体系与权限判断的核心表。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("user") // 指定对应的数据库表名为 user
public class User implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 用户主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 微信唯一 openid，微信小程序登录后由微信服务端返回，作为账号唯一标识。
     */
    private String openid;

    /**
     * 学号，学生完成实名认证后填写，用于教务信息关联。
     */
    private String studentId;

    /**
     * 真实姓名，实名认证后保存，用于展示、信用体系与业务审核。
     */
    private String realName;

    /**
     * 手机号，用于联系、短信通知与账号安全验证。
     */
    private String phone;

    /**
     * 身份证号，维修人员/配送员等角色实名认证时使用。
     */
    private String idCard;

    /**
     * 登录密码，普通账号（如管理员）登录时使用，微信用户通常为空。
     */
    private String password;

    /**
     * 支付密码，6 位数字，用于钱包支付、提现等资金操作校验。
     */
    private String payPassword;

    /**
     * 头像 OSS 地址，用户个人头像图片的云端存储链接。
     */
    private String avatar;

    /**
     * 微信昵称，从小程序授权获取，用于页面展示。
     */
    private String nickname;

    /**
     * 角色：1 学生、2 维修/配送员、3 社团运营、4 超级管理员。
     * 不同角色拥有不同的功能权限与业务入口。
     */
    private Integer role;

    /**
     * 宿舍楼栋，用于宿舍报修、外卖/快递配送等定位。
     */
    private String dormBuild;

    /**
     * 宿舍房间号，与楼栋一起精确定位到学生宿舍。
     */
    private String dormRoom;

    /**
     * 信用积分，初始值为 100，参与活动、违约投诉等场景会增减。
     */
    private Integer creditScore;

    /**
     * 账户余额，可用于支付订单、提现等资金操作。
     */
    private BigDecimal balance;

    /**
     * 实名状态：0 未实名、1 已实名。
     * 部分业务（如发布二手商品、接单配送）要求必须先实名。
     */
    private Integer isAuth;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     * 采用逻辑删除，数据不会真正从数据库移除，便于追溯。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录账号首次注册时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录账号信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
