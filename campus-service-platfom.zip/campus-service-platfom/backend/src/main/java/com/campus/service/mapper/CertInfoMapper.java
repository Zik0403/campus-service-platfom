package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.CertInfo;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户实名认证信息数据访问接口。
 *
 * <p>操作的数据库表为实名认证信息表，对应实体类为 {@link CertInfo}。
 * 主要负责学生或教职工实名认证资料（如姓名、学号、身份证等）的增删改查。</p>
 */
@Mapper
public interface CertInfoMapper extends BaseMapper<CertInfo> {
}
