package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 操作日志表。
 * 记录用户（学生、工作人员、管理员等）在系统中的关键操作，包括请求方法、路径、参数、IP 与结果，
 * 用于问题排查、安全审计与操作追溯。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("sys_log") // 指定对应的数据库表名为 sys_log
public class SysLog implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 日志主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 操作用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 用户类型：1 学生、2 工作人员、3 运营、4 管理员。
     */
    private Integer userType;

    /**
     * 操作类型，如“登录”“新增”“修改”“删除”“导出”。
     */
    private String action;

    /**
     * 请求方法签名，记录调用的是哪个 Service/Mapper/Controller 方法。
     */
    private String method;

    /**
     * 请求路径/接口地址。
     */
    private String url;

    /**
     * 请求参数，记录接口调用时传入的参数（注意敏感信息需脱敏）。
     */
    private String params;

    /**
     * 操作人 IP 地址，用于定位与安全审计。
     */
    private String ip;

    /**
     * 操作结果，如“成功”“失败：权限不足”。
     */
    private String result;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录操作发生时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;
}
