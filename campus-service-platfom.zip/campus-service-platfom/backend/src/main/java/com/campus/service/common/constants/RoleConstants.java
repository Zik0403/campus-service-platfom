package com.campus.service.common.constants;

/**
 * 校园生活服务项目用户角色常量类。
 * 定义小程序用户账号的角色编码（学生、维修/配送员、社团/学院运营、超级管理员），
 * 并提供角色名称转换及角色身份判断方法，供登录鉴权、接口权限控制、业务入口展示等场景统一使用。
 */
public class RoleConstants {

    /** 角色编码：1 普通学生，可使用下单、二手、活动、社区等校园服务功能 */
    public static final int ROLE_STUDENT = 1;
    /** 角色编码：2 维修员/配送员，可接维修单、配送单并赚取收入 */
    public static final int ROLE_WORKER = 2;
    /** 角色编码：3 社团/学院运营，可发布活动、管理社团成员与审核内容 */
    public static final int ROLE_OPERATOR = 3;
    /** 角色编码：4 超级管理员，拥有用户、订单、内容、配置等最高管理权限 */
    public static final int ROLE_ADMIN = 4;

    /**
     * 根据角色编码获取对应的中文角色名称。
     *
     * @param role 用户角色编码
     * @return 中文角色名称，如“学生”“管理员”；不匹配时返回“未知”
     */
    public static String getRoleName(int role) {
        // 使用 switch 表达式匹配角色编码，返回对应中文名称
        return switch (role) {
            case ROLE_STUDENT -> "学生";
            case ROLE_WORKER -> "工作人员";
            case ROLE_OPERATOR -> "运营者";
            case ROLE_ADMIN -> "管理员";
            default -> "未知";
        };
    }

    /**
     * 判断给定角色是否为超级管理员。
     *
     * @param role 用户角色编码
     * @return true 表示超级管理员；false 表示非超级管理员
     */
    public static boolean isAdmin(int role) {
        // 直接将角色编码与管理员编码 4 比较
        return role == ROLE_ADMIN;
    }

    /**
     * 判断给定角色是否为维修/配送工作人员。
     *
     * @param role 用户角色编码
     * @return true 表示维修/配送员；false 表示非工作人员
     */
    public static boolean isWorker(int role) {
        // 直接将角色编码与工作人员编码 2 比较
        return role == ROLE_WORKER;
    }

    /**
     * 判断给定角色是否为社团/学院运营人员。
     *
     * @param role 用户角色编码
     * @return true 表示运营人员；false 表示非运营人员
     */
    public static boolean isOperator(int role) {
        // 直接将角色编码与运营编码 3 比较
        return role == ROLE_OPERATOR;
    }

    /**
     * 判断给定角色是否为学生。
     *
     * @param role 用户角色编码
     * @return true 表示学生；false 表示非学生
     */
    public static boolean isStudent(int role) {
        // 直接将角色编码与学生编码 1 比较
        return role == ROLE_STUDENT;
    }
}
