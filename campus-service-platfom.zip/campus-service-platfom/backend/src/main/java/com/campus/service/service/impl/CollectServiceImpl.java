package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.entity.Collect;
import com.campus.service.mapper.CollectMapper;
import com.campus.service.service.CollectService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 用户收藏业务实现类。
 * <p>
 * 负责校园生活服务模块中的用户收藏功能，支持对服务订单、二手商品、报修工单等目标对象
 * 进行收藏、取消收藏、查询是否已收藏以及查询用户的收藏列表等业务操作。
 * </p>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class CollectServiceImpl extends ServiceImpl<CollectMapper, Collect> implements CollectService {

    /**
     * 用户添加收藏。
     *
     * @param userId     用户 ID
     * @param targetType 收藏目标类型（如服务订单、二手商品、报修工单等）
     * @param targetId   收藏目标 ID
     */
    @Override
    @Transactional
    public void addCollect(Long userId, Integer targetType, Long targetId) {
        // 查询 collect 表中是否已存在该用户对该目标的收藏记录
        Collect exist = getByUserAndTarget(userId, targetType, targetId);
        // 若已存在收藏记录，则直接返回，避免重复收藏
        if (exist != null) {
            return;
        }
        // 创建一个新的收藏实体对象
        Collect collect = new Collect();
        // 设置收藏用户 ID
        collect.setUserId(userId);
        // 设置收藏目标类型
        collect.setTargetType(targetType);
        // 设置收藏目标 ID
        collect.setTargetId(targetId);
        // 调用 save 方法将收藏记录插入 collect 表
        save(collect);
        // 记录用户收藏日志
        log.info("用户收藏: userId={}, targetType={}, targetId={}", userId, targetType, targetId);
    }

    /**
     * 用户取消收藏。
     *
     * @param userId     用户 ID
     * @param targetType 收藏目标类型
     * @param targetId   收藏目标 ID
     */
    @Override
    @Transactional
    public void removeCollect(Long userId, Integer targetType, Long targetId) {
        // 查询 collect 表中该用户对该目标的收藏记录
        Collect collect = getByUserAndTarget(userId, targetType, targetId);
        // 若存在收藏记录，则根据收藏记录 ID 从 collect 表中删除
        if (collect != null) {
            removeById(collect.getId());
            // 记录用户取消收藏日志
            log.info("用户取消收藏: userId={}, targetType={}, targetId={}", userId, targetType, targetId);
        }
    }

    /**
     * 判断用户是否已收藏指定目标。
     *
     * @param userId     用户 ID
     * @param targetType 收藏目标类型
     * @param targetId   收藏目标 ID
     * @return 已收藏返回 true，未收藏返回 false
     */
    @Override
    public boolean isCollected(Long userId, Integer targetType, Long targetId) {
        // 查询 collect 表中是否存在对应收藏记录，存在则返回 true，否则返回 false
        return getByUserAndTarget(userId, targetType, targetId) != null;
    }

    /**
     * 查询指定用户的所有收藏列表。
     *
     * @param userId 用户 ID
     * @return 该用户的收藏列表
     */
    @Override
    public List<Collect> getUserCollects(Long userId) {
        // 查询 collect 表中用户 ID 等于指定值的所有收藏记录，按创建时间倒序返回
        return list(new LambdaQueryWrapper<Collect>()
                .eq(Collect::getUserId, userId)
                .orderByDesc(Collect::getCreateTime));
    }

    /**
     * 根据用户、目标类型和目标 ID 查询单条收藏记录。
     *
     * @param userId     用户 ID
     * @param targetType 收藏目标类型
     * @param targetId   收藏目标 ID
     * @return 对应的收藏记录，若不存在则返回 null
     */
    private Collect getByUserAndTarget(Long userId, Integer targetType, Long targetId) {
        // 构建 collect 表查询条件：用户 ID、目标类型、目标 ID 均相等
        return getOne(new LambdaQueryWrapper<Collect>()
                .eq(Collect::getUserId, userId)
                .eq(Collect::getTargetType, targetType)
                .eq(Collect::getTargetId, targetId));
    }
}
