package com.campus.service.common.cache;

/**
 * 幂等性相关 Redis Key 常量。
 * <p>
 * 支付、退款等涉及资金变动的接口需要保证同一笔业务只执行一次，
 * 通过 Redis 幂等 Key 对重复请求进行拦截。
 * </p>
 *
 * @author campus-service
 */
public final class IdempotencyKeyConstant {

    /**
     * 服务订单余额支付幂等 Key 前缀。
     */
    public static final String PAY_ORDER_PREFIX = "idempotent:pay:order:";

    /**
     * 服务订单支付幂等 Key：以订单号作为唯一标识。
     * <p>
     * 同一笔服务订单无论用户重复提交多少次支付请求，只会真正扣款一次。
     * </p>
     *
     * @param orderId 服务订单号
     * @return 该订单对应的支付幂等 Redis Key
     */
    public static String payOrderKey(String orderId) {
        return PAY_ORDER_PREFIX + orderId;
    }

    private IdempotencyKeyConstant() {
        // 工具类禁止实例化
    }
}
