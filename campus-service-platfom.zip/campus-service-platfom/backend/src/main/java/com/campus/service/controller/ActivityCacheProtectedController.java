package com.campus.service.controller;

import com.campus.service.entity.Activity;
import com.campus.service.service.impl.ActivityServiceImpl;
import com.campus.service.vo.R;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 活动列表缓存防护接口控制器。
 * <p>
 * 与 {@link ActivityController} 并存，提供带缓存穿透、缓存击穿、缓存雪崩三重防护的活动查询接口。
 * 这些接口调用 {@link ActivityServiceImpl} 中的增强缓存方法，不影响原有活动业务接口。
 * </p>
 *
 * @author campus-service
 */
@RestController
@RequestMapping("/activity-protected")
@RequiredArgsConstructor
public class ActivityCacheProtectedController {

    /**
     * 校园活动服务实现类，直接注入以使用增强的带防护缓存方法。
     */
    private final ActivityServiceImpl activityServiceImpl;

    /**
     * 获取当前可报名活动列表（带缓存三重防护）。
     *
     * @return 当前可报名活动列表
     */
    @GetMapping("/available")
    public R<List<Activity>> getAvailableActivitiesWithCacheProtected() {
        // 调用带防护的可报名活动缓存查询方法
        return R.success(activityServiceImpl.getAvailableActivitiesWithCacheProtected());
    }

    /**
     * 获取指定社团活动列表（带缓存三重防护）。
     *
     * @param clubId 社团 ID
     * @return 该社团下已通过审核且启用的活动列表
     */
    @GetMapping("/club")
    public R<List<Activity>> getClubActivitiesWithCacheProtected(@RequestParam Long clubId) {
        // 调用带防护的社团活动缓存查询方法
        return R.success(activityServiceImpl.getClubActivitiesWithCacheProtected(clubId));
    }

    /**
     * 获取待审核活动列表（带缓存三重防护，管理员使用）。
     *
     * @return 待审核活动列表
     */
    @GetMapping("/pending")
    public R<List<Activity>> getPendingAuditActivitiesWithCacheProtected() {
        // 调用带防护的待审核活动缓存查询方法
        return R.success(activityServiceImpl.getPendingAuditActivitiesWithCacheProtected());
    }
}
