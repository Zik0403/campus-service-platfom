package com.campus.service.controller;

import com.campus.service.entity.CampusNotice;
import com.campus.service.service.impl.CampusNoticeServiceImpl;
import com.campus.service.vo.R;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 公告列表缓存防护接口控制器。
 * <p>
 * 与 {@link NoticeController} 并存，提供带缓存穿透、缓存击穿、缓存雪崩三重防护的公告查询接口。
 * 这些接口调用 {@link CampusNoticeServiceImpl} 中的增强缓存方法，不影响原有公告业务接口。
 * </p>
 *
 * @author campus-service
 */
@RestController
@RequestMapping("/notice-protected")
@RequiredArgsConstructor
public class NoticeCacheProtectedController {

    /**
     * 校园公告服务实现类，直接注入以使用增强的带防护缓存方法。
     */
    private final CampusNoticeServiceImpl noticeServiceImpl;

    /**
     * 获取全部已上线公告列表（带缓存三重防护）。
     * <p>
     * 先走 Redis 缓存；缓存未命中时使用分布式锁单线程回源，
     * 数据库无数据时写入空值占位，避免缓存穿透。
     * </p>
     *
     * @return 已上线公告列表
     */
    @GetMapping("/list")
    public R<List<CampusNotice>> getOnlineNoticesWithCacheProtected() {
        // 调用带防护的缓存查询方法
        return R.success(noticeServiceImpl.getOnlineNoticesWithCacheProtected());
    }

    /**
     * 按类型获取已上线公告列表（带缓存三重防护）。
     *
     * @param noticeType 公告类型
     * @return 指定类型下已上线公告列表
     */
    @GetMapping("/listByType")
    public R<List<CampusNotice>> getOnlineNoticesByTypeWithCacheProtected(@RequestParam Integer noticeType) {
        // 调用带防护的按类型缓存查询方法
        return R.success(noticeServiceImpl.getOnlineNoticesByTypeWithCacheProtected(noticeType));
    }
}
