package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 教室资源表。
 * 存储学校可用教室的基本信息，包括所在楼宇、房间号、容量、类型与设备，
 * 是教室预约、课程占用与自习室查询的数据基础。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("classroom") // 指定对应的数据库表名为 classroom
public class Classroom implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 教室主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 教学楼/楼栋名称，如“第一教学楼”。
     */
    private String building;

    /**
     * 教室房间号，如“302”。
     */
    private String roomNo;

    /**
     * 教室容量，最多可容纳人数，用于判断是否满足活动或自习人数需求。
     */
    private Integer capacity;

    /**
     * 教室类型，如“普通教室”“多媒体教室”“实验室”“会议室”。
     */
    private String classroomType;

    /**
     * 教室设备说明，如“投影仪”“空调”“白板”。
     */
    private String equipment;

    /**
     * 教室状态：0 禁用、1 可用，控制是否允许预约。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录教室资源首次录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录教室资源信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
