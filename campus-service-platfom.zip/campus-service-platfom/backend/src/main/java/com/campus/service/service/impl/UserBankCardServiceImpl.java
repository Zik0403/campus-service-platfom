package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.common.util.PasswordUtil;
import com.campus.service.entity.UserBankCard;
import com.campus.service.mapper.UserBankCardMapper;
import com.campus.service.service.UserBankCardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 用户银行卡服务实现类。
 * <p>
 * 负责校园生活服务系统中用户银行卡的绑定、解绑、默认卡设置、
 * 卡号脱敏展示、卡号格式校验以及银行卡密码校验等业务。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserBankCardServiceImpl extends ServiceImpl<UserBankCardMapper, UserBankCard> implements UserBankCardService {

    /**
     * 查询指定用户已绑定的所有银行卡列表，默认卡排在最前面。
     *
     * @param userId 用户 ID
     * @return 银行卡列表，按是否默认降序、创建时间降序排列
     */
    @Override
    public List<UserBankCard> getUserCards(Long userId) {
        // 查询用户银行卡表：用户 ID 匹配、未删除，按是否默认和创建时间倒序排列
        return list(new LambdaQueryWrapper<UserBankCard>()
                .eq(UserBankCard::getUserId, userId)
                .eq(UserBankCard::getIsDelete, 0)
                .orderByDesc(UserBankCard::getIsDefault)
                .orderByDesc(UserBankCard::getCreateTime));
    }

    /**
     * 为指定用户添加一张银行卡，并对卡号和密码进行加密存储。
     *
     * @param userId      用户 ID
     * @param bankName    银行名称
     * @param cardNumber  银行卡号
     * @param cardPassword 银行卡密码
     * @return 添加成功的银行卡信息
     */
    @Override
    @Transactional
    public UserBankCard addCard(Long userId, String bankName, String cardNumber, String cardPassword) {
        // 校验银行名称是否为空
        if (bankName == null || bankName.isEmpty()) {
            throw new BusinessException("请输入银行名称");
        }
        // 校验银行卡号格式是否正确
        if (cardNumber == null || !isValidCardNumber(cardNumber)) {
            throw new BusinessException("请输入正确的银行卡号");
        }
        // 校验银行卡密码是否为 6 位纯数字
        if (cardPassword == null || cardPassword.length() != 6 || !cardPassword.matches("\\d{6}")) {
            throw new BusinessException("银行卡密码必须是6位数字");
        }
        // 统计当前用户已绑定的银行卡数量
        long count = count(new LambdaQueryWrapper<UserBankCard>()
                .eq(UserBankCard::getUserId, userId)
                .eq(UserBankCard::getIsDelete, 0));
        // 如果已绑定 5 张卡，则不允许继续绑定
        if (count >= 5) {
            throw new BusinessException("最多绑定5张银行卡");
        }
        // 生成银行卡号的脱敏显示字符串
        String mask = maskCardNumber(cardNumber);
        // 创建银行卡实体对象
        UserBankCard card = new UserBankCard();
        // 设置银行卡所属用户
        card.setUserId(userId);
        // 设置银行名称
        card.setBankName(bankName);
        // 对完整银行卡号进行加密后保存
        card.setCardNumber(PasswordUtil.encode(cardNumber));
        // 保存脱敏后的卡号，用于前端展示
        card.setCardNumberMask(mask);
        // 对银行卡密码进行加密后保存
        card.setCardPassword(PasswordUtil.encode(cardPassword));
        // 如果当前没有绑定任何卡，则设为默认卡，否则设为非默认卡
        card.setIsDefault(count == 0 ? 1 : 0);
        // 设置银行卡为未删除状态
        card.setIsDelete(0);
        // 将银行卡信息插入数据库
        save(card);
        // 记录添加银行卡日志
        log.info("用户添加银行卡: userId={}, cardId={}, bankName={}", userId, card.getId(), bankName);
        // 返回添加成功的银行卡对象
        return card;
    }

    /**
     * 删除指定用户的某张银行卡，如果被删除的是默认卡，则自动将最早绑定的卡设为默认卡。
     *
     * @param userId 用户 ID
     * @param cardId 银行卡 ID
     */
    @Override
    @Transactional
    public void deleteCard(Long userId, Long cardId) {
        // 根据银行卡 ID 查询银行卡信息
        UserBankCard card = getById(cardId);
        // 如果银行卡不存在或不属于当前用户，则抛出异常
        if (card == null || !card.getUserId().equals(userId)) {
            throw new BusinessException("银行卡不存在");
        }
        // 使用逻辑删除方式更新银行卡表：将该卡标记为已删除
        int rows = baseMapper.update(null, new com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper<UserBankCard>()
                .eq(UserBankCard::getId, cardId)
                .eq(UserBankCard::getUserId, userId)
                .set(UserBankCard::getIsDelete, 1));
        // 如果更新失败，抛出异常
        if (rows <= 0) {
            throw new BusinessException("删除失败，请重试");
        }
        // 记录删除银行卡日志
        log.info("用户删除银行卡: userId={}, cardId={}", userId, cardId);
        // 如果被删除的是默认卡，需要重新指定默认卡
        if (card.getIsDefault() != null && card.getIsDefault() == 1) {
            // 查询该用户剩余银行卡中创建时间最早的一张
            List<UserBankCard> cards = list(new LambdaQueryWrapper<UserBankCard>()
                    .eq(UserBankCard::getUserId, userId)
                    .orderByAsc(UserBankCard::getCreateTime)
                    .last("LIMIT 1"));
            // 如果还有剩余银行卡，则把最早绑定的卡设为默认卡
            if (!cards.isEmpty()) {
                UserBankCard newDefault = cards.get(0);
                newDefault.setIsDefault(1);
                updateById(newDefault);
            }
        }
    }

    /**
     * 将指定银行卡设为默认卡，同时取消该用户其他卡的默认状态。
     *
     * @param userId 用户 ID
     * @param cardId 银行卡 ID
     */
    @Override
    @Transactional
    public void setDefaultCard(Long userId, Long cardId) {
        // 根据银行卡 ID 查询银行卡信息
        UserBankCard card = getById(cardId);
        // 如果银行卡不存在或不属于当前用户，则抛出异常
        if (card == null || !card.getUserId().equals(userId)) {
            throw new BusinessException("银行卡不存在");
        }
        // 先将该用户所有银行卡的默认状态取消
        baseMapper.update(null, new com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper<UserBankCard>()
                .eq(UserBankCard::getUserId, userId)
                .set(UserBankCard::getIsDefault, 0));
        // 将当前选中的银行卡设为默认卡
        card.setIsDefault(1);
        updateById(card);
        // 记录设置默认卡日志
        log.info("用户设置默认银行卡: userId={}, cardId={}", userId, cardId);
    }

    /**
     * 查询指定用户的默认银行卡。
     *
     * @param userId 用户 ID
     * @return 默认银行卡信息，不存在则返回 null
     */
    @Override
    public UserBankCard getDefaultCard(Long userId) {
        // 查询银行卡表：用户 ID 匹配、默认卡、未删除，只取一条记录
        return getOne(new LambdaQueryWrapper<UserBankCard>()
                .eq(UserBankCard::getUserId, userId)
                .eq(UserBankCard::getIsDefault, 1)
                .eq(UserBankCard::getIsDelete, 0)
                .last("LIMIT 1"));
    }

    /**
     * 校验银行卡密码是否正确。
     *
     * @param cardId   银行卡 ID
     * @param password 用户输入的银行卡密码
     * @return 校验通过返回 true，否则返回 false
     */
    @Override
    public boolean verifyCardPassword(Long cardId, String password) {
        // 校验密码长度是否为 6 位
        if (password == null || password.length() != 6) {
            return false;
        }
        // 根据银行卡 ID 查询银行卡信息
        UserBankCard card = getById(cardId);
        // 如果银行卡不存在或未设置密码，则校验失败
        if (card == null || card.getCardPassword() == null) {
            return false;
        }
        // 将输入的密码与数据库中的加密密码进行比对
        return PasswordUtil.matches(password, card.getCardPassword());
    }

    /**
     * 校验银行卡号格式是否合法。
     *
     * @param cardNumber 银行卡号
     * @return 合法返回 true，否则返回 false
     */
    private boolean isValidCardNumber(String cardNumber) {
        // 如果卡号为空，直接返回不合法
        if (cardNumber == null) return false;
        // 去掉卡号中的所有空白字符
        String num = cardNumber.replaceAll("\\s", "");
        // 银行卡号长度必须在 13 到 19 位之间
        if (num.length() < 13 || num.length() > 19) return false;
        // 银行卡号必须全部由数字组成
        return num.matches("\\d+");
    }

    /**
     * 对银行卡号进行脱敏处理，仅保留最后 4 位，其余用星号代替。
     *
     * @param cardNumber 原始银行卡号
     * @return 脱敏后的银行卡号展示字符串
     */
    private String maskCardNumber(String cardNumber) {
        // 去掉卡号中的所有空白字符
        String num = cardNumber.replaceAll("\\s", "");
        // 如果卡号长度小于等于 8 位，则直接返回原卡号
        if (num.length() <= 8) return num;
        // 保留最后 4 位，前面用星号占位展示
        return "**** **** **** " + num.substring(num.length() - 4);
    }
}
