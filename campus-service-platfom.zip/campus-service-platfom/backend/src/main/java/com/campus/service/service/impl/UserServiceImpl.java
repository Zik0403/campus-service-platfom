package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.RoleConstants;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.common.util.PasswordUtil;
import com.campus.service.entity.User;
import com.campus.service.entity.WalletRecord;
import com.campus.service.mapper.UserMapper;
import com.campus.service.mapper.WalletRecordMapper;
import com.campus.service.service.UserBankCardService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * 用户服务实现类。
 * <p>
 * 负责校园生活服务系统中与用户账号相关的核心业务处理，包括：
 * 微信 openid 登录、账号密码登录、学生与维修人员注册、实名认证、
 * 宿舍信息维护、账户余额与信用分管理、登录密码与支付密码的设置与修改等。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    // 用户表数据访问对象，用于查询和更新用户基础信息
    private final UserMapper userMapper;
    // 钱包流水表数据访问对象，用于记录余额变动明细
    private final WalletRecordMapper walletRecordMapper;
    // 用户银行卡服务，延迟加载以解决循环依赖，用于查询默认银行卡
    @Lazy
    private final UserBankCardService userBankCardService;

    /**
     * 通过微信 openid 登录，若该 openid 未注册则自动创建新用户。
     *
     * @param openid 微信用户的唯一 openid
     * @return 登录成功的用户信息
     */
    @Override
    @Transactional
    public User loginByOpenid(String openid) {
        // 构造查询条件：按 openid 查询用户表
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getOpenid, openid);
        // 执行查询，获取匹配的用户记录
        User user = userMapper.selectOne(wrapper);
        // 如果查询结果为空，说明该微信号首次登录，需要自动注册
        if (user == null) {
            // 创建新的用户对象
            user = new User();
            // 保存微信 openid，用于后续识别
            user.setOpenid(openid);
            // 设置默认昵称
            user.setNickname("新用户");
            // 设置默认角色为普通用户
            user.setRole(1);
            // 设置初始信用分为满分 100
            user.setCreditScore(100);
            // 设置初始账户余额为 0
            user.setBalance(java.math.BigDecimal.ZERO);
            // 设置未实名认证状态
            user.setIsAuth(0);
            // 设置账号未删除状态
            user.setIsDelete(0);
            // 将新用户插入到用户表
            userMapper.insert(user);
            // 记录新用户注册日志
            log.info("新用户注册: openid={}", openid);
        }
        // 如果用户存在且已被封禁，则禁止登录
        if (user.getIsDelete() != null && user.getIsDelete() == 1) {
            throw BusinessException.userBanned();
        }
        // 返回登录成功的用户对象
        return user;
    }

    /**
     * 通过账号和密码登录，账号可以是学号、手机号或身份证号。
     *
     * @param account  登录账号，支持学号、手机号、身份证号
     * @param password 登录密码
     * @return 登录成功的用户信息
     */
    @Override
    public User loginByPassword(String account, String password) {
        // 构造查询条件：按学号、手机号或身份证号任意一个匹配
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getStudentId, account).or().eq(User::getPhone, account).or().eq(User::getIdCard, account);
        // 在用户表中查询匹配的记录
        User user = userMapper.selectOne(wrapper);
        // 如果未找到用户，说明账号不存在
        if (user == null) {
            throw new BusinessException("账号不存在");
        }
        // 如果用户已被封禁，则禁止登录
        if (user.getIsDelete() != null && user.getIsDelete() == 1) {
            throw BusinessException.userBanned();
        }
        // 校验用户输入的密码是否与数据库中的加密密码一致
        if (!PasswordUtil.matches(password, user.getPassword())) {
            throw new BusinessException("密码错误");
        }
        // 返回登录成功的用户对象
        return user;
    }

    /**
     * 注册学生账号。
     *
     * @param studentId 学生学号
     * @param realName  真实姓名
     * @param phone     手机号
     * @param password  登录密码
     * @param dormBuild 宿舍楼栋，可为空
     * @param dormRoom  宿舍房间号，可为空
     * @return 注册成功的学生用户信息
     */
    @Override
    @Transactional
    public User registerStudent(String studentId, String realName, String phone, String password, String dormBuild, String dormRoom) {
        // 构造查询条件：按学号查询是否已存在
        LambdaQueryWrapper<User> wrapper1 = new LambdaQueryWrapper<>();
        wrapper1.eq(User::getStudentId, studentId);
        // 如果学号已被注册，则抛出异常
        if (userMapper.selectOne(wrapper1) != null) {
            throw new BusinessException("该学号已被注册");
        }
        // 构造查询条件：按手机号查询是否已存在
        LambdaQueryWrapper<User> wrapper2 = new LambdaQueryWrapper<>();
        wrapper2.eq(User::getPhone, phone);
        // 如果手机号已被注册，则抛出异常
        if (userMapper.selectOne(wrapper2) != null) {
            throw new BusinessException("该手机号已被注册");
        }
        // 创建新的用户对象用于保存学生信息
        User user = new User();
        // 学生通过账号注册，openid 为空
        user.setOpenid(null);
        // 设置学生学号
        user.setStudentId(studentId);
        // 设置真实姓名
        user.setRealName(realName);
        // 设置手机号
        user.setPhone(phone);
        // 对登录密码进行加密后保存
        user.setPassword(PasswordUtil.encrypt(password));
        // 默认昵称使用真实姓名
        user.setNickname(realName);
        // 设置角色为学生
        user.setRole(RoleConstants.ROLE_STUDENT);
        // 设置初始信用分为 100
        user.setCreditScore(100);
        // 设置初始余额为 0
        user.setBalance(java.math.BigDecimal.ZERO);
        // 设置账号为已实名认证
        user.setIsAuth(1);
        // 设置账号为未删除状态
        user.setIsDelete(0);
        // 如果填写了宿舍楼栋，则保存宿舍信息
        if (dormBuild != null && !dormBuild.isEmpty()) {
            user.setDormBuild(dormBuild);
        }
        // 如果填写了宿舍房间号，则保存房间信息
        if (dormRoom != null && !dormRoom.isEmpty()) {
            user.setDormRoom(dormRoom);
        }
        // 将新学生用户信息插入用户表
        userMapper.insert(user);
        // 记录学生注册日志
        log.info("新学生注册: studentId={}, realName={}", studentId, realName);
        // 返回注册成功的用户对象
        return user;
    }

    /**
     * 注册维修人员账号。
     *
     * @param realName 真实姓名
     * @param phone    手机号
     * @param idCard   身份证号
     * @param password 登录密码
     * @return 注册成功的维修人员用户信息
     */
    @Override
    @Transactional
    public User registerWorker(String realName, String phone, String idCard, String password) {
        // 构造查询条件：按身份证号查询是否已注册
        LambdaQueryWrapper<User> wrapper1 = new LambdaQueryWrapper<>();
        wrapper1.eq(User::getIdCard, idCard);
        // 如果身份证号已被注册，则抛出异常
        if (userMapper.selectOne(wrapper1) != null) {
            throw new BusinessException("该身份证号已被注册");
        }
        // 构造查询条件：按手机号查询是否已注册
        LambdaQueryWrapper<User> wrapper2 = new LambdaQueryWrapper<>();
        wrapper2.eq(User::getPhone, phone);
        // 如果手机号已被注册，则抛出异常
        if (userMapper.selectOne(wrapper2) != null) {
            throw new BusinessException("该手机号已被注册");
        }
        // 创建新的用户对象用于保存维修人员信息
        User user = new User();
        // 维修人员通过账号注册，openid 为空
        user.setOpenid(null);
        // 设置真实姓名
        user.setRealName(realName);
        // 设置手机号
        user.setPhone(phone);
        // 设置身份证号
        user.setIdCard(idCard);
        // 对登录密码进行加密后保存
        user.setPassword(PasswordUtil.encrypt(password));
        // 默认昵称使用真实姓名
        user.setNickname(realName);
        // 设置角色为维修人员
        user.setRole(RoleConstants.ROLE_WORKER);
        // 设置初始信用分为 100
        user.setCreditScore(100);
        // 设置初始余额为 0
        user.setBalance(java.math.BigDecimal.ZERO);
        // 设置账号为已实名认证
        user.setIsAuth(1);
        // 设置账号为未删除状态
        user.setIsDelete(0);
        // 将新维修人员信息插入用户表
        userMapper.insert(user);
        // 记录维修人员注册日志
        log.info("新维修人员注册: idCard={}, realName={}", idCard, realName);
        // 返回注册成功的用户对象
        return user;
    }

    /**
     * 重置登录密码。
     *
     * @param account     登录账号，学号或身份证号
     * @param phone       绑定的手机号
     * @param newPassword 新登录密码
     */
    @Override
    @Transactional
    public void resetPassword(String account, String phone, String newPassword) {
        // 构造查询条件：手机号必须匹配，且学号或身份证号至少一个匹配
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getPhone, phone)
                .and(w -> w.eq(User::getStudentId, account).or().eq(User::getIdCard, account));
        // 查询符合账号和手机号双重条件的用户
        User user = userMapper.selectOne(wrapper);
        // 如果未找到匹配用户，说明账号与手机号不匹配
        if (user == null) {
            throw new BusinessException("账号与手机号不匹配");
        }
        // 对新密码进行加密
        user.setPassword(PasswordUtil.encrypt(newPassword));
        // 更新用户表的密码字段
        userMapper.updateById(user);
        // 记录密码重置日志
        log.info("用户重置密码: account={}", account);
    }

    /**
     * 更新用户昵称和头像。
     *
     * @param userId   用户 ID
     * @param nickname 新昵称，可为空
     * @param avatar   新头像地址，可为空
     */
    @Override
    @Transactional
    public void updateUserInfo(Long userId, String nickname, String avatar) {
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 如果传入新昵称，则更新昵称字段
        if (nickname != null) {
            user.setNickname(nickname);
        }
        // 如果传入新头像，则更新头像字段
        if (avatar != null) {
            user.setAvatar(avatar);
        }
        // 将更新后的用户信息写回用户表
        userMapper.updateById(user);
    }

    /**
     * 对用户进行实名认证，可补充学号、身份证号、真实姓名、手机号。
     *
     * @param userId    用户 ID
     * @param studentId 学号，可为空
     * @param idCard    身份证号，可为空
     * @param realName  真实姓名，可为空
     * @param phone     手机号，可为空
     */
    @Override
    @Transactional
    public void authUser(Long userId, String studentId, String idCard, String realName, String phone) {
        // 根据用户 ID 查询待认证的用户
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 如果填写了学号，需要校验是否已被其他用户使用
        if (studentId != null && !studentId.isEmpty()) {
            // 构造查询条件：学号相同但排除当前用户自己
            LambdaQueryWrapper<User> wrapper1 = new LambdaQueryWrapper<>();
            wrapper1.eq(User::getStudentId, studentId).ne(User::getId, userId);
            // 查询是否存在使用相同学号的其他用户
            User existStudent = userMapper.selectOne(wrapper1);
            // 如果学号已被占用，抛出异常
            if (existStudent != null) {
                throw BusinessException.studentIdExists();
            }
            // 将学号设置到当前用户
            user.setStudentId(studentId);
        }
        // 如果填写了身份证号，需要校验是否已被其他用户认证
        if (idCard != null && !idCard.isEmpty()) {
            // 构造查询条件：身份证号相同但排除当前用户自己
            LambdaQueryWrapper<User> wrapperId = new LambdaQueryWrapper<>();
            wrapperId.eq(User::getIdCard, idCard).ne(User::getId, userId);
            // 查询是否存在使用相同身份证号的其他用户
            User existIdCard = userMapper.selectOne(wrapperId);
            // 如果身份证号已被占用，抛出异常
            if (existIdCard != null) {
                throw new BusinessException("该身份证号已被认证");
            }
            // 将身份证号设置到当前用户
            user.setIdCard(idCard);
        }
        // 如果填写了手机号，需要校验是否已被其他用户绑定
        if (phone != null && !phone.isEmpty()) {
            // 构造查询条件：手机号相同但排除当前用户自己
            LambdaQueryWrapper<User> wrapper2 = new LambdaQueryWrapper<>();
            wrapper2.eq(User::getPhone, phone).ne(User::getId, userId);
            // 查询是否存在使用相同手机号的其他用户
            User existPhone = userMapper.selectOne(wrapper2);
            // 如果手机号已被占用，抛出异常
            if (existPhone != null) {
                throw BusinessException.phoneExists();
            }
            // 将手机号设置到当前用户
            user.setPhone(phone);
        }
        // 如果填写了真实姓名，则保存真实姓名
        if (realName != null && !realName.isEmpty()) {
            user.setRealName(realName);
        }
        // 标记用户为已实名认证
        user.setIsAuth(1);
        // 将认证信息更新到用户表
        userMapper.updateById(user);
        // 记录实名认证日志
        log.info("用户实名认证: userId={}, studentId={}, idCard={}", userId, studentId, idCard);
    }

    /**
     * 更新用户的宿舍信息。
     *
     * @param userId    用户 ID
     * @param dormBuild 宿舍楼栋
     * @param dormRoom  宿舍房间号
     */
    @Override
    @Transactional
    public void updateDormInfo(Long userId, String dormBuild, String dormRoom) {
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 更新宿舍楼栋字段
        user.setDormBuild(dormBuild);
        // 更新宿舍房间号字段
        user.setDormRoom(dormRoom);
        // 将更新后的宿舍信息写回用户表
        userMapper.updateById(user);
    }

    /**
     * 更新用户手机号。
     *
     * @param userId 用户 ID
     * @param phone  新手机号
     */
    @Override
    @Transactional
    public void updatePhone(Long userId, String phone) {
        // 构造查询条件：手机号相同但排除当前用户，用于校验是否已被占用
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getPhone, phone).ne(User::getId, userId);
        // 查询是否存在使用相同手机号的其他用户
        User existPhone = userMapper.selectOne(wrapper);
        // 如果手机号已被占用，抛出异常
        if (existPhone != null) {
            throw BusinessException.phoneExists();
        }
        // 根据用户 ID 查询当前用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 设置新的手机号
        user.setPhone(phone);
        // 将新手机号更新到用户表
        userMapper.updateById(user);
    }

    /**
     * 查询所有未删除的维修人员列表。
     *
     * @return 维修人员用户列表
     */
    @Override
    public List<User> getWorkers() {
        // 构造查询条件：角色为维修人员且账号未删除
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getRole, 2).eq(User::getIsDelete, 0);
        // 返回维修人员列表
        return list(wrapper);
    }

    /**
     * 查询信用分最高的前 limit 名未删除用户。
     *
     * @param limit 返回的最大记录数
     * @return 信用分排行榜用户列表
     */
    @Override
    public List<User> getCreditTop(int limit) {
        // 构造查询条件：账号未删除，按信用分降序排列，限制返回条数
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getIsDelete, 0).orderByDesc(User::getCreditScore).last("LIMIT " + limit);
        // 执行查询并返回排行榜
        return userMapper.selectList(wrapper);
    }

    /**
     * 更新用户账户余额，并记录钱包流水。
     *
     * @param userId  用户 ID
     * @param amount  变动金额，正数表示收入，负数表示支出
     * @param bizType 业务类型
     */
    @Override
    @Transactional
    public void updateBalance(Long userId, BigDecimal amount, Integer bizType) {
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 计算变动后的新余额：当前余额加上变动金额
        BigDecimal newBalance = user.getBalance().add(amount);
        // 如果新余额小于 0，说明余额不足以支付，抛出异常
        if (newBalance.compareTo(BigDecimal.ZERO) < 0) {
            throw BusinessException.balanceNotEnough();
        }
        // 调用用户表的余额更新方法，按用户 ID 和变动金额原子性更新余额
        int rows = userMapper.updateBalance(userId, amount);
        // 如果更新行数为 0，说明余额更新失败，抛出异常
        if (rows <= 0) {
            throw new BusinessException("余额更新失败");
        }
        // 创建钱包流水记录对象，用于记录本次余额变动
        WalletRecord record = new WalletRecord();
        // 设置流水所属用户 ID
        record.setUserId(userId);
        // 记录金额变动的绝对值
        record.setAmount(amount.abs());
        // 记录变动后的余额
        record.setBalanceAfter(newBalance);
        // 设置业务类型
        record.setBizType(bizType);
        // 根据金额正负判断变动类型：1 收入，2 支出
        record.setChangeType(amount.compareTo(BigDecimal.ZERO) >= 0 ? 1 : 2);
        // 将钱包流水记录插入流水表
        walletRecordMapper.insert(record);
        // 记录余额变动日志
        log.info("用户余额变动: userId={}, amount={}, newBalance={}, bizType={}", userId, amount, newBalance, bizType);
    }

    /**
     * 调整用户信用分，并将分数限制在 0 到 100 之间。
     *
     * @param userId 用户 ID
     * @param score  信用分变动值，正数加分，负数减分
     */
    @Override
    @Transactional
    public void updateCreditScore(Long userId, int score) {
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 计算新的信用分
        int newScore = user.getCreditScore() + score;
        // 如果新分数小于 0，则置为 0，避免负数
        if (newScore < 0) {
            newScore = 0;
        }
        // 如果新分数超过 100，则置为 100，保持满分上限
        if (newScore > 100) {
            newScore = 100;
        }
        // 将新的信用分设置到用户对象
        user.setCreditScore(newScore);
        // 更新用户表的信用分字段
        userMapper.updateById(user);
        // 记录信用分变更日志
        log.info("用户信用分变更: userId={}, change={}, newScore={}", userId, score, newScore);
    }

    /**
     * 校验用户是否已实名认证且未被封禁。
     *
     * @param userId 用户 ID
     */
    @Override
    public void checkUserAuth(Long userId) {
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 如果用户未实名认证，抛出异常
        if (user.getIsAuth() == 0) {
            throw BusinessException.userNotAuth();
        }
        // 如果用户已被封禁，抛出异常
        if (user.getIsDelete() == 1) {
            throw BusinessException.userBanned();
        }
    }

    /**
     * 设置支付密码。
     *
     * @param userId      用户 ID
     * @param payPassword 6 位数字支付密码
     */
    @Override
    public void setPayPassword(Long userId, String payPassword) {
        // 校验支付密码是否为 6 位纯数字
        if (payPassword == null || payPassword.length() != 6 || !payPassword.matches("\\d{6}")) {
            throw new BusinessException("支付密码必须是6位数字");
        }
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 对支付密码进行加密
        String encrypted = PasswordUtil.encode(payPassword);
        // 将加密后的支付密码保存到用户对象
        user.setPayPassword(encrypted);
        // 更新用户表的支付密码字段
        updateById(user);
        // 记录设置支付密码日志
        log.info("用户设置支付密码: userId={}", userId);
    }

    /**
     * 校验用户输入的支付密码是否正确。
     *
     * @param userId      用户 ID
     * @param payPassword 用户输入的支付密码
     * @return 校验通过返回 true，否则返回 false
     */
    @Override
    public boolean verifyPayPassword(Long userId, String payPassword) {
        // 校验支付密码长度是否为 6 位
        if (payPassword == null || payPassword.length() != 6) {
            return false;
        }
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在或未设置支付密码，则校验失败
        if (user == null || user.getPayPassword() == null) {
            return false;
        }
        // 将输入的支付密码与数据库中的加密密码进行比对
        return PasswordUtil.matches(payPassword, user.getPayPassword());
    }

    /**
     * 修改支付密码，需要验证原支付密码。
     *
     * @param userId      用户 ID
     * @param oldPassword 原支付密码
     * @param newPassword 新支付密码
     */
    @Override
    public void updatePayPassword(Long userId, String oldPassword, String newPassword) {
        // 校验新支付密码是否为 6 位纯数字
        if (newPassword == null || newPassword.length() != 6 || !newPassword.matches("\\d{6}")) {
            throw new BusinessException("新支付密码必须是6位数字");
        }
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 如果用户不存在，抛出异常
        if (user == null) {
            throw BusinessException.userNotFound();
        }
        // 如果用户尚未设置支付密码，则无法修改
        if (user.getPayPassword() == null) {
            throw new BusinessException("请先设置支付密码");
        }
        // 校验原支付密码是否正确
        if (!PasswordUtil.matches(oldPassword, user.getPayPassword())) {
            throw new BusinessException("原支付密码错误");
        }
        // 对新支付密码进行加密并保存到用户对象
        user.setPayPassword(PasswordUtil.encode(newPassword));
        // 更新用户表的支付密码字段
        updateById(user);
        // 记录修改支付密码日志
        log.info("用户修改支付密码: userId={}", userId);
    }

    /**
     * 通过学号、真实姓名、手机号验证身份后重置支付密码。
     *
     * @param studentId   学生学号
     * @param realName    真实姓名
     * @param phone       手机号
     * @param newPassword 新支付密码
     */
    @Override
    public void resetPayPassword(String studentId, String realName, String phone, String newPassword) {
        // 校验新支付密码是否为 6 位纯数字
        if (newPassword == null || newPassword.length() != 6 || !newPassword.matches("\\d{6}")) {
            throw new BusinessException("新支付密码必须是6位数字");
        }
        // 校验学号是否为空
        if (studentId == null || studentId.isEmpty()) {
            throw new BusinessException("学号不能为空");
        }
        // 校验真实姓名是否为空
        if (realName == null || realName.isEmpty()) {
            throw new BusinessException("真实姓名不能为空");
        }
        // 校验手机号是否为空
        if (phone == null || phone.isEmpty()) {
            throw new BusinessException("手机号不能为空");
        }
        // 构造查询条件：学号、真实姓名、手机号同时匹配，且账号未删除
        User user = getOne(new LambdaQueryWrapper<User>()
                .eq(User::getStudentId, studentId)
                .eq(User::getRealName, realName)
                .eq(User::getPhone, phone)
                .eq(User::getIsDelete, 0));
        // 如果未找到匹配用户，说明个人信息验证失败
        if (user == null) {
            throw new BusinessException("个人信息验证失败，请核对后重试");
        }
        // 对新支付密码进行加密并保存到用户对象
        user.setPayPassword(PasswordUtil.encode(newPassword));
        // 更新用户表的支付密码字段
        updateById(user);
        // 记录重置支付密码日志
        log.info("用户重置支付密码: userId={}, studentId={}", user.getId(), studentId);
    }

    /**
     * 判断用户是否已绑定默认银行卡。
     *
     * @param userId 用户 ID
     * @return 已绑定默认银行卡返回 true，否则返回 false
     */
    @Override
    public boolean hasBankCard(Long userId) {
        // 调用银行卡服务查询默认银行卡，存在即表示已绑定
        return userBankCardService.getDefaultCard(userId) != null;
    }

    /**
     * 判断用户是否已设置支付密码。
     *
     * @param userId 用户 ID
     * @return 已设置支付密码返回 true，否则返回 false
     */
    @Override
    public boolean hasPayPassword(Long userId) {
        // 根据用户 ID 查询用户信息
        User user = getById(userId);
        // 判断用户存在且支付密码字段不为空
        return user != null && user.getPayPassword() != null && !user.getPayPassword().isEmpty();
    }
}
