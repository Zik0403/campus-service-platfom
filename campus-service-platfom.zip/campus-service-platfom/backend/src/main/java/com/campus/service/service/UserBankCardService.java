package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.UserBankCard;

import java.util.List;

/**
 * 用户银行卡服务接口。
 * 负责校园生活服务平台中学生银行卡的管理：绑定银行卡、解绑银行卡、
 * 设置默认银行卡以及验证银行卡密码，用于后续的充值、提现和支付。
 */
public interface UserBankCardService extends IService<UserBankCard> {

    /**
     * 查询某位学生绑定的所有银行卡。
     * @param userId 用户ID
     * @return 银行卡列表
     */
    List<UserBankCard> getUserCards(Long userId);

    /**
     * 学生绑定一张新的银行卡。
     * @param userId 用户ID
     * @param bankName 银行名称
     * @param cardNumber 银行卡号
     * @param cardPassword 银行卡密码，用于后续支付校验
     * @return 绑定后的银行卡对象
     */
    UserBankCard addCard(Long userId, String bankName, String cardNumber, String cardPassword);

    /**
     * 学生解绑指定的银行卡。
     * @param userId 用户ID
     * @param cardId 银行卡ID
     */
    void deleteCard(Long userId, Long cardId);

    /**
     * 设置某张银行卡为默认支付卡。
     * @param userId 用户ID
     * @param cardId 银行卡ID
     */
    void setDefaultCard(Long userId, Long cardId);

    /**
     * 查询某位学生的默认银行卡。
     * @param userId 用户ID
     * @return 默认银行卡对象；未设置默认卡时可能返回null
     */
    UserBankCard getDefaultCard(Long userId);

    /**
     * 验证某张银行卡的密码是否正确。
     * @param cardId 银行卡ID
     * @param password 待验证的银行卡密码
     * @return true表示密码正确，false表示密码错误
     */
    boolean verifyCardPassword(Long cardId, String password);
}
