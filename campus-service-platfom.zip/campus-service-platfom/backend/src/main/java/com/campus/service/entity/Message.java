package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 消息通知表。
 * 存储系统向用户推送的各类消息，包括系统通知、工单进度、社区互动、订单状态与匹配推送，
 * 支撑小程序端消息中心、未读红点与业务跳转。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("message") // 指定对应的数据库表名为 message
public class Message implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 消息主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 接收用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 消息类型：1 系统通知、2 工单进度、3 社区互动、4 订单状态、5 匹配推送。
     */
    private Integer msgType;

    /**
     * 消息标题，展示在消息列表中。
     */
    private String title;

    /**
     * 消息正文内容。
     */
    private String content;

    /**
     * 关联业务类型，如“repair_order”“service_order”“second_order”，用于点击跳转。
     */
    private String bizType;

    /**
     * 关联业务 ID，点击消息可跳转到对应业务详情页。
     */
    private Long bizId;

    /**
     * 是否已读：0 未读、1 已读。
     */
    private Integer isRead;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录消息发送时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;
}
