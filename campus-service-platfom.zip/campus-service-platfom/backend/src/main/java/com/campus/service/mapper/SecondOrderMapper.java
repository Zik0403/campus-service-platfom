package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.SecondOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 二手交易订单数据访问接口。
 *
 * <p>操作的数据库表为二手交易订单表，对应实体类为 {@link SecondOrder}。
 * 主要负责校园二手 marketplace 中交易订单的查询，例如查询买家的订单、卖家的订单、
 * 某件商品的订单以及超时未支付的订单。</p>
 */
@Mapper
public interface SecondOrderMapper extends BaseMapper<SecondOrder> {

    /**
     * 根据买家 ID 查询该买家购买的所有二手订单。
     *
     * @param buyerId 买家用户 ID
     * @return 该买家的二手订单列表
     */
    List<SecondOrder> selectByBuyerId(@Param("buyerId") Long buyerId);

    /**
     * 根据卖家 ID 查询该卖家出售的所有二手订单。
     *
     * @param sellerId 卖家用户 ID
     * @return 该卖家的二手订单列表
     */
    List<SecondOrder> selectBySellerId(@Param("sellerId") Long sellerId);

    /**
     * 根据商品 ID 查询该商品相关的所有订单。
     *
     * @param productId 二手商品 ID
     * @return 该商品的订单列表
     */
    List<SecondOrder> selectByProductId(@Param("productId") Long productId);

    /**
     * 查询所有超时未支付的二手订单。
     *
     * @return 超时未支付的订单列表
     */
    List<SecondOrder> selectTimeoutUnpaid();
}
