package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.LibrarySeat;
import org.apache.ibatis.annotations.Mapper;

/**
 * 图书馆座位数据访问接口。
 *
 * <p>操作的数据库表为图书馆座位表，对应实体类为 {@link LibrarySeat}。
 * 主要负责图书馆座位信息的增删改查，例如座位编号、所在楼层、当前状态等。</p>
 */
@Mapper
public interface LibrarySeatMapper extends BaseMapper<LibrarySeat> {
}
