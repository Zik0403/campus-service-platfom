package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.SecondProduct;
import com.campus.service.entity.User;
import com.campus.service.mapper.SecondProductMapper;
import com.campus.service.service.SecondProductService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * 校园二手商品业务实现类。
 * <p>
 * 负责校园二手交易模块中商品的全流程管理，包括学生发布商品、编辑商品、管理员审核、
 * 上下架、删除、详情查询、分类查询、关键词搜索、待审核列表以及过期商品查询等业务。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SecondProductServiceImpl extends ServiceImpl<SecondProductMapper, SecondProduct> implements SecondProductService {

    private final UserService userService;

    /**
     * 学生发布二手商品。
     *
     * @param sellerId    卖家用户 ID
     * @param title       商品标题
     * @param category    商品分类
     * @param price       商品价格字符串
     * @param description 商品描述
     * @param images      商品图片地址，多个地址以逗号分隔
     * @param allowBargain 是否允许砍价，1 表示允许，0 表示不允许
     * @param validDay    商品有效天数
     * @return 发布成功后的二手商品对象
     */
    @Override
    @Transactional
    public SecondProduct createProduct(Long sellerId, String title, String category, String price,
                                        String description, String images, Integer allowBargain, Integer validDay) {
        // 校验卖家是否已完成实名认证
        userService.checkUserAuth(sellerId);
        // 根据卖家 ID 查询用户信息
        User seller = userService.getById(sellerId);
        // 校验卖家信用积分是否达到 60 分，信用分不足则禁止发布商品
        if (seller.getCreditScore() < 60) {
            throw new BusinessException("信用积分不足，无法发布商品");
        }
        // 创建一个新的二手商品实体对象
        SecondProduct product = new SecondProduct();
        // 设置商品卖家 ID
        product.setSellerId(sellerId);
        // 设置商品标题
        product.setTitle(title);
        // 设置商品分类
        product.setCategory(category);
        // 将价格字符串转换为 BigDecimal 并设置商品价格
        product.setPrice(new BigDecimal(price));
        // 设置商品详细描述
        product.setDescription(description);
        // 设置商品图片地址
        product.setImages(images);
        // 设置是否允许砍价，若参数为空则默认允许砍价（1）
        product.setAllowBargain(allowBargain != null ? allowBargain : 1);
        // 设置商品有效天数，若参数为空则默认 15 天
        product.setValidDay(validDay != null ? validDay : 15);
        // 设置商品状态为上架在售
        product.setStatus(OrderStatus.PRODUCT_ONLINE);
        // 调用 save 方法将商品插入 second_product 表
        save(product);
        // 记录发布二手商品日志
        log.info("发布二手商品: productId={}, sellerId={}", product.getId(), sellerId);
        // 返回发布成功的商品对象
        return product;
    }

    /**
     * 卖家编辑自己发布的二手商品信息。
     *
     * @param productId    商品 ID
     * @param userId       当前操作用户 ID
     * @param title        商品标题，可为空
     * @param category     商品分类，可为空
     * @param price        商品价格字符串，可为空
     * @param description  商品描述，可为空
     * @param images       商品图片地址，可为空
     * @param allowBargain 是否允许砍价，可为空
     */
    @Override
    @Transactional
    public void updateProduct(Long productId, Long userId, String title, String category,
                               String price, String description, String images, Integer allowBargain) {
        // 根据商品 ID 查询 second_product 表中的商品信息
        SecondProduct product = getById(productId);
        // 若商品不存在，抛出商品不存在的业务异常
        if (product == null) {
            throw BusinessException.productNotFound();
        }
        // 校验当前操作人是否为商品发布者，只有本人可以编辑
        if (!product.getSellerId().equals(userId)) {
            throw BusinessException.productNotOwner();
        }
        // 校验商品状态，已售出的商品不允许编辑
        if (product.getStatus() == OrderStatus.PRODUCT_SOLD) {
            throw BusinessException.orderStatusError();
        }
        // 若传入了新标题，则更新商品标题
        if (title != null) {
            product.setTitle(title);
        }
        // 若传入了新分类，则更新商品分类
        if (category != null) {
            product.setCategory(category);
        }
        // 若传入了新价格，则将价格字符串转换为 BigDecimal 并更新商品价格
        if (price != null) {
            product.setPrice(new BigDecimal(price));
        }
        // 若传入了新描述，则更新商品描述
        if (description != null) {
            product.setDescription(description);
        }
        // 若传入了新图片，则更新商品图片地址
        if (images != null) {
            product.setImages(images);
        }
        // 若传入了是否允许砍价参数，则更新该字段
        if (allowBargain != null) {
            product.setAllowBargain(allowBargain);
        }
        // 更新 second_product 表中的商品信息
        updateById(product);
        // 记录更新二手商品日志
        log.info("更新二手商品: productId={}", productId);
    }

    /**
     * 管理员审核二手商品。
     *
     * @param productId   商品 ID
     * @param auditStatus 审核状态，2 表示审核通过，其他表示审核不通过
     */
    @Override
    @Transactional
    public void auditProduct(Long productId, Integer auditStatus) {
        // 根据商品 ID 查询 second_product 表中的商品信息
        SecondProduct product = getById(productId);
        // 若商品不存在，抛出商品不存在的业务异常
        if (product == null) {
            throw BusinessException.productNotFound();
        }
        // 校验商品状态是否为待审核，只有待审核商品才能进行审核操作
        if (product.getStatus() != OrderStatus.PRODUCT_PENDING) {
            throw BusinessException.orderStatusError();
        }
        // 根据审核状态设置商品状态：2 为上架，其他为封禁
        product.setStatus(auditStatus == 2 ? OrderStatus.PRODUCT_ONLINE : OrderStatus.PRODUCT_BANNED);
        // 更新 second_product 表中的商品状态
        updateById(product);
        // 记录审核二手商品日志
        log.info("审核二手商品: productId={}, status={}", productId, product.getStatus());
    }

    /**
     * 卖家将商品重新上架。
     *
     * @param productId 商品 ID
     * @param userId    当前操作用户 ID
     */
    @Override
    @Transactional
    public void onlineProduct(Long productId, Long userId) {
        // 根据商品 ID 查询 second_product 表中的商品信息
        SecondProduct product = getById(productId);
        // 若商品不存在，抛出商品不存在的业务异常
        if (product == null) {
            throw BusinessException.productNotFound();
        }
        // 校验当前操作人是否为商品发布者
        if (!product.getSellerId().equals(userId)) {
            throw BusinessException.productNotOwner();
        }
        // 校验商品状态，只有下架或上架状态的商品才能执行上架操作
        if (product.getStatus() != OrderStatus.PRODUCT_OFFLINE && product.getStatus() != OrderStatus.PRODUCT_ONLINE) {
            throw BusinessException.orderStatusError();
        }
        // 将商品状态设置为上架在售
        product.setStatus(OrderStatus.PRODUCT_ONLINE);
        // 更新 second_product 表中的商品状态
        updateById(product);
        // 记录上架二手商品日志
        log.info("上架二手商品: productId={}", productId);
    }

    /**
     * 卖家将商品下架。
     *
     * @param productId 商品 ID
     * @param userId    当前操作用户 ID
     */
    @Override
    @Transactional
    public void offlineProduct(Long productId, Long userId) {
        // 根据商品 ID 查询 second_product 表中的商品信息
        SecondProduct product = getById(productId);
        // 若商品不存在，抛出商品不存在的业务异常
        if (product == null) {
            throw BusinessException.productNotFound();
        }
        // 校验当前操作人是否为商品发布者
        if (!product.getSellerId().equals(userId)) {
            throw BusinessException.productNotOwner();
        }
        // 校验商品状态，已售出的商品不能下架
        if (product.getStatus() == OrderStatus.PRODUCT_SOLD) {
            throw BusinessException.orderStatusError();
        }
        // 将商品状态设置为下架
        product.setStatus(OrderStatus.PRODUCT_OFFLINE);
        // 更新 second_product 表中的商品状态
        updateById(product);
        // 记录下架二手商品日志
        log.info("下架二手商品: productId={}", productId);
    }

    /**
     * 卖家删除自己发布的二手商品。
     *
     * @param productId 商品 ID
     * @param userId    当前操作用户 ID
     */
    @Override
    @Transactional
    public void deleteProduct(Long productId, Long userId) {
        // 根据商品 ID 查询 second_product 表中的商品信息
        SecondProduct product = getById(productId);
        // 若商品不存在，抛出商品不存在的业务异常
        if (product == null) {
            throw BusinessException.productNotFound();
        }
        // 校验当前操作人是否为商品发布者
        if (!product.getSellerId().equals(userId)) {
            throw BusinessException.productNotOwner();
        }
        // 校验商品状态，已售出的商品不能删除
        if (product.getStatus() == OrderStatus.PRODUCT_SOLD) {
            throw BusinessException.orderStatusError();
        }
        // 根据商品 ID 从 second_product 表中删除商品记录
        removeById(productId);
        // 记录删除二手商品日志
        log.info("删除二手商品: productId={}", productId);
    }

    /**
     * 查询二手商品详情，并填充卖家信息。
     *
     * @param productId 商品 ID
     * @return 包含卖家信息的商品详情对象
     */
    @Override
    public SecondProduct getProductDetail(Long productId) {
        // 根据商品 ID 查询 second_product 表中的商品信息
        SecondProduct product = getById(productId);
        // 若商品不存在，抛出商品不存在的业务异常
        if (product == null) {
            throw BusinessException.productNotFound();
        }
        // 校验商品状态是否为待审核，待审核商品不允许查看详情
        if (product.getStatus() == OrderStatus.PRODUCT_PENDING) {
            throw BusinessException.productBanned();
        }
        // 根据卖家 ID 查询并填充卖家用户信息
        product.setSeller(userService.getById(product.getSellerId()));
        // 返回商品详情
        return product;
    }

    /**
     * 查询指定卖家发布的所有二手商品列表。
     *
     * @param sellerId 卖家用户 ID
     * @return 该卖家发布的商品列表
     */
    @Override
    public List<SecondProduct> getSellerProducts(Long sellerId) {
        // 查询 second_product 表中卖家 ID 等于指定值的所有商品，按创建时间倒序返回
        return list(new LambdaQueryWrapper<SecondProduct>()
                .eq(SecondProduct::getSellerId, sellerId)
                .orderByDesc(SecondProduct::getCreateTime));
    }

    /**
     * 按分类查询上架中的二手商品列表。
     *
     * @param category 商品分类
     * @return 该分类下上架中的商品列表
     */
    @Override
    public List<SecondProduct> getProductsByCategory(String category) {
        // 查询 second_product 表中指定分类且状态为上架的商品，按创建时间倒序返回
        return list(new LambdaQueryWrapper<SecondProduct>()
                .eq(SecondProduct::getCategory, category)
                .eq(SecondProduct::getStatus, OrderStatus.PRODUCT_ONLINE)
                .orderByDesc(SecondProduct::getCreateTime));
    }

    /**
     * 根据关键词搜索上架中的二手商品。
     *
     * @param keyword 搜索关键词
     * @return 标题或描述中包含关键词的上架商品列表
     */
    @Override
    public List<SecondProduct> searchProducts(String keyword) {
        // 查询 second_product 表中标题或描述包含关键词，且状态为上架的商品，按创建时间倒序返回
        return list(new LambdaQueryWrapper<SecondProduct>()
                .and(wrapper -> wrapper.like(SecondProduct::getTitle, keyword)
                        .or().like(SecondProduct::getDescription, keyword))
                .eq(SecondProduct::getStatus, OrderStatus.PRODUCT_ONLINE)
                .orderByDesc(SecondProduct::getCreateTime));
    }

    /**
     * 查询待审核的二手商品列表。
     *
     * @return 待审核商品列表
     */
    @Override
    public List<SecondProduct> getPendingAuditProducts() {
        // 查询 second_product 表中状态为待审核的所有商品，按创建时间倒序返回
        return list(new LambdaQueryWrapper<SecondProduct>()
                .eq(SecondProduct::getStatus, OrderStatus.PRODUCT_PENDING)
                .orderByDesc(SecondProduct::getCreateTime));
    }

    /**
     * 查询已过期的二手商品列表。
     *
     * @return 已过期的商品列表
     */
    @Override
    public List<SecondProduct> getExpiredProducts() {
        // 查询 second_product 表中状态为上架或下架，且创建时间加上有效天数小于当前时间的商品
        return list(new LambdaQueryWrapper<SecondProduct>()
                .in(SecondProduct::getStatus, OrderStatus.PRODUCT_ONLINE, OrderStatus.PRODUCT_OFFLINE)
                .apply("DATE_ADD(create_time, INTERVAL valid_day DAY) < NOW()")
                .orderByDesc(SecondProduct::getCreateTime));
    }
}
