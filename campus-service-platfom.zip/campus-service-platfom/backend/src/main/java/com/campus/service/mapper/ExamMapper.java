package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Exam;
import org.apache.ibatis.annotations.Mapper;

/**
 * 考试安排数据访问接口。
 *
 * <p>操作的数据库表为考试表，对应实体类为 {@link Exam}。
 * 主要负责学校考试安排信息的增删改查，例如查询某位学生某门课程的考试时间和地点。</p>
 */
@Mapper
public interface ExamMapper extends BaseMapper<Exam> {
}
