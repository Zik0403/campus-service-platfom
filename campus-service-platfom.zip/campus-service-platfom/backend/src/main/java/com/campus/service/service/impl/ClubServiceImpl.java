package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.Club;
import com.campus.service.entity.ClubMember;
import com.campus.service.entity.User;
import com.campus.service.mapper.ClubMemberMapper;
import com.campus.service.service.ClubService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 校园社团服务实现类。
 * <p>
 * 负责校园社团的信息管理，包括：
 * <ul>
 *     <li>学生申请创建社团，提交审核；</li>
 *     <li>管理员对社团进行审核（通过/驳回）；</li>
 *     <li>按分类、关键词查询社团，查看社团详情等。</li>
 * </ul>
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ClubServiceImpl extends ServiceImpl<com.campus.service.mapper.ClubMapper, Club> implements ClubService {

    /**
     * 社团成员数据访问对象，用于在创建社团时同时插入社长成员记录。
     */
    private final ClubMemberMapper clubMemberMapper;

    /**
     * 用户服务，用于校验创建人身份及查询创建人信息。
     */
    private final UserService userService;

    /**
     * 学生申请创建新社团。
     * <p>
     * 创建人必须是教师或学生干部等具备建社权限的角色；
     * 社团创建后初始状态为“待审核”，创建人自动成为该社团社长。
     * </p>
     *
     * @param userId   创建人用户ID
     * @param name     社团名称
     * @param logo     社团Logo图片地址
     * @param intro    社团简介
     * @param category 社团分类
     * @return 创建成功后的 Club 社团实体对象
     */
    @Override
    @Transactional
    public Club createClub(Long userId, String name, String logo, String intro, String category) {
        // 调用用户服务校验当前用户是否具备创建社团的权限（例如是否已实名认证）
        userService.checkUserAuth(userId);
        // 根据用户ID查询 user 表，获取创建人的角色信息
        User user = userService.getById(userId);
        // 判断用户角色是否为允许创建社团的角色（3 或 4 表示具备权限的角色，如教师/学生干部）
        if (user.getRole() != 3 && user.getRole() != 4) {
            // 角色不符合要求，抛出无权限异常
            throw BusinessException.roleNotAllowed();
        }
        // 创建一个新的 Club 实体对象，用于封装社团信息
        Club club = new Club();
        // 设置社团名称，展示在社团列表和详情页
        club.setName(name);
        // 设置社团Logo图片地址
        club.setLogo(logo);
        // 设置社团简介，介绍社团宗旨和活动内容
        club.setIntro(intro);
        // 设置社团分类，例如学术、文艺、体育等
        club.setCategory(category);
        // 设置社团负责人（社长）为用户本人
        club.setLeaderId(userId);
        // 设置审核状态为待审核，等待管理员审批
        club.setAuditStatus(OrderStatus.AUDIT_PENDING);
        // 设置社团状态为启用（1 表示正常展示）
        club.setStatus(1);
        // 初始化社团成员数为 1，即创建人本人
        club.setMemberCount(1);
        // 调用 save 方法将社团记录插入 club 表
        save(club);
        // 创建一条社团成员记录，将创建人设为该社团社长
        ClubMember member = new ClubMember();
        // 设置成员记录关联的社团ID
        member.setClubId(club.getId());
        // 设置成员记录关联的用户ID
        member.setUserId(userId);
        // 设置身份为社长（1 表示社长）
        member.setIdentity(1);
        // 设置成员状态为正式成员（1 表示正常）
        member.setStatus(1);
        // 将社长成员记录插入 club_member 表
        clubMemberMapper.insert(member);
        // 记录创建社团的日志
        log.info("创建社团: clubId={}, userId={}", club.getId(), userId);
        // 返回创建成功的社团对象
        return club;
    }

    /**
     * 审核社团。
     * <p>
     * 管理员根据审核结果更新 club 表的 audit_status 字段，
     * 审核通过的社团才会对学生可见并允许加入。
     * </p>
     *
     * @param clubId      待审核的社团ID
     * @param auditStatus 审核状态，如审核通过、审核驳回等
     */
    @Override
    @Transactional
    public void auditClub(Long clubId, Integer auditStatus) {
        // 根据社团ID从 club 表查询社团记录
        Club club = getById(clubId);
        // 如果社团不存在，抛出 404 业务异常
        if (club == null) {
            throw BusinessException.notFound();
        }
        // 将传入的审核状态设置到社团实体中
        club.setAuditStatus(auditStatus);
        // 调用 updateById 更新 club 表的审核状态
        updateById(club);
        // 记录审核社团的日志
        log.info("审核社团: clubId={}, status={}", clubId, auditStatus);
    }

    /**
     * 查询所有已通过审核且启用的社团列表。
     *
     * @return 已通过审核、状态正常的社团列表，按创建时间倒序排列
     */
    @Override
    public List<Club> getAuditedClubs() {
        // 查询 club 表中审核通过且状态启用的社团
        return list(new LambdaQueryWrapper<Club>()
                // 只查询审核状态为已通过（2）的社团
                .eq(Club::getAuditStatus, OrderStatus.AUDIT_PASSED)
                // 只查询状态为启用（1）的社团
                .eq(Club::getStatus, 1)
                // 按创建时间倒序，最新的社团排在最前面
                .orderByDesc(Club::getCreateTime));
    }

    /**
     * 根据分类查询已通过审核且启用的社团列表。
     *
     * @param category 社团分类
     * @return 该分类下已通过审核、状态正常的社团列表，按创建时间倒序排列
     */
    @Override
    public List<Club> getClubsByCategory(String category) {
        // 查询 club 表中指定分类、审核通过且状态启用的社团
        return list(new LambdaQueryWrapper<Club>()
                // 指定社团分类
                .eq(Club::getCategory, category)
                // 只查询审核通过的社团
                .eq(Club::getAuditStatus, OrderStatus.AUDIT_PASSED)
                // 只查询状态启用的社团
                .eq(Club::getStatus, 1)
                // 按创建时间倒序排列
                .orderByDesc(Club::getCreateTime));
    }

    /**
     * 根据关键词搜索已通过审核且启用的社团。
     *
     * @param keyword 搜索关键词
     * @return 社团名称包含关键词的社团列表，按创建时间倒序排列
     */
    @Override
    public List<Club> searchClubs(String keyword) {
        // 查询 club 表中社团名称包含关键词、审核通过且状态启用的社团
        return list(new LambdaQueryWrapper<Club>()
                // 社团名称模糊匹配关键词
                .like(Club::getName, keyword)
                // 只查询审核通过的社团
                .eq(Club::getAuditStatus, OrderStatus.AUDIT_PASSED)
                // 只查询状态启用的社团
                .eq(Club::getStatus, 1)
                // 按创建时间倒序排列
                .orderByDesc(Club::getCreateTime));
    }

    /**
     * 查询社团详情。
     *
     * @param clubId 社团ID
     * @return 社团详情实体对象
     */
    @Override
    public Club getClubDetail(Long clubId) {
        // 根据社团ID从 club 表查询社团详情
        Club club = getById(clubId);
        // 如果社团不存在，抛出 404 业务异常
        if (club == null) {
            throw BusinessException.notFound();
        }
        // 返回查询到的社团详情
        return club;
    }
}
