package com.campus.service.common.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

/**
 * 基于 BCrypt 算法的密码工具类。
 * <p>
 * 提供密码加密与密码比对能力，用于替代 {@link PasswordUtil} 中的 MD5 实现。
 * BCrypt 属于慢哈希算法，每次加密会自动生成随机盐，能有效抵御彩虹表攻击和暴力破解，
 * 更适合生产环境中存储用户登录密码和支付密码。
 * </p>
 * <p>
 * 本类方法签名与 {@link PasswordUtil} 保持一致（{@code encrypt}、{@code encode}、{@code matches}），
 * 便于业务代码无缝迁移：只需把 {@code PasswordUtil.xxx(...)} 替换为 {@code BCryptPasswordUtil.xxx(...)} 即可。
 * </p>
 *
 * @author campus-service
 */
public class BCryptPasswordUtil {

    /**
     * BCrypt 密码编码器，使用默认强度（10 轮）。
     * <p>
     * 强度越高，加密耗时越长，安全性越高，但登录响应也会相应变慢。
     * 默认 10 轮在大多数场景下是安全与性能的平衡点。
     * </p>
     */
    private static final BCryptPasswordEncoder ENCODER = new BCryptPasswordEncoder();

    /**
     * 私有构造方法，防止外部实例化。
     */
    private BCryptPasswordUtil() {
    }

    /**
     * 对明文密码进行 BCrypt 加密。
     *
     * @param password 明文密码
     * @return BCrypt 加密后的密码哈希（包含随机盐和算法标识）
     */
    public static String encrypt(String password) {
        if (password == null || password.isEmpty()) {
            return null;
        }
        // 使用 BCrypt 对明文密码进行加密，自动生成随机盐
        return ENCODER.encode(password);
    }

    /**
     * {@link #encrypt(String)} 的别名方法，与 {@link PasswordUtil#encode(String)} 保持同名，
     * 方便老代码迁移时少改方法名。
     *
     * @param password 明文密码
     * @return BCrypt 加密后的密码哈希
     */
    public static String encode(String password) {
        return encrypt(password);
    }

    /**
     * 校验明文密码与数据库中存储的 BCrypt 哈希是否匹配。
     *
     * @param rawPassword     用户输入的明文密码
     * @param encodedPassword 数据库存储的 BCrypt 哈希
     * @return 匹配返回 {@code true}，不匹配或参数为空返回 {@code false}
     */
    public static boolean matches(String rawPassword, String encodedPassword) {
        if (rawPassword == null || encodedPassword == null) {
            return false;
        }
        // BCrypt 会从 encodedPassword 中解析出盐，再与 rawPassword 做比对
        return ENCODER.matches(rawPassword, encodedPassword);
    }
}
