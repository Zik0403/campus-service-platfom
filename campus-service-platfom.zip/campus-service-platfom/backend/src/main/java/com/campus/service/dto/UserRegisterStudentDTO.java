package com.campus.service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;

/**
 * 学生用户注册入参 DTO。
 * <p>
 * 封装学生注册时必填字段，通过 JSR-303 注解校验学号、手机号、密码等格式，
 * 替代原有的 {@link java.util.Map} 传参方式。
 * </p>
 *
 * @author campus-service
 */
@Data
public class UserRegisterStudentDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 学生学号。
     */
    @NotBlank(message = "学号不能为空")
    @Size(max = 32, message = "学号长度不能超过32位")
    private String studentId;

    /**
     * 真实姓名。
     */
    @NotBlank(message = "真实姓名不能为空")
    @Size(max = 32, message = "真实姓名长度不能超过32位")
    private String realName;

    /**
     * 手机号。
     */
    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    /**
     * 登录密码。
     */
    @NotBlank(message = "登录密码不能为空")
    @Size(min = 6, max = 32, message = "登录密码长度必须在6到32位之间")
    private String password;

    /**
     * 宿舍楼栋，可选。
     */
    @Size(max = 32, message = "宿舍楼栋长度不能超过32位")
    private String dormBuild;

    /**
     * 宿舍房间号，可选。
     */
    @Size(max = 32, message = "宿舍房间号长度不能超过32位")
    private String dormRoom;
}
