package com.campus.service.controller;

import com.campus.service.dto.ServiceOrderCreateDTO;
import com.campus.service.entity.ServiceOrder;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.ServiceOrderService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 基于 DTO + JSR-303 校验的服务订单控制器。
 * <p>
 * 本类与 {@link ServiceOrderController} 并存，提供类型安全、带参数校验的下单接口，
 * 用于演示 DTO 入参和 {@link jakarta.validation.Valid} 校验在项目中的实际用法。
 * </p>
 *
 * @author campus-service
 */
@RestController
@RequestMapping("/service/order/dto")
@RequiredArgsConstructor
public class ServiceOrderDtoController {

    /**
     * 服务订单服务，处理订单创建等业务逻辑。
     */
    private final ServiceOrderService orderService;

    /**
     * 创建服务订单（DTO 版本）。
     * <p>
     * 使用 {@link ServiceOrderCreateDTO} 接收参数，并通过 {@link Valid} 触发 JSR-303 校验。
     * 校验失败时由 {@link com.campus.service.common.exception.GlobalExceptionHandler}
     * 统一捕获并返回 400 错误提示。
     * </p>
     *
     * @param request 当前 HTTP 请求对象，用于获取当前登录用户 ID
     * @param dto     订单创建入参 DTO
     * @return 创建成功的订单信息
     */
    @PostMapping("/create")
    public R<ServiceOrder> createOrder(HttpServletRequest request,
                                        @Valid @RequestBody ServiceOrderCreateDTO dto) {
        // 从请求属性中获取当前登录用户 ID
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        // 将 DTO 中的金额转换为字符串，保持与原 Service 方法参数类型一致
        String tipFeeStr = dto.getTipFee().toPlainString();
        String totalFeeStr = dto.getTotalFee().toPlainString();
        // 调用 Service 层创建订单
        ServiceOrder order = orderService.createOrder(
                userId,
                dto.getServiceType(),
                dto.getOriginAddr(),
                dto.getTargetAddr(),
                dto.getOrderContent(),
                tipFeeStr,
                totalFeeStr);
        return R.success(order);
    }
}
