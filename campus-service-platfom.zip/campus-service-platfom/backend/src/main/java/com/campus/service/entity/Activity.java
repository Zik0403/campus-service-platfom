package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 活动表。
 * 存储校园社团活动与个人活动的发布信息，包括主办方、时间地点、人数限制、报名统计、审核与上下架状态，
 * 支撑小程序端活动浏览、报名、签到与信用积分奖励等完整流程。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("activity") // 指定对应的数据库表名为 activity
public class Activity implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 活动主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 社团 ID，关联 club 表，标识该活动由哪个社团发起。
     * 若为个人活动，此字段可为空。
     */
    private Long clubId;

    /**
     * 发起人 ID，个人活动时为发起用户 ID；社团活动时通常为社团负责人。
     */
    private Long organizerId;

    /**
     * 活动类型：1 社团活动、2 个人活动。
     */
    private Integer activityType;

    /**
     * 活动名称，展示在活动列表与详情页。
     */
    private String name;

    /**
     * 活动海报图片地址，用于活动列表与详情页展示。
     */
    private String poster;

    /**
     * 活动地点，学生线下参与导航使用。
     */
    private String location;

    /**
     * 活动开始时间。
     */
    private LocalDateTime startTime;

    /**
     * 活动结束时间。
     */
    private LocalDateTime endTime;

    /**
     * 报名截止时间，超过该时间后不允许再报名。
     */
    private LocalDateTime enrollDeadline;

    /**
     * 活动描述，补充介绍活动内容、规则、注意事项等。
     */
    private String description;

    /**
     * 人数上限，控制活动最多允许多少人报名。
     */
    private Integer maxPeople;

    /**
     * 已报名人数，报名成功时递增，用于判断名额是否已满。
     */
    private Integer enrollCount;

    /**
     * 签到奖励信用积分，学生到场签到后可获得。
     */
    private Integer creditPoints;

    /**
     * 审核状态：1 待审核、2 已通过、3 驳回。
     * 社团/个人发布活动后需管理员审核通过方可上线。
     */
    private Integer auditStatus;

    /**
     * 活动上下架状态：0 禁用、1 启用。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录活动首次发布时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录活动信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
