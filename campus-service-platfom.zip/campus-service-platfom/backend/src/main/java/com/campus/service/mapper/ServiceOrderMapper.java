package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.ServiceOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 校园服务订单数据访问接口。
 *
 * <p>操作的数据库表为服务订单表，对应实体类为 {@link ServiceOrder}。
 * 主要负责校园跑腿、代办、配送等服务订单的查询，例如查询用户的服务订单、
 * 配送员的订单、按类型和状态筛选订单以及超时未支付订单。</p>
 */
@Mapper
public interface ServiceOrderMapper extends BaseMapper<ServiceOrder> {

    /**
     * 根据用户 ID 查询该用户发布的所有服务订单。
     *
     * @param userId 用户 ID
     * @return 该用户的服务订单列表
     */
    List<ServiceOrder> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据配送员 ID 查询分配给该配送员的服务订单。
     *
     * @param workerId 配送员用户 ID
     * @return 该配送员的服务订单列表
     */
    List<ServiceOrder> selectByWorkerId(@Param("workerId") Long workerId);

    /**
     * 根据服务类型和订单状态查询服务订单。
     *
     * @param serviceType 服务类型，例如跑腿、代办、快递代取等
     * @param status 订单状态，例如待接单、进行中、已完成等
     * @return 符合条件的服务订单列表
     */
    List<ServiceOrder> selectByTypeAndStatus(@Param("serviceType") Integer serviceType, @Param("status") Integer status);

    /**
     * 查询所有超时未支付的服务订单。
     *
     * @return 超时未支付的订单列表
     */
    List<ServiceOrder> selectTimeoutUnpaid();
}
