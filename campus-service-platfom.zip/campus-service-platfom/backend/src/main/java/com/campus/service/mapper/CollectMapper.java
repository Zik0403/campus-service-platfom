package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Collect;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 用户收藏数据访问接口。
 *
 * <p>操作的数据库表为收藏表，对应实体类为 {@link Collect}。
 * 主要负责用户对校园生活中各类内容（如帖子、商品、活动）的收藏记录的增删改查。</p>
 */
@Mapper
public interface CollectMapper extends BaseMapper<Collect> {

    /**
     * 根据用户 ID 查询该用户的所有收藏记录。
     *
     * @param userId 用户 ID
     * @return 该用户的收藏记录列表
     */
    List<Collect> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据用户、目标类型和目标 ID 查询某条具体的收藏记录。
     *
     * @param userId 用户 ID
     * @param targetType 收藏目标类型，例如帖子、商品、活动等
     * @param targetId 收藏目标 ID
     * @return 如果用户已收藏该目标则返回收藏记录，否则返回 null
     */
    Collect selectByUserAndTarget(@Param("userId") Long userId, @Param("targetType") Integer targetType, @Param("targetId") Long targetId);
}