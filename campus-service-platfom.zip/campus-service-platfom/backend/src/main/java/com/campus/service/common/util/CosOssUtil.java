package com.campus.service.common.util;

import com.campus.service.config.OssProperties;
import com.qcloud.cos.COSClient;
import com.qcloud.cos.model.ObjectMetadata;
import com.qcloud.cos.model.PutObjectRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

/**
 * 腾讯云 COS OSS 上传工具类。
 * <p>
 * 负责把头像等文件上传到 COS 对象存储，并返回可访问的完整 URL。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CosOssUtil {

    /**
     * 腾讯云 COS 客户端，由 {@link com.campus.service.config.OssConfig} 注入。
     */
    private final COSClient cosClient;

    /**
     * OSS 配置属性，包含 bucket、domain、endpoint 等。
     */
    private final OssProperties ossProperties;

    /**
     * 允许上传的头像文件类型白名单。
     */
    private static final String[] ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/jpg", "image/gif"};

    /**
     * 单个头像文件最大限制：10 MB。
     */
    private static final long MAX_AVATAR_SIZE = 10 * 1024 * 1024L;

    /**
     * 上传用户头像到 COS。
     * <p>
     * 文件会保存到 {@code avatar/{userId}/{uuid}.后缀} 路径下，
     * 上传成功后返回由 {@code oss.domain} 拼接的完整访问 URL。
     * </p>
     *
     * @param userId 当前上传用户 ID，用于构造文件路径
     * @param file   头像文件
     * @return 上传成功后的头像访问 URL
     */
    public String uploadAvatar(Long userId, MultipartFile file) {
        // 校验文件是否为空
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("请选择要上传的文件");
        }
        // 校验文件大小
        if (file.getSize() > MAX_AVATAR_SIZE) {
            throw new IllegalArgumentException("头像文件大小不能超过 10MB");
        }
        // 校验文件类型
        String contentType = file.getContentType();
        if (!isAllowedImageType(contentType)) {
            throw new IllegalArgumentException("仅支持上传 jpg、png、gif 格式的图片");
        }

        // 生成 COS 上的文件路径：avatar/{userId}/{uuid}.ext
        String originalFilename = file.getOriginalFilename();
        String ext = getFileExtension(originalFilename);
        String key = "avatar/" + userId + "/" + UUID.randomUUID().toString().replace("-", "") + ext;

        // 设置文件元数据
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(file.getSize());
        metadata.setContentType(contentType);

        try (InputStream inputStream = file.getInputStream()) {
            // 构造上传请求
            PutObjectRequest putObjectRequest = new PutObjectRequest(ossProperties.getBucket(), key, inputStream, metadata);
            // 执行上传
            cosClient.putObject(putObjectRequest);
            log.info("头像上传 COS 成功：userId={}, key={}", userId, key);
            // 返回可访问的完整 URL
            return buildAccessUrl(key);
        } catch (IOException e) {
            log.error("头像上传 COS 失败：userId={}", userId, e);
            throw new RuntimeException("头像上传失败：" + e.getMessage(), e);
        }
    }

    /**
     * 判断文件类型是否在允许的白名单内。
     *
     * @param contentType HTTP Content-Type
     * @return 是否允许上传
     */
    private boolean isAllowedImageType(String contentType) {
        if (contentType == null) {
            return false;
        }
        for (String type : ALLOWED_IMAGE_TYPES) {
            if (contentType.equalsIgnoreCase(type)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 获取文件扩展名，没有扩展名时默认返回 .jpg。
     *
     * @param filename 原始文件名
     * @return 扩展名（包含点）
     */
    private String getFileExtension(String filename) {
        if (filename != null && filename.contains(".")) {
            return filename.substring(filename.lastIndexOf("."));
        }
        return ".jpg";
    }

    /**
     * 拼接文件访问 URL。
     * <p>
     * 优先使用 {@code oss.domain} 配置；若未配置则使用 bucket + endpoint 拼接。
     * </p>
     *
     * @param key COS 文件路径
     * @return 完整访问 URL
     */
    private String buildAccessUrl(String key) {
        String domain = ossProperties.getDomain();
        if (domain == null || domain.isEmpty()) {
            domain = ossProperties.getEndpoint();
        }
        // 去掉末尾斜杠，统一拼接
        domain = domain.replaceAll("/$", "");
        return domain + "/" + key;
    }
}
