package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.ActivityEnroll;

import java.util.List;
import java.util.Map;

/**
 * 活动报名服务接口。
 * 负责校园社团活动的报名管理：学生报名、取消报名，活动现场签到/签退，
 * 以及社团负责人批量签到、签退、签到开关控制等。
 */
public interface ActivityEnrollService extends IService<ActivityEnroll> {

    /**
     * 学生报名指定活动。
     * @param userId 报名学生的用户ID
     * @param activityId 要报名的活动ID
     * @return 生成的活动报名记录
     */
    ActivityEnroll enroll(Long userId, Long activityId);

    /**
     * 学生取消自己的活动报名。
     * @param enrollId 报名记录ID
     * @param userId 当前操作用户ID，用于校验该报名是否属于本人
     */
    void cancelEnroll(Long enrollId, Long userId);

    /**
     * 学生参加活动现场签到。
     * @param enrollId 报名记录ID
     * @param userId 当前操作用户ID
     */
    void checkin(Long enrollId, Long userId);

    /**
     * 学生参加活动现场签退。
     * @param enrollId 报名记录ID
     * @param userId 当前操作用户ID
     */
    void checkout(Long enrollId, Long userId);

    /**
     * 查询某位学生参与的所有活动报名记录。
     * @param userId 学生用户ID
     * @return 该学生的活动报名记录列表
     */
    List<ActivityEnroll> getUserEnrolls(Long userId);

    /**
     * 查询某个活动的所有报名学生名单。
     * @param activityId 活动ID
     * @return 该活动的报名记录列表
     */
    List<ActivityEnroll> getActivityEnrolls(Long activityId);

    /**
     * 统计某个活动的报名与签到情况。
     * @param activityId 活动ID
     * @return 统计结果，通常包含报名人数、签到人数等
     */
    Map<String, Integer> getCheckinStats(Long activityId);

    /**
     * 社团负责人批量为活动签到。
     * @param activityId 活动ID
     * @param userIds 需要批量签到的学生用户ID列表
     * @param operatorId 执行操作的用户ID（一般为社团负责人）
     */
    void batchCheckin(Long activityId, List<Long> userIds, Long operatorId);

    /**
     * 社团负责人批量为活动签退。
     * @param activityId 活动ID
     * @param userIds 需要批量签退的学生用户ID列表
     * @param operatorId 执行操作的用户ID（一般为社团负责人）
     */
    void batchCheckout(Long activityId, List<Long> userIds, Long operatorId);

    /**
     * 活动发起人开启或关闭活动现场签到功能。
     * @param activityId 活动ID
     * @param enabled true表示开启签到，false表示关闭签到
     * @param operatorId 执行操作的用户ID
     */
    void toggleCheckin(Long activityId, Boolean enabled, Long operatorId);

    /**
     * 检查某位学生是否已经报名指定活动。
     * @param userId 学生用户ID
     * @param activityId 活动ID
     * @return 报名记录；如果未报名则返回null
     */
    ActivityEnroll checkUserEnrolled(Long userId, Long activityId);
}
