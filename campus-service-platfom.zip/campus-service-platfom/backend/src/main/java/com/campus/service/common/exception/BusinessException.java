package com.campus.service.common.exception;

import lombok.Getter;

/**
 * 业务异常基类
 */
@Getter
public class BusinessException extends RuntimeException {

    private final int code;
    private final String message;

    public BusinessException(int code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }

    public BusinessException(String message) {
        this(400, message);
    }

    // ========== 通用异常 ==========
    public static final BusinessException UNAUTHORIZED = new BusinessException(401, "未登录或登录已过期");
    public static final BusinessException FORBIDDEN = new BusinessException(403, "无权限访问");
    public static final BusinessException NOT_FOUND = new BusinessException(404, "资源不存在");
    public static final BusinessException SERVER_ERROR = new BusinessException(500, "服务器内部错误");

    // ========== 用户相关异常 ==========
    public static BusinessException userNotFound() {
        return new BusinessException(1001, "用户不存在");
    }

    public static BusinessException userNotAuth() {
        return new BusinessException(1002, "用户未实名认证");
    }

    public static BusinessException userBanned() {
        return new BusinessException(1003, "用户已被封禁");
    }

    public static BusinessException studentIdExists() {
        return new BusinessException(1004, "学号已被绑定");
    }

    public static BusinessException phoneExists() {
        return new BusinessException(1005, "手机号已被绑定");
    }

    // ========== 订单相关异常 ==========
    public static BusinessException orderNotFound() {
        return new BusinessException(2001, "订单不存在");
    }

    public static BusinessException orderStatusError() {
        return new BusinessException(2002, "订单状态不允许此操作");
    }

    public static BusinessException orderNotOwner() {
        return new BusinessException(2003, "不是订单所有者");
    }

    public static BusinessException orderExpired() {
        return new BusinessException(2004, "订单已过期");
    }

    // ========== 商品相关异常 ==========
    public static BusinessException productNotFound() {
        return new BusinessException(3001, "商品不存在");
    }

    public static BusinessException productNotOwner() {
        return new BusinessException(3002, "不是商品所有者");
    }

    public static BusinessException productStockNotEnough() {
        return new BusinessException(3003, "库存不足");
    }

    public static BusinessException productBanned() {
        return new BusinessException(3004, "商品违规已被下架");
    }

    // ========== 支付相关异常 ==========
    public static BusinessException payFailed() {
        return new BusinessException(4001, "支付失败");
    }

    public static BusinessException payCallbackError() {
        return new BusinessException(4002, "支付回调验证失败");
    }

    public static BusinessException refundFailed() {
        return new BusinessException(4003, "退款失败");
    }

    public static BusinessException balanceNotEnough() {
        return new BusinessException(4004, "余额不足");
    }

    // ========== 权限相关异常 ==========
    public static BusinessException roleNotAllowed() {
        return new BusinessException(5001, "角色权限不足");
    }

    public static BusinessException authFailed() {
        return new BusinessException(5002, "认证失败");
    }

    // ========== 参数校验异常 ==========
    public static BusinessException paramError(String message) {
        return new BusinessException(6001, "参数错误: " + message);
    }

    // ========== 通用快捷方法 ==========
    public static BusinessException notFound() {
        return new BusinessException(404, "资源不存在");
    }

    public static BusinessException notFound(String message) {
        return new BusinessException(404, message);
    }

    public static BusinessException forbidden() {
        return new BusinessException(403, "无权限访问");
    }

    public static BusinessException forbidden(String message) {
        return new BusinessException(403, message);
    }
}
