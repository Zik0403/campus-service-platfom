package com.campus.service.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.service.entity.Activity;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.ActivityEnrollService;
import com.campus.service.service.ActivityService;
import com.campus.service.service.ClubMemberService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/activity")
@RequiredArgsConstructor
public class ActivityController {

    private final ActivityService activityService;
    private final ClubMemberService clubMemberService;
    private final ActivityEnrollService enrollService;

    /**
     * 获取活动列表
     */
    @GetMapping("/list")
    public R<List<Activity>> getActivityList(@RequestParam(required = false) Long clubId) {
        if (clubId != null) {
            return R.success(activityService.getClubActivities(clubId));
        }
        List<Activity> list = activityService.list(new LambdaQueryWrapper<Activity>()
                .eq(Activity::getAuditStatus, 2)
                .eq(Activity::getStatus, 1)
                .orderByDesc(Activity::getCreateTime));
        return R.success(list);
    }

    /**
     * 获取活动详情
     */
    @GetMapping("/detail")
    public R<Activity> getActivityDetail(@RequestParam Long activityId) {
        Activity activity = activityService.getById(activityId);
        if (activity == null) {
            return R.error("活动不存在");
        }
        return R.success(activity);
    }

    /**
     * 获取可报名活动
     */
    @GetMapping("/available")
    public R<List<Activity>> getAvailableActivities() {
        return R.success(activityService.getAvailableActivities());
    }

    /**
     * 发布活动
     */
    @PostMapping("/create")
    public R<Activity> createActivity(HttpServletRequest request, @RequestBody java.util.Map<String, Object> body) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        
        String name = (String) body.get("name");
        String poster = (String) body.get("poster");
        String location = (String) body.get("location");
        String startTimeStr = (String) body.get("startTime");
        String endTimeStr = (String) body.get("endTime");
        String enrollDeadlineStr = (String) body.get("enrollDeadline");
        String description = (String) body.get("description");
        Integer maxPeople = body.get("maxPeople") != null ? Integer.parseInt(body.get("maxPeople").toString()) : 50;
        Integer creditPoints = body.get("creditPoints") != null ? Integer.parseInt(body.get("creditPoints").toString()) : 10;
        Integer activityType = body.get("activityType") != null ? Integer.parseInt(body.get("activityType").toString()) : 1;
        
        if (name == null || name.isEmpty()) {
            return R.error("活动名称不能为空");
        }
        if (location == null || location.isEmpty()) {
            return R.error("活动地点不能为空");
        }
        
        Activity activity = new Activity();
        
        // 个人活动（activityType=2）不需要社团权限
        if (activityType == 2) {
            activity.setOrganizerId(userId);
            activity.setActivityType(2);
            activity.setClubId(null);
            activity.setAuditStatus(2);
        } else {
            // 社团活动需要社团管理员权限
            Long clubId = null;
            if (body.get("clubId") != null) {
                clubId = Long.parseLong(body.get("clubId").toString());
            }
            if (clubId == null) {
                return R.error("社团活动需要指定社团");
            }
            if (!clubMemberService.isClubAdmin(userId, clubId)) {
                return R.error("您不是社团管理员，无法发布社团活动");
            }
            activity.setClubId(clubId);
            activity.setOrganizerId(userId);
            activity.setActivityType(1);
            activity.setAuditStatus(1);
        }
        
        activity.setName(name);
        activity.setPoster(poster);
        activity.setLocation(location);
        if (startTimeStr != null) {
            activity.setStartTime(java.time.LocalDateTime.parse(startTimeStr));
        }
        if (endTimeStr != null) {
            activity.setEndTime(java.time.LocalDateTime.parse(endTimeStr));
        }
        if (enrollDeadlineStr != null) {
            activity.setEnrollDeadline(java.time.LocalDateTime.parse(enrollDeadlineStr));
        }
        activity.setDescription(description);
        activity.setMaxPeople(maxPeople);
        activity.setEnrollCount(0);
        activity.setCreditPoints(creditPoints);
        activity.setStatus(1);
        activityService.save(activity);
        return R.success(activity);
    }

    /**
     * 更新活动信息
     */
    @PostMapping("/update")
    public R<Void> updateActivity(HttpServletRequest request,
                                   @RequestParam Long activityId,
                                   @RequestParam(required = false) String name,
                                   @RequestParam(required = false) String poster,
                                   @RequestParam(required = false) String location,
                                   @RequestParam(required = false) LocalDateTime startTime,
                                   @RequestParam(required = false) LocalDateTime endTime,
                                   @RequestParam(required = false) LocalDateTime enrollDeadline,
                                   @RequestParam(required = false) String description,
                                   @RequestParam(required = false) Integer maxPeople) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Activity activity = activityService.getById(activityId);
        if (activity == null) {
            return R.error("活动不存在");
        }
        // 校验是否是社团管理员
        if (!clubMemberService.isClubAdmin(userId, activity.getClubId())) {
            return R.error("您不是社团管理员，无法修改活动");
        }
        if (name != null) activity.setName(name);
        if (poster != null) activity.setPoster(poster);
        if (location != null) activity.setLocation(location);
        if (startTime != null) activity.setStartTime(startTime);
        if (endTime != null) activity.setEndTime(endTime);
        if (enrollDeadline != null) activity.setEnrollDeadline(enrollDeadline);
        if (description != null) activity.setDescription(description);
        if (maxPeople != null) activity.setMaxPeople(maxPeople);
        activityService.updateById(activity);
        return R.success();
    }

    /**
     * 删除活动
     */
    @PostMapping("/delete")
    public R<Void> deleteActivity(HttpServletRequest request, @RequestParam Long activityId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Activity activity = activityService.getById(activityId);
        if (activity == null) {
            return R.error("活动不存在");
        }
        if (!clubMemberService.isClubAdmin(userId, activity.getClubId())) {
            return R.error("您不是社团管理员，无法删除活动");
        }
        activity.setIsDelete(1);
        activityService.updateById(activity);
        return R.success();
    }

    /**
     * 审核活动（管理员操作）
     */
    @PostMapping("/audit")
    public R<Void> auditActivity(@RequestParam Long activityId, @RequestParam Integer auditStatus) {
        Activity activity = activityService.getById(activityId);
        if (activity == null) {
            return R.error("活动不存在");
        }
        activity.setAuditStatus(auditStatus);
        activityService.updateById(activity);
        return R.success();
    }

    /**
     * 获取我社团的活动列表
     */
    @GetMapping("/my/list")
    public R<List<Activity>> getMyActivities(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        // 获取我管理的社团ID列表
        List<Long> clubIds = clubMemberService.getUserClubs(userId).stream()
                .filter(m -> m.getIdentity() != null && m.getIdentity() <= 3)
                .map(m -> m.getClubId())
                .toList();
        if (clubIds.isEmpty()) {
            return R.success(List.of());
        }
        List<Activity> activities = activityService.list(new LambdaQueryWrapper<Activity>()
                .in(Activity::getClubId, clubIds)
                .orderByDesc(Activity::getCreateTime));
        return R.success(activities);
    }

    /**
     * 获取我发起的个人活动列表
     */
    @GetMapping("/my/personal")
    public R<List<Activity>> getMyPersonalActivities(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        List<Activity> activities = activityService.list(new LambdaQueryWrapper<Activity>()
                .eq(Activity::getOrganizerId, userId)
                .eq(Activity::getActivityType, 2)
                .orderByDesc(Activity::getCreateTime));
        return R.success(activities);
    }

    /**
     * 获取待审核的活动列表（管理员操作）
     */
    @GetMapping("/pending")
    public R<List<Activity>> getPendingActivities() {
        return R.success(activityService.list(new LambdaQueryWrapper<Activity>()
                .eq(Activity::getAuditStatus, 1)
                .orderByDesc(Activity::getCreateTime)));
    }

    /**
     * 获取活动报名统计
     */
    @GetMapping("/stats")
    public R<Map<String, Integer>> getActivityStats(@RequestParam Long activityId) {
        return R.success(enrollService.getCheckinStats(activityId));
    }

    /**
     * 获取可报名活动列表（走 Redis 缓存）。
     *
     * @return 当前可报名活动列表
     */
    @GetMapping("/available/cache")
    public R<List<Activity>> getAvailableActivitiesWithCache() {
        return R.success(activityService.getAvailableActivitiesWithCache());
    }

    /**
     * 获取指定社团活动列表（走 Redis 缓存）。
     *
     * @param clubId 社团 ID
     * @return 该社团下已通过审核的活动列表
     */
    @GetMapping("/club/cache")
    public R<List<Activity>> getClubActivitiesWithCache(@RequestParam Long clubId) {
        return R.success(activityService.getClubActivitiesWithCache(clubId));
    }

    /**
     * 获取待审核活动列表（走 Redis 缓存，管理员使用）。
     *
     * @return 待审核活动列表
     */
    @GetMapping("/pending/cache")
    public R<List<Activity>> getPendingAuditActivitiesWithCache() {
        return R.success(activityService.getPendingAuditActivitiesWithCache());
    }

    /**
     * 手动清除活动缓存（管理员维护活动后调用）。
     *
     * @return 操作结果
     */
    @PostMapping("/cache/evict")
    public R<Void> evictActivityCache() {
        activityService.evictActivityCache();
        return R.success();
    }
}
