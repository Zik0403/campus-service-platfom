package com.campus.service.controller;

import com.campus.service.entity.UserBankCard;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.UserBankCardService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user/bank-card")
@RequiredArgsConstructor
public class UserBankCardController {

    private final UserBankCardService bankCardService;

    @GetMapping("/list")
    public R<List<UserBankCard>> getCardList(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        List<UserBankCard> cards = bankCardService.getUserCards(userId);
        for (UserBankCard card : cards) {
            card.setCardNumber(null);
            card.setCardPassword(null);
        }
        return R.success(cards);
    }

    @PostMapping("/add")
    public R<UserBankCard> addCard(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String bankName = params.get("bankName");
        String cardNumber = params.get("cardNumber");
        String cardPassword = params.get("cardPassword");
        UserBankCard card = bankCardService.addCard(userId, bankName, cardNumber, cardPassword);
        card.setCardNumber(null);
        card.setCardPassword(null);
        return R.success(card);
    }

    @PostMapping("/delete")
    public R<Void> deleteCard(HttpServletRequest request,
                              @RequestBody(required = false) Map<String, Object> body,
                              @RequestParam(required = false) Long cardId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long cid = cardId;
        if (cid == null && body != null) {
            Object val = body.get("cardId");
            if (val != null) cid = Long.valueOf(val.toString());
        }
        if (cid == null) {
            return R.fail("银行卡ID不能为空");
        }
        bankCardService.deleteCard(userId, cid);
        return R.success();
    }

    @PostMapping("/set-default")
    public R<Void> setDefault(HttpServletRequest request,
                              @RequestBody(required = false) Map<String, Object> body,
                              @RequestParam(required = false) Long cardId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long cid = cardId;
        if (cid == null && body != null) {
            Object val = body.get("cardId");
            if (val != null) cid = Long.valueOf(val.toString());
        }
        if (cid == null) {
            return R.fail("银行卡ID不能为空");
        }
        bankCardService.setDefaultCard(userId, cid);
        return R.success();
    }
}
