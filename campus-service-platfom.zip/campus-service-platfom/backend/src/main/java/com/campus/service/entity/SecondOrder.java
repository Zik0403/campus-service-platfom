package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 二手担保交易订单表。
 * 记录二手商品交易的买卖双方、支付金额、平台佣金、支付状态、投诉与退款信息，
 * 支撑小程序端二手市场下单、担保支付、交付确认与售后处理。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("second_order") // 指定对应的数据库表名为 second_order
public class SecondOrder implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 订单号，采用雪花算法生成唯一字符串 ID。
     */
    @TableId(type = IdType.INPUT) // 主键由业务层生成（雪花字符串），非数据库自增
    private String id;

    /**
     * 商品 ID，关联 second_product 表。
     */
    private Long productId;

    /**
     * 买家用户 ID，关联 user 表。
     */
    private Long buyerId;

    /**
     * 卖家用户 ID，关联 user 表。
     */
    private Long sellerId;

    /**
     * 买家实付金额。
     */
    private BigDecimal payAmount;

    /**
     * 平台收取的佣金/服务费。
     */
    private BigDecimal platformFee;

    /**
     * 支付状态：1 待支付、2 已支付担保、3 已交付、4 资金打款卖家、5 全额退款。
     */
    private Integer payStatus;

    /**
     * 支付时间，买家完成微信支付的时间。
     */
    private LocalDateTime payTime;

    /**
     * 交付确认时间，买家确认收货/卖家确认交付完成的时间。
     */
    private LocalDateTime confirmTime;

    /**
     * 退款时间，发生全额退款时记录。
     */
    private LocalDateTime refundTime;

    /**
     * 微信支付单号，与微信支付回调对账使用。
     */
    private String wxPayNo;

    /**
     * 是否被投诉：0 否、1 是。
     */
    private Integer isComplained;

    /**
     * 投诉原因，买家对交易不满时填写。
     */
    private String complainReason;

    /**
     * 投诉时间。
     */
    private LocalDateTime complainTime;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录订单首次生成时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录订单信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联二手商品对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private SecondProduct product;

    /**
     * 关联买家用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User buyer;

    /**
     * 关联卖家用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User seller;
}
