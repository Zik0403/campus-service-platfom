package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.CetScore;
import com.campus.service.entity.CertInfo;
import com.campus.service.mapper.CetScoreMapper;
import com.campus.service.mapper.CertInfoMapper;
import com.campus.service.service.CareerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 职业生涯与考证服务实现类。
 * <p>
 * 负责校园场景中与学生职业发展相关的业务，包括大学英语四六级（CET）成绩查询、
 * 证书资讯列表查询以及证书详情查看等功能。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CareerServiceImpl extends ServiceImpl<CertInfoMapper, CertInfo> implements CareerService {

    /** 四六级成绩数据访问对象，用于查询 cet_score 四六级成绩表 */
    private final CetScoreMapper cetScoreMapper;

    /**
     * 查询学生的大学英语四六级成绩列表。
     * <p>
     * 支持按考试类型（如 CET4、CET6）筛选，结果按考试日期降序排列，
     * 最新的成绩排在最前面。
     * </p>
     *
     * @param studentId 学生编号
     * @param cetType   四六级考试类型，例如 "CET4" 或 "CET6"，可为空
     * @return 符合条件的四六级成绩列表
     */
    @Override
    public List<CetScore> getCetScores(String studentId, String cetType) {
        // 创建四六级成绩查询包装器
        LambdaQueryWrapper<CetScore> wrapper = new LambdaQueryWrapper<>();
        // 精确匹配学生编号，查询该学生的四六级成绩
        wrapper.eq(CetScore::getStudentId, studentId);
        // 如果传入了考试类型参数，则按考试类型精确查询
        if (cetType != null && !cetType.isEmpty()) {
            wrapper.eq(CetScore::getCetType, cetType);
        }
        // 按考试日期降序排列，最新成绩在前
        wrapper.orderByDesc(CetScore::getExamDate);
        // 执行四六级成绩列表查询
        return cetScoreMapper.selectList(wrapper);
    }

    /**
     * 查询证书资讯列表。
     * <p>
     * 支持按证书类型筛选，只返回状态正常的证书资讯，结果按排序值升序、创建时间降序排列。
     * </p>
     *
     * @param certType 证书类型，例如 "语言类"、"职业资格类" 等，可为空
     * @return 证书资讯列表
     */
    @Override
    public List<CertInfo> getCertList(String certType) {
        // 创建证书资讯查询包装器
        LambdaQueryWrapper<CertInfo> wrapper = new LambdaQueryWrapper<>();
        // 只查询状态正常的证书资讯
        wrapper.eq(CertInfo::getStatus, 1);
        // 如果传入了证书类型参数，则按类型精确查询
        if (certType != null && !certType.isEmpty()) {
            wrapper.eq(CertInfo::getCertType, certType);
        }
        // 先按排序值升序排列，排序值越小越靠前
        wrapper.orderByAsc(CertInfo::getSort)
                // 再按创建时间降序排列，新发布的证书资讯排在前面
                .orderByDesc(CertInfo::getCreateTime);
        // 执行证书资讯列表查询
        return list(wrapper);
    }

    /**
     * 查询证书资讯详情。
     *
     * @param certId 证书资讯编号
     * @return 证书资讯详情对象
     * @throws BusinessException 当证书资讯不存在时抛出
     */
    @Override
    public CertInfo getCertDetail(Long certId) {
        // 根据证书ID查询证书资讯信息
        CertInfo cert = getById(certId);
        // 判断证书资讯是否存在
        if (cert == null) {
            // 证书资讯不存在，抛出未找到异常
            throw BusinessException.notFound("证书资讯不存在");
        }
        // 返回证书资讯详情
        return cert;
    }
}
