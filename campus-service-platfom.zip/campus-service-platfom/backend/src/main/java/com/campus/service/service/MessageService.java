package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.Message;

import java.util.List;

/**
 * 消息通知服务接口。
 * 负责校园生活服务平台中的站内消息通知：系统或业务模块可向学生发送各类通知，
 * 学生可以查看未读消息、全部消息，并将消息标记为已读。
 */
public interface MessageService extends IService<Message> {

    /**
     * 向指定用户发送一条站内消息通知。
     * @param userId 接收消息的用户ID
     * @param msgType 消息类型（例如：1系统通知 2活动提醒 3订单通知 4审核通知等）
     * @param title 消息标题
     * @param content 消息正文内容
     * @param bizType 关联业务类型（例如：order、activity、club等）
     * @param bizId 关联业务记录ID
     */
    void sendMessage(Long userId, Integer msgType, String title, String content, String bizType, Long bizId);

    /**
     * 查询某位学生的未读消息列表。
     * @param userId 用户ID
     * @return 未读消息列表
     */
    List<Message> getUnreadMessages(Long userId);

    /**
     * 将某条消息标记为已读。
     * @param userId 当前操作用户ID
     * @param messageId 消息ID
     */
    void markAsRead(Long userId, Long messageId);

    /**
     * 将某位学生的全部消息标记为已读。
     * @param userId 用户ID
     */
    void markAllAsRead(Long userId);

    /**
     * 查询某位学生的全部消息列表。
     * @param userId 用户ID
     * @return 消息列表
     */
    List<Message> getUserMessages(Long userId);
}
