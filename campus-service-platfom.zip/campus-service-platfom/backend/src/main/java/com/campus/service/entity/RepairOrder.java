package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 报修工单表。
 * 存储学生提交的宿舍/公共设施报修请求，包括报修人、维修员、故障信息、地址、状态与评价，
 * 支撑小程序端报修下单、派单、维修进度跟踪与事后评价。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("repair_order") // 指定对应的数据库表名为 repair_order
public class RepairOrder implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 工单主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 报修学生用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 接单维修员用户 ID，关联 user 表。
     */
    private Long workerId;

    /**
     * 故障类型，如“水管漏水”“灯不亮”“门窗损坏”。
     */
    private String faultType;

    /**
     * 报修地址，如“3 号楼 502 宿舍”。
     */
    private String address;

    /**
     * 故障详细描述，补充说明问题现象与紧急程度。
     */
    private String description;

    /**
     * 故障图片 URL 数组，通常以 JSON 或逗号分隔的 OSS 地址存储。
     */
    private String images;

    /**
     * 紧急程度：1 普通、2 紧急。
     */
    private Integer priority;

    /**
     * 工单状态：1 待派单、2 维修中、3 已完成、4 驳回、5 取消。
     */
    private Integer status;

    /**
     * 评价星级，学生针对维修服务打分，取值 1-5。
     */
    private Integer evaluateStar;

    /**
     * 评价内容，学生对维修服务的文字反馈。
     */
    private String evaluateContent;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录工单首次提交时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录工单信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联报修学生用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User user;

    /**
     * 关联维修员用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User worker;
}
