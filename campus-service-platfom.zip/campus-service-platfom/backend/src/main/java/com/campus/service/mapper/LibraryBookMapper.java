package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.LibraryBook;
import org.apache.ibatis.annotations.Mapper;

/**
 * 图书馆藏书数据访问接口。
 *
 * <p>操作的数据库表为图书馆图书表，对应实体类为 {@link LibraryBook}。
 * 主要负责图书馆中图书基本信息的增删改查，例如书名、作者、ISBN、库存数量等。</p>
 */
@Mapper
public interface LibraryBookMapper extends BaseMapper<LibraryBook> {
}
