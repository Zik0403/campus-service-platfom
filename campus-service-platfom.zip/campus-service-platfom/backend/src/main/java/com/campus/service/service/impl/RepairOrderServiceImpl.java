package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.constants.RoleConstants;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.RepairOrder;
import com.campus.service.entity.User;
import com.campus.service.mapper.RepairOrderMapper;
import com.campus.service.service.RepairOrderService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 校园报修工单业务实现类。
 * <p>
 * 负责校园报修模块的工单全生命周期管理，包括学生提交报修、修改报修信息、
 * 管理员派单/维修员接单、维修完成、工单驳回、用户取消、用户评价以及超时待派单查询等业务。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RepairOrderServiceImpl extends ServiceImpl<RepairOrderMapper, RepairOrder> implements RepairOrderService {

    private final UserService userService;

    /**
     * 用户创建报修工单。
     *
     * @param userId      报修用户 ID
     * @param faultType   故障类型，如水电、网络、门窗等
     * @param address     报修地址
     * @param description 故障描述
     * @param images      故障图片地址
     * @param priority    优先级，数值越大优先级越高
     * @return 创建成功后的报修工单对象
     */
    @Override
    @Transactional
    public RepairOrder createOrder(Long userId, String faultType, String address, String description, String images, Integer priority) {
        // 创建一个新的报修工单实体对象
        RepairOrder order = new RepairOrder();
        // 设置报修用户 ID
        order.setUserId(userId);
        // 设置故障类型
        order.setFaultType(faultType);
        // 设置报修地址
        order.setAddress(address);
        // 设置故障详细描述
        order.setDescription(description);
        // 设置故障图片地址
        order.setImages(images);
        // 设置工单优先级，若参数为空则默认优先级为 1
        order.setPriority(priority != null ? priority : 1);
        // 设置工单状态为待派单
        order.setStatus(OrderStatus.REPAIR_PENDING);
        // 设置删除标识为未删除
        order.setIsDelete(0);
        // 调用 save 方法将工单插入 repair_order 表
        save(order);
        // 记录创建报修工单日志
        log.info("创建报修工单: orderId={}, userId={}", order.getId(), userId);
        // 返回创建成功的工单对象
        return order;
    }

    /**
     * 用户修改待派单状态下的报修工单。
     *
     * @param orderId     工单 ID
     * @param userId      当前操作用户 ID
     * @param faultType   故障类型
     * @param address     报修地址
     * @param description 故障描述
     * @param images      故障图片地址
     * @param priority    优先级
     * @return 修改成功后的报修工单对象
     */
    @Override
    @Transactional
    public RepairOrder updateOrder(Long orderId, Long userId, String faultType, String address, String description, String images, Integer priority) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为工单提交者
        if (!order.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验工单状态是否为待派单，只有待派单状态才允许修改
        if (order.getStatus() != OrderStatus.REPAIR_PENDING) {
            throw new BusinessException("当前状态不允许修改，仅待派单状态可修改");
        }
        // 更新故障类型
        order.setFaultType(faultType);
        // 更新报修地址
        order.setAddress(address);
        // 更新故障描述
        order.setDescription(description);
        // 更新故障图片地址
        order.setImages(images);
        // 更新工单优先级，若参数为空则默认优先级为 1
        order.setPriority(priority != null ? priority : 1);
        // 更新 repair_order 表中的工单信息
        updateById(order);
        // 记录修改报修工单日志
        log.info("修改报修工单: orderId={}, userId={}", orderId, userId);
        // 返回修改后的工单对象
        return order;
    }

    /**
     * 管理员将待派单工单指派给指定维修员。
     *
     * @param orderId  工单 ID
     * @param workerId 维修员用户 ID
     */
    @Override
    @Transactional
    public void assignWorker(Long orderId, Long workerId) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验工单状态是否为待派单
        if (order.getStatus() != OrderStatus.REPAIR_PENDING) {
            throw BusinessException.orderStatusError();
        }
        // 根据维修员 ID 查询用户信息
        User worker = userService.getById(workerId);
        // 若维修员不存在，抛出用户不存在的业务异常
        if (worker == null) {
            throw BusinessException.userNotFound();
        }
        // 校验用户角色是否为维修员
        if (worker.getRole() != RoleConstants.ROLE_WORKER) {
            throw BusinessException.roleNotAllowed();
        }
        // 校验维修员不能接自己提交的报修单
        if (order.getUserId().equals(workerId)) {
            throw new BusinessException("不能接自己的维修单");
        }
        // 设置工单的维修员 ID
        order.setWorkerId(workerId);
        // 将工单状态更新为处理中
        order.setStatus(OrderStatus.REPAIR_PROCESSING);
        // 更新 repair_order 表中的工单信息
        updateById(order);
        // 记录派单日志
        log.info("派单给维修员: orderId={}, workerId={}", orderId, workerId);
    }

    /**
     * 维修员主动接取待派单的报修工单。
     *
     * @param orderId  工单 ID
     * @param workerId 维修员用户 ID
     */
    @Override
    @Transactional
    public void workerAccept(Long orderId, Long workerId) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 根据维修员 ID 查询用户信息
        User worker = userService.getById(workerId);
        // 若维修员不存在，抛出用户不存在的业务异常
        if (worker == null) {
            throw BusinessException.userNotFound();
        }
        // 校验用户角色是否为维修员
        if (worker.getRole() != RoleConstants.ROLE_WORKER) {
            throw BusinessException.roleNotAllowed();
        }
        // 校验维修员不能接自己提交的报修单
        if (order.getUserId().equals(workerId)) {
            throw new BusinessException("不能接自己的维修单");
        }
        // 校验工单状态是否为待派单
        if (order.getStatus() != OrderStatus.REPAIR_PENDING) {
            throw BusinessException.orderStatusError();
        }
        // 设置工单的维修员 ID
        order.setWorkerId(workerId);
        // 将工单状态更新为处理中
        order.setStatus(OrderStatus.REPAIR_PROCESSING);
        // 更新 repair_order 表中的工单信息
        updateById(order);
        // 记录维修员接单日志
        log.info("维修员接单: orderId={}, workerId={}", orderId, workerId);
    }

    /**
     * 维修员完成报修工单。
     *
     * @param orderId  工单 ID
     * @param workerId 完成工单的维修员 ID
     */
    @Override
    @Transactional
    public void completeOrder(Long orderId, Long workerId) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验工单状态是否为处理中，只有处理中工单才能完成
        if (order.getStatus() != OrderStatus.REPAIR_PROCESSING) {
            throw BusinessException.orderStatusError();
        }
        // 若指定了维修员 ID，则校验当前操作人是否为该工单的维修员
        if (workerId != null && order.getWorkerId() != null && !order.getWorkerId().equals(workerId)) {
            throw BusinessException.roleNotAllowed();
        }
        // 将工单状态更新为已完成
        order.setStatus(OrderStatus.REPAIR_COMPLETED);
        // 更新 repair_order 表中的工单状态
        updateById(order);
        // 记录报修工单完成日志
        log.info("报修工单完成: orderId={}", orderId);
    }

    /**
     * 管理员驳回报修工单。
     *
     * @param orderId 工单 ID
     * @param reason  驳回原因
     */
    @Override
    @Transactional
    public void rejectOrder(Long orderId, String reason) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验工单状态，已完成或已取消的工单不允许驳回
        if (order.getStatus() == OrderStatus.REPAIR_COMPLETED || order.getStatus() == OrderStatus.REPAIR_CANCELLED) {
            throw BusinessException.orderStatusError();
        }
        // 将工单状态更新为已驳回
        order.setStatus(OrderStatus.REPAIR_REJECTED);
        // 更新 repair_order 表中的工单状态
        updateById(order);
        // 记录报修工单驳回日志
        log.info("报修工单驳回: orderId={}, reason={}", orderId, reason);
    }

    /**
     * 用户取消待派单状态下的报修工单。
     *
     * @param orderId 工单 ID
     * @param userId  当前操作用户 ID
     */
    @Override
    @Transactional
    public void cancelOrder(Long orderId, Long userId) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为工单提交者
        if (!order.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验工单状态是否为待派单，只有待派单状态才能取消
        if (order.getStatus() != OrderStatus.REPAIR_PENDING) {
            throw BusinessException.orderStatusError();
        }
        // 将工单状态更新为已取消
        order.setStatus(OrderStatus.REPAIR_CANCELLED);
        // 更新 repair_order 表中的工单状态
        updateById(order);
        // 记录用户取消报修工单日志
        log.info("用户取消报修工单: orderId={}, userId={}", orderId, userId);
    }

    /**
     * 用户对已完成的报修工单进行评价，并影响维修员信用分。
     *
     * @param orderId 工单 ID
     * @param userId  评价用户 ID
     * @param star    评价星级（1-5）
     * @param content 评价内容
     */
    @Override
    @Transactional
    public void evaluate(Long orderId, Long userId, Integer star, String content) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为工单提交者
        if (!order.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验工单状态是否为已完成，只有已完成工单才能评价
        if (order.getStatus() != OrderStatus.REPAIR_COMPLETED) {
            throw BusinessException.orderStatusError();
        }
        // 设置评价星级
        order.setEvaluateStar(star);
        // 设置评价内容
        order.setEvaluateContent(content);
        // 更新 repair_order 表中的评价信息
        updateById(order);
        // 若工单存在维修员且评价星级有效，则根据星级调整维修员信用分
        if (order.getWorkerId() != null && star != null) {
            // 4-5 星加 2 分，3 星不变，1-2 星扣 2 分
            int creditChange = star >= 4 ? 2 : (star >= 3 ? 0 : -2);
            // 更新维修员信用积分
            userService.updateCreditScore(order.getWorkerId(), creditChange);
        }
        // 记录用户评价报修工单日志
        log.info("用户评价报修工单: orderId={}, star={}", orderId, star);
    }

    /**
     * 查询指定用户提交的所有报修工单列表。
     *
     * @param userId 报修用户 ID
     * @return 该用户提交的报修工单列表
     */
    @Override
    public List<RepairOrder> getUserOrders(Long userId) {
        // 查询 repair_order 表中用户 ID 等于指定值的所有工单，按创建时间倒序返回
        return list(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getUserId, userId)
                .orderByDesc(RepairOrder::getCreateTime));
    }

    /**
     * 查询指定维修员待处理和处理中的报修工单列表。
     *
     * @param workerId 维修员用户 ID
     * @return 该维修员待处理和处理中的工单列表
     */
    @Override
    public List<RepairOrder> getWorkerPendingOrders(Long workerId) {
        // 查询 repair_order 表中维修员 ID 等于指定值，且状态为待派单或处理中的工单，按创建时间倒序返回
        return list(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getWorkerId, workerId)
                .in(RepairOrder::getStatus, OrderStatus.REPAIR_PENDING, OrderStatus.REPAIR_PROCESSING)
                .orderByDesc(RepairOrder::getCreateTime));
    }

    /**
     * 查询待派单的报修工单列表。
     *
     * @param excludeUserId 需要排除的用户 ID（通常为用户自己），可为空
     * @return 待派单的报修工单列表
     */
    @Override
    public List<RepairOrder> getPendingOrders(Long excludeUserId) {
        // 构建 repair_order 表查询条件：状态为待派单，并按创建时间倒序
        LambdaQueryWrapper<RepairOrder> wrapper = new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, OrderStatus.REPAIR_PENDING)
                .orderByDesc(RepairOrder::getCreateTime);
        // 若需要排除指定用户，则追加用户 ID 不等于条件
        if (excludeUserId != null) {
            wrapper.ne(RepairOrder::getUserId, excludeUserId);
        }
        // 执行查询并返回待派单工单列表
        return list(wrapper);
    }

    /**
     * 查询报修工单详情，并填充报修人与维修员信息。
     *
     * @param orderId 工单 ID
     * @param userId  当前查看用户 ID
     * @return 包含用户信息的工单详情对象
     */
    @Override
    public RepairOrder getOrderDetail(Long orderId, Long userId) {
        // 根据工单 ID 查询 repair_order 表中的工单信息
        RepairOrder order = getById(orderId);
        // 若工单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 查询当前查看用户信息
        User currentUser = userService.getById(userId);
        // 若当前用户不存在，抛出用户不存在的业务异常
        if (currentUser == null) {
            throw BusinessException.userNotFound();
        }
        // 判断当前用户是否为工单提交者
        boolean isOwner = order.getUserId().equals(userId);
        // 判断当前用户是否为该工单的维修员
        boolean isWorker = order.getWorkerId() != null && order.getWorkerId().equals(userId);
        // 若当前用户既不是提交者也不是维修员，且不是管理员，则无权查看
        if (!isOwner && !isWorker && currentUser.getRole() != RoleConstants.ROLE_ADMIN) {
            throw BusinessException.forbidden();
        }
        // 填充工单提交者用户信息
        order.setUser(userService.getById(order.getUserId()));
        // 若工单存在维修员，则填充维修员用户信息
        if (order.getWorkerId() != null) {
            order.setWorker(userService.getById(order.getWorkerId()));
        }
        // 返回工单详情
        return order;
    }

    /**
     * 查询超过 3 天仍未派单的报修工单列表。
     *
     * @return 超时未派单的工单列表
     */
    @Override
    public List<RepairOrder> getTimeoutPendingOrders() {
        // 查询 repair_order 表中状态为待派单且创建时间早于 3 天前的工单
        return list(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, OrderStatus.REPAIR_PENDING)
                .lt(RepairOrder::getCreateTime, LocalDateTime.now().minusDays(3)));
    }
}
