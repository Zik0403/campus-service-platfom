package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 跑腿外卖快递订单表（跑腿/外卖/快递代取共用）。
 * 记录学生发布的跑腿、外卖代购、快递代取等服务订单，包括下单人、配送员、服务类型、地址、费用、状态与评价，
 * 支撑小程序端服务下单、接单、配送、完成与售后投诉。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("service_order") // 指定对应的数据库表名为 service_order
public class ServiceOrder implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 订单号，采用雪花算法生成唯一字符串 ID。
     */
    @TableId(type = IdType.INPUT) // 主键由业务层生成（雪花字符串），非数据库自增
    private String id;

    /**
     * 下单用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 接单配送员用户 ID，关联 user 表。
     */
    private Long workerId;

    /**
     * 服务类型：1 快递代取、2 校园跑腿、3 校园外卖。
     */
    private Integer serviceType;

    /**
     * 取货/起点地址，如快递点、食堂、商店等。
     */
    private String originAddr;

    /**
     * 送达地址，通常为宿舍楼栋或指定位置。
     */
    private String targetAddr;

    /**
     * 代办/点餐内容描述，如快递取件码、外卖菜品、跑腿代办事项。
     */
    private String orderContent;

    /**
     * 小费，下单人额外给配送员的奖励金额。
     */
    private BigDecimal tipFee;

    /**
     * 订单总价，包含小费与商品费用等。
     */
    private BigDecimal totalFee;

    /**
     * 订单状态：1 待付款、2 待接单、3 配送中、4 已完成、5 退款取消。
     */
    private Integer status;

    /**
     * 微信支付单号，与微信支付回调对账使用。
     */
    private String wxPayNo;

    /**
     * 接单时间，配送员抢单/派单成功的时间。
     */
    private LocalDateTime acceptTime;

    /**
     * 评价星级，下单人针对配送服务打分，取值 1-5。
     */
    private Integer evaluateStar;

    /**
     * 是否被投诉：0 否、1 是。
     */
    private Integer isComplained;

    /**
     * 投诉原因，下单人对服务不满时填写。
     */
    private String complainReason;

    /**
     * 投诉时间。
     */
    private LocalDateTime complainTime;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录订单首次生成时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录订单信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联下单用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User user;

    /**
     * 关联配送员用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User worker;

    // ========== 业务方法：枚举值转中文名称 ==========

    /**
     * 根据 serviceType 字段值获取服务类型中文名称。
     *
     * @return 服务类型名称，如“快递代取”“校园跑腿”“校园外卖”
     */
    public String getServiceTypeName() {
        // 根据服务类型编码返回对应的中文描述，便于前端直接展示
        return switch (serviceType) {
            case 1 -> "快递代取";
            case 2 -> "校园跑腿";
            case 3 -> "校园外卖";
            default -> "未知";
        };
    }
}
