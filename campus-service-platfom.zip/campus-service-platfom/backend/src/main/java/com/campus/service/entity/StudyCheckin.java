package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 学习打卡表。
 * 记录学生每日学习打卡信息，包括打卡日期、时间、学习时长、地点与备注，
 * 支撑小程序端学习自律、打卡统计与习惯养成。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("study_checkin") // 指定对应的数据库表名为 study_checkin
public class StudyCheckin implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 打卡记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 打卡用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 打卡日期，表示本次打卡所属日期。
     */
    private LocalDate checkinDate;

    /**
     * 打卡时间，学生点击打卡按钮的时间。
     */
    private LocalDateTime checkinTime;

    /**
     * 学习时长（分钟），学生填写或由系统根据起止时间计算。
     */
    private Integer studyDuration;

    /**
     * 学习地点，如“图书馆”“自习室”“宿舍”。
     */
    private String location;

    /**
     * 学习备注，学生记录当天学习内容或心得。
     */
    private String note;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录打卡记录首次生成时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;
}
