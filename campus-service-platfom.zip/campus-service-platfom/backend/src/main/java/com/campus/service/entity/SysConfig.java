package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 系统配置表。
 * 存储后端系统的运行时配置项，如开关、阈值、第三方参数等，
 * 支持热更新与动态调整，避免硬编码到业务代码中。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("sys_config") // 指定对应的数据库表名为 sys_config
public class SysConfig implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 配置主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 配置键，程序中通过该键读取配置值，如“wx.appid”“service.fee.rate”。
     */
    private String configKey;

    /**
     * 配置值，对应配置键的实际内容。
     */
    private String configValue;

    /**
     * 配置名称/描述，便于管理员在后台识别用途。
     */
    private String configName;

    /**
     * 配置类型：1 系统、2 业务、3 第三方，用于后台分类管理。
     */
    private Integer configType;

    /**
     * 配置备注，补充说明配置项作用、取值范围等。
     */
    private String remark;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录配置项首次录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录配置项最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
