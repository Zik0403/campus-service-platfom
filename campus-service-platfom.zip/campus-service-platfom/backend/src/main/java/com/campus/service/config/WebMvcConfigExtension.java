package com.campus.service.config;

import com.campus.service.security.TokenBlacklistInterceptor;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web MVC 扩展配置类。
 * <p>
 * 用于注册项目新增的 {@link TokenBlacklistInterceptor}，
 * 与已有的 {@link com.campus.service.config.WebMvcConfig} 互补，
 * 共同完成拦截器链配置。
 * </p>
 * <p>
 * Spring 支持多个 {@link WebMvcConfigurer} 同时生效，
 * 因此本类无需修改原配置类即可扩展拦截器链。
 * </p>
 *
 * @author campus-service
 */
@Configuration
@RequiredArgsConstructor
public class WebMvcConfigExtension implements WebMvcConfigurer {

    /**
     * Token 黑名单拦截器，由 Spring 自动注入。
     */
    private final TokenBlacklistInterceptor tokenBlacklistInterceptor;

    /**
     * 注册拦截器。
     * <p>
     * 黑名单拦截器在登录拦截器之后执行，order 值设为 2，
     * 原 {@link com.campus.service.security.AuthInterceptor} 使用默认 order 0，
     * 因此先完成 Token 合法性校验，再校验黑名单。
     * </p>
     *
     * @param registry 拦截器注册器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 注册 Token 黑名单拦截器，拦截所有路径
        registry.addInterceptor(tokenBlacklistInterceptor)
                // 拦截所有请求路径
                .addPathPatterns("/**")
                // 登录、注册、swagger 等开放接口不需要校验黑名单
                .excludePathPatterns(
                        "/user/login",
                        "/user/register",
                        "/user/reset-password",
                        "/error",
                        "/api/doc.html",
                        "/api/webjars/**",
                        "/api/swagger-resources/**",
                        "/api/v3/api-docs/**",
                        "/uploads/**"
                )
                // 设置执行顺序在 AuthInterceptor 之后
                .order(2);
    }
}
