package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.User;

import java.math.BigDecimal;
import java.util.List;

/**
 * 用户服务接口。
 * 负责校园生活服务平台中用户账号的全生命周期管理：微信登录/注册、账号密码登录、
 * 学生与维修人员注册、实名认证、个人信息与宿舍信息维护、余额与信用积分管理、
 * 支付密码设置与验证，以及银行卡绑定状态检查等。
 */
public interface UserService extends IService<User> {

    /**
     * 通过微信openid完成登录或自动注册。
     * @param openid 微信用户在小程序中的唯一标识openid
     * @return 登录成功后的用户信息
     */
    User loginByOpenid(String openid);

    /**
     * 使用学号或手机号加密码登录。
     * @param account 学号或手机号
     * @param password 登录密码
     * @return 登录成功后的用户信息
     */
    User loginByPassword(String account, String password);

    /**
     * 学生用户注册账号。
     * @param studentId 学生学号
     * @param realName 真实姓名
     * @param phone 手机号
     * @param password 登录密码
     * @param dormBuild 宿舍楼栋
     * @param dormRoom 宿舍房间号
     * @return 注册成功后的用户信息
     */
    User registerStudent(String studentId, String realName, String phone, String password, String dormBuild, String dormRoom);

    /**
     * 维修人员注册账号。
     * @param realName 真实姓名
     * @param phone 手机号
     * @param idCard 身份证号
     * @param password 登录密码
     * @return 注册成功后的用户信息
     */
    User registerWorker(String realName, String phone, String idCard, String password);

    /**
     * 学生或维修人员通过手机号重置登录密码。
     * @param account 学号或手机号
     * @param phone 手机号
     * @param newPassword 新密码
     */
    void resetPassword(String account, String phone, String newPassword);

    /**
     * 用户完善个人基础信息（昵称、头像等）。
     * @param userId 用户ID
     * @param nickname 用户昵称
     * @param avatar 头像图片地址
     */
    void updateUserInfo(Long userId, String nickname, String avatar);

    /**
     * 用户实名认证：学生认证使用学号，维修人员认证使用身份证号。
     * @param userId 用户ID
     * @param studentId 学生学号（学生认证时传入）
     * @param idCard 身份证号（维修人员认证时传入）
     * @param realName 真实姓名
     * @param phone 手机号
     */
    void authUser(Long userId, String studentId, String idCard, String realName, String phone);

    /**
     * 用户更新自己的宿舍信息。
     * @param userId 用户ID
     * @param dormBuild 宿舍楼栋
     * @param dormRoom 宿舍房间号
     */
    void updateDormInfo(Long userId, String dormBuild, String dormRoom);

    /**
     * 用户修改绑定的手机号。
     * @param userId 用户ID
     * @param phone 新手机号
     */
    void updatePhone(Long userId, String phone);

    /**
     * 查询所有已注册的配送员/维修员用户列表。
     * @return 配送员或维修员用户列表
     */
    List<User> getWorkers();

    /**
     * 查询信用积分排行榜前N名用户。
     * @param limit 排行榜数量限制
     * @return 信用积分靠前的用户列表
     */
    List<User> getCreditTop(int limit);

    /**
     * 修改用户钱包余额。
     * @param userId 用户ID
     * @param amount 变动金额（正数表示增加，负数表示减少）
     * @param bizType 业务类型（例如：1充值 2消费 3提现 4退款 5配送收入 6交易收入 7平台佣金）
     */
    void updateBalance(Long userId, BigDecimal amount, Integer bizType);

    /**
     * 修改用户的信用积分。
     * @param userId 用户ID
     * @param score 信用积分变动值（正数加分，负数扣分）
     */
    void updateCreditScore(Long userId, int score);

    /**
     * 检查用户是否已完成实名认证等高风险操作所需的前置条件。
     * @param userId 用户ID
     */
    void checkUserAuth(Long userId);

    /**
     * 用户设置支付密码。
     * @param userId 用户ID
     * @param payPassword 支付密码
     */
    void setPayPassword(Long userId, String payPassword);

    /**
     * 验证用户输入的支付密码是否正确。
     * @param userId 用户ID
     * @param payPassword 待验证的支付密码
     * @return true表示密码正确，false表示密码错误
     */
    boolean verifyPayPassword(Long userId, String payPassword);

    /**
     * 用户修改支付密码。
     * @param userId 用户ID
     * @param oldPassword 原支付密码
     * @param newPassword 新支付密码
     */
    void updatePayPassword(Long userId, String oldPassword, String newPassword);

    /**
     * 用户通过个人信息验证后重置支付密码。
     * @param studentId 学生学号
     * @param realName 真实姓名
     * @param phone 手机号
     * @param newPassword 新支付密码
     */
    void resetPayPassword(String studentId, String realName, String phone, String newPassword);

    /**
     * 检查用户是否已经绑定了银行卡。
     * @param userId 用户ID
     * @return true表示已绑定，false表示未绑定
     */
    boolean hasBankCard(Long userId);

    /**
     * 检查用户是否已经设置了支付密码。
     * @param userId 用户ID
     * @return true表示已设置，false表示未设置
     */
    boolean hasPayPassword(Long userId);
}
