package com.campus.service.controller;

import com.campus.service.entity.LostFound;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.LostFoundService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/lostfound")
@RequiredArgsConstructor
public class LostFoundController {

    private final LostFoundService lostFoundService;

    private String getStr(Map<String, Object> body, String key, String defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        return v != null ? v.toString() : defaultValue;
    }

    private Integer getInt(Map<String, Object> body, String key, Integer defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Integer.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    private Long getLong(Map<String, Object> body, String key, Long defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Long.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    /**
     * 发布失物招领
     */
    @PostMapping("/create")
    public R<LostFound> createLostFound(HttpServletRequest request,
                                         @RequestBody(required = false) Map<String, Object> body,
                                         @RequestParam(required = false) Integer type,
                                         @RequestParam(required = false) String goodsName,
                                         @RequestParam(required = false) String goodsType,
                                         @RequestParam(required = false) String location,
                                         @RequestParam(required = false) String feature,
                                         @RequestParam(required = false) String contact,
                                         @RequestParam(required = false) String images) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Integer t = type != null ? type : getInt(body, "type", null);
        String gn = goodsName != null ? goodsName : getStr(body, "goodsName", getStr(body, "title", null));
        String gt = goodsType != null ? goodsType : getStr(body, "goodsType", getStr(body, "category", null));
        String loc = location != null ? location : getStr(body, "location", null);
        String feat = feature != null ? feature : getStr(body, "feature", getStr(body, "desc", null));
        String con = contact != null ? contact : getStr(body, "contact", null);
        String imgs = images != null ? images : getStr(body, "images", null);
        return R.success(lostFoundService.createLostFound(userId, t, gn, gt, loc, feat, con, imgs));
    }

    /**
     * 更新失物状态
     */
    @PutMapping("/status")
    public R<Void> updateStatus(@RequestBody(required = false) Map<String, Object> body,
                                 @RequestParam(required = false) Long id,
                                 @RequestParam(required = false) Integer status) {
        Long i = id != null ? id : getLong(body, "id", null);
        Integer s = status != null ? status : getInt(body, "status", null);
        lostFoundService.updateStatus(i, s);
        return R.success();
    }

    /**
     * 获取用户发布的失物
     */
    @GetMapping("/my/list")
    public R<List<LostFound>> getUserLostFound(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(lostFoundService.getUserLostFound(userId));
    }

    /**
     * 按类型获取失物列表
     */
    @GetMapping("/list")
    public R<List<LostFound>> getByType(@RequestParam(required = false) Integer type) {
        return R.success(lostFoundService.getByType(type));
    }

    /**
     * 获取智能匹配列表
     */
    @GetMapping("/match")
    public R<List<LostFound>> getMatchCandidates(@RequestParam Long lostFoundId) {
        return R.success(lostFoundService.getMatchCandidates(lostFoundId));
    }

    /**
     * 获取失物详情
     */
    @GetMapping("/detail")
    public R<LostFound> getDetail(HttpServletRequest request, @RequestParam Long id) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(lostFoundService.getDetail(id, userId));
    }

    /**
     * 点赞失物招领
     */
    @PostMapping("/like")
    public R<Void> likeLostFound(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) Long id) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long i = id != null ? id : getLong(body, "id", null);
        lostFoundService.likeLostFound(i, userId);
        return R.success();
    }
}
