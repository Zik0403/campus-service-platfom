package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.constants.RoleConstants;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.SecondOrder;
import com.campus.service.entity.SecondProduct;
import com.campus.service.entity.User;
import com.campus.service.mapper.SecondOrderMapper;
import com.campus.service.service.SecondOrderService;
import com.campus.service.service.SecondProductService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 校园二手交易订单业务实现类。
 * <p>
 * 负责校园二手商品交易订单的完整生命周期管理，包括买家下单、余额支付、卖家接单/交付、
 * 买家确认收货（平台打款）、退款、投诉以及超时未支付自动取消等业务流程。
 * 平台会按成交金额收取一定比例的担保手续费。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SecondOrderServiceImpl extends ServiceImpl<SecondOrderMapper, SecondOrder> implements SecondOrderService {

    private final SecondProductService productService;
    private final UserService userService;

    /**
     * 平台担保手续费率，当前为成交金额的 2%。
     */
    private static final BigDecimal PLATFORM_FEE_RATE = new BigDecimal("0.02");

    /**
     * 买家创建二手商品订单。
     *
     * @param buyerId   买家用户 ID
     * @param productId 二手商品 ID
     * @return 创建成功后的二手订单对象
     */
    @Override
    @Transactional
    public SecondOrder createOrder(Long buyerId, Long productId) {
        // 根据商品 ID 查询 second_product 表中的商品信息
        SecondProduct product = productService.getById(productId);
        // 若商品不存在，抛出商品不存在的业务异常
        if (product == null) {
            throw BusinessException.productNotFound();
        }
        // 校验商品状态是否为在售，只有上架商品才能下单
        if (product.getStatus() != OrderStatus.PRODUCT_ONLINE) {
            throw BusinessException.productBanned();
        }
        // 校验买家不能购买自己发布的商品
        if (product.getSellerId().equals(buyerId)) {
            throw new BusinessException("不能购买自己的商品");
        }
        // 校验买家是否已完成实名认证
        userService.checkUserAuth(buyerId);
        // 校验买家是否已设置支付密码
        if (!userService.hasPayPassword(buyerId)) {
            throw new BusinessException("请先设置支付密码后再下单");
        }
        // 创建一个新的二手订单实体对象
        SecondOrder order = new SecondOrder();
        // 生成订单编号：当前时间戳 + 4 位随机数
        order.setId(String.valueOf(System.currentTimeMillis()) + (int) (Math.random() * 10000));
        // 设置订单关联的商品 ID
        order.setProductId(productId);
        // 设置买家用户 ID
        order.setBuyerId(buyerId);
        // 设置卖家用户 ID（商品发布者）
        order.setSellerId(product.getSellerId());
        // 设置买家需支付的金额，即商品售价
        order.setPayAmount(product.getPrice());
        // 计算平台担保手续费：成交价 × 手续费率
        order.setPlatformFee(product.getPrice().multiply(PLATFORM_FEE_RATE));
        // 设置订单支付状态为待支付
        order.setPayStatus(OrderStatus.PAY_UNPAID);
        // 调用 save 方法将订单插入 second_order 表
        save(order);
        // 记录二手订单创建日志
        log.info("创建二手担保订单: orderId={}, buyerId={}, productId={}", order.getId(), buyerId, productId);
        // 返回创建成功的订单对象
        return order;
    }

    /**
     * 买家使用账户余额支付二手订单。
     *
     * @param orderId     待支付的二手订单 ID
     * @param wxPayNo     微信支付流水号
     * @param payPassword 用户支付密码
     */
    @Override
    @Transactional
    public void payOrder(String orderId, String wxPayNo, String payPassword) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验订单支付状态是否为待支付
        if (order.getPayStatus() != OrderStatus.PAY_UNPAID) {
            throw BusinessException.orderStatusError();
        }
        // 根据买家 ID 查询用户信息
        User buyer = userService.getById(order.getBuyerId());
        // 若买家不存在，抛出用户不存在的业务异常
        if (buyer == null) {
            throw BusinessException.userNotFound();
        }
        // 校验买家是否已绑定银行卡
        if (!userService.hasBankCard(order.getBuyerId())) {
            throw new BusinessException("请先绑定银行卡后再支付");
        }
        // 校验买家是否已设置支付密码
        if (buyer.getPayPassword() == null || buyer.getPayPassword().isEmpty()) {
            throw new BusinessException("请先设置支付密码");
        }
        // 校验请求中是否传入了支付密码
        if (payPassword == null || payPassword.isEmpty()) {
            throw new BusinessException("请输入支付密码");
        }
        // 校验支付密码是否正确
        if (!userService.verifyPayPassword(order.getBuyerId(), payPassword)) {
            throw new BusinessException("支付密码错误，请重新输入");
        }
        // 校验买家余额是否足够支付订单金额
        if (buyer.getBalance().compareTo(order.getPayAmount()) < 0) {
            throw new BusinessException("账户余额不足，请先充值");
        }
        // 扣除买家账户余额，交易类型 2 表示支付扣款
        userService.updateBalance(order.getBuyerId(), order.getPayAmount().negate(), 2);
        // 将订单支付状态更新为已支付
        order.setPayStatus(OrderStatus.PAY_PAID);
        // 记录微信支付流水号
        order.setWxPayNo(wxPayNo);
        // 记录实际支付时间
        order.setPayTime(LocalDateTime.now());
        // 更新 second_order 表中的订单支付信息
        updateById(order);
        // 记录二手订单支付成功日志
        log.info("二手订单支付成功: orderId={}, wxPayNo={}, amount={}", orderId, wxPayNo, order.getPayAmount());
    }

    /**
     * 买家或卖家确认二手商品已交付（线下交货完成）。
     *
     * @param orderId 订单 ID
     * @param userId  确认交付的用户 ID
     */
    @Override
    @Transactional
    public void confirmDelivery(String orderId, Long userId) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为买家或卖家之一
        if (!order.getBuyerId().equals(userId) && !order.getSellerId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验订单支付状态是否为已支付，只有已支付才能确认交付
        if (order.getPayStatus() != OrderStatus.PAY_PAID) {
            throw BusinessException.orderStatusError();
        }
        // 将订单支付状态更新为已交付
        order.setPayStatus(OrderStatus.PAY_DELIVERED);
        // 记录交付确认时间
        order.setConfirmTime(LocalDateTime.now());
        // 更新 second_order 表中的订单状态
        updateById(order);
        // 将对应商品状态更新为已售出
        productService.updateById(new SecondProduct() {{ setId(order.getProductId()); setStatus(OrderStatus.PRODUCT_SOLD); }});
        // 记录二手订单确认交付日志
        log.info("二手订单确认交付: orderId={}", orderId);
    }

    /**
     * 卖家确认买家已收货，平台将扣除手续费后的金额打款给卖家。
     *
     * @param orderId 订单 ID
     * @param userId  确认收货的卖家用户 ID
     */
    @Override
    @Transactional
    public void confirmReceive(String orderId, Long userId) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为卖家
        if (!order.getSellerId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验订单支付状态是否为已交付，只有已交付才能确认收货打款
        if (order.getPayStatus() != OrderStatus.PAY_DELIVERED) {
            throw BusinessException.orderStatusError();
        }
        // 计算卖家实际到账金额：成交价 - 平台手续费
        BigDecimal sellerAmount = order.getPayAmount().subtract(order.getPlatformFee());
        // 增加卖家账户余额，交易类型 6 表示二手交易收入
        userService.updateBalance(order.getSellerId(), sellerAmount, 6);
        // 将订单支付状态更新为已转账（平台已打款）
        order.setPayStatus(OrderStatus.PAY_TRANSFERRED);
        // 更新 second_order 表中的订单状态
        updateById(order);
        // 记录二手订单打款日志
        log.info("二手订单打款给卖家: orderId={}, amount={}", orderId, sellerAmount);
    }

    /**
     * 买家申请二手订单退款。
     *
     * @param orderId 订单 ID
     * @param userId  申请退款的用户 ID
     */
    @Override
    @Transactional
    public void refundOrder(String orderId, Long userId) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为买家
        if (!order.getBuyerId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 校验订单支付状态，已转账或已退款的订单不能再退款
        if (order.getPayStatus() == OrderStatus.PAY_TRANSFERRED || order.getPayStatus() == OrderStatus.PAY_REFUND) {
            throw BusinessException.orderStatusError();
        }
        // 若商品已交付，则不允许退款，需联系客服处理
        if (order.getPayStatus() == OrderStatus.PAY_DELIVERED) {
            throw new BusinessException("已交付商品无法退款，请联系客服");
        }
        // 将买家支付金额全额退回余额，交易类型 4 表示退款
        userService.updateBalance(order.getBuyerId(), order.getPayAmount(), 4);
        // 将订单支付状态更新为已退款
        order.setPayStatus(OrderStatus.PAY_REFUND);
        // 记录退款时间
        order.setRefundTime(LocalDateTime.now());
        // 更新 second_order 表中的订单状态
        updateById(order);
        // 将对应商品状态恢复为在售，允许其他人再次购买
        productService.updateById(new SecondProduct() {{ setId(order.getProductId()); setStatus(OrderStatus.PRODUCT_ONLINE); }});
        // 记录二手订单退款日志
        log.info("二手订单退款: orderId={}", orderId);
    }

    /**
     * 买家或卖家对二手订单发起投诉。
     *
     * @param orderId 订单 ID
     * @param userId  投诉用户 ID
     * @param reason  投诉原因
     */
    @Override
    @Transactional
    public void complainOrder(String orderId, Long userId, String reason) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 校验当前操作人是否为买家或卖家之一
        if (!order.getBuyerId().equals(userId) && !order.getSellerId().equals(userId)) {
            throw BusinessException.forbidden();
        }
        // 校验订单是否已被投诉，避免重复提交
        if (order.getIsComplained() != null && order.getIsComplained() == 1) {
            throw new BusinessException("该订单已投诉，请勿重复提交");
        }
        // 设置订单投诉标识为已投诉
        order.setIsComplained(1);
        // 记录投诉原因
        order.setComplainReason(reason);
        // 记录投诉提交时间
        order.setComplainTime(LocalDateTime.now());
        // 更新 second_order 表中的投诉信息
        updateById(order);
        // 记录用户投诉二手订单日志
        log.info("用户投诉二手订单: orderId={}, userId={}, reason={}", orderId, userId, reason);
    }

    /**
     * 查询二手订单详情，并填充商品、买家、卖家信息。
     *
     * @param orderId 订单 ID
     * @param userId  当前查看用户 ID
     * @return 包含关联信息的二手订单详情对象
     */
    @Override
    public SecondOrder getOrderDetail(String orderId, Long userId) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 查询当前查看用户信息
        User currentUser = userService.getById(userId);
        // 若当前用户既不是买家也不是卖家，且不是管理员（角色 4），则无权查看
        if (!order.getBuyerId().equals(userId) && !order.getSellerId().equals(userId)
                && currentUser.getRole() != 4) {
            throw BusinessException.forbidden();
        }
        // 填充订单关联的商品信息
        order.setProduct(productService.getById(order.getProductId()));
        // 填充买家用户信息
        order.setBuyer(userService.getById(order.getBuyerId()));
        // 填充卖家用户信息
        order.setSeller(userService.getById(order.getSellerId()));
        // 返回订单详情
        return order;
    }

    /**
     * 查询指定买家的二手订单列表。
     *
     * @param buyerId 买家用户 ID
     * @return 该买家的二手订单列表
     */
    @Override
    public List<SecondOrder> getBuyerOrders(Long buyerId) {
        // 查询 second_order 表中买家 ID 等于指定值的所有订单，按创建时间倒序返回
        return list(new LambdaQueryWrapper<SecondOrder>()
                .eq(SecondOrder::getBuyerId, buyerId)
                .orderByDesc(SecondOrder::getCreateTime));
    }

    /**
     * 查询指定卖家的二手订单列表。
     *
     * @param sellerId 卖家用户 ID
     * @return 该卖家的二手订单列表
     */
    @Override
    public List<SecondOrder> getSellerOrders(Long sellerId) {
        // 查询 second_order 表中卖家 ID 等于指定值的所有订单，按创建时间倒序返回
        return list(new LambdaQueryWrapper<SecondOrder>()
                .eq(SecondOrder::getSellerId, sellerId)
                .orderByDesc(SecondOrder::getCreateTime));
    }

    /**
     * 处理微信支付回调，将订单状态更新为已支付。
     *
     * @param orderId 订单 ID
     * @param wxPayNo 微信支付流水号
     */
    @Override
    @Transactional
    public void handlePayCallback(String orderId, String wxPayNo) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，记录错误日志并直接返回，避免影响回调处理
        if (order == null) {
            log.error("支付回调订单不存在: orderId={}", orderId);
            return;
        }
        // 若订单支付状态不是待支付，说明已处理过或状态异常，记录警告日志并返回
        if (order.getPayStatus() != OrderStatus.PAY_UNPAID) {
            log.warn("支付回调订单状态异常: orderId={}, status={}", orderId, order.getPayStatus());
            return;
        }
        // 将订单支付状态更新为已支付
        order.setPayStatus(OrderStatus.PAY_PAID);
        // 记录微信支付流水号
        order.setWxPayNo(wxPayNo);
        // 记录实际支付时间
        order.setPayTime(LocalDateTime.now());
        // 更新 second_order 表中的订单支付信息
        updateById(order);
        // 记录支付回调处理成功日志
        log.info("支付回调处理成功: orderId={}", orderId);
    }

    /**
     * 自动取消超时未支付的二手订单。
     */
    @Override
    @Transactional
    public void cancelTimeoutOrders() {
        // 查询 second_order 表中支付状态为待支付且创建时间超过 15 分钟的订单
        List<SecondOrder> timeoutOrders = list(new LambdaQueryWrapper<SecondOrder>()
                .eq(SecondOrder::getPayStatus, OrderStatus.PAY_UNPAID)
                .lt(SecondOrder::getCreateTime, LocalDateTime.now().minusMinutes(15)));
        // 遍历所有超时未支付订单，将其状态更新为已退款（超时取消）
        for (SecondOrder order : timeoutOrders) {
            // 将订单支付状态设置为已退款
            order.setPayStatus(OrderStatus.PAY_REFUND);
            // 记录退款时间
            order.setRefundTime(LocalDateTime.now());
            // 更新 second_order 表中的订单状态
            updateById(order);
            // 记录超时未支付订单自动取消日志
            log.info("超时未支付订单自动取消: orderId={}", order.getId());
        }
    }

    /**
     * 查询已支付待交付的二手订单列表（接单大厅使用）。
     *
     * @param excludeUserId 需要排除的用户 ID（通常为用户自己），可为空
     * @return 已支付待交付的二手订单列表
     */
    @Override
    public List<SecondOrder> getPendingOrders(Long excludeUserId) {
        // 构建 second_order 表查询条件：支付状态为已支付，按创建时间倒序
        LambdaQueryWrapper<SecondOrder> wrapper = new LambdaQueryWrapper<SecondOrder>()
                .eq(SecondOrder::getPayStatus, OrderStatus.PAY_PAID)
                .orderByDesc(SecondOrder::getCreateTime);
        // 若需要排除指定用户，则追加卖家 ID 不等于条件
        if (excludeUserId != null) {
            wrapper.ne(SecondOrder::getSellerId, excludeUserId);
        }
        // 执行查询获取订单列表
        List<SecondOrder> orders = list(wrapper);
        // 遍历订单，填充商品信息和买家信息，用于列表展示
        for (SecondOrder order : orders) {
            // 根据商品 ID 填充商品信息
            order.setProduct(productService.getById(order.getProductId()));
            // 根据买家 ID 填充买家信息
            order.setBuyer(userService.getById(order.getBuyerId()));
        }
        // 返回处理后的订单列表
        return orders;
    }

    /**
     * 学生卖家接取已支付的二手订单，并标记为已交付。
     *
     * @param orderId  订单 ID
     * @param sellerId 接单卖家用户 ID
     */
    @Override
    @Transactional
    public void sellerAccept(String orderId, Long sellerId) {
        // 根据订单 ID 查询 second_order 表中的订单信息
        SecondOrder order = getById(orderId);
        // 若订单不存在，抛出订单不存在的业务异常
        if (order == null) {
            throw BusinessException.orderNotFound();
        }
        // 根据卖家 ID 查询用户信息
        User seller = userService.getById(sellerId);
        // 若卖家用户不存在，抛出用户不存在的业务异常
        if (seller == null) {
            throw BusinessException.userNotFound();
        }
        // 校验接单者角色是否为学生
        if (seller.getRole() != RoleConstants.ROLE_STUDENT) {
            throw new BusinessException("只有学生可以接二手订单");
        }
        // 校验卖家不能接自己发布的商品的订单
        if (order.getBuyerId().equals(sellerId)) {
            throw new BusinessException("不能接自己购买的订单");
        }
        // 校验订单支付状态是否为已支付
        if (order.getPayStatus() != OrderStatus.PAY_PAID) {
            throw BusinessException.orderStatusError();
        }
        // 设置订单的卖家 ID 为接单学生
        order.setSellerId(sellerId);
        // 将订单支付状态更新为已交付
        order.setPayStatus(OrderStatus.PAY_DELIVERED);
        // 记录交付确认时间
        order.setConfirmTime(LocalDateTime.now());
        // 更新 second_order 表中的订单信息
        updateById(order);
        // 记录用户接单二手订单日志
        log.info("用户接单二手订单: orderId={}, userId={}", orderId, sellerId);
    }
}
