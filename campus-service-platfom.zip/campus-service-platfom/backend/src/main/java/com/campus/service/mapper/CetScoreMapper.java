package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.CetScore;
import org.apache.ibatis.annotations.Mapper;

/**
 * 大学英语四六级成绩数据访问接口。
 *
 * <p>操作的数据库表为四六级成绩表，对应实体类为 {@link CetScore}。
 * 主要负责学生 CET 成绩的增删改查，例如查询某位学生的四级或六级成绩。</p>
 */
@Mapper
public interface CetScoreMapper extends BaseMapper<CetScore> {
}
