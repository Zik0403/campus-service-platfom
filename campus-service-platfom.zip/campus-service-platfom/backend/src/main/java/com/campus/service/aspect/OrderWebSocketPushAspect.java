package com.campus.service.aspect;

import com.campus.service.entity.ServiceOrder;
import com.campus.service.service.OrderWebSocketPushService;
import com.campus.service.service.ServiceOrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/**
 * 订单变更 WebSocket 推送切面。
 * <p>
 * 在不改动原有 {@link com.campus.service.service.ServiceOrderService} 业务代码的前提下，
 * 通过 AOP 拦截订单相关方法的执行结果，当订单状态发生变化时，
 * 调用 {@link OrderWebSocketPushService} 向前端推送实时消息。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class OrderWebSocketPushAspect {

    /**
     * WebSocket 订单推送服务。
     */
    private final OrderWebSocketPushService pushService;

    /**
     * 定义切入点：拦截 ServiceOrderService 接口中所有会改变订单状态的方法。
     * <p>
     * 包括下单、支付、接单、开始配送、完成、取消、退款、评价、投诉、退回等操作。
     * </p>
     */
    @Pointcut("execution(* com.campus.service.service.ServiceOrderService.*(..))")
    public void orderServicePointcut() {
        // 切入点声明，无需业务逻辑
    }

    /**
     * 订单创建成功后推送 CREATE 事件。
     * <p>
     * createOrder 方法会返回创建成功的 {@link ServiceOrder} 对象，直接用于推送。
     * </p>
     *
     * @param order 创建成功的订单对象
     */
    @AfterReturning(pointcut = "orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.createOrder(..))", returning = "order")
    public void afterCreateOrder(ServiceOrder order) {
        if (order == null) {
            return;
        }
        pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_CREATE);
    }

    /**
     * 订单支付成功后推送 PAY 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.payOrder(..))")
    public void afterPayOrder(JoinPoint joinPoint) {
        // 获取第一个参数订单号
        String orderId = (String) joinPoint.getArgs()[0];
        // 通过 ServiceOrderService 查询最新订单状态
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_PAY);
        }
    }

    /**
     * 配送员接单成功后推送 ACCEPT 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.workerAccept(..))")
    public void afterWorkerAccept(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_ACCEPT);
        }
    }

    /**
     * 开始配送后推送 START 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.startDelivery(..))")
    public void afterStartDelivery(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_START);
        }
    }

    /**
     * 订单完成后推送 COMPLETE 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.completeOrder(..))")
    public void afterCompleteOrder(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_COMPLETE);
        }
    }

    /**
     * 用户取消订单后推送 CANCEL 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.cancelOrder(..))")
    public void afterCancelOrder(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_CANCEL);
        }
    }

    /**
     * 用户申请退款后推送 CANCEL 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.refundOrder(..))")
    public void afterRefundOrder(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_CANCEL);
        }
    }

    /**
     * 用户评价后推送 EVALUATE 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.evaluate(..))")
    public void afterEvaluate(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_EVALUATE);
        }
    }

    /**
     * 用户投诉后推送 COMPLAIN 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.complainOrder(..))")
    public void afterComplainOrder(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_COMPLAIN);
        }
    }

    /**
     * 接单员退回订单后推送 RETURN 事件。
     *
     * @param joinPoint AOP 连接点
     */
    @AfterReturning("orderServicePointcut() && execution(* com.campus.service.service.ServiceOrderService.workerReturnOrder(..))")
    public void afterWorkerReturnOrder(JoinPoint joinPoint) {
        String orderId = (String) joinPoint.getArgs()[0];
        ServiceOrder order = getOrderById(joinPoint, orderId);
        if (order != null) {
            pushService.pushOrderUpdate(order, OrderWebSocketPushService.EVENT_RETURN);
        }
    }

    /**
     * 通过目标 Service 查询最新订单状态。
     * <p>
     * 利用 Spring AOP 代理的目标对象调用 {@link ServiceOrderService#getById(java.io.Serializable)}，
     * 避免引入新的 Mapper 依赖。
     * </p>
     *
     * @param joinPoint AOP 连接点
     * @param orderId   订单号
     * @return 最新订单对象；查询失败时返回 null
     */
    private ServiceOrder getOrderById(JoinPoint joinPoint, String orderId) {
        try {
            // 获取被代理的目标对象，转换为 ServiceOrderService 接口
            ServiceOrderService service = (ServiceOrderService) joinPoint.getTarget();
            // 调用 getById 查询最新订单状态
            return service.getById(orderId);
        } catch (Exception e) {
            log.error("订单推送时查询订单失败：orderId={}", orderId, e);
            return null;
        }
    }
}
