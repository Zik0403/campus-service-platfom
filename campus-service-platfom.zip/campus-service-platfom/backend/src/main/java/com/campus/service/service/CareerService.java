package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.CetScore;
import com.campus.service.entity.CertInfo;

import java.util.List;

/**
 * 学业与考证服务接口。
 * 负责学生在校期间的学业信息查询，包括英语四六级成绩、各类资格证书信息，
 * 帮助学生随时查看自己的考试与考证记录。
 */
public interface CareerService extends IService<CertInfo> {

    /**
     * 查询学生的英语四六级成绩。
     * @param studentId 学生学号
     * @param cetType 考试类型（例如：CET4、CET6）
     * @return 该学生的四六级成绩列表
     */
    List<CetScore> getCetScores(String studentId, String cetType);

    /**
     * 查询某类资格证书的列表。
     * @param certType 证书类型（例如：计算机等级、普通话、教师资格证等）
     * @return 该类型的证书信息列表
     */
    List<CertInfo> getCertList(String certType);

    /**
     * 查询某张资格证书的详细信息。
     * @param certId 证书记录ID
     * @return 证书详细信息
     */
    CertInfo getCertDetail(Long certId);
}
