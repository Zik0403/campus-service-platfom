package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Club;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 校园社团数据访问接口。
 *
 * <p>操作的数据库表为社团表，对应实体类为 {@link Club}。
 * 主要负责学校社团信息的查询，例如查询已审核通过的社团、按分类浏览社团、搜索感兴趣的社团。</p>
 */
@Mapper
public interface ClubMapper extends BaseMapper<Club> {

    /**
     * 查询所有已经审核通过的社团。
     *
     * @return 已审核社团列表
     */
    List<Club> selectAuditedClubs();

    /**
     * 根据社团分类查询社团。
     *
     * @param category 社团分类，例如体育、文艺、学术等
     * @return 该分类下的社团列表
     */
    List<Club> selectByCategory(@Param("category") String category);

    /**
     * 根据关键字搜索社团。
     *
     * @param keyword 搜索关键字，例如社团名称中的关键字
     * @return 符合搜索条件的社团列表
     */
    List<Club> searchClubs(@Param("keyword") String keyword);
}
