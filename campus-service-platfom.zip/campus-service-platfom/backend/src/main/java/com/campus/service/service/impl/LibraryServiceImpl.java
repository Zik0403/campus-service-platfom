package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.*;
import com.campus.service.mapper.*;
import com.campus.service.service.LibraryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * 图书馆服务实现类。
 * <p>
 * 负责校园图书馆相关业务，包括图书检索与详情查看、图书借阅/归还/续借、图书预约、
 * 图书馆座位查询与预约、座位签到签退以及学习打卡统计等功能。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LibraryServiceImpl extends ServiceImpl<LibraryBookMapper, LibraryBook> implements LibraryService {

    /** 图书借阅记录数据访问对象，用于查询 borrow_record 借阅记录表 */
    private final BorrowRecordMapper borrowRecordMapper;
    /** 图书馆座位数据访问对象，用于查询 library_seat 座位表 */
    private final LibrarySeatMapper librarySeatMapper;
    /** 座位预约记录数据访问对象，用于查询 seat_reservation 座位预约表 */
    private final SeatReservationMapper seatReservationMapper;
    /** 学习打卡记录数据访问对象，用于查询 study_checkin 学习打卡表 */
    private final StudyCheckinMapper studyCheckinMapper;
    /** 图书预约记录数据访问对象，用于查询 book_reservation 图书预约表 */
    private final BookReservationMapper bookReservationMapper;
    /** 用户信息数据访问对象，用于查询 user 用户表 */
    private final UserMapper userMapper;

    /**
     * 根据关键词和分类检索图书。
     * <p>
     * 支持按书名、作者、ISBN 进行模糊匹配，并按分类精确筛选，结果按创建时间倒序展示。
     * </p>
     *
     * @param keyword 检索关键词，可为空
     * @param category 图书分类，可为空
     * @return 符合条件的图书列表
     */
    @Override
    public List<LibraryBook> searchBooks(String keyword, String category) {
        // 创建图书查询包装器
        LambdaQueryWrapper<LibraryBook> wrapper = new LambdaQueryWrapper<>();
        // 只查询状态正常的图书
        wrapper.eq(LibraryBook::getStatus, 1);
        // 如果关键词不为空，则按书名、作者、ISBN 进行模糊查询
        if (keyword != null && !keyword.isEmpty()) {
            // 使用 and 条件组合多个 like 查询
            wrapper.and(w -> w.like(LibraryBook::getTitle, keyword)
                    // 或匹配作者
                    .or().like(LibraryBook::getAuthor, keyword)
                    // 或匹配 ISBN
                    .or().like(LibraryBook::getIsbn, keyword));
        }
        // 如果分类参数不为空，则按分类精确查询
        if (category != null && !category.isEmpty()) {
            wrapper.eq(LibraryBook::getCategory, category);
        }
        // 按创建时间降序排列，新上架的图书排在前面
        wrapper.orderByDesc(LibraryBook::getCreateTime);
        // 执行图书列表查询
        return list(wrapper);
    }

    /**
     * 查询图书详情。
     *
     * @param bookId 图书编号
     * @return 图书详情对象
     * @throws BusinessException 当图书不存在时抛出
     */
    @Override
    public LibraryBook getBookDetail(Long bookId) {
        // 根据图书ID查询图书信息
        LibraryBook book = getById(bookId);
        // 判断图书是否存在
        if (book == null) {
            // 图书不存在，抛出未找到异常
            throw BusinessException.notFound("图书不存在");
        }
        // 返回图书详情
        return book;
    }

    /**
     * 查询指定用户的图书借阅记录。
     * <p>
     * 返回该用户的所有借阅记录，并为每条记录填充对应的图书详情。
     * </p>
     *
     * @param userId 用户编号
     * @return 借阅记录列表
     */
    @Override
    public List<BorrowRecord> getBorrowRecords(Long userId) {
        // 查询该用户的所有借阅记录，按创建时间倒序排列
        List<BorrowRecord> records = borrowRecordMapper.selectList(new LambdaQueryWrapper<BorrowRecord>()
                // 精确匹配用户ID
                .eq(BorrowRecord::getUserId, userId)
                // 按创建时间降序，最新借阅排在前面
                .orderByDesc(BorrowRecord::getCreateTime));
        // 遍历借阅记录，为每条记录关联查询图书详情
        for (BorrowRecord record : records) {
            // 根据图书ID查询图书信息，并设置到借阅记录中
            record.setBook(getById(record.getBookId()));
        }
        // 返回填充好图书信息的借阅记录列表
        return records;
    }

    /**
     * 借阅图书。
     * <p>
     * 校验用户状态、图书可借数量、重复借阅、借阅上限、逾期未还、月度归还限制以及
     * 长期逾期限制等规则，校验通过后扣减图书可借数量并生成借阅记录，
     * 同时将该用户对应的图书预约状态置为已通知。
     * </p>
     *
     * @param userId 借阅人用户编号
     * @param bookId 要借阅的图书编号
     * @return 创建成功的借阅记录
     */
    @Override
    @Transactional
    public BorrowRecord borrowBook(Long userId, Long bookId) {
        // 根据用户ID查询用户信息，确认用户处于登录状态
        User user = userMapper.selectById(userId);
        // 判断用户是否存在
        if (user == null) {
            // 用户不存在，记录错误日志并提示重新登录
            log.error("借书失败，用户不存在: userId={}", userId);
            throw new BusinessException("登录状态异常，请重新登录");
        }
        // 根据图书ID查询图书信息
        LibraryBook book = getById(bookId);
        // 判断图书是否存在
        if (book == null) {
            // 图书不存在，抛出未找到异常
            throw BusinessException.notFound("图书不存在");
        }
        // 判断图书剩余可借数量是否充足
        if (book.getAvailableCount() <= 0) {
            // 图书已无可借库存，提示可以预约
            throw new BusinessException("图书已被借完，可预约");
        }

        // 查询该用户是否已经借阅过同一本书且尚未归还
        Long sameBookCount = borrowRecordMapper.selectCount(new LambdaQueryWrapper<BorrowRecord>()
                // 精确匹配用户ID
                .eq(BorrowRecord::getUserId, userId)
                // 精确匹配图书ID
                .eq(BorrowRecord::getBookId, bookId)
                // 状态为借阅中
                .eq(BorrowRecord::getStatus, 1));
        // 如果已存在未归还的同一本书借阅记录
        if (sameBookCount > 0) {
            // 不允许重复借阅同一本书
            throw new BusinessException("您已借阅这本书，不可重复借阅");
        }

        // 查询该用户当前借阅中的图书总数量
        Long borrowingCount = borrowRecordMapper.selectCount(new LambdaQueryWrapper<BorrowRecord>()
                // 精确匹配用户ID
                .eq(BorrowRecord::getUserId, userId)
                // 状态为借阅中
                .eq(BorrowRecord::getStatus, 1));
        // 如果借阅中数量已经达到上限
        if (borrowingCount >= 3) {
            // 提示用户已达借阅上限 3 本
            throw new BusinessException("借阅数量已达上限(3本)");
        }

        // 查询该用户是否有逾期未还的图书
        Long overdueCount = borrowRecordMapper.selectCount(new LambdaQueryWrapper<BorrowRecord>()
                // 精确匹配用户ID
                .eq(BorrowRecord::getUserId, userId)
                // 状态为借阅中
                .eq(BorrowRecord::getStatus, 1)
                // 应还时间早于当前时间，表示已逾期
                .lt(BorrowRecord::getDueTime, LocalDateTime.now()));
        // 如果存在逾期未还图书
        if (overdueCount > 0) {
            // 提示先归还逾期图书
            throw new BusinessException("您有逾期未还的图书，请先归还");
        }

        // 计算一个月前的时间点
        LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);
        // 查询该用户近一个月内已归还的图书数量
        Long returnCountInMonth = borrowRecordMapper.selectCount(new LambdaQueryWrapper<BorrowRecord>()
                // 精确匹配用户ID
                .eq(BorrowRecord::getUserId, userId)
                // 状态为已归还
                .eq(BorrowRecord::getStatus, 2)
                // 归还时间在一月内
                .ge(BorrowRecord::getReturnTime, oneMonthAgo));
        // 如果本月已经归还过图书
        if (returnCountInMonth >= 1) {
            // 限制本月再次借书，提示下月再借
            throw new BusinessException("本月已归还过图书，请下个月再借");
        }

        // 查询该用户是否有逾期超过一个学期的图书
        Long semesterOverdueCount = borrowRecordMapper.selectCount(new LambdaQueryWrapper<BorrowRecord>()
                // 精确匹配用户ID
                .eq(BorrowRecord::getUserId, userId)
                // 状态为借阅中
                .eq(BorrowRecord::getStatus, 1)
                // 应还时间早于四个月前，表示逾期超过一个学期
                .lt(BorrowRecord::getDueTime, LocalDateTime.now().minusMonths(4)));
        // 如果存在 3 本以上逾期超过一个学期的图书
        if (semesterOverdueCount >= 3) {
            // 提示先处理长期逾期图书
            throw new BusinessException("您有3本以上图书逾期超过一个学期，请先处理逾期图书");
        }

        // 扣减图书可借数量
        book.setAvailableCount(book.getAvailableCount() - 1);
        // 更新图书表中的可借数量
        updateById(book);

        // 创建新的借阅记录实体
        BorrowRecord record = new BorrowRecord();
        // 设置借阅人用户ID
        record.setUserId(userId);
        // 设置借阅的图书ID
        record.setBookId(bookId);
        // 设置借阅时间为当前时间
        record.setBorrowTime(LocalDateTime.now());
        // 设置应还时间为 30 天后
        record.setDueTime(LocalDateTime.now().plusDays(30));
        // 设置借阅状态为借阅中
        record.setStatus(1);
        // 设置续借次数为 0
        record.setRenewCount(0);
        // 设置未删除标记
        record.setIsDelete(0);
        // 将借阅记录插入 borrow_record 表
        borrowRecordMapper.insert(record);
        // 将图书详情设置到借阅记录中，方便返回展示
        record.setBook(book);

        // 更新该用户对该图书的预约状态为已通知，避免用户再次预约
        bookReservationMapper.update(null, new com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper<BookReservation>()
                // 精确匹配用户ID
                .eq(BookReservation::getUserId, userId)
                // 精确匹配图书ID
                .eq(BookReservation::getBookId, bookId)
                // 状态为预约中
                .eq(BookReservation::getStatus, 1)
                // 将状态更新为已通知
                .set(BookReservation::getStatus, 2));

        // 记录借阅成功日志
        log.info("图书借阅成功: recordId={}, userId={}, bookId={}", record.getId(), userId, bookId);
        // 返回创建成功的借阅记录
        return record;
    }

    /**
     * 归还图书。
     * <p>
     * 校验借阅记录存在、当前用户有权限且状态为借阅中，
     * 校验通过后将借阅记录状态更新为已归还，并增加图书可借数量。
     * </p>
     *
     * @param userId   当前操作用户编号
     * @param recordId 借阅记录编号
     */
    @Override
    @Transactional
    public void returnBook(Long userId, Long recordId) {
        // 根据借阅记录ID查询借阅记录
        BorrowRecord record = borrowRecordMapper.selectById(recordId);
        // 判断借阅记录是否存在
        if (record == null) {
            // 借阅记录不存在，抛出未找到异常
            throw BusinessException.notFound("借阅记录不存在");
        }
        // 判断当前用户是否为该借阅记录的借阅人
        if (!record.getUserId().equals(userId)) {
            // 不是本人借阅，无权限归还
            throw BusinessException.forbidden("无权限操作");
        }
        // 判断借阅状态是否为借阅中，只有借阅中才能归还
        if (record.getStatus() != 1) {
            // 当前状态不允许归还
            throw new BusinessException("当前状态不可归还");
        }
        // 将借阅状态更新为已归还
        record.setStatus(2);
        // 设置实际归还时间为当前时间
        record.setReturnTime(LocalDateTime.now());
        // 更新 borrow_record 表中的借阅记录
        borrowRecordMapper.updateById(record);

        // 根据图书ID查询图书信息
        LibraryBook book = getById(record.getBookId());
        // 如果图书存在
        if (book != null) {
            // 增加图书可借数量
            book.setAvailableCount(book.getAvailableCount() + 1);
            // 更新图书表
            updateById(book);
        }
        // 记录归还成功日志
        log.info("图书归还成功: recordId={}, userId={}, bookId={}", recordId, userId, record.getBookId());
    }

    /**
     * 续借图书。
     * <p>
     * 校验借阅记录存在、当前用户有权限、状态为借阅中且未超过最大续借次数，
     * 校验通过后将续借次数加 1 并将应还时间延后 30 天。
     * </p>
     *
     * @param userId   当前操作用户编号
     * @param recordId 借阅记录编号
     */
    @Override
    @Transactional
    public void renewBook(Long userId, Long recordId) {
        // 根据借阅记录ID查询借阅记录
        BorrowRecord record = borrowRecordMapper.selectById(recordId);
        // 判断借阅记录是否存在
        if (record == null) {
            // 借阅记录不存在，抛出未找到异常
            throw BusinessException.notFound("借阅记录不存在");
        }
        // 判断当前用户是否为借阅人
        if (!record.getUserId().equals(userId)) {
            // 不是本人，无权限续借
            throw BusinessException.forbidden("无权限操作");
        }
        // 判断借阅状态是否为借阅中
        if (record.getStatus() != 1) {
            // 非借阅中状态不支持续借
            throw new BusinessException("当前状态不支持续借");
        }
        // 判断续借次数是否已达到上限
        if (record.getRenewCount() >= 1) {
            // 每本书最多续借一次
            throw new BusinessException("已达到最大续借次数");
        }
        // 续借次数加 1
        record.setRenewCount(record.getRenewCount() + 1);
        // 应还时间延后 30 天
        record.setDueTime(record.getDueTime().plusDays(30));
        // 更新借阅记录
        borrowRecordMapper.updateById(record);
        // 记录续借成功日志
        log.info("图书续借成功: recordId={}, userId={}", recordId, userId);
    }

    /**
     * 查询指定用户的图书预约记录。
     * <p>
     * 返回该用户的所有图书预约记录，并为每条记录填充对应图书详情。
     * </p>
     *
     * @param userId 用户编号
     * @return 图书预约记录列表
     */
    @Override
    public List<BookReservation> getBookReservations(Long userId) {
        // 查询该用户的所有图书预约记录，按创建时间倒序
        List<BookReservation> reservations = bookReservationMapper.selectList(new LambdaQueryWrapper<BookReservation>()
                // 精确匹配用户ID
                .eq(BookReservation::getUserId, userId)
                // 按创建时间降序排列
                .orderByDesc(BookReservation::getCreateTime));
        // 遍历预约记录，填充图书详情
        for (BookReservation reservation : reservations) {
            // 根据图书ID查询图书信息并设置到预约记录中
            reservation.setBook(getById(reservation.getBookId()));
        }
        // 返回填充好图书信息的预约列表
        return reservations;
    }

    /**
     * 预约图书。
     * <p>
     * 校验图书是否存在、用户是否已预约过该书、图书是否已借完，
     * 校验通过后生成处于预约中状态的图书记录，预约有效期为 7 天。
     * </p>
     *
     * @param userId 预约人用户编号
     * @param bookId 要预约的图书编号
     * @return 创建成功的图书预约记录
     */
    @Override
    @Transactional
    public BookReservation reserveBook(Long userId, Long bookId) {
        // 根据图书ID查询图书信息
        LibraryBook book = getById(bookId);
        // 判断图书是否存在
        if (book == null) {
            // 图书不存在，抛出未找到异常
            throw BusinessException.notFound("图书不存在");
        }
        // 查询该用户对该图书是否已存在有效的预约记录
        Long existCount = bookReservationMapper.selectCount(new LambdaQueryWrapper<BookReservation>()
                // 精确匹配用户ID
                .eq(BookReservation::getUserId, userId)
                // 精确匹配图书ID
                .eq(BookReservation::getBookId, bookId)
                // 状态为预约中
                .eq(BookReservation::getStatus, 1));
        // 如果已经预约过
        if (existCount > 0) {
            // 提示不可重复预约
            throw new BusinessException("您已预约过此书");
        }
        // 判断图书是否仍有可借数量
        if (book.getAvailableCount() > 0) {
            // 图书可借时无需预约，提示直接借阅
            throw new BusinessException("图书可借，无需预约");
        }
        // 创建新的图书预约实体
        BookReservation reservation = new BookReservation();
        // 设置预约人用户ID
        reservation.setUserId(userId);
        // 设置预约的图书ID
        reservation.setBookId(bookId);
        // 设置预约时间为当前时间
        reservation.setReserveTime(LocalDateTime.now());
        // 设置预约过期时间为 7 天后
        reservation.setExpireTime(LocalDateTime.now().plusDays(7));
        // 设置预约状态为预约中
        reservation.setStatus(1);
        // 设置未删除标记
        reservation.setIsDelete(0);
        // 将预约记录插入 book_reservation 表
        bookReservationMapper.insert(reservation);
        // 将图书详情设置到预约记录中
        reservation.setBook(book);
        // 记录图书预约成功日志
        log.info("图书预约成功: reservationId={}, userId={}, bookId={}", reservation.getId(), userId, bookId);
        // 返回创建成功的预约记录
        return reservation;
    }

    /**
     * 取消图书预约。
     * <p>
     * 校验预约记录存在、当前用户有权限且状态为预约中，
     * 校验通过后将预约状态更新为已取消。
     * </p>
     *
     * @param userId        当前操作用户编号
     * @param reservationId 要取消的预约记录编号
     */
    @Override
    @Transactional
    public void cancelBookReservation(Long userId, Long reservationId) {
        // 根据预约ID查询图书预约记录
        BookReservation reservation = bookReservationMapper.selectById(reservationId);
        // 判断预约记录是否存在
        if (reservation == null) {
            // 预约记录不存在，抛出未找到异常
            throw BusinessException.notFound("预约记录不存在");
        }
        // 判断当前用户是否为预约提交人
        if (!reservation.getUserId().equals(userId)) {
            // 不是本人，无权限操作
            throw BusinessException.forbidden("无权限操作");
        }
        // 判断预约状态是否为预约中
        if (reservation.getStatus() != 1) {
            // 非预约中状态不可取消
            throw new BusinessException("当前状态不可取消");
        }
        // 将预约状态更新为已取消
        reservation.setStatus(3);
        // 更新 book_reservation 表中的预约记录
        bookReservationMapper.updateById(reservation);
        // 记录取消预约日志
        log.info("取消图书预约: reservationId={}, userId={}", reservationId, userId);
    }

    /**
     * 查询图书馆座位列表。
     * <p>
     * 支持按楼层、是否有插座、是否有窗户等条件筛选状态正常的座位。
     * </p>
     *
     * @param floor      楼层编号，可为空
     * @param hasSocket  是否有插座，"1" 表示筛选有插座座位，可为空
     * @param hasWindow  是否靠窗，"1" 表示筛选靠窗座位，可为空
     * @return 符合条件的座位列表
     */
    @Override
    public List<LibrarySeat> getSeatList(Integer floor, String hasSocket, String hasWindow) {
        // 创建座位查询包装器
        LambdaQueryWrapper<LibrarySeat> wrapper = new LambdaQueryWrapper<>();
        // 只查询状态正常的座位
        wrapper.eq(LibrarySeat::getStatus, 1);
        // 如果传入楼层参数，按楼层精确查询
        if (floor != null) {
            wrapper.eq(LibrarySeat::getFloor, floor);
        }
        // 如果要求有插座，筛选 has_socket 为 1 的座位
        if ("1".equals(hasSocket)) {
            wrapper.eq(LibrarySeat::getHasSocket, 1);
        }
        // 如果要求靠窗，筛选 has_window 为 1 的座位
        if ("1".equals(hasWindow)) {
            wrapper.eq(LibrarySeat::getHasWindow, 1);
        }
        // 先按楼层升序排列，再按座位号升序排列
        wrapper.orderByAsc(LibrarySeat::getFloor).orderByAsc(LibrarySeat::getSeatNo);
        // 执行座位列表查询
        return librarySeatMapper.selectList(wrapper);
    }

    /**
     * 预约图书馆座位。
     * <p>
     * 校验座位是否存在、目标时间段是否已被他人预约、用户是否已有有效座位预约，
     * 校验通过后生成处于预约中状态的座位预约记录。
     * </p>
     *
     * @param userId       预约人用户编号
     * @param seatId       目标座位编号
     * @param reserveDate  预约日期，字符串格式
     * @param startTime    开始时间，字符串格式
     * @param endTime      结束时间，字符串格式
     * @return 创建成功的座位预约记录
     */
    @Override
    @Transactional
    public SeatReservation reserveSeat(Long userId, Long seatId, String reserveDate, String startTime, String endTime) {
        // 根据座位ID查询座位信息
        LibrarySeat seat = librarySeatMapper.selectById(seatId);
        // 判断座位是否存在
        if (seat == null) {
            // 座位不存在，抛出未找到异常
            throw BusinessException.notFound("座位不存在");
        }
        // 将预约日期字符串解析为 LocalDate
        LocalDate date = LocalDate.parse(reserveDate);
        // 将开始时间字符串解析为 LocalTime
        LocalTime start = LocalTime.parse(startTime);
        // 将结束时间字符串解析为 LocalTime
        LocalTime end = LocalTime.parse(endTime);

        // 查询目标座位、目标日期、有效状态下与当前预约时间段冲突的预约记录数
        Long conflictCount = seatReservationMapper.selectCount(new LambdaQueryWrapper<SeatReservation>()
                // 同一座位
                .eq(SeatReservation::getSeatId, seatId)
                // 同一日期
                .eq(SeatReservation::getReserveDate, date)
                // 有效预约状态
                .in(SeatReservation::getStatus, 1, 2)
                // 新预约开始时间早于已有预约结束时间，可能存在重叠
                .lt(SeatReservation::getStartTime, end)
                // 新预约结束时间晚于已有预约开始时间，可能存在重叠
                .gt(SeatReservation::getEndTime, start));
        // 如果存在冲突
        if (conflictCount > 0) {
            // 说明该时段已被预约
            throw new BusinessException("该时段已被预约");
        }

        // 查询该用户当前有效座位预约数量
        Long userActiveCount = seatReservationMapper.selectCount(new LambdaQueryWrapper<SeatReservation>()
                // 精确匹配用户ID
                .eq(SeatReservation::getUserId, userId)
                // 有效预约状态
                .in(SeatReservation::getStatus, 1, 2));
        // 如果用户已有有效预约
        if (userActiveCount > 0) {
            // 提示先取消或结束后再预约
            throw new BusinessException("您已有有效座位预约，请先取消或结束后再预约");
        }

        // 创建新的座位预约实体
        SeatReservation reservation = new SeatReservation();
        // 设置预约人用户ID
        reservation.setUserId(userId);
        // 设置预约的座位ID
        reservation.setSeatId(seatId);
        // 设置预约日期
        reservation.setReserveDate(date);
        // 设置开始时间
        reservation.setStartTime(start);
        // 设置结束时间
        reservation.setEndTime(end);
        // 设置预约状态为预约中
        reservation.setStatus(1);
        // 设置未删除标记
        reservation.setIsDelete(0);
        // 将座位预约记录插入 seat_reservation 表
        seatReservationMapper.insert(reservation);
        // 记录座位预约成功日志
        log.info("座位预约成功: reservationId={}, userId={}, seatId={}", reservation.getId(), userId, seatId);
        // 返回创建成功的座位预约记录
        return reservation;
    }

    /**
     * 查询当前用户的座位预约记录。
     * <p>
     * 返回该用户的所有座位预约记录，并为每条记录填充对应座位详情。
     * </p>
     *
     * @param userId 用户编号
     * @return 座位预约记录列表
     */
    @Override
    public List<SeatReservation> getMyReservations(Long userId) {
        // 查询该用户的所有座位预约记录，按创建时间倒序
        List<SeatReservation> reservations = seatReservationMapper.selectList(new LambdaQueryWrapper<SeatReservation>()
                // 精确匹配用户ID
                .eq(SeatReservation::getUserId, userId)
                // 按创建时间降序排列
                .orderByDesc(SeatReservation::getCreateTime));
        // 遍历预约记录，填充座位详情
        for (SeatReservation reservation : reservations) {
            // 根据座位ID查询座位信息并设置到预约记录中
            reservation.setSeat(librarySeatMapper.selectById(reservation.getSeatId()));
        }
        // 返回填充好座位信息的预约列表
        return reservations;
    }

    /**
     * 取消座位预约。
     * <p>
     * 校验预约记录存在、当前用户有权限且状态为预约中，
     * 校验通过后将预约状态更新为已取消。
     * </p>
     *
     * @param userId        当前操作用户编号
     * @param reservationId 要取消的座位预约记录编号
     */
    @Override
    @Transactional
    public void cancelReservation(Long userId, Long reservationId) {
        // 根据预约ID查询座位预约记录
        SeatReservation reservation = seatReservationMapper.selectById(reservationId);
        // 判断预约记录是否存在
        if (reservation == null) {
            // 预约记录不存在，抛出未找到异常
            throw BusinessException.notFound("预约记录不存在");
        }
        // 判断当前用户是否为预约提交人
        if (!reservation.getUserId().equals(userId)) {
            // 不是本人，无权限操作
            throw BusinessException.forbidden("无权限操作");
        }
        // 判断预约状态是否为预约中
        if (reservation.getStatus() != 1) {
            // 非预约中状态不可取消
            throw new BusinessException("当前状态不可取消");
        }
        // 将预约状态更新为已取消
        reservation.setStatus(4);
        // 更新 seat_reservation 表中的预约记录
        seatReservationMapper.updateById(reservation);
        // 记录取消座位预约日志
        log.info("取消座位预约: reservationId={}, userId={}", reservationId, userId);
    }

    /**
     * 座位签到。
     * <p>
     * 校验预约记录存在、当前用户有权限且状态为预约中，
     * 校验通过后将状态更新为使用中并记录签到时间。
     * </p>
     *
     * @param userId        当前操作用户编号
     * @param reservationId 座位预约记录编号
     */
    @Override
    @Transactional
    public void checkinSeat(Long userId, Long reservationId) {
        // 根据预约ID查询座位预约记录
        SeatReservation reservation = seatReservationMapper.selectById(reservationId);
        // 判断预约记录是否存在
        if (reservation == null) {
            // 预约记录不存在，抛出未找到异常
            throw BusinessException.notFound("预约记录不存在");
        }
        // 判断当前用户是否为预约提交人
        if (!reservation.getUserId().equals(userId)) {
            // 不是本人，无权限签到
            throw BusinessException.forbidden("无权限操作");
        }
        // 判断预约状态是否为预约中
        if (reservation.getStatus() != 1) {
            // 非预约中状态不可签到
            throw new BusinessException("当前状态不可签到");
        }
        // 将预约状态更新为使用中
        reservation.setStatus(2);
        // 设置签到时间为当前时间
        reservation.setCheckinTime(LocalDateTime.now());
        // 更新 seat_reservation 表中的预约记录
        seatReservationMapper.updateById(reservation);
        // 记录座位签到成功日志
        log.info("座位签到成功: reservationId={}, userId={}", reservationId, userId);
    }

    /**
     * 座位签退。
     * <p>
     * 校验预约记录存在、当前用户有权限且状态为使用中，
     * 校验通过后将状态更新为已结束并记录签退时间。
     * </p>
     *
     * @param userId        当前操作用户编号
     * @param reservationId 座位预约记录编号
     */
    @Override
    @Transactional
    public void checkoutSeat(Long userId, Long reservationId) {
        // 根据预约ID查询座位预约记录
        SeatReservation reservation = seatReservationMapper.selectById(reservationId);
        // 判断预约记录是否存在
        if (reservation == null) {
            // 预约记录不存在，抛出未找到异常
            throw BusinessException.notFound("预约记录不存在");
        }
        // 判断当前用户是否为预约提交人
        if (!reservation.getUserId().equals(userId)) {
            // 不是本人，无权限签退
            throw BusinessException.forbidden("无权限操作");
        }
        // 判断预约状态是否为使用中
        if (reservation.getStatus() != 2) {
            // 非使用中状态不可签退
            throw new BusinessException("当前状态不可签退");
        }
        // 将预约状态更新为已结束
        reservation.setStatus(3);
        // 设置签退时间为当前时间
        reservation.setCheckoutTime(LocalDateTime.now());
        // 更新 seat_reservation 表中的预约记录
        seatReservationMapper.updateById(reservation);
        // 记录座位签退成功日志
        log.info("座位签退成功: reservationId={}, userId={}", reservationId, userId);
    }

    /**
     * 学习打卡。
     * <p>
     * 校验用户今天是否已打卡，若未打卡则在 study_checkin 表中新增一条打卡记录，
     * 初始学习时长为 0。
     * </p>
     *
     * @param userId   打卡用户编号
     * @param location 打卡地点
     * @param note     打卡备注
     * @return 创建成功的学习打卡记录
     */
    @Override
    @Transactional
    public StudyCheckin studyCheckin(Long userId, String location, String note) {
        // 获取今天的日期
        LocalDate today = LocalDate.now();
        // 查询该用户今天是否已存在打卡记录
        StudyCheckin exist = studyCheckinMapper.selectOne(new LambdaQueryWrapper<StudyCheckin>()
                // 精确匹配用户ID
                .eq(StudyCheckin::getUserId, userId)
                // 精确匹配今天日期
                .eq(StudyCheckin::getCheckinDate, today));
        // 如果今天已经打卡
        if (exist != null) {
            // 提示今日已打卡，不可重复打卡
            throw new BusinessException("今日已打卡");
        }
        // 创建新的学习打卡实体
        StudyCheckin checkin = new StudyCheckin();
        // 设置打卡用户ID
        checkin.setUserId(userId);
        // 设置打卡日期为今天
        checkin.setCheckinDate(today);
        // 设置打卡时间为当前时间
        checkin.setCheckinTime(LocalDateTime.now());
        // 设置打卡地点
        checkin.setLocation(location);
        // 设置打卡备注
        checkin.setNote(note);
        // 设置初始学习时长为 0 分钟
        checkin.setStudyDuration(0);
        // 设置未删除标记
        checkin.setIsDelete(0);
        // 将打卡记录插入 study_checkin 表
        studyCheckinMapper.insert(checkin);
        // 记录学习打卡成功日志
        log.info("自习打卡成功: checkinId={}, userId={}", checkin.getId(), userId);
        // 返回创建成功的打卡记录
        return checkin;
    }

    /**
     * 查询指定用户的学习打卡记录列表。
     *
     * @param userId 用户编号
     * @return 学习打卡记录列表，按打卡日期降序排列
     */
    @Override
    public List<StudyCheckin> getStudyCheckinList(Long userId) {
        // 查询该用户的学习打卡记录，按打卡日期倒序排列
        return studyCheckinMapper.selectList(new LambdaQueryWrapper<StudyCheckin>()
                // 精确匹配用户ID
                .eq(StudyCheckin::getUserId, userId)
                // 按打卡日期降序，最新的打卡在前
                .orderByDesc(StudyCheckin::getCheckinDate));
    }

    /**
     * 统计学习打卡数据。
     * <p>
     * 汇总该用户的总打卡天数、累计学习小时数以及连续打卡天数。
     * </p>
     *
     * @param userId 用户编号
     * @return 包含学习统计指标的结果Map
     */
    @Override
    public Map<String, Object> getStudyStatistics(Long userId) {
        // 查询该用户的所有学习打卡记录，按打卡日期倒序排列
        List<StudyCheckin> list = studyCheckinMapper.selectList(new LambdaQueryWrapper<StudyCheckin>()
                // 精确匹配用户ID
                .eq(StudyCheckin::getUserId, userId)
                // 按打卡日期降序排列
                .orderByDesc(StudyCheckin::getCheckinDate));
        // 创建结果容器
        Map<String, Object> result = new HashMap<>();
        // 放入总打卡天数
        result.put("totalDays", list.size());
        // 累计所有打卡记录的学习分钟数
        int totalMinutes = list.stream().mapToInt(StudyCheckin::getStudyDuration).sum();
        // 将分钟转换为小时并保留一位小数后放入结果
        result.put("totalHours", String.format("%.1f", totalMinutes / 60.0));

        // 初始化连续打卡天数
        int continuousDays = 0;
        // 获取今天的日期
        LocalDate today = LocalDate.now();
        // 遍历打卡记录计算连续打卡天数
        for (int i = 0; i < list.size(); i++) {
            // 获取当前遍历到的打卡日期
            LocalDate date = list.get(i).getCheckinDate();
            // 判断该日期是否等于今天往前推 i 天
            if (date.equals(today.minusDays(i))) {
                // 日期连续，连续天数加 1
                continuousDays++;
            } else {
                // 日期不连续，中断统计
                break;
            }
        }
        // 将连续打卡天数放入结果
        result.put("continuousDays", continuousDays);
        // 返回学习统计结果
        return result;
    }
}
