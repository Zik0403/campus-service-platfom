package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.RepairOrder;

import java.util.List;

/**
 * 校园报修服务接口。
 * 负责学生宿舍或教室设施故障报修的全流程管理：学生提交报修工单，管理员派单，
 * 维修员接单并上门维修，完成后学生评价，系统还会对超时未派单的工单进行预警。
 */
public interface RepairOrderService extends IService<RepairOrder> {

    /**
     * 学生提交一条新的报修工单。
     * @param userId 报修学生用户ID
     * @param faultType 故障类型（例如：水电、门窗、网络、家具等）
     * @param address 故障发生地址（例如：宿舍楼栋与房间号）
     * @param description 故障详细描述
     * @param images 故障现场图片地址，多张图片通常以逗号分隔
     * @param priority 优先级（例如：1普通 2紧急）
     * @return 创建后的报修工单
     */
    RepairOrder createOrder(Long userId, String faultType, String address, String description, String images, Integer priority);

    /**
     * 学生在待派单状态下修改自己的报修工单。
     * @param orderId 报修工单ID
     * @param userId 当前操作用户ID
     * @param faultType 故障类型
     * @param address 故障发生地址
     * @param description 故障详细描述
     * @param images 故障现场图片地址
     * @param priority 优先级
     * @return 修改后的报修工单
     */
    RepairOrder updateOrder(Long orderId, Long userId, String faultType, String address, String description, String images, Integer priority);

    /**
     * 管理员将报修工单派单给指定维修员。
     * @param orderId 报修工单ID
     * @param workerId 维修员用户ID
     */
    void assignWorker(Long orderId, Long workerId);

    /**
     * 维修员接单，开始处理报修工单。
     * @param orderId 报修工单ID
     * @param workerId 维修员用户ID
     */
    void workerAccept(Long orderId, Long workerId);

    /**
     * 维修员完成维修后确认工单完成。
     * @param orderId 报修工单ID
     * @param workerId 维修员用户ID
     */
    void completeOrder(Long orderId, Long workerId);

    /**
     * 管理员驳回不符合条件的报修工单。
     * @param orderId 报修工单ID
     * @param reason 驳回原因
     */
    void rejectOrder(Long orderId, String reason);

    /**
     * 用户在维修开始前取消自己的报修工单。
     * @param orderId 报修工单ID
     * @param userId 当前操作用户ID
     */
    void cancelOrder(Long orderId, Long userId);

    /**
     * 学生对已完成的维修服务进行评价。
     * @param orderId 报修工单ID
     * @param userId 评价用户ID
     * @param star 评分星级（例如：1-5星）
     * @param content 评价内容
     */
    void evaluate(Long orderId, Long userId, Integer star, String content);

    /**
     * 查询某位学生提交的所有报修工单。
     * @param userId 学生用户ID
     * @return 该学生的报修工单列表
     */
    List<RepairOrder> getUserOrders(Long userId);

    /**
     * 查询某位维修员当前待处理的报修工单。
     * @param workerId 维修员用户ID
     * @return 待处理工单列表
     */
    List<RepairOrder> getWorkerPendingOrders(Long workerId);

    /**
     * 查询抢单大厅中所有待接单的报修工单。
     * @param excludeUserId 需要排除的用户ID（例如：当前登录的维修员自己）
     * @return 待接单工单列表
     */
    List<RepairOrder> getPendingOrders(Long excludeUserId);

    /**
     * 查询某个报修工单的详细信息。
     * @param orderId 报修工单ID
     * @param userId 当前查看用户ID
     * @return 报修工单详情对象
     */
    RepairOrder getOrderDetail(Long orderId, Long userId);

    /**
     * 查询超过规定时间仍未派单的报修工单，用于预警提醒。
     * @return 超时未派单工单列表
     */
    List<RepairOrder> getTimeoutPendingOrders();
}
