package com.campus.service.aspect;

import com.campus.service.common.cache.IdempotencyKeyConstant;
import com.campus.service.common.exception.BusinessException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

/**
 * 服务订单支付幂等控制切面。
 * <p>
 * 对 {@link com.campus.service.service.ServiceOrderService#payOrder(String, String, String)} 方法进行增强，
 * 在不改动原有支付业务代码的前提下，通过 Redis 幂等 Key 保证同一笔订单的余额支付只真正执行一次。
 * </p>
 * <p>
 * 幂等状态说明：
 * <ul>
 *   <li>PROCESSING：正在处理中，其他相同请求会被拒绝，防止并发重复扣款；</li>
 *   <li>SUCCESS：已支付成功，后续重复请求直接放行（跳过执行），避免重复扣款。</li>
 * </ul>
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class PayIdempotencyAspect {

    /**
     * Redis 缓存模板，用于读写幂等状态。
     */
    private final RedisTemplate<String, Object> redisTemplate;

    /**
     * 支付处理中状态的 Redis Value。
     */
    private static final String STATUS_PROCESSING = "PROCESSING";

    /**
     * 支付成功状态的 Redis Value。
     */
    private static final String STATUS_SUCCESS = "SUCCESS";

    /**
     * 处理中状态保留时间，60 秒足够覆盖一次正常支付流程。
     */
    private static final Duration PROCESSING_TTL = Duration.ofSeconds(60);

    /**
     * 支付成功状态保留时间，保留 24 小时用于拦截重复请求。
     */
    private static final Duration SUCCESS_TTL = Duration.ofHours(24);

    /**
     * 定义切入点：拦截 ServiceOrderService 接口的 payOrder 方法。
     * <p>
     * 使用接口方法签名切入，无论具体实现类是哪个，只要调用支付方法都会进入幂等控制。
     * </p>
     */
    @Pointcut("execution(* com.campus.service.service.ServiceOrderService.payOrder(String, String, String))")
    public void payOrderPointcut() {
        // 切入点声明
    }

    /**
     * 环绕通知：在 payOrder 方法执行前后维护 Redis 幂等状态。
     * <p>
     * 1. 根据订单号生成幂等 Key；
     * 2. 如果 Key 已标记 SUCCESS，说明该订单已支付成功，直接返回，不重复执行；
     * 3. 如果 Key 已标记 PROCESSING，说明有并发请求正在处理，直接抛出“处理中”异常；
     * 4. 如果 Key 不存在，设置 PROCESSING 状态并继续执行原支付方法；
     * 5. 支付成功后更新为 SUCCESS 状态；抛出异常时状态会随 TTL 自动过期，不破坏原有回滚逻辑。
     * </p>
     *
     * @param joinPoint AOP 连接点
     * @return 目标方法的返回值（payOrder 为 void，返回 null）
     * @throws Throwable 目标方法抛出的异常或幂等校验失败抛出的业务异常
     */
    @Around("payOrderPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        // 获取 payOrder 方法的第一个参数：订单号
        String orderId = (String) joinPoint.getArgs()[0];
        // 构造该订单的幂等 Redis Key
        String idempotencyKey = IdempotencyKeyConstant.payOrderKey(orderId);

        // 查询当前幂等状态
        Object status = redisTemplate.opsForValue().get(idempotencyKey);

        // 如果已经是成功状态，说明该订单已经支付过，直接跳过原方法，返回 null（void 方法）
        if (STATUS_SUCCESS.equals(status)) {
            log.info("支付幂等命中：订单 {} 已支付成功，跳过重复执行", orderId);
            return null;
        }

        // 如果正在处理中，说明有并发请求在执行，拒绝本次请求
        if (STATUS_PROCESSING.equals(status)) {
            log.warn("支付幂等拦截：订单 {} 正在处理中，拒绝重复请求", orderId);
            throw new BusinessException("支付处理中，请勿重复提交");
        }

        // 尝试设置处理中状态，使用 setIfAbsent 保证并发下只有一个请求能拿到执行权
        Boolean locked = redisTemplate.opsForValue().setIfAbsent(idempotencyKey, STATUS_PROCESSING, PROCESSING_TTL);
        if (!Boolean.TRUE.equals(locked)) {
            // 设置失败，说明其他线程抢先设置了状态，按处理中处理
            log.warn("支付幂等加锁失败：订单 {} 可能已有并发请求", orderId);
            throw new BusinessException("支付处理中，请勿重复提交");
        }

        try {
            // 执行原支付业务方法
            Object result = joinPoint.proceed();
            // 支付成功，将幂等状态更新为 SUCCESS，并设置较长过期时间
            redisTemplate.opsForValue().set(idempotencyKey, STATUS_SUCCESS, SUCCESS_TTL);
            log.info("支付幂等成功：订单 {} 已标记为 SUCCESS", orderId);
            return result;
        } catch (Throwable e) {
            // 支付失败时记录幂等异常日志，不手动删除 PROCESSING，让其随 TTL 自动过期
            log.error("支付幂等执行异常：订单 {}，原因：{}", orderId, e.getMessage(), e);
            throw e;
        }
    }
}
