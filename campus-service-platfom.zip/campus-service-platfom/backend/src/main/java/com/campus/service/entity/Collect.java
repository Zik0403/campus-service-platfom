package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 用户收藏表。
 * 记录学生对帖子、商品等内容的收藏关系，便于用户后续快速查找感兴趣的内容。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("collect") // 指定对应的数据库表名为 collect
public class Collect implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 收藏记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 收藏用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 收藏目标类型：1 帖子、2 商品等。
     */
    private Integer targetType;

    /**
     * 收藏目标 ID，对应目标表（如 community_post、second_product）的主键。
     */
    private Long targetId;

    /**
     * 收藏时间，用户点击收藏按钮的时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;
}
