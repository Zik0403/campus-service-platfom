package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.CommunityPost;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 社区帖子数据访问接口。
 *
 * <p>操作的数据库表为社区帖子表，对应实体类为 {@link CommunityPost}。
 * 主要负责校园社区中帖子的查询，例如查询某用户发布的帖子、按类型浏览已通过审核的帖子、
 * 搜索帖子以及查看待审核的帖子。</p>
 */
@Mapper
public interface CommunityPostMapper extends BaseMapper<CommunityPost> {

    /**
     * 根据用户 ID 查询该用户发布的所有帖子。
     *
     * @param userId 用户 ID
     * @return 该用户发布的帖子列表
     */
    List<CommunityPost> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据帖子类型查询已经审核通过的帖子。
     *
     * @param postType 帖子类型，例如失物招领、二手交易、拼车、表白墙等
     * @return 指定类型且已审核通过的帖子列表
     */
    List<CommunityPost> selectAuditedByType(@Param("postType") Integer postType);

    /**
     * 查询所有待审核的帖子。
     *
     * @return 待管理员审核的帖子列表
     */
    List<CommunityPost> selectPendingAudit();

    /**
     * 根据关键字搜索帖子。
     *
     * @param keyword 搜索关键字
     * @return 符合搜索条件的帖子列表
     */
    List<CommunityPost> searchPosts(@Param("keyword") String keyword);
}
