package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.CampusNotice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 校园公告数据访问接口。
 *
 * <p>操作的数据库表为校园公告表，对应实体类为 {@link CampusNotice}。
 * 主要负责学校发布的各类公告信息的查询，例如查询已经上架的公告、按公告类型查询公告。</p>
 */
@Mapper
public interface CampusNoticeMapper extends BaseMapper<CampusNotice> {

    /**
     * 查询所有已经上架的校园公告。
     *
     * @return 上架公告列表
     */
    List<CampusNotice> selectOnlineNotices();

    /**
     * 根据公告类型查询已经上架的公告。
     *
     * @param noticeType 公告类型，例如教务通知、活动通知等
     * @return 指定类型的上架公告列表
     */
    List<CampusNotice> selectOnlineByType(@Param("noticeType") Integer noticeType);
}
