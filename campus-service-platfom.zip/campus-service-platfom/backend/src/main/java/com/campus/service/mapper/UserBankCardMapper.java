package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.UserBankCard;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户银行卡数据访问接口。
 *
 * <p>操作的数据库表为用户银行卡表，对应实体类为 {@link UserBankCard}。
 * 主要负责用户绑定银行卡信息的增删改查，例如用户添加、删除或查看自己的银行卡。</p>
 */
@Mapper
public interface UserBankCardMapper extends BaseMapper<UserBankCard> {
}
