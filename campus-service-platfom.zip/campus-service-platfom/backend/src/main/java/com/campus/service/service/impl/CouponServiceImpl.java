package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.Coupon;
import com.campus.service.entity.UserCoupon;
import com.campus.service.mapper.CouponMapper;
import com.campus.service.mapper.UserCouponMapper;
import com.campus.service.service.CouponService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 优惠券服务实现类。
 * <p>
 * 负责校园生活服务系统中优惠券相关核心业务，包括：
 * 查询当前可领取的优惠券、用户领取优惠券、查询用户已领取的优惠券等。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CouponServiceImpl extends ServiceImpl<CouponMapper, Coupon> implements CouponService {

    // 用户优惠券关联表数据访问对象，用于记录用户领取优惠券的信息
    private final UserCouponMapper userCouponMapper;

    /**
     * 查询当前可领取的优惠券列表。
     * <p>
     * 可领取的条件为：优惠券已上架、有效期未结束。
     * </p>
     *
     * @return 可领取优惠券列表，按有效期结束时间升序排列
     */
    @Override
    public List<Coupon> getAvailableCoupons() {
        // 查询优惠券表：状态为上架、有效期结束时间晚于当前时间，并按有效期结束时间升序排列
        return list(new LambdaQueryWrapper<Coupon>()
                .eq(Coupon::getStatus, 1)
                .gt(Coupon::getValidEnd, LocalDateTime.now())
                .orderByAsc(Coupon::getValidEnd));
    }

    /**
     * 用户领取优惠券。
     * <p>
     * 领取时会校验优惠券是否存在、是否已下架、是否已领完、是否已过期，
     * 领取成功后会在用户优惠券表中新增记录，并更新优惠券已领取数量。
     * </p>
     *
     * @param userId   用户 ID
     * @param couponId 优惠券 ID
     */
    @Override
    @Transactional
    public void receiveCoupon(Long userId, Long couponId) {
        // 根据优惠券 ID 查询优惠券信息
        Coupon coupon = getById(couponId);
        // 如果优惠券不存在，抛出异常
        if (coupon == null) {
            throw BusinessException.notFound();
        }
        // 如果优惠券状态不是上架状态，说明已下架
        if (coupon.getStatus() != 1) {
            throw new BusinessException("优惠券已下架");
        }
        // 如果已领取数量大于等于总数量，说明优惠券已领完
        if (coupon.getUsedCount() >= coupon.getTotalCount()) {
            throw new BusinessException("优惠券已领完");
        }
        // 如果优惠券有效期结束时间早于当前时间，说明已过期
        if (coupon.getValidEnd().isBefore(LocalDateTime.now())) {
            throw new BusinessException("优惠券已过期");
        }
        // 创建用户领取优惠券的关联记录对象
        UserCoupon userCoupon = new UserCoupon();
        // 设置领取优惠券的用户 ID
        userCoupon.setUserId(userId);
        // 设置领取的优惠券 ID
        userCoupon.setCouponId(couponId);
        // 设置领取时间为当前时间
        userCoupon.setReceiveTime(LocalDateTime.now());
        // 设置用户优惠券状态为已领取未使用
        userCoupon.setStatus(1);
        // 将用户领取优惠券的记录插入用户优惠券表
        userCouponMapper.insert(userCoupon);
        // 将优惠券已领取数量加 1
        coupon.setUsedCount(coupon.getUsedCount() + 1);
        // 更新优惠券表的已领取数量
        updateById(coupon);
        // 记录领取优惠券日志
        log.info("用户领取优惠券: userId={}, couponId={}", userId, couponId);
    }

    /**
     * 查询用户已领取的优惠券列表。
     * <p>
     * 当前方法尚未实现具体查询逻辑，返回 null。
     * </p>
     *
     * @param userId 用户 ID
     * @return 用户已领取的优惠券列表，当前固定返回 null
     */
    @Override
    public List<Coupon> getUserCoupons(Long userId) {
        // 该方法目前未实现具体查询逻辑，直接返回 null
        return null;
    }
}
