package com.campus.service.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.io.Serializable;

/**
 * 校园生活服务项目统一响应结果包装类（VO）。
 * 所有 Controller 接口返回给小程序的数据都会封装成该对象，包含业务状态码、提示信息和具体业务数据，
 * 便于小程序统一判断请求是否成功并解析返回内容。
 *
 * @param <T> 业务数据的具体类型
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL) // JSON 序列化时忽略值为 null 的字段，减少无效数据传输
public class R<T> implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 业务状态码：200 表示成功，400 或其他非 200 表示失败。
     * 小程序通过该字段判断接口调用是否成功。
     */
    private int code;

    /**
     * 提示信息：成功时通常为“操作成功”，失败时返回具体错误原因，供小程序弹窗或日志使用。
     */
    private String message;

    /**
     * 业务数据：接口真正返回给小程序的内容，类型由具体接口决定；失败或无数据时可能为 null。
     */
    private T data;

    /**
     * 无参构造方法，用于反序列化或需要手动 set 属性的场景。
     */
    public R() {
    }

    /**
     * 全参构造方法，用于手动构造统一响应对象。
     *
     * @param code    业务状态码
     * @param message 提示信息
     * @param data    业务数据
     */
    public R(int code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    /**
     * 构造一个不带业务数据的成功响应。
     *
     * @param <T> 业务数据类型
     * @return code=200、message=操作成功、data=null 的统一响应对象
     */
    public static <T> R<T> success() {
        // 返回默认成功响应，不携带具体数据
        return new R<>(200, "操作成功", null);
    }

    /**
     * 构造一个带业务数据的成功响应。
     *
     * @param data 需要返回给小程序的业务数据
     * @param <T>  业务数据类型
     * @return code=200、message=操作成功、data=传入数据的统一响应对象
     */
    public static <T> R<T> success(T data) {
        // 返回成功响应，并携带具体业务数据
        return new R<>(200, "操作成功", data);
    }

    /**
     * 构造一个带自定义提示信息和业务数据的成功响应。
     *
     * @param message 自定义成功提示
     * @param data    需要返回给小程序的业务数据
     * @param <T>     业务数据类型
     * @return code=200、message=自定义提示、data=传入数据的统一响应对象
     */
    public static <T> R<T> success(String message, T data) {
        // 返回成功响应，使用自定义提示信息并携带具体业务数据
        return new R<>(200, message, data);
    }

    /**
     * 构造一个不带提示信息和业务数据的失败响应。
     *
     * @param <T> 业务数据类型
     * @return code=400、message=操作失败、data=null 的统一响应对象
     */
    public static <T> R<T> fail() {
        // 返回默认失败响应
        return new R<>(400, "操作失败", null);
    }

    /**
     * 构造一个带自定义错误提示的失败响应。
     *
     * @param message 失败原因说明
     * @param <T>     业务数据类型
     * @return code=400、message=自定义失败原因、data=null 的统一响应对象
     */
    public static <T> R<T> fail(String message) {
        // 返回失败响应，使用自定义失败提示
        return new R<>(400, message, null);
    }

    /**
     * 构造一个带自定义状态码和错误提示的失败响应。
     *
     * @param code    自定义业务状态码
     * @param message 失败原因说明
     * @param <T>     业务数据类型
     * @return code=传入状态码、message=自定义失败原因、data=null 的统一响应对象
     */
    public static <T> R<T> fail(int code, String message) {
        // 返回失败响应，支持自定义状态码和提示信息
        return new R<>(code, message, null);
    }

    /**
     * 构造一个带错误提示的异常响应（与 fail(String) 语义相同，便于业务代码区分调用）。
     *
     * @param message 错误原因说明
     * @param <T>     业务数据类型
     * @return code=400、message=错误原因、data=null 的统一响应对象
     */
    public static <T> R<T> error(String message) {
        // 返回错误响应，常用于异常处理或参数校验失败场景
        return new R<>(400, message, null);
    }

    /**
     * 判断当前响应是否为成功状态。
     *
     * @return true 表示 code 等于 200；false 表示失败或其他状态
     */
    public boolean isSuccess() {
        // 通过状态码是否为 200 判断请求是否成功
        return code == 200;
    }
}
