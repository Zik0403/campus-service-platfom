package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 二手商品表。
 * 存储学生发布的二手商品信息，包括卖家、标题、分类、价格、描述、图片、议价规则与状态，
 * 支撑小程序端二手市场商品展示、搜索、下单与审核管理。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("second_product") // 指定对应的数据库表名为 second_product
public class SecondProduct implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 商品主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 发布卖家用户 ID，关联 user 表。
     */
    private Long sellerId;

    /**
     * 商品标题，展示在商品列表与详情页。
     */
    private String title;

    /**
     * 商品分类，如“书籍”“电子数码”“生活用品”。
     */
    private String category;

    /**
     * 商品标价。
     */
    private BigDecimal price;

    /**
     * 商品描述，补充成色、使用情况、交易方式等信息。
     */
    private String description;

    /**
     * 商品图片数组，通常以 JSON 或逗号分隔的 OSS 地址存储。
     */
    private String images;

    /**
     * 是否允许议价：0 不议价、1 可议价。
     */
    private Integer allowBargain;

    /**
     * 商品有效期（天），超过有效期自动下架。
     */
    private Integer validDay;

    /**
     * 商品状态：1 待审核、2 上架、3 售出、4 下架、5 违规封禁。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录商品首次发布时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录商品信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联卖家用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User seller;
}
