package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.SecondProduct;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 二手商品数据访问接口。
 *
 * <p>操作的数据库表为二手商品表，对应实体类为 {@link SecondProduct}。
 * 主要负责校园二手 marketplace 中商品信息的查询，例如查询某卖家发布的商品、
 * 按分类浏览上架商品、搜索商品、查看待审核商品以及查询过期商品。</p>
 */
@Mapper
public interface SecondProductMapper extends BaseMapper<SecondProduct> {

    /**
     * 根据卖家 ID 查询该卖家发布的所有二手商品。
     *
     * @param sellerId 卖家用户 ID
     * @return 该卖家的商品列表
     */
    List<SecondProduct> selectBySellerId(@Param("sellerId") Long sellerId);

    /**
     * 根据商品分类查询已经上架的二手商品。
     *
     * @param category 商品分类，例如书籍、电子产品、生活用品等
     * @return 指定分类的上架商品列表
     */
    List<SecondProduct> selectOnlineByCategory(@Param("category") String category);

    /**
     * 根据关键字搜索二手商品。
     *
     * @param keyword 搜索关键字，例如商品名称中的关键字
     * @return 符合搜索条件的商品列表
     */
    List<SecondProduct> searchProducts(@Param("keyword") String keyword);

    /**
     * 查询所有待审核的二手商品。
     *
     * @return 待管理员审核的商品列表
     */
    List<SecondProduct> selectPendingAudit();

    /**
     * 查询所有已经过期的二手商品。
     *
     * @return 过期商品列表
     */
    List<SecondProduct> selectExpired();
}
