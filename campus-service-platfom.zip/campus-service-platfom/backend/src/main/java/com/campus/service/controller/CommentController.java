package com.campus.service.controller;

import com.campus.service.entity.Comment;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.CommentService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/comment")
@RequiredArgsConstructor
public class CommentController {

    private final CommentService commentService;

    private String getStr(Map<String, Object> body, String key, String defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        return v != null ? v.toString() : defaultValue;
    }

    private Long getLong(Map<String, Object> body, String key, Long defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Long.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    private Integer getInt(Map<String, Object> body, String key, Integer defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Integer.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    /**
     * 添加评论
     */
    @PostMapping("/add")
    public R<Comment> addComment(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) Integer targetType,
                                  @RequestParam(required = false) Long targetId,
                                  @RequestParam(required = false) Long parentId,
                                  @RequestParam(required = false) String content) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Integer tt = targetType != null ? targetType : getInt(body, "targetType", null);
        Long tid = targetId != null ? targetId : getLong(body, "targetId", null);
        Long pid = parentId != null ? parentId : getLong(body, "parentId", null);
        String c = content != null ? content : getStr(body, "content", null);
        return R.success(commentService.addComment(userId, tt, tid, pid, c));
    }

    /**
     * 获取目标评论列表
     */
    @GetMapping("/list")
    public R<List<Comment>> getComments(@RequestParam Integer targetType, @RequestParam Long targetId) {
        return R.success(commentService.getComments(targetType, targetId));
    }

    /**
     * 删除评论
     */
    @DeleteMapping("/delete")
    public R<Void> deleteComment(HttpServletRequest request, 
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) Long commentId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long cid = commentId != null ? commentId : getLong(body, "commentId", null);
        commentService.deleteComment(cid, userId);
        return R.success();
    }
}
