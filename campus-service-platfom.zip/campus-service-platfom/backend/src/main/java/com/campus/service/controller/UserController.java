package com.campus.service.controller;

import com.campus.service.common.constants.RoleConstants;
import com.campus.service.common.util.CosOssUtil;
import com.campus.service.entity.User;
import com.campus.service.entity.WalletRecord;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.security.JwtUtils;
import com.campus.service.security.TokenBlacklistInterceptor;
import com.campus.service.service.UserService;
import com.campus.service.service.WalletRecordService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final JwtUtils jwtUtils;
    private final WalletRecordService walletRecordService;
    private final com.campus.service.service.UserBankCardService bankCardService;
    private final TokenBlacklistInterceptor tokenBlacklistInterceptor;
    private final CosOssUtil cosOssUtil;

    /**
     * 账号密码登录（学号或手机号）
     */
    @PostMapping("/login")
    public R<Map<String, Object>> login(@RequestBody Map<String, String> params) {
        String account = params.get("account");
        String password = params.get("password");
        User user = userService.loginByPassword(account, password);
        String token = jwtUtils.generateToken(user.getId(), user.getOpenid(), user.getRole());
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userInfo", user);
        return R.success(data);
    }

    /**
     * 用户注册（学生和维修人员通用）
     * role=1 学生，role=2 维修人员
     */
    @PostMapping("/register")
    public R<Map<String, Object>> register(@RequestBody Map<String, String> params) {
        Integer role = parseRole(params.get("role"));
        String realName = params.get("realName");
        String phone = params.get("phone");
        String password = params.get("password");
        User user;
        if (role == RoleConstants.ROLE_WORKER) {
            String idCard = params.get("idCard");
            user = userService.registerWorker(realName, phone, idCard, password);
        } else {
            String studentId = params.get("studentId");
            String dormBuild = params.get("dormBuild");
            String dormRoom = params.get("dormRoom");
            user = userService.registerStudent(studentId, realName, phone, password, dormBuild, dormRoom);
        }
        String token = jwtUtils.generateToken(user.getId(), user.getOpenid(), user.getRole());
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userInfo", user);
        return R.success(data);
    }

    private Integer parseRole(String roleStr) {
        if (roleStr == null || roleStr.isEmpty()) {
            return RoleConstants.ROLE_STUDENT;
        }
        try {
            return Integer.valueOf(roleStr);
        } catch (Exception e) {
            return RoleConstants.ROLE_STUDENT;
        }
    }

    /**
     * 忘记密码重置
     */
    @PostMapping("/reset-password")
    public R<Void> resetPassword(@RequestBody Map<String, String> params) {
        String studentId = params.get("studentId");
        String phone = params.get("phone");
        String newPassword = params.get("newPassword");
        userService.resetPassword(studentId, phone, newPassword);
        return R.success();
    }

    /**
     * 获取当前用户信息
     */
    @GetMapping("/info")
    public R<User> getUserInfo(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        User user = userService.getById(userId);
        return R.success(user);
    }

    /**
     * 更新用户信息
     */
    @PutMapping("/update")
    public R<Void> updateUserInfo(HttpServletRequest request,
                                   @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String nickname = params.get("nickname");
        String avatar = params.get("avatar");
        userService.updateUserInfo(userId, nickname, avatar);
        return R.success();
    }

    /**
     * 实名认证（学生和维修人员通用）
     * 学生传 studentId，维修人员传 idCard
     */
    @PostMapping("/auth")
    public R<User> authUser(HttpServletRequest request,
                             @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String studentId = params.get("studentId");
        String idCard = params.get("idCard");
        String realName = params.get("realName");
        String phone = params.get("phone");
        String avatar = params.get("avatar");
        String payPassword = params.get("payPassword");
        userService.authUser(userId, studentId, idCard, realName, phone);
        // 如果传了头像，也更新
        if (avatar != null && !avatar.isEmpty()) {
            userService.updateUserInfo(userId, null, avatar);
        }
        // 如果传了支付密码，也设置
        if (payPassword != null && !payPassword.isEmpty()) {
            userService.setPayPassword(userId, payPassword);
        }
        User user = userService.getById(userId);
        return R.success(user);
    }

    /**
     * 更新宿舍信息
     */
    @PutMapping("/dorm")
    public R<User> updateDormInfo(HttpServletRequest request,
                                   @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String dormBuild = params.get("dormBuild");
        String dormRoom = params.get("dormRoom");
        userService.updateDormInfo(userId, dormBuild, dormRoom);
        User user = userService.getById(userId);
        return R.success(user);
    }

    /**
     * 修改手机号
     */
    @PutMapping("/phone")
    public R<User> updatePhone(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String phone = params.get("phone");
        userService.updatePhone(userId, phone);
        User user = userService.getById(userId);
        return R.success(user);
    }

    /**
     * 获取配送员列表
     */
    @GetMapping("/workers")
    public R<List<User>> getWorkers() {
        return R.success(userService.getWorkers());
    }

    /**
     * 获取信用积分排行榜
     */
    @GetMapping("/credit/top")
    public R<List<User>> getCreditTop(@RequestParam(defaultValue = "10") int limit) {
        return R.success(userService.getCreditTop(limit));
    }

    /**
     * 钱包充值（从银行卡充值）
     */
    @PostMapping("/wallet/recharge")
    public R<User> recharge(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        java.math.BigDecimal amount = new java.math.BigDecimal(params.get("amount"));
        String cardIdStr = params.get("cardId");
        String cardPassword = params.get("cardPassword");
        if (amount.compareTo(java.math.BigDecimal.ZERO) <= 0) {
            return R.error("充值金额必须大于0");
        }
        if (cardIdStr == null || cardIdStr.isEmpty()) {
            return R.error("请选择充值银行卡");
        }
        Long cardId = Long.valueOf(cardIdStr);
        com.campus.service.entity.UserBankCard card = bankCardService.getById(cardId);
        if (card == null || !card.getUserId().equals(userId)) {
            return R.error("银行卡不存在");
        }
        if (!bankCardService.verifyCardPassword(cardId, cardPassword)) {
            return R.error("银行卡密码错误");
        }
        userService.updateBalance(userId, amount, 1);
        return R.success(userService.getById(userId));
    }

    /**
     * 钱包提现（提现到银行卡）
     */
    @PostMapping("/wallet/withdraw")
    public R<User> withdraw(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        java.math.BigDecimal amount = new java.math.BigDecimal(params.get("amount"));
        String payPassword = params.get("payPassword");
        String cardIdStr = params.get("cardId");
        if (amount.compareTo(java.math.BigDecimal.ZERO) <= 0) {
            return R.error("提现金额必须大于0");
        }
        if (cardIdStr == null || cardIdStr.isEmpty()) {
            return R.error("请选择提现银行卡");
        }
        Long cardId = Long.valueOf(cardIdStr);
        com.campus.service.entity.UserBankCard card = bankCardService.getById(cardId);
        if (card == null || !card.getUserId().equals(userId)) {
            return R.error("银行卡不存在");
        }
        User user = userService.getById(userId);
        if (user == null) {
            return R.error("用户不存在");
        }
        if (user.getPayPassword() == null || user.getPayPassword().isEmpty()) {
            return R.error("请先设置支付密码");
        }
        if (!userService.verifyPayPassword(userId, payPassword)) {
            return R.error("支付密码错误");
        }
        if (user.getBalance().compareTo(amount) < 0) {
            return R.error("余额不足");
        }
        userService.updateBalance(userId, amount.negate(), 3);
        return R.success(userService.getById(userId));
    }

    /**
     * 获取资金流水
     */
    @GetMapping("/wallet/records")
    public R<List<WalletRecord>> getWalletRecords(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(walletRecordService.getUserRecords(userId));
    }

    /**
     * 设置支付密码
     */
    @PostMapping("/pay-password/set")
    public R<Void> setPayPassword(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String payPassword = params.get("payPassword");
        userService.setPayPassword(userId, payPassword);
        return R.success();
    }

    /**
     * 修改支付密码
     */
    @PostMapping("/pay-password/update")
    public R<Void> updatePayPassword(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oldPassword = params.get("oldPassword");
        String newPassword = params.get("newPassword");
        userService.updatePayPassword(userId, oldPassword, newPassword);
        return R.success();
    }

    /**
     * 验证支付密码
     */
    @PostMapping("/pay-password/verify")
    public R<Boolean> verifyPayPassword(HttpServletRequest request, @RequestBody Map<String, String> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String payPassword = params.get("payPassword");
        boolean valid = userService.verifyPayPassword(userId, payPassword);
        return R.success(valid);
    }

    /**
     * 检查是否已设置支付密码
     */
    @GetMapping("/pay-password/status")
    public R<Boolean> getPayPasswordStatus(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        User user = userService.getById(userId);
        boolean hasPayPassword = user != null && user.getPayPassword() != null && !user.getPayPassword().isEmpty();
        return R.success(hasPayPassword);
    }

    /**
     * 重置支付密码（验证个人信息后）
     */
    @PostMapping("/pay-password/reset")
    public R<Void> resetPayPassword(@RequestBody Map<String, String> params) {
        String studentId = params.get("studentId");
        String realName = params.get("realName");
        String phone = params.get("phone");
        String newPassword = params.get("newPassword");
        userService.resetPayPassword(studentId, realName, phone, newPassword);
        return R.success();
    }

    /**
     * 头像上传
     */
    @PostMapping("/avatar/upload")
    public R<String> uploadAvatar(HttpServletRequest request,
                                   @RequestParam("file") MultipartFile file) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        if (file.isEmpty()) {
            return R.error("请选择文件");
        }
        try {
            String originalFilename = file.getOriginalFilename();
            String ext = originalFilename != null && originalFilename.contains(".") 
                ? originalFilename.substring(originalFilename.lastIndexOf(".")) 
                : ".jpg";
            String fileName = "avatar_" + userId + "_" + System.currentTimeMillis() + ext;
            String uploadDir = System.getProperty("user.dir") + "/uploads/avatar/";
            File dir = new File(uploadDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            Path filePath = Paths.get(uploadDir + fileName);
            Files.write(filePath, file.getBytes());
            String avatarUrl = "/api/uploads/avatar/" + fileName;
            User user = userService.getById(userId);
            if (user != null) {
                user.setAvatar(avatarUrl);
                userService.updateById(user);
            }
            return R.success(avatarUrl);
        } catch (IOException e) {
            return R.error("上传失败：" + e.getMessage());
        }
    }

    /**
     * 头像上传到 OSS（腾讯云 COS）。
     * <p>
     * 与原有的 {@link #uploadAvatar(HttpServletRequest, MultipartFile)} 本地存储方式并存，
     * 本接口把头像文件上传到 COS 对象存储，并返回云端访问 URL。
     * </p>
     *
     * @param request 当前 HTTP 请求对象，用于获取当前登录用户 ID
     * @param file    头像图片文件
     * @return 上传成功后的 COS 访问 URL
     */
    @PostMapping("/avatar/upload/oss")
    public R<String> uploadAvatarOss(HttpServletRequest request,
                                      @RequestParam("file") MultipartFile file) {
        // 从请求属性中获取当前登录用户 ID
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        // 校验用户是否已登录
        if (userId == null) {
            return R.error("用户未登录");
        }
        // 校验文件是否为空
        if (file.isEmpty()) {
            return R.error("请选择文件");
        }
        try {
            // 上传头像到 COS，返回完整访问 URL
            String avatarUrl = cosOssUtil.uploadAvatar(userId, file);
            // 更新用户表中的头像字段
            User user = userService.getById(userId);
            if (user != null) {
                user.setAvatar(avatarUrl);
                userService.updateById(user);
            }
            return R.success(avatarUrl);
        } catch (Exception e) {
            return R.error("OSS 上传失败：" + e.getMessage());
        }
    }

    /**
     * 用户登出。
     * <p>
     * 从请求头中提取当前登录用户的 Token，将其加入 Redis 黑名单，
     * 使其在 Token 自然过期之前无法再次访问受保护接口。
     * </p>
     *
     * @param request 当前 HTTP 请求对象
     * @return 登出结果
     */
    @PostMapping("/logout")
    public R<Void> logout(HttpServletRequest request) {
        // 从请求头 Authorization 中提取 Bearer Token
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            // 去掉 "Bearer " 前缀，获取纯 Token 字符串
            String token = authHeader.substring(7);
            // 将 Token 加入 Redis 黑名单
            tokenBlacklistInterceptor.addToBlacklist(token);
        }
        return R.success();
    }
}
