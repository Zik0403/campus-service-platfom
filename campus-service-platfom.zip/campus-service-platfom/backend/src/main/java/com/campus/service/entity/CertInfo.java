package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 证书/考证信息表。
 * 存储校园学生常见考证（如计算机等级、普通话、教师资格证等）的简介、报名条件、考试时间、费用等信息，
 * 供小程序端“考证资讯”模块查询与展示。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("cert_info") // 指定对应的数据库表名为 cert_info
public class CertInfo implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 考证信息主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 证书/考证名称，如“全国计算机等级考试二级”。
     */
    private String certName;

    /**
     * 证书类型，用于分类展示，如“计算机类”“语言类”“职业资格类”。
     */
    private String certType;

    /**
     * 发证机构或组织单位。
     */
    private String organization;

    /**
     * 考证简介，介绍证书含金量、适用人群、考试内容等。
     */
    private String description;

    /**
     * 考试时间，可存字符串描述（如“每年 3 月、9 月”）或具体日期。
     */
    private String examTime;

    /**
     * 报名时间，可存字符串描述。
     */
    private String signupTime;

    /**
     * 考试费用，字符串形式存储便于展示（如“120 元”）。
     */
    private String examFee;

    /**
     * 报考条件，说明学历、年级、专业等限制。
     */
    private String applyCondition;

    /**
     * 证书配图或宣传图地址。
     */
    private String image;

    /**
     * 状态：0 禁用、1 启用，控制是否在前端展示。
     */
    private Integer status;

    /**
     * 排序值，值越小通常越靠前，用于控制列表展示顺序。
     */
    private Integer sort;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录考证信息首次录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录考证信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
