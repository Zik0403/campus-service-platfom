package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.Activity;

import java.util.List;

/**
 * 校园活动服务接口。
 * 负责社团活动的创建、管理以及审核：社团负责人可发布活动，管理员可审核活动，
 * 学生可以浏览可报名的活动列表。
 */
public interface ActivityService extends IService<Activity> {

    /**
     * 社团负责人创建新活动。
     * @param clubId 所属社团ID
     * @param name 活动名称
     * @param poster 活动海报图片地址
     * @param location 活动地点
     * @param startTime 活动开始时间
     * @param endTime 活动结束时间
     * @param enrollDeadline 报名截止时间
     * @param description 活动详细介绍
     * @param maxPeople 最大可报名人数
     * @return 创建后的活动对象
     */
    Activity createActivity(Long clubId, String name, String poster, String location,
                            String startTime, String endTime, String enrollDeadline,
                            String description, Integer maxPeople);

    /**
     * 管理员审核活动是否允许上线。
     * @param activityId 活动ID
     * @param auditStatus 审核状态（例如：0待审核 1通过 2拒绝）
     */
    void auditActivity(Long activityId, Integer auditStatus);

    /**
     * 查询某个社团已发布的活动列表。
     * @param clubId 社团ID
     * @return 该社团的活动列表
     */
    List<Activity> getClubActivities(Long clubId);

    /**
     * 查询当前学生可以报名的活动列表。
     * @return 可报名活动列表
     */
    List<Activity> getAvailableActivities();

    /**
     * 查询所有待管理员审核的活动列表。
     * @return 待审核活动列表
     */
    List<Activity> getPendingAuditActivities();

    /**
     * 带缓存查询：获取当前学生可以报名的活动列表。
     * @return 可报名活动列表
     */
    List<Activity> getAvailableActivitiesWithCache();

    /**
     * 带缓存查询：获取指定社团已通过审核且启用的活动列表。
     * @param clubId 社团ID
     * @return 该社团下的活动列表
     */
    List<Activity> getClubActivitiesWithCache(Long clubId);

    /**
     * 带缓存查询：获取待管理员审核的活动列表。
     * @return 待审核活动列表
     */
    List<Activity> getPendingAuditActivitiesWithCache();

    /**
     * 清除活动相关的所有缓存。
     */
    void evictActivityCache();

    /**
     * 预加载活动相关热点缓存。
     */
    void warmActivityCache();
}
