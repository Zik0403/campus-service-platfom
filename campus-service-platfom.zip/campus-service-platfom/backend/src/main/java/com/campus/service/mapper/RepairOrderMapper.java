package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.RepairOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 维修工单数据访问接口。
 *
 * <p>操作的数据库表为维修工单表，对应实体类为 {@link RepairOrder}。
 * 主要负责校园报修工单的查询，例如查询某用户提交的工单、维修员待处理的工单、
 * 以及超时未派单的预警工单。</p>
 */
@Mapper
public interface RepairOrderMapper extends BaseMapper<RepairOrder> {

    /**
     * 根据用户 ID 查询该用户提交的所有报修工单。
     *
     * @param userId 用户 ID
     * @return 该用户的报修工单列表
     */
    List<RepairOrder> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据维修员 ID 查询分配给该维修员的待处理工单。
     *
     * @param workerId 维修员用户 ID
     * @return 该维修员的待处理工单列表
     */
    List<RepairOrder> selectPendingByWorkerId(@Param("workerId") Long workerId);

    /**
     * 查询超时未派单的报修工单，用于预警提醒。
     *
     * @return 超时未派单的工单列表
     */
    List<RepairOrder> selectTimeoutPending();
}
