package com.campus.service.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.service.entity.*;
import com.campus.service.service.*;
import com.campus.service.vo.R;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理后台控制器
 * 集中提供统计、审核、用户管理等管理功能
 */
@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserService userService;
    private final RepairOrderService repairOrderService;
    private final SecondProductService productService;
    private final SecondOrderService orderService;
    private final CommunityPostService postService;
    private final ActivityService activityService;
    private final ClubService clubService;
    private final LostFoundService lostFoundService;
    private final ServiceOrderService serviceOrderService;

    /**
     * 系统统计数据汇总
     */
    @GetMapping("/stats")
    public R<Map<String, Object>> getSystemStats() {
        Map<String, Object> stats = new HashMap<>();
        // 用户统计
        stats.put("totalUsers", userService.count());
        // 报修统计
        stats.put("totalRepairs", repairOrderService.count());
        stats.put("pendingRepairs", repairOrderService.count(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, 1)));
        stats.put("completedRepairs", repairOrderService.count(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, 3)));
        // 二手交易统计
        stats.put("totalProducts", productService.count());
        stats.put("pendingProducts", productService.count(new LambdaQueryWrapper<SecondProduct>()
                .eq(SecondProduct::getStatus, 1)));
        stats.put("totalOrders", orderService.count());
        // 社区统计
        stats.put("totalPosts", postService.count());
        stats.put("pendingPosts", postService.count(new LambdaQueryWrapper<CommunityPost>()
                .eq(CommunityPost::getAuditStatus, 1)));
        // 活动统计
        stats.put("totalActivities", activityService.count());
        stats.put("pendingActivities", activityService.count(new LambdaQueryWrapper<Activity>()
                .eq(Activity::getAuditStatus, 1)));
        // 社团统计
        stats.put("totalClubs", clubService.count());
        stats.put("pendingClubs", clubService.count(new LambdaQueryWrapper<Club>()
                .eq(Club::getAuditStatus, 1)));
        // 失物招领统计
        stats.put("totalLostFound", lostFoundService.count());
        // 跑腿订单统计
        stats.put("totalServiceOrders", serviceOrderService.count());
        return R.success(stats);
    }

    /**
     * 报修工单详细统计
     */
    @GetMapping("/repair/stats")
    public R<Map<String, Object>> getRepairStats() {
        Map<String, Object> stats = new HashMap<>();
        // 按状态统计
        stats.put("pending", repairOrderService.count(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, 1)));
        stats.put("processing", repairOrderService.count(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, 2)));
        stats.put("completed", repairOrderService.count(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, 3)));
        stats.put("rejected", repairOrderService.count(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, 4)));
        stats.put("cancelled", repairOrderService.count(new LambdaQueryWrapper<RepairOrder>()
                .eq(RepairOrder::getStatus, 5)));
        return R.success(stats);
    }

    /**
     * 获取所有待审核内容汇总
     */
    @GetMapping("/pending/all")
    public R<Map<String, List<?>>> getPendingAll() {
        Map<String, List<?>> pending = new HashMap<>();
        // 待审核社团
        pending.put("clubs", clubService.list(new LambdaQueryWrapper<Club>()
                .eq(Club::getAuditStatus, 1)
                .orderByDesc(Club::getCreateTime)));
        // 待审核活动
        pending.put("activities", activityService.list(new LambdaQueryWrapper<Activity>()
                .eq(Activity::getAuditStatus, 1)
                .orderByDesc(Activity::getCreateTime)));
        // 待审核二手商品
        pending.put("products", productService.list(new LambdaQueryWrapper<SecondProduct>()
                .eq(SecondProduct::getStatus, 1)
                .orderByDesc(SecondProduct::getCreateTime)));
        // 待审核社区帖子
        pending.put("posts", postService.list(new LambdaQueryWrapper<CommunityPost>()
                .eq(CommunityPost::getAuditStatus, 1)
                .orderByDesc(CommunityPost::getCreateTime)));
        return R.success(pending);
    }

    /**
     * 批量审核（通过或驳回）
     * @param type 审核类型：club/activity/product/post
     * @param ids 待审核ID列表
     * @param auditStatus 审核结果：2通过 3驳回
     */
    @PostMapping("/audit/batch")
    public R<Void> batchAudit(@RequestParam String type,
                               @RequestBody List<Long> ids,
                               @RequestParam Integer auditStatus) {
        switch (type) {
            case "club":
                for (Long id : ids) {
                    clubService.auditClub(id, auditStatus);
                }
                break;
            case "activity":
                for (Long id : ids) {
                    Activity activity = activityService.getById(id);
                    if (activity != null) {
                        activity.setAuditStatus(auditStatus);
                        activityService.updateById(activity);
                    }
                }
                break;
            case "product":
                for (Long id : ids) {
                    SecondProduct product = productService.getById(id);
                    if (product != null) {
                        product.setStatus(auditStatus == 2 ? 2 : 5); // 2上架 5违规封禁
                        productService.updateById(product);
                    }
                }
                break;
            case "post":
                for (Long id : ids) {
                    CommunityPost post = postService.getById(id);
                    if (post != null) {
                        post.setAuditStatus(auditStatus);
                        postService.updateById(post);
                    }
                }
                break;
            default:
                return R.error("不支持的审核类型");
        }
        return R.success();
    }

    /**
     * 获取用户列表（管理员查看）
     */
    @GetMapping("/user/list")
    public R<List<User>> getUserList(@RequestParam(required = false) Integer role,
                                      @RequestParam(required = false) String keyword) {
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        if (role != null) {
            wrapper.eq(User::getRole, role);
        }
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like(User::getNickname, keyword).or()
                   .like(User::getStudentId, keyword).or()
                   .like(User::getRealName, keyword);
        }
        wrapper.eq(User::getIsDelete, 0)
               .orderByDesc(User::getCreateTime);
        return R.success(userService.list(wrapper));
    }

    /**
     * 修改用户角色
     */
    @PutMapping("/user/role")
    public R<Void> updateUserRole(@RequestParam Long userId, @RequestParam Integer role) {
        User user = userService.getById(userId);
        if (user == null) {
            return R.error("用户不存在");
        }
        user.setRole(role);
        userService.updateById(user);
        return R.success();
    }

    /**
     * 禁用/启用用户
     */
    @PutMapping("/user/status")
    public R<Void> updateUserStatus(@RequestParam Long userId, @RequestParam Integer status) {
        User user = userService.getById(userId);
        if (user == null) {
            return R.error("用户不存在");
        }
        // status: 0禁用 1正常
        user.setIsDelete(status);
        userService.updateById(user);
        return R.success();
    }
}