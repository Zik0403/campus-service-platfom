package com.campus.service.controller;

import com.campus.service.entity.CampusNotice;
import com.campus.service.service.CampusNoticeService;
import com.campus.service.vo.R;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notice")
public class NoticeController {

    private final CampusNoticeService noticeService;

    public NoticeController(CampusNoticeService noticeService) {
        this.noticeService = noticeService;
    }

    /**
     * 获取上架公告列表
     */
    @GetMapping("/list")
    public R<List<CampusNotice>> getOnlineNotices() {
        return R.success(noticeService.getOnlineNotices());
    }

    /**
     * 按类型获取上架公告
     */
    @GetMapping("/listByType")
    public R<List<CampusNotice>> getOnlineNoticesByType(@RequestParam Integer noticeType) {
        return R.success(noticeService.getOnlineNoticesByType(noticeType));
    }

    /**
     * 获取公告详情
     */
    @GetMapping("/detail")
    public R<CampusNotice> getNoticeDetail(@RequestParam Long id) {
        CampusNotice notice = noticeService.getById(id);
        if (notice == null || notice.getStatus() != 1) {
            return R.error("公告不存在或已下架");
        }
        return R.success(notice);
    }

    /**
     * 获取上架公告列表（走 Redis 缓存）。
     * <p>
     * 与 {@link #getOnlineNotices()} 返回数据一致，但优先读取 Redis 缓存，
     * 用于学生首页等高频访问场景，降低数据库压力。
     * </p>
     *
     * @return 已上线公告列表
     */
    @GetMapping("/list/cache")
    public R<List<CampusNotice>> getOnlineNoticesWithCache() {
        return R.success(noticeService.getOnlineNoticesWithCache());
    }

    /**
     * 按类型获取上架公告（走 Redis 缓存）。
     *
     * @param noticeType 公告类型
     * @return 指定类型下已上线公告列表
     */
    @GetMapping("/listByType/cache")
    public R<List<CampusNotice>> getOnlineNoticesByTypeWithCache(@RequestParam Integer noticeType) {
        return R.success(noticeService.getOnlineNoticesByTypeWithCache(noticeType));
    }

    /**
     * 手动清除公告缓存（管理员维护公告后调用）。
     *
     * @return 操作结果
     */
    @PostMapping("/cache/evict")
    public R<Void> evictNoticeCache() {
        noticeService.evictNoticeCache();
        return R.success();
    }
}
