package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.BorrowRecord;
import org.apache.ibatis.annotations.Mapper;

/**
 * 图书借阅记录数据访问接口。
 *
 * <p>操作的数据库表为借阅记录表，对应实体类为 {@link BorrowRecord}。
 * 主要负责图书馆图书借阅、归还等记录的增删改查，例如记录学生借走了哪本书、何时归还。</p>
 */
@Mapper
public interface BorrowRecordMapper extends BaseMapper<BorrowRecord> {
}
