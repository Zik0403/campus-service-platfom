package com.campus.service.controller;

import com.campus.service.entity.ActivityEnroll;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.ActivityEnrollService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 活动报名控制器
 */
@RestController
@RequestMapping("/enroll")
@RequiredArgsConstructor
public class ActivityEnrollController {

    private final ActivityEnrollService enrollService;

    /**
     * 用户报名活动
     */
    @PostMapping("/create")
    public R<ActivityEnroll> enroll(HttpServletRequest request,
                                     @RequestBody(required = false) Map<String, Object> body,
                                     @RequestParam(required = false) Long activityId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long aid = activityId != null ? activityId : (body != null && body.get("activityId") != null ? Long.valueOf(body.get("activityId").toString()) : null);
        ActivityEnroll enroll = enrollService.enroll(userId, aid);
        return R.success(enroll);
    }

    /**
     * 取消报名
     */
    @PostMapping("/cancel")
    public R<Void> cancelEnroll(HttpServletRequest request,
                                 @RequestBody(required = false) Map<String, Object> body,
                                 @RequestParam(required = false) Long enrollId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long eid = enrollId != null ? enrollId : (body != null && body.get("enrollId") != null ? Long.valueOf(body.get("enrollId").toString()) : null);
        enrollService.cancelEnroll(eid, userId);
        return R.success();
    }

    /**
     * 用户签到
     */
    @PostMapping("/checkin")
    public R<Void> checkin(HttpServletRequest request,
                            @RequestBody(required = false) Map<String, Object> body,
                            @RequestParam(required = false) Long enrollId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long eid = enrollId != null ? enrollId : (body != null && body.get("enrollId") != null ? Long.valueOf(body.get("enrollId").toString()) : null);
        enrollService.checkin(eid, userId);
        return R.success();
    }

    /**
     * 用户签退
     */
    @PostMapping("/checkout")
    public R<Void> checkout(HttpServletRequest request,
                             @RequestBody(required = false) Map<String, Object> body,
                             @RequestParam(required = false) Long enrollId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long eid = enrollId != null ? enrollId : (body != null && body.get("enrollId") != null ? Long.valueOf(body.get("enrollId").toString()) : null);
        enrollService.checkout(eid, userId);
        return R.success();
    }

    /**
     * 批量签到（社团负责人/发起人使用）
     */
    @PostMapping("/batch/checkin")
    public R<Void> batchCheckin(HttpServletRequest request, @RequestBody Map<String, Object> body) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long activityId = body.get("activityId") != null ? Long.parseLong(body.get("activityId").toString()) : null;
        List<Long> userIds = (List<Long>) body.get("userIds");
        if (activityId == null) {
            return R.error("缺少活动ID");
        }
        enrollService.batchCheckin(activityId, userIds, userId);
        return R.success();
    }

    /**
     * 批量签退（社团负责人/发起人使用）
     */
    @PostMapping("/batch/checkout")
    public R<Void> batchCheckout(HttpServletRequest request, @RequestBody Map<String, Object> body) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long activityId = body.get("activityId") != null ? Long.parseLong(body.get("activityId").toString()) : null;
        List<Long> userIds = (List<Long>) body.get("userIds");
        if (activityId == null) {
            return R.error("缺少活动ID");
        }
        enrollService.batchCheckout(activityId, userIds, userId);
        return R.success();
    }

    /**
     * 开启/关闭签到（发起人控制）
     */
    @PostMapping("/checkin/toggle")
    public R<Void> toggleCheckin(HttpServletRequest request, @RequestBody Map<String, Object> body) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long activityId = body.get("activityId") != null ? Long.parseLong(body.get("activityId").toString()) : null;
        Boolean enabled = body.get("enabled") != null ? Boolean.parseBoolean(body.get("enabled").toString()) : true;
        if (activityId == null) {
            return R.error("缺少活动ID");
        }
        enrollService.toggleCheckin(activityId, enabled, userId);
        return R.success();
    }

    /**
     * 获取用户报名列表
     */
    @GetMapping("/my/list")
    public R<List<ActivityEnroll>> getUserEnrolls(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(enrollService.getUserEnrolls(userId));
    }

    /**
     * 获取活动报名名单
     */
    @GetMapping("/activity/list")
    public R<List<ActivityEnroll>> getActivityEnrolls(@RequestParam Long activityId) {
        return R.success(enrollService.getActivityEnrolls(activityId));
    }

    /**
     * 获取签到统计
     */
    @GetMapping("/checkin/stats")
    public R<Map<String, Integer>> getCheckinStats(@RequestParam Long activityId) {
        return R.success(enrollService.getCheckinStats(activityId));
    }

    /**
     * 检查用户是否已报名
     */
    @GetMapping("/check")
    public R<ActivityEnroll> checkUserEnrolled(HttpServletRequest request, @RequestParam Long activityId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        ActivityEnroll enroll = enrollService.checkUserEnrolled(userId, activityId);
        return R.success(enroll);
    }
}