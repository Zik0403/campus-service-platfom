package com.campus.service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * ============================================================
 * 【Redis 配置类】
 * 作用：配置 Redis 连接和序列化方式
 * 
 * 本项目使用 Redis 存储：
 * 1. 用户登录 Token 信息
 * 2. 缓存热点数据（如公告列表）
 * 3. 分布式锁（防止重复提交）
 * 
 * 序列化配置：
 * - Key 使用 String 序列化
 * - Value 使用 JSON 序列化
 * ============================================================
 */
@Configuration
public class RedisConfig {

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(factory);
        template.setKeySerializer(new StringRedisSerializer());
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
        template.afterPropertiesSet();
        return template;
    }
}
