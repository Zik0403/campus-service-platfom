package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 失物招领表。
 * 存储学生发布的寻物启事与拾物招领信息，包括物品描述、地点、特征、联系方式与状态，
 * 支撑校园失物招领匹配、认领归还与社区互动。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("lost_found") // 指定对应的数据库表名为 lost_found
public class LostFound implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 失物招领主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 发布用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 信息类型：1 寻物、2 拾物。
     */
    private Integer type;

    /**
     * 物品名称，如“校园卡”“耳机”“身份证”。
     */
    private String goodsName;

    /**
     * 物品分类，如“证件”“电子产品”“生活用品”。
     */
    private String goodsType;

    /**
     * 丢失/拾取地点，如“食堂一楼”“图书馆三楼”。
     */
    private String location;

    /**
     * 物品特征描述，便于他人识别与匹配。
     */
    private String feature;

    /**
     * 联系方式，便于失主与拾取者取得联系。
     */
    private String contact;

    /**
     * 物品图片数组，通常以 JSON 或逗号分隔的 OSS 地址存储。
     */
    private String images;

    /**
     * 状态：1 待匹配、2 已认领归还、3 过期归档。
     */
    private Integer status;

    /**
     * 点赞数，其他学生对信息点赞时递增。
     */
    private Integer likeNum;

    /**
     * 评论数，有用户评论或删除评论时维护。
     */
    private Integer commentNum;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录失物招领信息首次发布时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录失物招领信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联发布者用户对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User user;
}
