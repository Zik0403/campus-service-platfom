package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.*;

import java.util.List;
import java.util.Map;

/**
 * 图书馆服务接口。
 * 负责校园图书馆相关服务：图书检索与详情查看、借书/还书/续借、图书预约、
 * 座位预约与签到签退，以及学习打卡和时长统计，帮助学生更好地利用图书馆资源。
 */
public interface LibraryService extends IService<LibraryBook> {

    /**
     * 根据关键词和分类搜索图书馆藏书。
     * @param keyword 搜索关键词（书名、作者、ISBN等）
     * @param category 图书分类
     * @return 符合条件的图书列表
     */
    List<LibraryBook> searchBooks(String keyword, String category);

    /**
     * 查询某本图书的详细信息。
     * @param bookId 图书ID
     * @return 图书详情对象
     */
    LibraryBook getBookDetail(Long bookId);

    /**
     * 查询某位学生的借书记录。
     * @param userId 学生用户ID
     * @return 借书记录列表
     */
    List<BorrowRecord> getBorrowRecords(Long userId);

    /**
     * 学生借阅指定图书。
     * @param userId 借阅学生用户ID
     * @param bookId 图书ID
     * @return 生成的借书记录
     */
    BorrowRecord borrowBook(Long userId, Long bookId);

    /**
     * 学生归还借阅的图书。
     * @param userId 归还学生用户ID
     * @param recordId 借书记录ID
     */
    void returnBook(Long userId, Long recordId);

    /**
     * 学生续借已借图书以延长归还时间。
     * @param userId 续借学生用户ID
     * @param recordId 借书记录ID
     */
    void renewBook(Long userId, Long recordId);

    /**
     * 查询某位学生的图书预约记录。
     * @param userId 学生用户ID
     * @return 图书预约记录列表
     */
    List<BookReservation> getBookReservations(Long userId);

    /**
     * 学生预约当前已借出的图书。
     * @param userId 预约学生用户ID
     * @param bookId 图书ID
     * @return 生成的图书预约记录
     */
    BookReservation reserveBook(Long userId, Long bookId);

    /**
     * 学生取消图书预约。
     * @param userId 预约学生用户ID
     * @param reservationId 图书预约记录ID
     */
    void cancelBookReservation(Long userId, Long reservationId);

    /**
     * 按楼层、是否有插座、是否有窗等条件查询图书馆座位列表。
     * @param floor 楼层
     * @param hasSocket 是否有插座（例如：1有 0无）
     * @param hasWindow 是否靠窗（例如：1是 0否）
     * @return 座位列表
     */
    List<LibrarySeat> getSeatList(Integer floor, String hasSocket, String hasWindow);

    /**
     * 学生预约图书馆座位。
     * @param userId 预约学生用户ID
     * @param seatId 座位ID
     * @param reserveDate 预约日期
     * @param startTime 预约开始时间
     * @param endTime 预约结束时间
     * @return 生成的座位预约记录
     */
    SeatReservation reserveSeat(Long userId, Long seatId, String reserveDate, String startTime, String endTime);

    /**
     * 查询某位学生的图书馆座位预约记录。
     * @param userId 学生用户ID
     * @return 座位预约记录列表
     */
    List<SeatReservation> getMyReservations(Long userId);

    /**
     * 学生取消图书馆座位预约。
     * @param userId 预约学生用户ID
     * @param reservationId 座位预约记录ID
     */
    void cancelReservation(Long userId, Long reservationId);

    /**
     * 学生对已预约的图书馆座位进行现场签到。
     * @param userId 学生用户ID
     * @param reservationId 座位预约记录ID
     */
    void checkinSeat(Long userId, Long reservationId);

    /**
     * 学生学习结束后对图书馆座位进行签退。
     * @param userId 学生用户ID
     * @param reservationId 座位预约记录ID
     */
    void checkoutSeat(Long userId, Long reservationId);

    /**
     * 学生在图书馆进行学习打卡。
     * @param userId 打卡学生用户ID
     * @param location 打卡位置
     * @param note 打卡备注
     * @return 生成的学习打卡记录
     */
    StudyCheckin studyCheckin(Long userId, String location, String note);

    /**
     * 查询某位学生的学习打卡记录。
     * @param userId 学生用户ID
     * @return 学习打卡记录列表
     */
    List<StudyCheckin> getStudyCheckinList(Long userId);

    /**
     * 统计某位学生的学习情况，例如学习总时长、打卡次数等。
     * @param userId 学生用户ID
     * @return 学习统计数据
     */
    Map<String, Object> getStudyStatistics(Long userId);
}
