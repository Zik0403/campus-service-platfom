package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 资金流水表。
 * 记录用户钱包的每一笔资金变动，包括充值、消费、提现、退款、配送收入、交易收入与平台佣金，
 * 是钱包余额、收支明细与财务对账的核心数据。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("wallet_record") // 指定对应的数据库表名为 wallet_record
public class WalletRecord implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 资金流水主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 所属用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 业务类型：1 充值、2 消费、3 提现、4 退款、5 配送收入、6 交易收入、7 平台佣金。
     */
    private Integer bizType;

    /**
     * 关联订单号，如二手订单号、跑腿订单号，便于追溯。
     */
    private String orderNo;

    /**
     * 变动金额，正值表示增加余额，负值表示扣减余额。
     */
    private BigDecimal amount;

    /**
     * 变动后余额，该笔流水发生后的用户钱包余额快照。
     */
    private BigDecimal balanceAfter;

    /**
     * 变动类型：1 收入、2 支出，用于收支分类统计。
     */
    private Integer changeType;

    /**
     * 备注，说明该笔资金变动的具体原因。
     */
    private String remark;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     * 资金流水通常不允许物理删除，保留完整审计链。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录资金变动发生时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;
}
