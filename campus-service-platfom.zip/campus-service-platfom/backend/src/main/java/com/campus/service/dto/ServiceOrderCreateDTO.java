package com.campus.service.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 服务订单（跑腿/代取/外卖）创建入参 DTO。
 * <p>
 * 封装下单时必填字段，通过 JSR-303 注解校验服务类型、地址、金额等，
 * 替代原有的 {@link java.util.Map} 传参方式，使接口入参更规范、可维护。
 * </p>
 *
 * @author campus-service
 */
@Data
public class ServiceOrderCreateDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 服务类型：1 代取快递、2 代买饭、3 打印资料等，具体含义由业务字典定义。
     */
    @NotNull(message = "服务类型不能为空")
    private Integer serviceType;

    /**
     * 取货地址/起点地址。
     */
    @NotBlank(message = "取货地址不能为空")
    @Size(max = 255, message = "取货地址长度不能超过255位")
    private String originAddr;

    /**
     * 送达地址/目标地址。
     */
    @NotBlank(message = "送达地址不能为空")
    @Size(max = 255, message = "送达地址长度不能超过255位")
    private String targetAddr;

    /**
     * 订单需求描述，例如快递取件码、购买物品清单等。
     */
    @NotBlank(message = "订单内容不能为空")
    @Size(max = 1000, message = "订单内容长度不能超过1000位")
    private String orderContent;

    /**
     * 小费金额，默认 0。
     */
    @NotNull(message = "小费金额不能为空")
    @DecimalMin(value = "0.00", message = "小费金额不能小于0")
    private BigDecimal tipFee;

    /**
     * 订单总金额。
     */
    @NotNull(message = "订单总金额不能为空")
    @DecimalMin(value = "0.01", message = "订单总金额必须大于0")
    private BigDecimal totalFee;
}
