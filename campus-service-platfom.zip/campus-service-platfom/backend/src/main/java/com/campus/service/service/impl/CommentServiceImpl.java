package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.Comment;
import com.campus.service.mapper.CommentMapper;
import com.campus.service.service.CommentService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 评论服务实现类。
 * <p>
 * 负责校园各业务模块（社区帖子、失物招领等）的评论业务处理，
 * 包括发表评论、查询评论列表、删除评论以及为评论关联用户信息等功能。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {

    /** 用户服务，用于校验用户权限、查询评论者信息。 */
    private final UserService userService;

    /**
     * 添加一条评论。
     * <p>
     * 评论可以作用于不同类型的业务对象（如帖子、失物招领等），
     * 也支持一级评论和二级回复（通过 parentId 区分）。
     * </p>
     *
     * @param userId     评论用户ID
     * @param targetType 评论目标类型（如帖子、失物招领等业务标识）
     * @param targetId   评论目标对象ID
     * @param parentId   父评论ID，一级评论时为null或0
     * @param content    评论内容
     * @return 保存成功后的评论对象，包含生成的评论ID
     */
    @Override
    @Transactional
    public Comment addComment(Long userId, Integer targetType, Long targetId, Long parentId, String content) {
        // 校验当前用户是否具备评论权限（如是否被封禁、是否已认证）
        userService.checkUserAuth(userId);
        // 创建一个新的评论实体对象
        Comment comment = new Comment();
        // 设置评论发布者
        comment.setUserId(userId);
        // 设置评论目标类型，标识这条评论属于哪个业务模块
        comment.setTargetType(targetType);
        // 设置评论目标对象ID，标识评论的是哪条具体记录
        comment.setTargetId(targetId);
        // 设置父评论ID，用于区分一级评论与二级回复
        comment.setParentId(parentId);
        // 设置评论正文内容
        comment.setContent(content);
        // 将评论数据插入 comment 表
        save(comment);
        // 记录评论日志，便于后续排查与审计
        log.info("添加评论: commentId={}, userId={}, targetType={}, targetId={}",
                comment.getId(), userId, targetType, targetId);
        // 返回保存后的评论对象
        return comment;
    }

    /**
     * 查询指定目标对象下的所有评论，按创建时间倒序排列，并为每条评论关联发布者信息。
     *
     * @param targetType 评论目标类型
     * @param targetId   评论目标对象ID
     * @return 评论列表，每条评论已填充发布者用户信息
     */
    @Override
    public List<Comment> getComments(Integer targetType, Long targetId) {
        // 构造查询条件：目标类型和目标ID匹配，并按创建时间倒序，从 comment 表查询评论列表
        List<Comment> comments = list(new LambdaQueryWrapper<Comment>()
                .eq(Comment::getTargetType, targetType)
                .eq(Comment::getTargetId, targetId)
                .orderByDesc(Comment::getCreateTime));
        // 遍历每条评论，根据评论者ID查询用户信息并填充到评论对象中
        for (Comment comment : comments) {
            comment.setUser(userService.getById(comment.getUserId()));
        }
        // 返回已填充用户信息的评论列表
        return comments;
    }

    /**
     * 删除指定评论，仅评论发布者本人可删除。
     *
     * @param commentId 评论ID
     * @param userId    当前操作用户ID
     */
    @Override
    @Transactional
    public void deleteComment(Long commentId, Long userId) {
        // 根据评论ID从 comment 表查询评论记录
        Comment comment = getById(commentId);
        // 若评论不存在，抛出“资源不存在”业务异常
        if (comment == null) {
            throw BusinessException.notFound();
        }
        // 校验当前用户是否为评论发布者，非本人不能删除他人评论
        if (!comment.getUserId().equals(userId)) {
            throw BusinessException.orderNotOwner();
        }
        // 从 comment 表中删除该评论记录
        removeById(commentId);
        // 记录删除评论日志
        log.info("删除评论: commentId={}, userId={}", commentId, userId);
    }
}
