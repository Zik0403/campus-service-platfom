package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.CommunityPost;
import com.campus.service.entity.User;
import com.campus.service.mapper.CommunityPostMapper;
import com.campus.service.service.CommunityPostService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 校园社区帖子服务实现类。
 * <p>
 * 负责校园社区模块（表白墙、树洞、二手交易、组队等）的帖子业务处理，
 * 包括发帖、审核、点赞、查看详情、按类型/关键词/审核状态查询帖子等功能。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CommunityPostServiceImpl extends ServiceImpl<CommunityPostMapper, CommunityPost> implements CommunityPostService {

    /** 用户服务，用于校验用户权限、查询发布者信息。 */
    private final UserService userService;

    /**
     * 创建并发布一条社区帖子。
     *
     * @param userId   发帖用户ID
     * @param postType 帖子类型（如表白墙、树洞、二手交易、组队等）
     * @param title    帖子标题
     * @param content  帖子正文内容
     * @param images   帖子配图地址，多个图片以逗号分隔
     * @param isAnon   是否匿名发布，1表示匿名，0或null表示实名
     * @return 保存成功后的帖子对象，包含生成的帖子ID
     */
    @Override
    @Transactional
    public CommunityPost createPost(Long userId, Integer postType, String title, String content,
                                     String images, Integer isAnon) {
        // 校验当前用户是否具备发帖权限（如是否被封禁、是否已认证）
        userService.checkUserAuth(userId);
        // 创建一个新的帖子实体对象
        CommunityPost post = new CommunityPost();
        // 设置帖子的发布者
        post.setUserId(userId);
        // 设置帖子所属类型
        post.setPostType(postType);
        // 设置帖子标题
        post.setTitle(title);
        // 设置帖子正文内容
        post.setContent(content);
        // 设置帖子配图
        post.setImages(images);
        // 设置是否匿名：若前端未传则默认实名（0）
        post.setIsAnon(isAnon != null ? isAnon : 0);
        // 新帖子默认已通过审核，可直接展示
        post.setAuditStatus(OrderStatus.AUDIT_PASSED);
        // 初始化点赞数为0
        post.setLikeNum(0);
        // 初始化评论数为0
        post.setCommentNum(0);
        // 将帖子数据插入 community_post 表
        save(post);
        // 记录发帖日志，便于后续排查与审计
        log.info("发布帖子: postId={}, userId={}, type={}", post.getId(), userId, postType);
        // 返回保存后的帖子对象
        return post;
    }

    /**
     * 审核社区帖子，将帖子审核状态由“待审核”更新为指定状态。
     *
     * @param postId      待审核的帖子ID
     * @param auditStatus 目标审核状态（通过/驳回等）
     */
    @Override
    @Transactional
    public void auditPost(Long postId, Integer auditStatus) {
        // 根据帖子ID从 community_post 表查询帖子记录
        CommunityPost post = getById(postId);
        // 若帖子不存在，抛出“资源不存在”业务异常
        if (post == null) {
            throw BusinessException.notFound();
        }
        // 只有处于“待审核”状态的帖子才允许审核，防止重复审核
        if (post.getAuditStatus() != OrderStatus.AUDIT_PENDING) {
            throw BusinessException.orderStatusError();
        }
        // 将帖子审核状态更新为目标状态
        post.setAuditStatus(auditStatus);
        // 更新 community_post 表中对应记录的审核状态
        updateById(post);
        // 记录审核操作日志
        log.info("审核帖子: postId={}, status={}", postId, auditStatus);
    }

    /**
     * 对指定帖子进行点赞，点赞数加1。
     *
     * @param postId 被点赞的帖子ID
     * @param userId 点赞用户ID
     */
    @Override
    @Transactional
    public void likePost(Long postId, Long userId) {
        // 根据帖子ID从 community_post 表查询帖子记录
        CommunityPost post = getById(postId);
        // 若帖子不存在，抛出“资源不存在”业务异常
        if (post == null) {
            throw BusinessException.notFound();
        }
        // 只有审核通过的帖子才允许点赞，未审核或驳回的帖子不可点赞
        if (post.getAuditStatus() != OrderStatus.AUDIT_PASSED) {
            throw new BusinessException("帖子未通过审核");
        }
        // 将帖子点赞数加1
        post.setLikeNum(post.getLikeNum() + 1);
        // 更新 community_post 表中的点赞数字段
        updateById(post);
        // 记录点赞日志
        log.info("点赞帖子: postId={}, userId={}", postId, userId);
    }

    /**
     * 查看帖子详情。
     * <p>
     * 非审核通过的帖子仅允许管理员（role=4）查看，普通用户只能查看已通过的帖子。
     * </p>
     *
     * @param postId 帖子ID
     * @return 包含发布者信息的帖子详情对象
     */
    @Override
    public CommunityPost getPostDetail(Long postId) {
        // 根据帖子ID从 community_post 表查询帖子记录
        CommunityPost post = getById(postId);
        // 若帖子不存在，抛出“资源不存在”业务异常
        if (post == null) {
            throw BusinessException.notFound();
        }
        // 若帖子未通过审核，需要校验查看者身份
        if (post.getAuditStatus() != OrderStatus.AUDIT_PASSED) {
            // 查询帖子发布者的用户信息
            User currentUser = userService.getById(post.getUserId());
            // 只有管理员角色（role=4）可以查看未审核帖子，否则当作不存在处理
            if (currentUser == null || currentUser.getRole() != 4) {
                throw BusinessException.notFound();
            }
        }
        // 将发布者用户信息封装到帖子对象中，供前端展示头像、昵称等
        post.setUser(userService.getById(post.getUserId()));
        // 返回帖子详情
        return post;
    }

    /**
     * 查询指定用户发布的全部帖子，按创建时间倒序排列。
     *
     * @param userId 用户ID
     * @return 该用户发布的帖子列表
     */
    @Override
    public List<CommunityPost> getUserPosts(Long userId) {
        // 构造查询条件：发布者ID等于指定用户，并按创建时间倒序
        return list(new LambdaQueryWrapper<CommunityPost>()
                .eq(CommunityPost::getUserId, userId)
                .orderByDesc(CommunityPost::getCreateTime));
    }

    /**
     * 按帖子类型查询已审核通过的帖子，按创建时间倒序排列。
     *
     * @param postType 帖子类型
     * @return 该类型下已通过的帖子列表
     */
    @Override
    public List<CommunityPost> getPostsByType(Integer postType) {
        // 构造查询条件：指定帖子类型、审核状态为已通过、按创建时间倒序
        return list(new LambdaQueryWrapper<CommunityPost>()
                .eq(CommunityPost::getPostType, postType)
                .eq(CommunityPost::getAuditStatus, OrderStatus.AUDIT_PASSED)
                .orderByDesc(CommunityPost::getCreateTime));
    }

    /**
     * 查询所有待审核的帖子，按创建时间倒序排列。
     *
     * @return 待审核帖子列表
     */
    @Override
    public List<CommunityPost> getPendingAuditPosts() {
        // 构造查询条件：审核状态为待审核，并按创建时间倒序
        return list(new LambdaQueryWrapper<CommunityPost>()
                .eq(CommunityPost::getAuditStatus, OrderStatus.AUDIT_PENDING)
                .orderByDesc(CommunityPost::getCreateTime));
    }

    /**
     * 根据关键词搜索已审核通过的帖子，支持标题或正文模糊匹配。
     *
     * @param keyword 搜索关键词
     * @return 符合条件的帖子列表
     */
    @Override
    public List<CommunityPost> searchPosts(String keyword) {
        // 构造查询条件：标题或内容包含关键词、审核通过、按创建时间倒序
        return list(new LambdaQueryWrapper<CommunityPost>()
                .and(wrapper -> wrapper.like(CommunityPost::getTitle, keyword)
                        .or().like(CommunityPost::getContent, keyword))
                .eq(CommunityPost::getAuditStatus, OrderStatus.AUDIT_PASSED)
                .orderByDesc(CommunityPost::getCreateTime));
    }

    /**
     * 增加指定帖子的评论数，通常在新增评论后调用。
     *
     * @param postId 帖子ID
     */
    @Override
    @Transactional
    public void incrementCommentNum(Long postId) {
        // 根据帖子ID从 community_post 表查询帖子记录
        CommunityPost post = getById(postId);
        // 若帖子存在，则将其评论数加1
        if (post != null) {
            post.setCommentNum(post.getCommentNum() + 1);
            // 更新 community_post 表中的评论数字段
            updateById(post);
        }
    }
}
