package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Coupon;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 优惠券数据访问接口。
 *
 * <p>操作的数据库表为优惠券表，对应实体类为 {@link Coupon}。
 * 主要负责校园生活服务中优惠券的查询，例如查询当前可以领取的优惠券列表。</p>
 */
@Mapper
public interface CouponMapper extends BaseMapper<Coupon> {

    /**
     * 查询当前可以领取的优惠券列表。
     *
     * @return 可领取优惠券列表
     */
    List<Coupon> selectAvailableCoupons();
}
