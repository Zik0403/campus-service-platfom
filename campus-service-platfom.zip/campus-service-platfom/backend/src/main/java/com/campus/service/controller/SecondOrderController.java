package com.campus.service.controller;

import com.campus.service.entity.SecondOrder;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.SecondOrderService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/second/order")
@RequiredArgsConstructor
public class SecondOrderController {

    private final SecondOrderService orderService;

    private String getStr(Map<String, Object> body, String key, String defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        return v != null ? v.toString() : defaultValue;
    }

    private Long getLong(Map<String, Object> body, String key, Long defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Long.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    /**
     * 创建二手担保订单
     */
    @PostMapping("/create")
    public R<SecondOrder> createOrder(HttpServletRequest request,
                                       @RequestBody(required = false) Map<String, Object> body,
                                       @RequestParam(required = false) Long productId) {
        Long buyerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long pid = productId != null ? productId : getLong(body, "productId", null);
        return R.success(orderService.createOrder(buyerId, pid));
    }

    /**
     * 支付订单
     */
    @PostMapping("/pay")
    public R<Void> payOrder(@RequestBody(required = false) Map<String, Object> body,
                             @RequestParam(required = false) String orderId,
                             @RequestParam(required = false) String wxPayNo,
                             @RequestParam(required = false) String payPassword) {
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        String wxp = wxPayNo != null ? wxPayNo : getStr(body, "wxPayNo", null);
        String pp = payPassword != null ? payPassword : getStr(body, "payPassword", null);
        orderService.payOrder(oid, wxp, pp);
        return R.success();
    }

    /**
     * 确认交付（线下见面后）
     */
    @PostMapping("/confirm/delivery")
    public R<Void> confirmDelivery(HttpServletRequest request,
                                    @RequestBody(required = false) Map<String, Object> body,
                                    @RequestParam(required = false) String orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.confirmDelivery(oid, userId);
        return R.success();
    }

    /**
     * 确认收款（卖家确认收到款）
     */
    @PostMapping("/confirm/receive")
    public R<Void> confirmReceive(HttpServletRequest request,
                                   @RequestBody(required = false) Map<String, Object> body,
                                   @RequestParam(required = false) String orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.confirmReceive(oid, userId);
        return R.success();
    }

    /**
     * 申请退款
     */
    @PostMapping("/refund")
    public R<Void> refundOrder(HttpServletRequest request,
                                @RequestBody(required = false) Map<String, Object> body,
                                @RequestParam(required = false) String orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.refundOrder(oid, userId);
        return R.success();
    }

    /**
     * 投诉订单
     */
    @PostMapping("/complain")
    public R<Void> complainOrder(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) String orderId,
                                  @RequestParam(required = false) String reason) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        String r = reason != null ? reason : getStr(body, "reason", null);
        orderService.complainOrder(oid, userId, r);
        return R.success();
    }

    /**
     * 获取订单详情
     */
    @GetMapping("/detail")
    public R<SecondOrder> getOrderDetail(HttpServletRequest request, @RequestParam String orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getOrderDetail(orderId, userId));
    }

    /**
     * 获取买家的订单
     */
    @GetMapping("/buyer/list")
    public R<List<SecondOrder>> getBuyerOrders(HttpServletRequest request) {
        Long buyerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getBuyerOrders(buyerId));
    }

    /**
     * 获取卖家的订单
     */
    @GetMapping("/seller/list")
    public R<List<SecondOrder>> getSellerOrders(HttpServletRequest request) {
        Long sellerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getSellerOrders(sellerId));
    }

    /**
     * 获取待接单的二手订单（卖家接单大厅）
     */
    @GetMapping("/pending")
    public R<List<SecondOrder>> getPendingOrders(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getPendingOrders(userId));
    }

    /**
     * 卖家接单（确认发货）
     */
    @PostMapping("/accept")
    public R<Void> sellerAccept(HttpServletRequest request,
                                @RequestBody(required = false) Map<String, Object> body,
                                @RequestParam(required = false) String orderId) {
        Long sellerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.sellerAccept(oid, sellerId);
        return R.success();
    }
}
