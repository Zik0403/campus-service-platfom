package com.campus.service.common.cache;

/**
 * Redis 缓存 Key 常量类。
 * <p>
 * 集中管理校园生活服务平台中所有缓存数据的 Key 前缀，避免各业务类中硬编码，
 * 便于后续统一调整缓存命名规范、定位缓存数据。
 * </p>
 * <p>
 * 命名规范：业务模块:具体数据:标识参数，例如 {@code notice:online:list}、
 * {@code activity:available:list}。
 * </p>
 *
 * @author campus-service
 */
public final class CacheKeyConstant {

    /**
     * 私有构造方法，防止外部实例化。
     */
    private CacheKeyConstant() {
    }

    /**
     * 校园公告模块缓存前缀。
     */
    public static final String NOTICE_PREFIX = "notice";

    /**
     * 校园活动模块缓存前缀。
     */
    public static final String ACTIVITY_PREFIX = "activity";

    /**
     * 已上线的全部校园公告列表缓存 Key。
     * <p>
     * 学生首页展示的公告轮播/列表访问频率高，数据变化由管理员后台控制，适合缓存。
     * </p>
     */
    public static final String NOTICE_ONLINE_LIST = NOTICE_PREFIX + ":online:list";

    /**
     * 按类型查询的已上线校园公告列表缓存 Key 前缀。
     * <p>
     * 实际使用时会拼接公告类型，例如 {@code notice:online:type:1}。
     * </p>
     */
    public static final String NOTICE_ONLINE_TYPE_PREFIX = NOTICE_PREFIX + ":online:type:";

    /**
     * 当前学生可报名的活动列表缓存 Key。
     * <p>
     * 活动广场页面访问量大，且可报名活动随时间推移才变化，适合作为热点数据缓存。
     * </p>
     */
    public static final String ACTIVITY_AVAILABLE_LIST = ACTIVITY_PREFIX + ":available:list";

    /**
     * 指定社团已审核通过的活动列表缓存 Key 前缀。
     * <p>
     * 实际使用时会拼接社团 ID，例如 {@code activity:club:1001}。
     * </p>
     */
    public static final String ACTIVITY_CLUB_PREFIX = ACTIVITY_PREFIX + ":club:";

    /**
     * 待管理员审核的活动列表缓存 Key。
     * <p>
     * 管理员后台使用，访问频率相对较低，但数据量不大，可缓存以减轻数据库压力。
     * </p>
     */
    public static final String ACTIVITY_PENDING_AUDIT_LIST = ACTIVITY_PREFIX + ":pending:audit:list";

    /**
     * 构建按类型查询公告的完整缓存 Key。
     *
     * @param noticeType 公告类型，例如 1 通知、2 活动等
     * @return 拼接后的缓存 Key
     */
    public static String noticeOnlineTypeKey(Integer noticeType) {
        return NOTICE_ONLINE_TYPE_PREFIX + noticeType;
    }

    /**
     * 构建指定社团活动列表的完整缓存 Key。
     *
     * @param clubId 社团 ID
     * @return 拼接后的缓存 Key
     */
    public static String activityClubKey(Long clubId) {
        return ACTIVITY_CLUB_PREFIX + clubId;
    }
}
