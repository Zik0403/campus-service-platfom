package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 通用评论表。
 * 存储用户对帖子、商品、工单等的评论内容，支持一级评论与回复上级评论，
 * 是社区互动、商品评价与服务质量反馈的数据基础。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("comment") // 指定对应的数据库表名为 comment
public class Comment implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 评论主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 评论人用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 评论目标类型：1 帖子、2 商品、3 工单评价。
     */
    private Integer targetType;

    /**
     * 关联目标 ID，对应被评论对象（帖子/商品/工单）的主键。
     */
    private Long targetId;

    /**
     * 回复上级评论 ID，为空表示一级评论，有值表示针对某条评论的回复。
     */
    private Long parentId;

    /**
     * 评论文本内容。
     */
    private String content;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录评论首次发布时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    // ========== 关联对象（非数据库字段） ==========

    /**
     * 关联评论人对象，查询时组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private User user;

    /**
     * 关联父级评论对象，用于展示“回复了谁”，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private Comment parent;
}
