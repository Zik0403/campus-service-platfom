package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 图书馆藏图书表。
 * 存储图书馆书目信息，包括 ISBN、书名、作者、出版社、分类、馆藏位置、库存与封面，
 * 支撑图书检索、预约、借阅与馆藏管理。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("library_book") // 指定对应的数据库表名为 library_book
public class LibraryBook implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 图书主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 国际标准书号，图书唯一标识。
     */
    private String isbn;

    /**
     * 图书标题/书名。
     */
    private String title;

    /**
     * 作者姓名，多名作者可用逗号分隔。
     */
    private String author;

    /**
     * 出版社名称。
     */
    private String publisher;

    /**
     * 出版日期。
     */
    private LocalDate publishDate;

    /**
     * 图书分类，如“计算机”“文学”“历史”。
     */
    private String category;

    /**
     * 馆藏位置，如“三楼 A 区 12 架”。
     */
    private String location;

    /**
     * 馆藏总数量，该 ISBN 图书在馆共有多少本。
     */
    private Integer totalCount;

    /**
     * 可借数量，当前未被借出且可立即借阅的册数。
     */
    private Integer availableCount;

    /**
     * 图书封面图片地址。
     */
    private String cover;

    /**
     * 图书简介/摘要。
     */
    private String description;

    /**
     * 图书状态：0 不可借、1 可借，控制是否在检索结果中展示与可借阅。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录图书信息首次录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录图书信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
