package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 社团成员表。
 * 记录用户与社团的从属关系，包括身份（社长/副社长/管理员/成员）、加入时间与状态，
 * 支撑社团权限判断、成员列表展示与退出管理。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("club_member") // 指定对应的数据库表名为 club_member
public class ClubMember implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 成员记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 社团 ID，关联 club 表。
     */
    private Long clubId;

    /**
     * 用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 成员身份：1 社长、2 副社长、3 管理员、4 普通成员。
     * 不同身份拥有不同的社团管理权限。
     */
    private Integer identity;

    /**
     * 加入时间，用户通过申请/邀请进入社团的时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime joinTime;

    /**
     * 成员状态：1 正常、2 退出。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;
}
