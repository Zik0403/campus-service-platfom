package com.campus.service.job;

import com.campus.service.service.SecondOrderService;
import com.campus.service.service.ServiceOrderService;
import lombok.extern.slf4j.Slf4j;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * Quartz 持久化订单超时检查任务。
 * <p>
 * 与原有的 {@link OrderTimeoutJob}（基于 {@code @Scheduled} 的内存定时任务）并存，
 * 本任务由 Quartz 持久化调度，适合集群部署场景：
 * 任务状态、触发器信息保存在数据库中，即使应用重启或集群多节点，也不会丢失或重复触发。
 * </p>
 * <p>
 * 业务逻辑：调用服务订单和二手订单的超时处理方法，
 * 将超时未支付、超时未完成的订单自动取消或退款。
 * </p>
 *
 * @author campus-service
 */
@Slf4j
public class OrderTimeoutQuartzJob extends QuartzJobBean {

    /**
     * 服务订单业务服务，处理跑腿、代取快递等服务类订单超时。
     */
    @Autowired
    private ServiceOrderService serviceOrderService;

    /**
     * 二手订单业务服务，处理闲置交易类订单超时。
     */
    @Autowired
    private SecondOrderService secondOrderService;

    /**
     * Quartz 任务实际执行入口。
     * <p>
     * 分别调用两类订单的超时处理方法，并独立捕获异常，
     * 避免一种订单处理异常影响另一种订单。
     * </p>
     *
     * @param context Quartz 任务执行上下文
     */
    @Override
    protected void executeInternal(JobExecutionContext context) {
        // 记录本次 Quartz 持久化任务开始执行
        log.info("[Quartz 持久化任务] 开始执行订单超时检查任务");

        // 处理服务订单超时
        try {
            serviceOrderService.cancelTimeoutOrders();
        } catch (Exception e) {
            log.error("[Quartz 持久化任务] 服务订单超时处理异常", e);
        }

        // 处理二手订单超时
        try {
            secondOrderService.cancelTimeoutOrders();
        } catch (Exception e) {
            log.error("[Quartz 持久化任务] 二手订单超时处理异常", e);
        }

        // 记录本次 Quartz 持久化任务执行完成
        log.info("[Quartz 持久化任务] 订单超时检查任务执行完成");
    }
}
