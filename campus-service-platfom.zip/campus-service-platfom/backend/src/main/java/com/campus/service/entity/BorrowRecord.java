package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 图书借阅记录表。
 * 记录学生从图书馆借出、归还、续借图书的完整生命周期，
 * 是图书馆催还、逾期统计、借阅历史查询的核心数据。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("borrow_record") // 指定对应的数据库表名为 borrow_record
public class BorrowRecord implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 借阅记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 借阅用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 借阅图书 ID，关联 library_book 表。
     */
    private Long bookId;

    /**
     * 借出时间，图书被学生实际借走的时间。
     */
    private LocalDateTime borrowTime;

    /**
     * 应还时间，根据借阅规则计算得到的最晚归还时间。
     */
    private LocalDateTime dueTime;

    /**
     * 实际归还时间，学生还书时记录。
     */
    private LocalDateTime returnTime;

    /**
     * 续借次数，每续借一次递增，通常有最大续借次数限制。
     */
    private Integer renewCount;

    /**
     * 借阅状态：1 借阅中、2 已归还、3 已逾期等。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录借阅记录首次生成时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录借阅记录最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    /**
     * 关联图书对象，查询时通过联表或单独查询组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private LibraryBook book;
}
