package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.SecondOrder;

import java.util.List;

/**
 * 二手交易订单服务接口。
 * 负责校园二手市场中学生买卖双方的担保交易流程：买家下单、在线支付、
 * 卖家接单并线下交付、双方确认收款与收货，以及退款、投诉、超时取消等处理。
 */
public interface SecondOrderService extends IService<SecondOrder> {

    /**
     * 买家对指定二手商品创建订单。
     * @param buyerId 买家用户ID
     * @param productId 二手商品ID
     * @return 创建后的二手交易订单
     */
    SecondOrder createOrder(Long buyerId, Long productId);

    /**
     * 买家支付已创建的二手交易订单。
     * @param orderId 订单号
     * @param wxPayNo 微信支付流水号
     * @param payPassword 用户支付密码
     */
    void payOrder(String orderId, String wxPayNo, String payPassword);

    /**
     * 买家在线下收到商品后确认交付。
     * @param orderId 订单号
     * @param userId 当前操作用户ID
     */
    void confirmDelivery(String orderId, Long userId);

    /**
     * 卖家确认已收到平台打款。
     * @param orderId 订单号
     * @param userId 当前操作用户ID
     */
    void confirmReceive(String orderId, Long userId);

    /**
     * 买家申请退款。
     * @param orderId 订单号
     * @param userId 当前操作用户ID
     */
    void refundOrder(String orderId, Long userId);

    /**
     * 用户对交易过程存在问题时发起投诉。
     * @param orderId 订单号
     * @param userId 投诉用户ID
     * @param reason 投诉原因
     */
    void complainOrder(String orderId, Long userId, String reason);

    /**
     * 查询某笔二手交易订单的详情。
     * @param orderId 订单号
     * @param userId 当前查看用户ID
     * @return 订单详情对象
     */
    SecondOrder getOrderDetail(String orderId, Long userId);

    /**
     * 查询某位买家的所有二手交易订单。
     * @param buyerId 买家用户ID
     * @return 买家的订单列表
     */
    List<SecondOrder> getBuyerOrders(Long buyerId);

    /**
     * 查询某位卖家的所有二手交易订单。
     * @param sellerId 卖家用户ID
     * @return 卖家的订单列表
     */
    List<SecondOrder> getSellerOrders(Long sellerId);

    /**
     * 处理微信支付成功后的回调通知，更新订单支付状态。
     * @param orderId 订单号
     * @param wxPayNo 微信支付流水号
     */
    void handlePayCallback(String orderId, String wxPayNo);

    /**
     * 取消超过规定时间仍未支付的二手交易订单。
     */
    void cancelTimeoutOrders();

    /**
     * 查询待接单的二手交易订单（卖家视角）。
     * @param excludeUserId 需要排除的用户ID
     * @return 待接单订单列表
     */
    List<SecondOrder> getPendingOrders(Long excludeUserId);

    /**
     * 卖家确认接单并发货。
     * @param orderId 订单号
     * @param sellerId 卖家用户ID
     */
    void sellerAccept(String orderId, Long sellerId);
}
