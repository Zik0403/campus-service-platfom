package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Classroom;
import org.apache.ibatis.annotations.Mapper;

/**
 * 教室基础信息数据访问接口。
 *
 * <p>操作的数据库表为教室表，对应实体类为 {@link Classroom}。
 * 主要负责学校教学楼、教室等基础信息的增删改查，例如教室名称、容量、设备等。</p>
 */
@Mapper
public interface ClassroomMapper extends BaseMapper<Classroom> {
}
