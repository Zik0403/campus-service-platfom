package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.ActivityEnroll;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 活动报名数据访问接口。
 *
 * <p>操作的数据库表为活动报名表，对应实体类为 {@link ActivityEnroll}。
 * 主要负责校园活动中用户报名记录的查询，例如查询某活动的所有报名、某用户报名的所有活动、
 * 以及判断用户是否已经报名某个活动。</p>
 */
@Mapper
public interface ActivityEnrollMapper extends BaseMapper<ActivityEnroll> {

    /**
     * 根据活动 ID 查询该活动的所有报名记录。
     *
     * @param activityId 活动 ID，表示要查询的校园活动
     * @return 该活动的报名记录列表，没有人报名时返回空列表
     */
    List<ActivityEnroll> selectByActivityId(@Param("activityId") Long activityId);

    /**
     * 根据用户 ID 查询该用户报名的所有活动记录。
     *
     * @param userId 用户 ID，表示要查询的学生或用户
     * @return 该用户的报名记录列表，没有报名时返回空列表
     */
    List<ActivityEnroll> selectByUserId(@Param("userId") Long userId);

    /**
     * 查询某个用户是否已经报名某个活动。
     *
     * @param activityId 活动 ID
     * @param userId 用户 ID
     * @return 如果用户已报名则返回对应的报名记录，未报名则返回 null
     */
    ActivityEnroll selectUserEnroll(@Param("activityId") Long activityId, @Param("userId") Long userId);
}
