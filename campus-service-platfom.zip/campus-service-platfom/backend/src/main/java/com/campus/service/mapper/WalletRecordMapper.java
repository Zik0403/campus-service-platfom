package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.WalletRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 钱包资金流水数据访问接口。
 *
 * <p>操作的数据库表为钱包流水表，对应实体类为 {@link WalletRecord}。
 * 主要负责用户钱包收支明细的查询，例如查询某用户的所有资金流水、根据订单号查询对应流水。</p>
 */
@Mapper
public interface WalletRecordMapper extends BaseMapper<WalletRecord> {

    /**
     * 根据用户 ID 查询该用户的所有钱包资金流水。
     *
     * @param userId 用户 ID
     * @return 该用户的资金流水列表
     */
    List<WalletRecord> selectByUserId(@Param("userId") Long userId);

    /**
     * 根据订单号查询对应的钱包流水记录。
     *
     * @param orderNo 业务订单号
     * @return 对应的资金流水记录，不存在时返回 null
     */
    WalletRecord selectByOrderNo(@Param("orderNo") String orderNo);
}
