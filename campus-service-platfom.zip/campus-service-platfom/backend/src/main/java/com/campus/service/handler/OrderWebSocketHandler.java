package com.campus.service.handler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 订单变更 WebSocket 处理器。
 * <p>
 * 负责维护前端与后端的 WebSocket 长连接，并根据用户 ID 进行会话管理。
 * 当订单状态发生变更时，由 {@link com.campus.service.aspect.OrderWebSocketPushAspect}
 * 调用本处理器的静态方法，向订单相关用户推送消息。
 * </p>
 * <p>
 * 前端连接示例：{@code ws://host:port/api/ws/order?userId=123}
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Component
public class OrderWebSocketHandler extends TextWebSocketHandler {

    /**
     * 用户 ID 与会话的映射表。
     * <p>
     * 使用 {@link ConcurrentHashMap} 保证多线程环境下的线程安全，
     * Key 为连接时传入的 userId，Value 为该用户对应的 WebSocket 会话。
     * </p>
     */
    private static final Map<String, WebSocketSession> USER_SESSION_MAP = new ConcurrentHashMap<>();

    /**
     * 连接建立成功后调用。
     * <p>
     * 从连接 URL 的查询参数中解析 userId，并将会话保存到内存中，
     * 后续订单变更消息会根据 userId 推送给对应的长连接。
     * </p>
     *
     * @param session 新建立的 WebSocket 会话
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        // 获取连接 URI
        URI uri = session.getUri();
        if (uri == null) {
            log.warn("WebSocket 连接未携带 URI，无法识别用户");
            return;
        }
        // 从查询参数中解析 userId
        String userId = extractUserId(uri.getQuery());
        if (userId == null || userId.isEmpty()) {
            log.warn("WebSocket 连接未携带 userId 参数：{}" , uri);
            return;
        }
        // 将 userId 保存到会话属性中，便于后续关闭时清理
        session.getAttributes().put("userId", userId);
        // 将会话加入用户会话映射表
        USER_SESSION_MAP.put(userId, session);
        log.info("WebSocket 连接建立：userId={}，当前在线 {} 人", userId, USER_SESSION_MAP.size());
    }

    /**
     * 收到客户端文本消息时调用。
     * <p>
     * 当前仅对心跳消息做简单响应，收到消息后原样回传，保持连接活跃。
     * </p>
     *
     * @param session 当前会话
     * @param message 收到的文本消息
     */
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) {
        // 读取客户端发送的文本内容
        String payload = message.getPayload();
        log.debug("收到 WebSocket 消息：sessionId={}, payload={}", session.getId(), payload);
        try {
            // 回传消息，用于心跳或简单测试
            session.sendMessage(new TextMessage("pong:" + payload));
        } catch (IOException e) {
            log.error("WebSocket 消息回传失败：sessionId={}", session.getId(), e);
        }
    }

    /**
     * 连接关闭后调用。
     * <p>
     * 根据会话属性中的 userId 清理会话映射，避免向已离线用户推送消息。
     * </p>
     *
     * @param session 已关闭的 WebSocket 会话
     * @param status  关闭状态
     */
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        // 从会话属性中获取用户 ID
        Object userId = session.getAttributes().get("userId");
        if (userId != null) {
            // 移除该用户的在线会话
            USER_SESSION_MAP.remove(userId.toString());
            log.info("WebSocket 连接关闭：userId={}，status={}，当前在线 {} 人",
                    userId, status, USER_SESSION_MAP.size());
        }
    }

    /**
     * 连接发生异常时调用。
     * <p>
     * 异常时主动移除会话，避免脏连接占用内存。
     * </p>
     *
     * @param session   发生异常的会话
     * @param exception 异常对象
     */
    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        log.error("WebSocket 传输异常：sessionId={}", session.getId(), exception);
        // 从会话属性中获取用户 ID 并清理映射
        Object userId = session.getAttributes().get("userId");
        if (userId != null) {
            USER_SESSION_MAP.remove(userId.toString());
        }
    }

    /**
     * 向指定用户推送订单变更消息。
     * <p>
     * 如果该用户当前在线，则发送 JSON 文本消息；不在线则忽略，不抛异常。
     * </p>
     *
     * @param userId  接收消息的用户 ID
     * @param message 订单变更 JSON 消息
     */
    public static void sendMessageToUser(Long userId, String message) {
        if (userId == null) {
            return;
        }
        // 根据 userId 查找对应的 WebSocket 会话
        WebSocketSession session = USER_SESSION_MAP.get(userId.toString());
        if (session == null || !session.isOpen()) {
            // 用户不在线或连接已关闭，直接跳过
            return;
        }
        try {
            // 发送文本消息
            session.sendMessage(new TextMessage(message));
            log.debug("WebSocket 推送成功：userId={}，message={}", userId, message);
        } catch (IOException e) {
            log.error("WebSocket 推送失败：userId={}", userId, e);
        }
    }

    /**
     * 向所有在线用户广播订单变更消息。
     *
     * @param message 订单变更 JSON 消息
     */
    public static void broadcast(String message) {
        // 遍历所有在线会话并发送消息
        for (Map.Entry<String, WebSocketSession> entry : USER_SESSION_MAP.entrySet()) {
            WebSocketSession session = entry.getValue();
            if (session.isOpen()) {
                try {
                    session.sendMessage(new TextMessage(message));
                } catch (IOException e) {
                    log.error("WebSocket 广播失败：userId={}", entry.getKey(), e);
                }
            }
        }
    }

    /**
     * 从 URL 查询字符串中解析 userId 参数。
     *
     * @param query URL 查询字符串，例如 userId=123&token=xxx
     * @return userId 参数值；未找到时返回 null
     */
    private String extractUserId(String query) {
        if (query == null || query.isEmpty()) {
            return null;
        }
        // 按 & 拆分成多个参数对
        String[] pairs = query.split("&");
        for (String pair : pairs) {
            // 按 = 拆分成键和值
            int idx = pair.indexOf('=');
            if (idx > 0 && "userId".equals(pair.substring(0, idx))) {
                // 对 URL 编码的值进行解码
                return java.net.URLDecoder.decode(pair.substring(idx + 1), StandardCharsets.UTF_8);
            }
        }
        return null;
    }
}
