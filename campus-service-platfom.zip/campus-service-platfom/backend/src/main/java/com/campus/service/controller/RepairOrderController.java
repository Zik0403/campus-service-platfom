package com.campus.service.controller;

import com.campus.service.entity.RepairOrder;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.RepairOrderService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/repair")
@RequiredArgsConstructor
public class RepairOrderController {

    private final RepairOrderService repairOrderService;

    /**
     * 创建报修工单
     */
    @PostMapping("/create")
    public R<RepairOrder> createOrder(HttpServletRequest request,
                                        @RequestBody java.util.Map<String, Object> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String faultType = (String) params.get("faultType");
        String address = (String) params.get("address");
        String description = (String) params.get("description");
        if (description == null) {
            description = (String) params.get("desc");
        }
        String images = (String) params.get("images");
        Integer priority = params.get("priority") != null ? ((Number) params.get("priority")).intValue() : 1;
        RepairOrder order = repairOrderService.createOrder(userId, faultType, address, description, images, priority);
        return R.success(order);
    }

    /**
     * 修改报修工单（仅待派单状态可修改）
     */
    @PostMapping("/update")
    public R<RepairOrder> updateOrder(HttpServletRequest request,
                                       @RequestBody java.util.Map<String, Object> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long orderId = ((Number) params.get("orderId")).longValue();
        String faultType = (String) params.get("faultType");
        String address = (String) params.get("address");
        String description = (String) params.get("description");
        if (description == null) {
            description = (String) params.get("desc");
        }
        String images = (String) params.get("images");
        Integer priority = params.get("priority") != null ? ((Number) params.get("priority")).intValue() : 1;
        RepairOrder order = repairOrderService.updateOrder(orderId, userId, faultType, address, description, images, priority);
        return R.success(order);
    }

    private String getStr(Map<String, Object> body, String key, String defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        return v != null ? v.toString() : defaultValue;
    }

    private Long getLong(Map<String, Object> body, String key, Long defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try {
            if (v instanceof Number) {
                return ((Number) v).longValue();
            }
            return Long.valueOf(v.toString());
        } catch (Exception e) {
            return defaultValue;
        }
    }

    private Integer getInt(Map<String, Object> body, String key, Integer defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try {
            if (v instanceof Number) {
                return ((Number) v).intValue();
            }
            return Integer.valueOf(v.toString());
        } catch (Exception e) {
            return defaultValue;
        }
    }

    /**
     * 派单给维修员
     */
    @PostMapping("/assign")
    public R<Void> assignWorker(@RequestBody(required = false) Map<String, Object> body,
                                 @RequestParam(required = false) Long orderId,
                                 @RequestParam(required = false) Long workerId) {
        Long oid = orderId != null ? orderId : getLong(body, "orderId", null);
        Long wid = workerId != null ? workerId : getLong(body, "workerId", null);
        repairOrderService.assignWorker(oid, wid);
        return R.success();
    }

    /**
     * 维修员接单
     */
    @PostMapping("/accept")
    public R<Void> workerAccept(HttpServletRequest request,
                                 @RequestBody(required = false) Map<String, Object> body,
                                 @RequestParam(required = false) String orderId) {
        Long workerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        repairOrderService.workerAccept(Long.parseLong(oid), workerId);
        return R.success();
    }

    /**
     * 确认完成
     */
    @PostMapping("/complete")
    public R<Void> completeOrder(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) Long orderId) {
        Long workerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long oid = orderId != null ? orderId : getLong(body, "orderId", null);
        repairOrderService.completeOrder(oid, workerId);
        return R.success();
    }

    /**
     * 驳回工单
     */
    @PostMapping("/reject")
    public R<Void> rejectOrder(@RequestBody(required = false) Map<String, Object> body,
                                @RequestParam(required = false) Long orderId,
                                @RequestParam(required = false) String reason) {
        Long oid = orderId != null ? orderId : getLong(body, "orderId", null);
        String r = reason != null ? reason : getStr(body, "reason", null);
        repairOrderService.rejectOrder(oid, r);
        return R.success();
    }

    /**
     * 用户取消工单
     */
    @PostMapping("/cancel")
    public R<Void> cancelOrder(HttpServletRequest request,
                                @RequestBody(required = false) Map<String, Object> body,
                                @RequestParam(required = false) Long orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long oid = orderId != null ? orderId : getLong(body, "orderId", null);
        repairOrderService.cancelOrder(oid, userId);
        return R.success();
    }

    /**
     * 用户评价
     */
    @PostMapping("/evaluate")
    public R<Void> evaluate(HttpServletRequest request,
                             @RequestBody(required = false) Map<String, Object> body,
                             @RequestParam(required = false) Long orderId,
                             @RequestParam(required = false) Integer star,
                             @RequestParam(required = false) String content) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Long oid = orderId != null ? orderId : getLong(body, "orderId", null);
        Integer s = star != null ? star : getInt(body, "star", null);
        String c = content != null ? content : getStr(body, "content", null);
        repairOrderService.evaluate(oid, userId, s, c);
        return R.success();
    }

    /**
     * 获取用户报修工单列表
     */
    @GetMapping("/list")
    public R<List<RepairOrder>> getUserOrders(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(repairOrderService.getUserOrders(userId));
    }

    /**
     * 获取维修员待处理工单
     */
    @GetMapping("/worker/pending")
    public R<List<RepairOrder>> getWorkerPendingOrders(HttpServletRequest request) {
        Long workerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(repairOrderService.getWorkerPendingOrders(workerId));
    }

    /**
     * 获取待接单维修工单（抢单大厅）
     */
    @GetMapping("/pending")
    public R<List<RepairOrder>> getPendingOrders(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(repairOrderService.getPendingOrders(userId));
    }

    /**
     * 获取工单详情
     */
    @GetMapping("/detail")
    public R<RepairOrder> getOrderDetail(HttpServletRequest request, @RequestParam Long orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(repairOrderService.getOrderDetail(orderId, userId));
    }
}
