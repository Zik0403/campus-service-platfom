package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 图书预约表。
 * 记录学生对馆藏图书的线上预约信息，包括预约时间、过期时间与预约状态，
 * 用于图书馆在图书归还后为预约者保留借阅权。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("book_reservation") // 指定对应的数据库表名为 book_reservation
public class BookReservation implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 预约记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 预约用户 ID，关联 user 表。
     */
    private Long userId;

    /**
     * 预约图书 ID，关联 library_book 表。
     */
    private Long bookId;

    /**
     * 预约时间，学生提交预约请求的时间。
     */
    private LocalDateTime reserveTime;

    /**
     * 过期时间，超过该时间未取书则预约自动失效。
     */
    private LocalDateTime expireTime;

    /**
     * 预约状态：1 预约中、2 已取书、3 已过期、4 已取消等。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录预约记录首次生成时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录预约记录最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;

    /**
     * 关联图书对象，查询时通过联表或单独查询组装，非数据库字段。
     */
    @TableField(exist = false) // 非数据库字段，仅用于业务查询结果封装
    private LibraryBook book;
}
