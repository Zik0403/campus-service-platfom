package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.math.BigDecimal;
import java.util.List;

/**
 * 用户数据访问接口。
 *
 * <p>操作的数据库表为用户表，对应实体类为 {@link User}。
 * 主要负责平台用户信息的查询与更新，例如根据 openid、学号、手机号查询用户、
 * 查询信用积分排行榜、查询配送员列表以及原子性更新账户余额。</p>
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {

    /**
     * 根据微信 openid 查询用户。
     *
     * @param openid 微信用户唯一标识
     * @return 对应的用户信息，不存在时返回 null
     */
    User selectByOpenid(@Param("openid") String openid);

    /**
     * 根据学号查询用户。
     *
     * @param studentId 学生学号
     * @return 对应的用户信息，不存在时返回 null
     */
    User selectByStudentId(@Param("studentId") String studentId);

    /**
     * 根据手机号查询用户。
     *
     * @param phone 用户手机号
     * @return 对应的用户信息，不存在时返回 null
     */
    User selectByPhone(@Param("phone") String phone);

    /**
     * 查询信用积分排行榜前 N 名用户。
     *
     * @param limit 返回的用户数量
     * @return 信用积分最高的用户列表
     */
    List<User> selectCreditTop(@Param("limit") int limit);

    /**
     * 查询所有配送员用户列表。
     *
     * @return 配送员用户列表
     */
    List<User> selectWorkers();

    /**
     * 原子性地更新用户账户余额。
     *
     * <p>直接在数据库层执行余额加减，避免并发时余额出现负数。</p>
     *
     * @param userId 用户 ID
     * @param amount 变动金额，正数表示增加余额，负数表示扣减余额
     * @return 受影响的数据行数，更新成功返回 1，余额不足或用户不存在返回 0
     */
    @Update("UPDATE user SET balance = balance + #{amount} WHERE id = #{userId} AND is_delete = 0 AND balance + #{amount} >= 0")
    int updateBalance(@Param("userId") Long userId, @Param("amount") BigDecimal amount);
}
