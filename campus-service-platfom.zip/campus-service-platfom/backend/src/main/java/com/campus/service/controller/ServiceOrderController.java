package com.campus.service.controller;

import com.campus.service.entity.ServiceOrder;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.ServiceOrderService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/service/order")
@RequiredArgsConstructor
public class ServiceOrderController {

    private final ServiceOrderService orderService;

    private String getStr(Map<String, Object> body, String key, String defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        return v != null ? v.toString() : defaultValue;
    }

    private Integer getInt(Map<String, Object> body, String key, Integer defaultValue) {
        if (body == null) return defaultValue;
        Object v = body.get(key);
        if (v == null) return defaultValue;
        try { return Integer.valueOf(v.toString()); } catch (Exception e) { return defaultValue; }
    }

    /**
     * 创建服务订单（快递/跑腿/外卖）
     */
    @PostMapping("/create")
    public R<ServiceOrder> createOrder(HttpServletRequest request,
                                        @RequestBody(required = false) Map<String, Object> body,
                                        @RequestParam(required = false) Integer serviceType,
                                        @RequestParam(required = false) String originAddr,
                                        @RequestParam(required = false) String targetAddr,
                                        @RequestParam(required = false) String orderContent,
                                        @RequestParam(required = false) String tipFee,
                                        @RequestParam(required = false) String totalFee) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Integer st = serviceType != null ? serviceType : getInt(body, "serviceType", null);
        String oa = originAddr != null ? originAddr : getStr(body, "originAddr", getStr(body, "fromAddr", null));
        String ta = targetAddr != null ? targetAddr : getStr(body, "targetAddr", null);
        String oc = orderContent != null ? orderContent : getStr(body, "orderContent", null);
        String tf = tipFee != null ? tipFee : getStr(body, "tipFee", "0");
        String tfee = totalFee != null ? totalFee : getStr(body, "totalFee", null);
        return R.success(orderService.createOrder(userId, st, oa, ta, oc, tf, tfee));
    }

    /**
     * 支付订单
     */
    @PostMapping("/pay")
    public R<Void> payOrder(@RequestBody(required = false) Map<String, Object> body,
                             @RequestParam(required = false) String orderId,
                             @RequestParam(required = false) String wxPayNo,
                             @RequestParam(required = false) String payPassword) {
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        String wxp = wxPayNo != null ? wxPayNo : getStr(body, "wxPayNo", null);
        String pp = payPassword != null ? payPassword : getStr(body, "payPassword", null);
        orderService.payOrder(oid, wxp, pp);
        return R.success();
    }

    /**
     * 配送员接单
     */
    @PostMapping("/accept")
    public R<Void> workerAccept(HttpServletRequest request,
                                 @RequestBody(required = false) Map<String, Object> body,
                                 @RequestParam(required = false) String orderId) {
        Long workerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.workerAccept(oid, workerId);
        return R.success();
    }

    /**
     * 开始配送
     */
    @PostMapping("/start")
    public R<Void> startDelivery(@RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) String orderId) {
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.startDelivery(oid);
        return R.success();
    }

    /**
     * 完成配送
     */
    @PostMapping("/complete")
    public R<Void> completeOrder(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) String orderId) {
        Long workerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.completeOrder(oid, workerId);
        return R.success();
    }

    /**
     * 取消订单
     */
    @PostMapping("/cancel")
    public R<Void> cancelOrder(HttpServletRequest request,
                                @RequestBody(required = false) Map<String, Object> body,
                                @RequestParam(required = false) String orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.cancelOrder(oid, userId);
        return R.success();
    }

    /**
     * 申请退款
     */
    @PostMapping("/refund")
    public R<Void> refundOrder(HttpServletRequest request,
                                @RequestBody(required = false) Map<String, Object> body,
                                @RequestParam(required = false) String orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.refundOrder(oid, userId);
        return R.success();
    }

    /**
     * 用户评价
     */
    @PostMapping("/evaluate")
    public R<Void> evaluate(HttpServletRequest request,
                             @RequestBody(required = false) Map<String, Object> body,
                             @RequestParam(required = false) String orderId,
                             @RequestParam(required = false) Integer star) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        Integer s = star != null ? star : getInt(body, "star", null);
        orderService.evaluate(oid, userId, s);
        return R.success();
    }

    /**
     * 投诉订单
     */
    @PostMapping("/complain")
    public R<Void> complainOrder(HttpServletRequest request,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) String orderId,
                                  @RequestParam(required = false) String reason) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        String r = reason != null ? reason : getStr(body, "reason", null);
        orderService.complainOrder(oid, userId, r);
        return R.success();
    }

    /**
     * 获取订单详情
     */
    @GetMapping("/detail")
    public R<ServiceOrder> getOrderDetail(HttpServletRequest request, @RequestParam String orderId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getOrderDetail(orderId, userId));
    }

    /**
     * 获取用户订单列表
     */
    @GetMapping("/list")
    public R<List<ServiceOrder>> getUserOrders(HttpServletRequest request,
                                                @RequestParam(required = false) Integer serviceType) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getUserOrders(userId, serviceType));
    }

    /**
     * 获取配送员订单列表
     */
    @GetMapping("/worker/list")
    public R<List<ServiceOrder>> getWorkerOrders(HttpServletRequest request) {
        Long workerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getWorkerOrders(workerId));
    }

    /**
     * 接单者退回订单（放弃接单）
     */
    @PostMapping("/worker/return")
    public R<Void> workerReturnOrder(HttpServletRequest request,
                                      @RequestBody(required = false) Map<String, Object> body,
                                      @RequestParam(required = false) String orderId) {
        Long workerId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        String oid = orderId != null ? orderId : getStr(body, "orderId", null);
        orderService.workerReturnOrder(oid, workerId);
        return R.success();
    }

    /**
     * 获取待接单订单（配送员/学生抢单）
     */
    @GetMapping("/pending")
    public R<List<ServiceOrder>> getPendingOrders(HttpServletRequest request,
                                                   @RequestParam(required = false) Integer serviceType) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(orderService.getPendingOrders(serviceType, userId));
    }
}
