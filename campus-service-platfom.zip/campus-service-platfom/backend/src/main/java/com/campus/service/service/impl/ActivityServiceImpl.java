package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.cache.CacheKeyConstant;
import com.campus.service.common.cache.CacheProtectionService;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.Activity;
import com.campus.service.mapper.ActivityMapper;
import com.campus.service.service.ActivityService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 校园活动服务实现类。
 * <p>
 * 负责社团或个人发起的校园活动全生命周期管理，包括：
 * <ul>
 *     <li>创建新活动并提交审核；</li>
 *     <li>管理员对活动进行审核（通过/驳回）；</li>
 *     <li>查询指定社团的活动列表、当前可报名的活动列表以及待审核的活动列表。</li>
 * </ul>
 * </p>
 *
 * @author campus-service
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ActivityServiceImpl extends ServiceImpl<ActivityMapper, Activity> implements ActivityService {

    /**
     * 创建新的校园活动。
     * <p>
     * 由社团管理员或活动发起人调用，将活动信息保存到 activity 表，
     * 初始状态为“待审核”，报名计数从 0 开始。
     * </p>
     *
     * @param clubId        所属社团ID（若为个人活动可传 null，视业务而定）
     * @param name          活动名称
     * @param poster        活动海报图片地址
     * @param location      活动地点
     * @param startTime     活动开始时间，字符串格式，会解析为 LocalDateTime
     * @param endTime       活动结束时间，字符串格式，会解析为 LocalDateTime
     * @param enrollDeadline 报名截止时间，字符串格式，会解析为 LocalDateTime
     * @param description   活动详情描述
     * @param maxPeople     活动最大报名人数，0 表示不限制
     * @return 创建成功后的 Activity 实体对象，包含生成的活动ID
     */
    @Override
    @Transactional
    public Activity createActivity(Long clubId, String name, String poster, String location,
                                   String startTime, String endTime, String enrollDeadline,
                                   String description, Integer maxPeople) {
        // 创建一个空的活动实体对象，用于封装前端传入的活动信息
        Activity activity = new Activity();
        // 设置活动所属社团ID，标识该活动由哪个社团发布
        activity.setClubId(clubId);
        // 设置活动名称，展示在活动列表和详情页
        activity.setName(name);
        // 设置活动海报图片地址，用于活动列表和详情展示
        activity.setPoster(poster);
        // 设置活动地点，告知学生参加活动的位置
        activity.setLocation(location);
        // 将字符串开始时间解析为 LocalDateTime 后存入活动表
        activity.setStartTime(LocalDateTime.parse(startTime));
        // 将字符串结束时间解析为 LocalDateTime 后存入活动表
        activity.setEndTime(LocalDateTime.parse(endTime));
        // 将字符串报名截止时间解析为 LocalDateTime，超过该时间学生无法报名
        activity.setEnrollDeadline(LocalDateTime.parse(enrollDeadline));
        // 设置活动详细说明，帮助用户了解活动内容
        activity.setDescription(description);
        // 设置活动最多允许报名的人数，控制活动规模
        activity.setMaxPeople(maxPeople);
        // 初始化已报名人数为 0，每有人报名会递增
        activity.setEnrollCount(0);
        // 设置审核状态为待审核，等待管理员或社长审批
        activity.setAuditStatus(OrderStatus.AUDIT_PENDING);
        // 设置活动状态为启用（1 表示正常展示），学生可见
        activity.setStatus(1);
        // 调用 MyBatis-Plus 提供的 save 方法，将活动记录插入 activity 表
        save(activity);
        // 记录创建活动的日志，方便后续排查问题
        log.info("创建活动: activityId={}, clubId={}", activity.getId(), clubId);
        // 返回创建成功的活动对象，供 controller 层返回给前端
        return activity;
    }

    /**
     * 审核活动。
     * <p>
     * 管理员根据审核结果更新 activity 表的 audit_status 字段，
     * 审核通过的活动才会对学生可见并可报名。
     * </p>
     *
     * @param activityId  待审核的活动ID
     * @param auditStatus 审核状态，如审核通过、审核驳回等
     */
    @Override
    @Transactional
    public void auditActivity(Long activityId, Integer auditStatus) {
        // 根据活动ID从 activity 表查询活动记录
        Activity activity = getById(activityId);
        // 如果活动不存在，抛出 404 业务异常，提示前端活动未找到
        if (activity == null) {
            throw BusinessException.notFound();
        }
        // 将传入的审核状态设置到活动实体中，更新活动审批结果
        activity.setAuditStatus(auditStatus);
        // 调用 MyBatis-Plus 的 updateById，根据主键更新 activity 表的审核状态
        updateById(activity);
        // 记录审核操作的日志，便于审计和问题追踪
        log.info("审核活动: activityId={}, status={}", activityId, auditStatus);
    }

    /**
     * 查询指定社团已通过审核且启用的活动列表。
     *
     * @param clubId 社团ID
     * @return 该社团下已通过审核、状态正常的活动列表，按开始时间倒序排列
     */
    @Override
    public List<Activity> getClubActivities(Long clubId) {
        // 查询 activity 表，条件是：指定社团、审核通过、状态启用，并按开始时间倒序
        return list(new LambdaQueryWrapper<Activity>()
                // 指定查询 club_id 等于传入社团ID的活动
                .eq(Activity::getClubId, clubId)
                // 只查询审核状态为已通过的活动
                .eq(Activity::getAuditStatus, OrderStatus.AUDIT_PASSED)
                // 只查询状态为启用的活动
                .eq(Activity::getStatus, 1)
                // 按活动开始时间倒序排列，最近开始的活动排在最前面
                .orderByDesc(Activity::getStartTime));
    }

    /**
     * 查询当前学生可报名的活动列表。
     * <p>
     * 仅返回已通过审核、状态启用且报名截止时间未过的活动。
     * </p>
     *
     * @return 当前可报名的活动列表，按开始时间倒序排列
     */
    @Override
    public List<Activity> getAvailableActivities() {
        // 查询 activity 表，条件是：审核通过、状态启用、报名截止时间大于当前时间
        return list(new LambdaQueryWrapper<Activity>()
                // 只查询审核通过的活动，未通过审核的不允许报名
                .eq(Activity::getAuditStatus, OrderStatus.AUDIT_PASSED)
                // 只查询状态为启用的活动，已禁用活动不展示
                .eq(Activity::getStatus, 1)
                // 报名截止时间必须晚于当前时间，确保活动仍在报名期内
                .gt(Activity::getEnrollDeadline, LocalDateTime.now())
                // 按活动开始时间倒序排列
                .orderByDesc(Activity::getStartTime));
    }

    /**
     * 查询待管理员审核的活动列表。
     *
     * @return 所有审核状态为“待审核”的活动列表，按创建时间倒序排列
     */
    @Override
    public List<Activity> getPendingAuditActivities() {
        // 查询 activity 表中审核状态为待审核的所有活动
        return list(new LambdaQueryWrapper<Activity>()
                // 只查询 audit_status 为待审核的活动
                .eq(Activity::getAuditStatus, OrderStatus.AUDIT_PENDING)
                // 按创建时间倒序，最新的申请排在最前面
                .orderByDesc(Activity::getCreateTime));
    }

    /**
     * Redis 缓存模板，用于热点活动数据的读取与写入。
     */
    private final RedisTemplate<String, Object> redisTemplate;

    /**
     * 缓存防护服务，提供缓存穿透、击穿、雪崩保护能力。
     */
    private final CacheProtectionService cacheProtectionService;

    /**
     * 活动相关缓存过期时间，报名截止时间临近时数据会变化，默认缓存 20 分钟。
     */
    private static final Duration ACTIVITY_CACHE_TTL = Duration.ofMinutes(20);

    /**
     * 带缓存的查询：获取当前学生可报名的活动列表。
     *
     * @return 当前可报名的活动列表
     */
    public List<Activity> getAvailableActivitiesWithCache() {
        // 构造可报名活动列表的缓存 Key
        String cacheKey = CacheKeyConstant.ACTIVITY_AVAILABLE_LIST;
        // 先尝试从 Redis 读取缓存
        @SuppressWarnings("unchecked")
        List<Activity> cachedList = (List<Activity>) redisTemplate.opsForValue().get(cacheKey);
        if (cachedList != null) {
            // 缓存命中直接返回
            return cachedList;
        }
        // 缓存未命中，调用原方法查询数据库
        List<Activity> activities = getAvailableActivities();
        // 写入 Redis 并设置过期时间
        redisTemplate.opsForValue().set(cacheKey, activities, ACTIVITY_CACHE_TTL);
        return activities;
    }

    /**
     * 带缓存的查询：获取指定社团已通过审核且启用的活动列表。
     *
     * @param clubId 社团 ID
     * @return 该社团下已通过审核、状态正常的活动列表
     */
    public List<Activity> getClubActivitiesWithCache(Long clubId) {
        // 根据社团 ID 构造唯一缓存 Key
        String cacheKey = CacheKeyConstant.activityClubKey(clubId);
        // 先尝试从 Redis 读取缓存
        @SuppressWarnings("unchecked")
        List<Activity> cachedList = (List<Activity>) redisTemplate.opsForValue().get(cacheKey);
        if (cachedList != null) {
            // 缓存命中直接返回
            return cachedList;
        }
        // 缓存未命中回源查询
        List<Activity> activities = getClubActivities(clubId);
        // 写入 Redis 并设置过期时间
        redisTemplate.opsForValue().set(cacheKey, activities, ACTIVITY_CACHE_TTL);
        return activities;
    }

    /**
     * 带缓存的查询：获取待管理员审核的活动列表。
     *
     * @return 待审核活动列表
     */
    public List<Activity> getPendingAuditActivitiesWithCache() {
        // 构造待审核活动列表的缓存 Key
        String cacheKey = CacheKeyConstant.ACTIVITY_PENDING_AUDIT_LIST;
        // 先尝试从 Redis 读取缓存
        @SuppressWarnings("unchecked")
        List<Activity> cachedList = (List<Activity>) redisTemplate.opsForValue().get(cacheKey);
        if (cachedList != null) {
            // 缓存命中直接返回
            return cachedList;
        }
        // 缓存未命中回源查询
        List<Activity> activities = getPendingAuditActivities();
        // 写入 Redis 并设置过期时间
        redisTemplate.opsForValue().set(cacheKey, activities, ACTIVITY_CACHE_TTL);
        return activities;
    }

    /**
     * 清除活动相关的所有缓存。
     * <p>
     * 当管理员审核活动、社团创建/修改/删除活动时调用，保证缓存数据及时失效。
     * </p>
     */
    public void evictActivityCache() {
        // 删除可报名活动列表缓存
        redisTemplate.delete(CacheKeyConstant.ACTIVITY_AVAILABLE_LIST);
        // 删除待审核活动列表缓存
        redisTemplate.delete(CacheKeyConstant.ACTIVITY_PENDING_AUDIT_LIST);
        // 删除所有社团活动列表缓存（匹配 activity:club:* 模式）
        java.util.Set<String> clubKeys = redisTemplate.keys(CacheKeyConstant.ACTIVITY_CLUB_PREFIX + "*");
        if (clubKeys != null && !clubKeys.isEmpty()) {
            redisTemplate.delete(clubKeys);
        }
    }

    /**
     * 预加载活动相关热点缓存。
     * <p>
     * 应用启动或手动触发时调用，把可报名活动、待审核活动提前写入 Redis。
     * </p>
     */
    public void warmActivityCache() {
        // 预热可报名活动列表缓存
        List<Activity> availableActivities = getAvailableActivities();
        redisTemplate.opsForValue().set(CacheKeyConstant.ACTIVITY_AVAILABLE_LIST, availableActivities, ACTIVITY_CACHE_TTL);
        // 预热待审核活动列表缓存
        List<Activity> pendingActivities = getPendingAuditActivities();
        redisTemplate.opsForValue().set(CacheKeyConstant.ACTIVITY_PENDING_AUDIT_LIST, pendingActivities, ACTIVITY_CACHE_TTL);
    }

    /**
     * 带三重防护的查询：获取当前学生可报名的活动列表。
     * <p>
     * 在 {@link #getAvailableActivitiesWithCache()} 基础上增加缓存穿透、缓存击穿、缓存雪崩保护。
     * </p>
     *
     * @return 当前可报名的活动列表
     */
    public List<Activity> getAvailableActivitiesWithCacheProtected() {
        // 使用缓存防护服务读取可报名活动列表
        return cacheProtectionService.getListWithProtection(
                CacheKeyConstant.ACTIVITY_AVAILABLE_LIST,
                this::getAvailableActivities,
                ACTIVITY_CACHE_TTL,
                Activity.class);
    }

    /**
     * 带三重防护的查询：获取指定社团已通过审核且启用的活动列表。
     *
     * @param clubId 社团 ID
     * @return 该社团下已通过审核、状态正常的活动列表
     */
    public List<Activity> getClubActivitiesWithCacheProtected(Long clubId) {
        // 根据社团 ID 构造唯一缓存 Key
        String cacheKey = CacheKeyConstant.activityClubKey(clubId);
        // 使用缓存防护服务读取社团活动列表
        return cacheProtectionService.getListWithProtection(
                cacheKey,
                () -> getClubActivities(clubId),
                ACTIVITY_CACHE_TTL,
                Activity.class);
    }

    /**
     * 带三重防护的查询：获取待管理员审核的活动列表。
     *
     * @return 待审核活动列表
     */
    public List<Activity> getPendingAuditActivitiesWithCacheProtected() {
        // 使用缓存防护服务读取待审核活动列表
        return cacheProtectionService.getListWithProtection(
                CacheKeyConstant.ACTIVITY_PENDING_AUDIT_LIST,
                this::getPendingAuditActivities,
                ACTIVITY_CACHE_TTL,
                Activity.class);
    }
}
