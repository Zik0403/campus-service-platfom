package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 校园资讯公告表。
 * 存储运营端发布的校园公告、活动推广、优惠信息等内容，
 * 按类型与排序展示在小程序首页或公告频道，帮助学生及时获取校园动态。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("campus_notice") // 指定对应的数据库表名为 campus_notice
public class CampusNotice implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 公告主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 公告类型：1 校园公告、2 活动、3 优惠。
     */
    private Integer noticeType;

    /**
     * 公告标题，展示在公告列表与详情页。
     */
    private String title;

    /**
     * 公告正文内容，支持富文本或纯文本。
     */
    private String content;

    /**
     * 公告配图地址，用于列表卡片展示。
     */
    private String image;

    /**
     * 外部链接地址，点击公告可跳转至 H5 或小程序页面。
     */
    private String linkUrl;

    /**
     * 排序值，值越小通常越靠前，用于控制公告展示顺序。
     */
    private Integer sort;

    /**
     * 上下架状态：0 下架、1 上架。
     * 下架后用户在小程序端不可见。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录公告首次发布时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录公告信息最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
