package com.campus.service;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * ============================================================
 * 【项目启动类 - CampusServiceApplication】
 * 这是整个 Spring Boot 后端的入口类，运行此类的 main 方法即可启动后端服务
 * 
 * 作用说明：
 * 1. @SpringBootApplication - Spring Boot 核心注解，开启自动配置
 * 2. @MapperScan("com.campus.service.mapper") - 自动扫描 MyBatis Mapper 接口
 * 3. @EnableScheduling - 开启定时任务（如订单超时自动取消）
 * 4. @EnableTransactionManagement - 开启事务管理
 * 
 * 【如何在 IDEA 中启动】
 * 1. 打开 IDEA，导入 backend 文件夹作为 Maven 项目
 * 2. 等待 Maven 自动下载依赖（右下角有进度条）
 * 3. 找到此类，右键 → Run 'CampusServiceApplication'
 * 4. 或在 Terminal 中运行：mvn spring-boot:run
 * 5. 启动成功后，访问 http://localhost:8080/api/doc.html 查看 API 文档
 * ============================================================
 */
@SpringBootApplication
@MapperScan("com.campus.service.mapper")
@EnableScheduling
@EnableTransactionManagement
public class CampusServiceApplication {

    public static void main(String[] args) {
        // 启动 Spring Boot 应用
        SpringApplication.run(CampusServiceApplication.class, args);
    }
}
