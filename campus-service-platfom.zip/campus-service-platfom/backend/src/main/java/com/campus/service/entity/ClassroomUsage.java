package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 教室课程占用表。
 * 存储学校教务排课后各教室的课程占用安排，包括星期、节次、起止周、学期等，
 * 用于教室预约冲突检测与自习空教室查询。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("classroom_usage") // 指定对应的数据库表名为 classroom_usage
public class ClassroomUsage implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 占用记录主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 占用教室 ID，关联 classroom 表。
     */
    private Long classroomId;

    /**
     * 课程名称，如“高等数学”“Java 程序设计”。
     */
    private String courseName;

    /**
     * 星期几，取值 1-7 分别代表周一至周日。
     */
    private Integer weekDay;

    /**
     * 开始节次，表示该课程从第几节课开始。
     */
    private Integer sectionStart;

    /**
     * 结束节次，表示该课程到第几节课结束。
     */
    private Integer sectionEnd;

    /**
     * 开始周次，表示该课程从学期第几周开始占用教室。
     */
    private Integer weekStart;

    /**
     * 结束周次，表示该课程占用教室到第几周结束。
     */
    private Integer weekEnd;

    /**
     * 学期，如“2025-2026-1”，表示学年与上下学期。
     */
    private String semester;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录课程占用数据首次录入时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;
}
