package com.campus.service.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 优惠券表。
 * 存储运营端发放的优惠券模板信息，包括优惠券名称、类型、门槛、面额/折扣、使用范围与有效期，
 * 供小程序端领取、使用与订单抵扣。
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("coupon") // 指定对应的数据库表名为 coupon
public class Coupon implements Serializable {

    // 序列化版本号，用于对象序列化/反序列化时保持一致
    private static final long serialVersionUID = 1L;

    /**
     * 优惠券主键，数据库自增 ID。
     */
    @TableId(type = IdType.AUTO) // 主键，使用数据库自增策略
    private Long id;

    /**
     * 优惠券名称，展示在用户卡券包与领取页面。
     */
    private String name;

    /**
     * 优惠券类型：1 满减券、2 折扣券。
     */
    private Integer couponType;

    /**
     * 满减门槛金额，订单金额达到该值方可使用优惠券。
     */
    private BigDecimal minAmount;

    /**
     * 优惠金额或折扣率。
     * 满减券表示减免金额；折扣券表示折扣比例（如 0.85 表示 85 折）。
     */
    private BigDecimal discountValue;

    /**
     * 使用范围：1 全部、2 外卖、3 二手、4 跑腿。
     */
    private Integer useScope;

    /**
     * 发行总量，该优惠券最多可发放多少张。
     */
    private Integer totalCount;

    /**
     * 已领取数量，用户领取优惠券时递增，用于判断库存是否充足。
     */
    private Integer usedCount;

    /**
     * 每人限领数量，防止单个用户恶意囤券。
     */
    private Integer perLimit;

    /**
     * 有效期开始时间，早于该时间优惠券不可用。
     */
    private LocalDateTime validStart;

    /**
     * 有效期结束时间，晚于该时间优惠券自动过期。
     */
    private LocalDateTime validEnd;

    /**
     * 优惠券状态：0 禁用、1 启用，控制是否可领取/使用。
     */
    private Integer status;

    /**
     * 逻辑删除标志：0 正常、1 已删除。
     */
    @TableLogic // MyBatis-Plus 逻辑删除字段注解
    private Integer isDelete;

    /**
     * 创建时间，记录优惠券模板首次创建时间。
     */
    @TableField(fill = FieldFill.INSERT) // 插入时自动填充当前时间
    private LocalDateTime createTime;

    /**
     * 更新时间，记录优惠券模板最后一次修改时间。
     */
    @TableField(fill = FieldFill.INSERT_UPDATE) // 插入和更新时自动填充当前时间
    private LocalDateTime updateTime;
}
