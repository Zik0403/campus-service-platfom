package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.Comment;

import java.util.List;

/**
 * 评论服务接口。
 * 负责校园生活服务平台中各内容模块的评论互动：学生可对二手商品、失物招领、
 * 帖子等目标发表评论，支持回复他人评论，也可删除自己的评论。
 */
public interface CommentService extends IService<Comment> {

    /**
     * 用户对指定目标内容发表评论或回复。
     * @param userId 发表评论的用户ID
     * @param targetType 评论目标类型（例如：1二手商品 2失物招领 3帖子等）
     * @param targetId 评论目标内容的ID
     * @param parentId 父评论ID，如果是回复某条评论则传入该评论ID；顶级评论传null或0
     * @param content 评论内容
     * @return 发布后的评论对象
     */
    Comment addComment(Long userId, Integer targetType, Long targetId, Long parentId, String content);

    /**
     * 查询指定目标内容下的所有评论列表（含回复）。
     * @param targetType 评论目标类型
     * @param targetId 评论目标内容的ID
     * @return 该目标内容下的评论列表
     */
    List<Comment> getComments(Integer targetType, Long targetId);

    /**
     * 用户删除自己发表的评论。
     * @param commentId 评论ID
     * @param userId 当前操作用户ID，用于校验评论是否属于本人
     */
    void deleteComment(Long commentId, Long userId);
}
