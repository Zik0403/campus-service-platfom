package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.common.constants.OrderStatus;
import com.campus.service.common.exception.BusinessException;
import com.campus.service.entity.LostFound;
import com.campus.service.entity.User;
import com.campus.service.mapper.LostFoundMapper;
import com.campus.service.service.LostFoundService;
import com.campus.service.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 失物招领服务实现类。
 * <p>
 * 负责校园失物招领模块的业务处理，包括发布寻物/招领信息、更新状态、
 * 按类型查询、失主匹配推荐、过期归档、点赞以及评论数统计等功能。
 * </p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LostFoundServiceImpl extends ServiceImpl<LostFoundMapper, LostFound> implements LostFoundService {

    /** 用户服务，用于校验用户权限、查询发布者信息。 */
    private final UserService userService;

    /**
     * 发布一条失物招领信息。
     *
     * @param userId    发布用户ID
     * @param type      信息类型（如寻物、招领）
     * @param goodsName 物品名称
     * @param goodsType 物品类别（如钱包、手机、书籍等）
     * @param location  丢失/拾取地点
     * @param feature   物品特征描述
     * @param contact   联系方式
     * @param images    物品图片地址
     * @return 保存成功后的失物招领对象，包含生成的记录ID
     */
    @Override
    @Transactional
    public LostFound createLostFound(Long userId, Integer type, String goodsName, String goodsType,
                                       String location, String feature, String contact, String images) {
        // 校验当前用户是否具备发布权限（如是否被封禁、是否已认证）
        userService.checkUserAuth(userId);
        // 创建一个新的失物招领实体对象
        LostFound lostFound = new LostFound();
        // 设置信息发布者
        lostFound.setUserId(userId);
        // 设置信息类型：寻物还是招领
        lostFound.setType(type);
        // 设置物品名称
        lostFound.setGoodsName(goodsName);
        // 设置物品类别
        lostFound.setGoodsType(goodsType);
        // 设置丢失或拾取地点
        lostFound.setLocation(location);
        // 设置物品特征描述，便于失主辨认
        lostFound.setFeature(feature);
        // 设置联系方式，方便双方沟通
        lostFound.setContact(contact);
        // 设置物品图片
        lostFound.setImages(images);
        // 新发布的信息默认状态为“进行中/待处理”
        lostFound.setStatus(OrderStatus.LOST_PENDING);
        // 初始化点赞数为0
        lostFound.setLikeNum(0);
        // 初始化评论数为0
        lostFound.setCommentNum(0);
        // 将失物招领数据插入 lost_found 表
        save(lostFound);
        // 记录发布日志，便于后续排查与审计
        log.info("发布失物招领: id={}, userId={}, type={}", lostFound.getId(), userId, type);
        // 返回保存后的失物招领对象
        return lostFound;
    }

    /**
     * 更新失物招领记录的状态（如已找到、已认领、已解决等）。
     *
     * @param id     失物招领记录ID
     * @param status 目标状态
     */
    @Override
    @Transactional
    public void updateStatus(Long id, Integer status) {
        // 根据记录ID从 lost_found 表查询失物招领记录
        LostFound lostFound = getById(id);
        // 若记录不存在，抛出“资源不存在”业务异常
        if (lostFound == null) {
            throw BusinessException.notFound();
        }
        // 将记录状态更新为目标状态
        lostFound.setStatus(status);
        // 更新 lost_found 表中对应记录的状态字段
        updateById(lostFound);
        // 记录状态更新日志
        log.info("更新失物状态: id={}, status={}", id, status);
    }

    /**
     * 查询指定用户发布的全部失物招领记录，按创建时间倒序排列。
     *
     * @param userId 用户ID
     * @return 该用户发布的失物招领列表
     */
    @Override
    public List<LostFound> getUserLostFound(Long userId) {
        // 构造查询条件：发布者ID等于指定用户，并按创建时间倒序
        return list(new LambdaQueryWrapper<LostFound>()
                .eq(LostFound::getUserId, userId)
                .orderByDesc(LostFound::getCreateTime));
    }

    /**
     * 按类型查询状态为“进行中”的失物招领记录，按创建时间倒序排列。
     *
     * @param type 信息类型（寻物/招领）
     * @return 符合条件的失物招领列表
     */
    @Override
    public List<LostFound> getByType(Integer type) {
        // 构造查询条件：指定类型、状态为进行中、按创建时间倒序
        return list(new LambdaQueryWrapper<LostFound>()
                .eq(LostFound::getType, type)
                .eq(LostFound::getStatus, OrderStatus.LOST_PENDING)
                .orderByDesc(LostFound::getCreateTime));
    }

    /**
     * 根据地点和物品类型为指定失物招领记录推荐匹配候选。
     * <p>
     * 例如：某条“寻物”信息可以匹配同地点、同物品类型的“招领”信息。
     * </p>
     *
     * @param lostFoundId 待匹配的失物招领记录ID
     * @return 匹配候选列表
     */
    @Override
    public List<LostFound> getMatchCandidates(Long lostFoundId) {
        // 根据记录ID从 lost_found 表查询当前失物招领记录
        LostFound lostFound = getById(lostFoundId);
        // 若记录不存在，抛出“资源不存在”业务异常
        if (lostFound == null) {
            throw BusinessException.notFound();
        }
        // 构造查询条件：同地点、同物品类型、排除发布者本人、状态为进行中，并按创建时间倒序
        return list(new LambdaQueryWrapper<LostFound>()
                .eq(LostFound::getLocation, lostFound.getLocation())
                .eq(LostFound::getGoodsType, lostFound.getGoodsType())
                .ne(LostFound::getUserId, lostFound.getUserId())
                .eq(LostFound::getStatus, OrderStatus.LOST_PENDING)
                .orderByDesc(LostFound::getCreateTime));
    }

    /**
     * 查看失物招领详情，并关联发布者用户信息。
     *
     * @param id     失物招领记录ID
     * @param userId 当前查看用户ID（预留，可用于后续权限扩展）
     * @return 包含发布者信息的失物招领详情对象
     */
    @Override
    public LostFound getDetail(Long id, Long userId) {
        // 根据记录ID从 lost_found 表查询失物招领记录
        LostFound lostFound = getById(id);
        // 若记录不存在，抛出“资源不存在”业务异常
        if (lostFound == null) {
            throw BusinessException.notFound();
        }
        // 查询发布者用户信息并封装到记录对象中，供前端展示头像、昵称等
        lostFound.setUser(userService.getById(lostFound.getUserId()));
        // 返回详情对象
        return lostFound;
    }

    /**
     * 将超过30天仍处于“进行中”状态的失物招领记录自动归档为“已过期”。
     */
    @Override
    @Transactional
    public void archiveExpired() {
        // 构造查询条件：状态为进行中且创建时间早于30天前，从 lost_found 表查询过期记录
        List<LostFound> expiredList = list(new LambdaQueryWrapper<LostFound>()
                .eq(LostFound::getStatus, OrderStatus.LOST_PENDING)
                .lt(LostFound::getCreateTime, LocalDateTime.now().minusDays(30)));
        // 遍历所有过期记录，将其状态更新为已过期
        for (LostFound lostFound : expiredList) {
            // 将记录状态设置为已过期
            lostFound.setStatus(OrderStatus.LOST_EXPIRED);
            // 更新 lost_found 表中对应记录的状态
            updateById(lostFound);
            // 记录归档日志
            log.info("失物过期归档: id={}", lostFound.getId());
        }
    }

    /**
     * 对指定失物招领记录进行点赞，点赞数加1。
     *
     * @param id     失物招领记录ID
     * @param userId 点赞用户ID
     */
    @Override
    @Transactional
    public void likeLostFound(Long id, Long userId) {
        // 根据记录ID从 lost_found 表查询失物招领记录
        LostFound lostFound = getById(id);
        // 若记录不存在，抛出“资源不存在”业务异常
        if (lostFound == null) {
            throw BusinessException.notFound();
        }
        // 将点赞数加1
        lostFound.setLikeNum(lostFound.getLikeNum() + 1);
        // 更新 lost_found 表中的点赞数字段
        updateById(lostFound);
        // 记录点赞日志
        log.info("点赞失物招领: id={}, userId={}", id, userId);
    }

    /**
     * 增加指定失物招领记录的评论数，通常在新增评论后调用。
     *
     * @param id 失物招领记录ID
     */
    @Override
    @Transactional
    public void incrementCommentNum(Long id) {
        // 根据记录ID从 lost_found 表查询失物招领记录
        LostFound lostFound = getById(id);
        // 若记录存在，则将其评论数加1
        if (lostFound != null) {
            lostFound.setCommentNum(lostFound.getCommentNum() + 1);
            // 更新 lost_found 表中的评论数字段
            updateById(lostFound);
        }
    }
}
