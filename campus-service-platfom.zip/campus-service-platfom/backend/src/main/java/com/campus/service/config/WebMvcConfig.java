package com.campus.service.config;

import com.campus.service.security.AuthInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * ============================================================
 * 【Web MVC 配置类】
 * 作用：配置拦截器、跨域(CORS)、静态资源映射
 * 
 * 1. addInterceptors - 注册 JWT 登录拦截器
 *    - 拦截所有请求 /** 
 *    - 排除白名单：登录/注册/公告/商品列表等公开接口
 *    
 * 2. addCorsMappings - 配置跨域，允许微信小程序访问
 *    - 允许所有来源 (*)
 *    - 允许 GET/POST/PUT/DELETE/OPTIONS 方法
 *    
 * 3. addResourceHandlers - 配置上传文件访问路径
 *    - /uploads/** 映射到本地 uploads 文件夹
 * ============================================================
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final AuthInterceptor authInterceptor;

    public WebMvcConfig(AuthInterceptor authInterceptor) {
        this.authInterceptor = authInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/user/login",
                        "/user/register",
                        "/user/reset-password",
                        "/user/pay-password/reset",
                        "/notice/list",
                        "/notice/listByType",
                        "/notice/detail",
                        "/product/list",
                        "/product/detail",
                        "/product/search",
                        "/post/list",
                        "/post/detail",
                        "/lostfound/list",
                        "/lostfound/detail",
                        "/activity/list",
                        "/club/list",
                        "/club/detail",
                        "/uploads/**",
                        "/swagger-ui/**",
                        "/v3/api-docs/**",
                        "/doc.html",
                        "/webjars/**"
                );
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:" + System.getProperty("user.dir") + "/uploads/");
    }
}
