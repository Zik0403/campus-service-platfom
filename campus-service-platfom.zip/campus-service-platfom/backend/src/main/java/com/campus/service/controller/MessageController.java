package com.campus.service.controller;

import com.campus.service.entity.Message;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.MessageService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/message")
@RequiredArgsConstructor
public class MessageController {

    private final MessageService messageService;

    /**
     * 获取用户未读消息
     */
    @GetMapping("/unread")
    public R<List<Message>> getUnreadMessages(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(messageService.getUnreadMessages(userId));
    }

    /**
     * 标记消息已读
     */
    @PostMapping("/read")
    public R<Void> markAsRead(HttpServletRequest request, @RequestParam Long messageId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        messageService.markAsRead(userId, messageId);
        return R.success();
    }

    /**
     * 标记所有消息已读
     */
    @PostMapping("/read/all")
    public R<Void> markAllAsRead(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        messageService.markAllAsRead(userId);
        return R.success();
    }

    /**
     * 获取用户消息列表
     */
    @GetMapping("/list")
    public R<List<Message>> getUserMessages(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(messageService.getUserMessages(userId));
    }
}
