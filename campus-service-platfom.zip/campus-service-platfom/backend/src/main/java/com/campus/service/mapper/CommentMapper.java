package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 评论数据访问接口。
 *
 * <p>操作的数据库表为评论表，对应实体类为 {@link Comment}。
 * 主要负责校园生活中评论与回复的查询，例如查询某条帖子或商品下的所有评论、查询某条评论的回复。</p>
 */
@Mapper
public interface CommentMapper extends BaseMapper<Comment> {

    /**
     * 根据目标类型和目标 ID 查询该目标下的所有评论。
     *
     * @param targetType 评论目标类型，例如帖子、商品等
     * @param targetId 评论目标 ID
     * @return 该目标下的评论列表
     */
    List<Comment> selectByTarget(@Param("targetType") Integer targetType, @Param("targetId") Long targetId);

    /**
     * 根据父评论 ID 查询该评论的所有回复。
     *
     * @param parentId 父评论 ID
     * @return 该评论的回复列表
     */
    List<Comment> selectReplies(@Param("parentId") Long parentId);
}
