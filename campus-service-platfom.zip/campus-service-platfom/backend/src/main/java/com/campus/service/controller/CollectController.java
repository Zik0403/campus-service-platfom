package com.campus.service.controller;

import com.campus.service.entity.Collect;
import com.campus.service.security.AuthInterceptor;
import com.campus.service.service.CollectService;
import com.campus.service.vo.R;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/collect")
@RequiredArgsConstructor
public class CollectController {

    private final CollectService collectService;

    @PostMapping("/add")
    public R<Void> addCollect(HttpServletRequest request, @RequestBody Map<String, Object> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Integer targetType = ((Number) params.get("targetType")).intValue();
        Long targetId = ((Number) params.get("targetId")).longValue();
        collectService.addCollect(userId, targetType, targetId);
        return R.success();
    }

    @PostMapping("/remove")
    public R<Void> removeCollect(HttpServletRequest request, @RequestBody Map<String, Object> params) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        Integer targetType = ((Number) params.get("targetType")).intValue();
        Long targetId = ((Number) params.get("targetId")).longValue();
        collectService.removeCollect(userId, targetType, targetId);
        return R.success();
    }

    @GetMapping("/check")
    public R<Boolean> checkCollect(HttpServletRequest request,
                                   @RequestParam Integer targetType,
                                   @RequestParam Long targetId) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(collectService.isCollected(userId, targetType, targetId));
    }

    @GetMapping("/my/list")
    public R<List<Collect>> getUserCollects(HttpServletRequest request) {
        Long userId = (Long) request.getAttribute(AuthInterceptor.USER_ID_KEY);
        return R.success(collectService.getUserCollects(userId));
    }
}