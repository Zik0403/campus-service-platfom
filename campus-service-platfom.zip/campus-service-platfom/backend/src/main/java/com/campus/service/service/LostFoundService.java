package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.LostFound;

import java.util.List;

/**
 * 失物招领服务接口。
 * 负责校园内失物与寻物信息的发布、状态更新、智能匹配、浏览与互动：
 * 学生可以发布自己捡到或丢失的物品信息，也可以对信息进行点赞、评论和查看详情。
 */
public interface LostFoundService extends IService<LostFound> {

    /**
     * 学生发布一条失物招领或寻物启事。
     * @param userId 发布用户ID
     * @param type 信息类型（例如：1失物招领 2寻物启事）
     * @param goodsName 物品名称
     * @param goodsType 物品分类（例如：钱包、手机、书籍、校园卡等）
     * @param location 丢失或捡到的地点
     * @param feature 物品特征描述
     * @param contact 联系方式
     * @param images 物品图片地址，多张图片通常以逗号分隔
     * @return 发布后的失物招领记录
     */
    LostFound createLostFound(Long userId, Integer type, String goodsName, String goodsType,
                              String location, String feature, String contact, String images);

    /**
     * 更新失物招领信息的状态（例如：待认领、已认领、已关闭）。
     * @param id 失物招领记录ID
     * @param status 新的状态值
     */
    void updateStatus(Long id, Integer status);

    /**
     * 查询某位学生发布的所有失物招领信息。
     * @param userId 用户ID
     * @return 该用户发布的失物招领列表
     */
    List<LostFound> getUserLostFound(Long userId);

    /**
     * 按信息类型查询失物招领列表。
     * @param type 信息类型（例如：1失物招领 2寻物启事）
     * @return 该类型的失物招领列表
     */
    List<LostFound> getByType(Integer type);

    /**
     * 为某条失物招领信息智能推荐可能匹配的候选记录。
     * @param lostFoundId 失物招领记录ID
     * @return 智能匹配到的候选列表
     */
    List<LostFound> getMatchCandidates(Long lostFoundId);

    /**
     * 查询某条失物招领的详细信息。
     * @param id 失物招领记录ID
     * @param userId 当前查看用户ID，用于记录浏览或权限校验
     * @return 失物招领详情对象
     */
    LostFound getDetail(Long id, Long userId);

    /**
     * 将发布时间过久仍未处理的失物招领信息进行归档。
     */
    void archiveExpired();

    /**
     * 用户对某条失物招领信息点赞或取消点赞。
     * @param id 失物招领记录ID
     * @param userId 当前操作用户ID
     */
    void likeLostFound(Long id, Long userId);

    /**
     * 当某条失物招领信息新增评论时，增加其评论数量。
     * @param id 失物招领记录ID
     */
    void incrementCommentNum(Long id);
}
