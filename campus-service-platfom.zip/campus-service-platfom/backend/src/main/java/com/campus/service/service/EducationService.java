package com.campus.service.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.campus.service.entity.CourseSchedule;
import com.campus.service.entity.Exam;
import com.campus.service.entity.Score;
import com.campus.service.entity.Classroom;
import com.campus.service.entity.ClassroomReservation;

import java.util.List;
import java.util.Map;

/**
 * 教务教学服务接口。
 * 负责学生在校期间与教务相关的信息查询与办事服务：包括课表查询、成绩查询、考试安排、
 * 空教室查询以及教室预约等，方便学生安排学习与自习。
 */
public interface EducationService extends IService<CourseSchedule> {

    /**
     * 查询学生某学期的课程表。
     * @param studentId 学生学号
     * @param semester 学期（例如：2024-2025-1）
     * @return 该学生该学期的课程安排列表
     */
    List<CourseSchedule> getCourseSchedule(String studentId, String semester);

    /**
     * 查询学生某学期的成绩列表。
     * @param studentId 学生学号
     * @param semester 学期
     * @return 该学生该学期的成绩列表
     */
    List<Score> getScoreList(String studentId, String semester);

    /**
     * 汇总学生的成绩信息，例如平均分、学分绩点、挂科数等。
     * @param studentId 学生学号
     * @return 成绩汇总数据
     */
    Map<String, Object> getScoreSummary(String studentId);

    /**
     * 查询指定条件下没有课程安排的空闲教室。
     * @param building 教学楼名称
     * @param weekDay 星期几（例如：1表示周一，7表示周日）
     * @param section 节次（例如：第1节、第2节）
     * @return 符合条件的空闲教室列表
     */
    List<Classroom> getEmptyClassrooms(String building, Integer weekDay, Integer section);

    /**
     * 查询指定条件下已经被占用的教室情况。
     * @param building 教学楼名称
     * @param weekDay 星期几
     * @param section 节次
     * @return 占用教室信息列表
     */
    List<Map<String, Object>> getOccupiedClassrooms(String building, Integer weekDay, Integer section);

    /**
     * 查询学生某学期的考试安排。
     * @param studentId 学生学号
     * @param semester 学期
     * @return 该学生该学期的考试安排列表
     */
    List<Exam> getExamList(String studentId, String semester);

    /**
     * 查询某位学生发起的所有教室预约记录。
     * @param userId 学生用户ID
     * @return 教室预约记录列表
     */
    List<ClassroomReservation> getClassroomReservations(Long userId);

    /**
     * 学生预约空闲教室用于自习、班会等活动。
     * @param userId 预约学生用户ID
     * @param classroomId 教室ID
     * @param reserveDate 预约日期
     * @param sectionStart 开始节次
     * @param sectionEnd 结束节次
     * @param purpose 预约用途说明
     * @param peopleCount 预计使用人数
     * @return 生成的教室预约记录
     */
    ClassroomReservation reserveClassroom(Long userId, Long classroomId, String reserveDate,
                                          Integer sectionStart, Integer sectionEnd,
                                          String purpose, Integer peopleCount);

    /**
     * 学生取消自己的教室预约。
     * @param userId 预约学生用户ID
     * @param reservationId 教室预约记录ID
     */
    void cancelClassroomReservation(Long userId, Long reservationId);
}
