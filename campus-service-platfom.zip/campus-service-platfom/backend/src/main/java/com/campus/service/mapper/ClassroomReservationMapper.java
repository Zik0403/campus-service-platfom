package com.campus.service.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.service.entity.ClassroomReservation;
import org.apache.ibatis.annotations.Mapper;

/**
 * 教室预约数据访问接口。
 *
 * <p>操作的数据库表为教室预约表，对应实体类为 {@link ClassroomReservation}。
 * 主要负责学生或社团对教室的预约记录的增删改查，例如提交自习或活动用教室的申请。</p>
 */
@Mapper
public interface ClassroomReservationMapper extends BaseMapper<ClassroomReservation> {
}
