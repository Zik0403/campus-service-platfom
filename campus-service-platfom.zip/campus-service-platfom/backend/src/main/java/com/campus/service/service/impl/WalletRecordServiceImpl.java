package com.campus.service.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.campus.service.entity.WalletRecord;
import com.campus.service.mapper.WalletRecordMapper;
import com.campus.service.service.WalletRecordService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 钱包流水服务实现类。
 * <p>
 * 负责校园生活服务系统中用户钱包流水记录的查询业务，
 * 钱包流水用于记录用户账户余额的收入、支出及余额变动明细，
 * 为余额对账和资金追溯提供数据支持。
 * </p>
 */
@Service
@RequiredArgsConstructor
public class WalletRecordServiceImpl extends ServiceImpl<WalletRecordMapper, WalletRecord> implements WalletRecordService {

    /**
     * 查询指定用户的全部钱包流水记录，按创建时间倒序排列。
     *
     * @param userId 用户 ID
     * @return 该用户的钱包流水记录列表，最新的记录排在最前面
     */
    @Override
    public List<WalletRecord> getUserRecords(Long userId) {
        // 构造查询条件：按用户 ID 查询钱包流水表，并按创建时间倒序排列
        return list(new LambdaQueryWrapper<WalletRecord>()
                .eq(WalletRecord::getUserId, userId)
                .orderByDesc(WalletRecord::getCreateTime));
    }
}
