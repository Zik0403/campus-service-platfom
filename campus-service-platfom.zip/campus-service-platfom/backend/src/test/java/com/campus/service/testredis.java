package com.campus.service;

import com.campus.service.entity.User;
import com.campus.service.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;

@SpringBootTest
public class testredis {
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    @Autowired
    private UserMapper userMapper;
    @Test
    public  void testwriteRedis(){
        redisTemplate.opsForValue().set("token:blacklist:test123", "1");
        System.out.println("写入Redis成功");
    }
    @Test
    public  void testSimulateLogout(){
        // 模拟一个真实jwt token字符串
        String mockToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9_demo_token_111";
        // 和项目logout业务代码一模一样，写入黑名单
        redisTemplate.opsForValue().set("token:blacklist:" + mockToken,"1");
        System.out.println("模拟退出登录，token存入黑名单完成");
    }
    @Test
    public void testMPselect(){
        User user = userMapper.selectById(1L);
        System.out.println(user);
    }

}
