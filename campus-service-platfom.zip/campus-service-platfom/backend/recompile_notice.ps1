$ErrorActionPreference = "Stop"

$JAVA_HOME = "C:\Program Files\Java\latest\jdk-25"
$BACKEND_DIR = "e:\校园生活服务小程序\backend"
$MAVEN_REPO = "$env:USERPROFILE\.m2\repository"

Write-Host "=== Recompiling NoticeController ==="

# Build classpath from all jars in maven repo
$jars = Get-ChildItem -Path $MAVEN_REPO -Filter "*.jar" -Recurse | Select-Object -ExpandProperty FullName
$jarString = ($jars -join ";") + ";$BACKEND_DIR\target\classes"

Write-Host "Compiling NoticeController.java..."

& "$JAVA_HOME\bin\javac.exe" `
    -cp "$jarString" `
    -d "$BACKEND_DIR\target\classes" `
    "$BACKEND_DIR\src\main\java\com\campus\service\controller\NoticeController.java"

if ($LASTEXITCODE -eq 0) {
    Write-Host "Compilation successful!"
    
    # Verify the compiled class has the new method
    $classFile = "$BACKEND_DIR\target\classes\com\campus\service\controller\NoticeController.class"
    if (Test-Path $classFile) {
        Write-Host "Class file updated: $classFile"
        Write-Host "File size: $((Get-Item $classFile).Length) bytes"
    }
} else {
    Write-Host "Compilation failed!"
    exit 1
}