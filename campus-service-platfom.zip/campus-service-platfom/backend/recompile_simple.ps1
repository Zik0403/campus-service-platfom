$ErrorActionPreference = "Stop"

$JAVA_HOME = "C:\Program Files\Java\latest\jdk-25"
$BACKEND_DIR = "e:\校园生活服务小程序\backend"
$TEMP_DIR = "C:\temp_compile_notice"
$JAR_PATH = "$BACKEND_DIR\target\campus-service-1.0.0.jar"

Write-Host "=== Setting up compilation environment ==="

# Create temp directory
if (Test-Path $TEMP_DIR) { Remove-Item -Recurse -Force $TEMP_DIR }
New-Item -ItemType Directory -Path $TEMP_DIR | Out-Null

# Copy jar to temp dir (avoid Chinese path issue)
$TEMP_JAR = "$TEMP_DIR\app.jar"
Copy-Item $JAR_PATH $TEMP_JAR

# Extract jar using PowerShell (jar.exe has encoding issues with Chinese paths)
Write-Host "Extracting jar..."
Expand-Archive -Path $TEMP_JAR -DestinationPath $TEMP_DIR -Force

# Build classpath from extracted lib
$libJars = Get-ChildItem -Path "$TEMP_DIR\BOOT-INF\lib" -Filter "*.jar" | Select-Object -ExpandProperty FullName
$cp = ($libJars -join ";") + ";$TEMP_DIR\BOOT-INF\classes"

Write-Host "Classpath jars count: $($libJars.Count)"

# Also add target/classes for project classes
$cp += ";$BACKEND_DIR\target\classes"

Write-Host "Compiling NoticeController..."
$srcFile = "$BACKEND_DIR\src\main\java\com\campus\service\controller\NoticeController.java"
& "$JAVA_HOME\bin\javac.exe" -cp "$cp" -d "$TEMP_DIR\BOOT-INF\classes" "$srcFile"

if ($LASTEXITCODE -eq 0) {
    Write-Host "Compilation successful!"
    
    # Update jar with new class
    Write-Host "Updating jar..."
    Push-Location $TEMP_DIR
    & "$JAVA_HOME\bin\jar.exe" uf "$TEMP_JAR" "BOOT-INF\classes\com\campus\service\controller\NoticeController.class"
    Pop-Location
    
    # Copy updated jar back
    Copy-Item $TEMP_JAR $JAR_PATH -Force
    
    Write-Host "Jar updated successfully!"
    
    # Cleanup
    Remove-Item -Recurse -Force $TEMP_DIR
} else {
    Write-Host "Compilation failed!"
}