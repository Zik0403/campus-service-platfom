@echo off
setlocal enabledelayedexpansion

set BASE_DIR=%~dp0
set JAVA_HOME=C:\Program Files\Java\latest\jdk-25
set MAVEN_REPO=%USERPROFILE%\.m2\repository

echo Starting Campus Service with compiled classes...

set CLASSPATH=%BASE_DIR%target\classes

for /r "%MAVEN_REPO%" %%f in (*.jar) do (
    set CLASSPATH=!CLASSPATH!;%%f
)

echo Classpath built successfully.
echo Starting application...

"%JAVA_HOME%\bin\java.exe" -cp "%CLASSPATH%" com.campus.service.CampusServiceApplication

endlocal
