-- ============================================================
-- Quartz 持久化建表脚本（MySQL InnoDB）
-- ============================================================
-- 适用版本：Quartz 2.3.x
-- 执行说明：
--   1. 在 campus_db 数据库中执行本脚本；
--   2. 表名前缀统一为 QRTZ_，与 QuartzConfig 中的 tablePrefix 配置一致；
--   3. 执行完成后启动后端，Spring 会自动将 OrderTimeoutQuartzJob 注册到 QRTZ 表中。
-- ============================================================

-- 如果已存在旧表，先删除（首次执行可忽略）
DROP TABLE IF EXISTS `QRTZ_TRIGGERS`;
DROP TABLE IF EXISTS `QRTZ_JOB_DETAILS`;
DROP TABLE IF EXISTS `QRTZ_SIMPLE_TRIGGERS`;
DROP TABLE IF EXISTS `QRTZ_CRON_TRIGGERS`;
DROP TABLE IF EXISTS `QRTZ_SIMPROP_TRIGGERS`;
DROP TABLE IF EXISTS `QRTZ_BLOB_TRIGGERS`;
DROP TABLE IF EXISTS `QRTZ_CALENDARS`;
DROP TABLE IF EXISTS `QRTZ_PAUSED_TRIGGER_GRPS`;
DROP TABLE IF EXISTS `QRTZ_SCHEDULER_STATE`;
DROP TABLE IF EXISTS `QRTZ_LOCKS`;
DROP TABLE IF EXISTS `QRTZ_FIRED_TRIGGERS`;

-- ------------------------------------------------------------
-- 1. 任务详情表：保存每个 Job 的类名、描述、是否持久化等元数据
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_JOB_DETAILS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `JOB_NAME` VARCHAR(200) NOT NULL COMMENT '任务名称',
    `JOB_GROUP` VARCHAR(200) NOT NULL COMMENT '任务分组',
    `DESCRIPTION` VARCHAR(250) NULL COMMENT '任务描述',
    `JOB_CLASS_NAME` VARCHAR(250) NOT NULL COMMENT '任务类全限定名',
    `IS_DURABLE` VARCHAR(1) NOT NULL COMMENT '是否持久化（没有触发器也保留）',
    `IS_NONCONCURRENT` VARCHAR(1) NOT NULL COMMENT '是否禁止并发执行',
    `IS_UPDATE_DATA` VARCHAR(1) NOT NULL COMMENT '是否更新 JobDataMap',
    `REQUESTS_RECOVERY` VARCHAR(1) NOT NULL COMMENT '故障恢复时是否重新执行',
    `JOB_DATA` BLOB NULL COMMENT 'Job 数据（序列化）',
    PRIMARY KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz 任务详情表';

-- ------------------------------------------------------------
-- 2. 触发器表：保存每个 Trigger 与 Job 的关联关系
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_TRIGGERS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `TRIGGER_NAME` VARCHAR(200) NOT NULL COMMENT '触发器名称',
    `TRIGGER_GROUP` VARCHAR(200) NOT NULL COMMENT '触发器分组',
    `JOB_NAME` VARCHAR(200) NOT NULL COMMENT '关联的任务名称',
    `JOB_GROUP` VARCHAR(200) NOT NULL COMMENT '关联的任务分组',
    `DESCRIPTION` VARCHAR(250) NULL COMMENT '触发器描述',
    `NEXT_FIRE_TIME` BIGINT(13) NULL COMMENT '下次触发时间戳',
    `PREV_FIRE_TIME` BIGINT(13) NULL COMMENT '上次触发时间戳',
    `PRIORITY` INTEGER NULL COMMENT '优先级',
    `TRIGGER_STATE` VARCHAR(16) NOT NULL COMMENT '触发器状态（WAITING、ACQUIRED 等）',
    `TRIGGER_TYPE` VARCHAR(8) NOT NULL COMMENT '触发器类型（CRON、SIMPLE 等）',
    `START_TIME` BIGINT(13) NOT NULL COMMENT '开始时间戳',
    `END_TIME` BIGINT(13) NULL COMMENT '结束时间戳',
    `CALENDAR_NAME` VARCHAR(200) NULL COMMENT '关联的日历名称',
    `MISFIRE_INSTR` SMALLINT(2) NULL COMMENT 'Misfire 策略',
    `JOB_DATA` BLOB NULL COMMENT 'Trigger 数据（序列化）',
    PRIMARY KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`),
    FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `QRTZ_JOB_DETAILS`(`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz 触发器表';

-- ------------------------------------------------------------
-- 3. Simple 触发器表
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_SIMPLE_TRIGGERS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `TRIGGER_NAME` VARCHAR(200) NOT NULL COMMENT '触发器名称',
    `TRIGGER_GROUP` VARCHAR(200) NOT NULL COMMENT '触发器分组',
    `REPEAT_COUNT` BIGINT(7) NOT NULL COMMENT '重复次数',
    `REPEAT_INTERVAL` BIGINT(12) NOT NULL COMMENT '重复间隔（毫秒）',
    `TIMES_TRIGGERED` BIGINT(10) NOT NULL COMMENT '已触发次数',
    PRIMARY KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`),
    FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS`(`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz Simple 触发器表';

-- ------------------------------------------------------------
-- 4. Cron 触发器表
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_CRON_TRIGGERS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `TRIGGER_NAME` VARCHAR(200) NOT NULL COMMENT '触发器名称',
    `TRIGGER_GROUP` VARCHAR(200) NOT NULL COMMENT '触发器分组',
    `CRON_EXPRESSION` VARCHAR(200) NOT NULL COMMENT 'Cron 表达式',
    `TIME_ZONE_ID` VARCHAR(80) COMMENT '时区 ID',
    PRIMARY KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`),
    FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS`(`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz Cron 触发器表';

-- ------------------------------------------------------------
-- 5. Calendar 触发器表
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_SIMPROP_TRIGGERS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL,
    `TRIGGER_NAME` VARCHAR(200) NOT NULL,
    `TRIGGER_GROUP` VARCHAR(200) NOT NULL,
    `STR_PROP_1` VARCHAR(512) NULL,
    `STR_PROP_2` VARCHAR(512) NULL,
    `STR_PROP_3` VARCHAR(512) NULL,
    `INT_PROP_1` INT NULL,
    `INT_PROP_2` INT NULL,
    `LONG_PROP_1` BIGINT NULL,
    `LONG_PROP_2` BIGINT NULL,
    `DEC_PROP_1` NUMERIC(13,4) NULL,
    `DEC_PROP_2` NUMERIC(13,4) NULL,
    `BOOL_PROP_1` VARCHAR(1) NULL,
    `BOOL_PROP_2` VARCHAR(1) NULL,
    `TIME_ZONE_ID` VARCHAR(80) NULL,
    PRIMARY KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`),
    FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS`(`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz Calendar Interval 触发器表';

-- ------------------------------------------------------------
-- 6. BLOB 触发器表：存储简单/Cron 以外触发器的 BLOB 数据
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_BLOB_TRIGGERS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `TRIGGER_NAME` VARCHAR(200) NOT NULL COMMENT '触发器名称',
    `TRIGGER_GROUP` VARCHAR(200) NOT NULL COMMENT '触发器分组',
    `BLOB_DATA` BLOB NULL COMMENT '触发器 BLOB 数据',
    PRIMARY KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`),
    FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS`(`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz BLOB 触发器表';

-- ------------------------------------------------------------
-- 7. 日历表：保存 Quartz 日历定义
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_CALENDARS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `CALENDAR_NAME` VARCHAR(200) NOT NULL COMMENT '日历名称',
    `CALENDAR` BLOB NOT NULL COMMENT '日历对象（序列化）',
    PRIMARY KEY (`SCHED_NAME`, `CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz 日历表';

-- ------------------------------------------------------------
-- 8. 暂停触发器组表
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_PAUSED_TRIGGER_GRPS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `TRIGGER_GROUP` VARCHAR(200) NOT NULL COMMENT '触发器分组',
    PRIMARY KEY (`SCHED_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz 暂停触发器组表';

-- ------------------------------------------------------------
-- 9. 调度器状态表：集群模式下记录每个实例的状态
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_SCHEDULER_STATE` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `INSTANCE_NAME` VARCHAR(200) NOT NULL COMMENT '实例名称',
    `LAST_CHECKIN_TIME` BIGINT(13) NOT NULL COMMENT '上次签到时间戳',
    `CHECKIN_INTERVAL` BIGINT(13) NOT NULL COMMENT '签到间隔（毫秒）',
    PRIMARY KEY (`SCHED_NAME`, `INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz 调度器状态表';

-- ------------------------------------------------------------
-- 10. 锁表：集群模式下用于并发控制
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_LOCKS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `LOCK_NAME` VARCHAR(40) NOT NULL COMMENT '锁名称',
    PRIMARY KEY (`SCHED_NAME`, `LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz 锁表';

-- ------------------------------------------------------------
-- 11. 已触发记录表：记录当前正在执行的触发器实例
-- ------------------------------------------------------------
CREATE TABLE `QRTZ_FIRED_TRIGGERS` (
    `SCHED_NAME` VARCHAR(120) NOT NULL COMMENT '调度器名称',
    `ENTRY_ID` VARCHAR(95) NOT NULL COMMENT '条目 ID',
    `TRIGGER_NAME` VARCHAR(200) NOT NULL COMMENT '触发器名称',
    `TRIGGER_GROUP` VARCHAR(200) NOT NULL COMMENT '触发器分组',
    `INSTANCE_NAME` VARCHAR(200) NOT NULL COMMENT '实例名称',
    `FIRED_TIME` BIGINT(13) NOT NULL COMMENT '触发时间戳',
    `SCHED_TIME` BIGINT(13) NOT NULL COMMENT '调度时间戳',
    `PRIORITY` INTEGER NOT NULL COMMENT '优先级',
    `STATE` VARCHAR(16) NOT NULL COMMENT '状态',
    `JOB_NAME` VARCHAR(200) NULL COMMENT '任务名称',
    `JOB_GROUP` VARCHAR(200) NULL COMMENT '任务分组',
    `IS_NONCONCURRENT` VARCHAR(1) NULL COMMENT '是否禁止并发',
    `REQUESTS_RECOVERY` VARCHAR(1) NULL COMMENT '是否请求恢复',
    PRIMARY KEY (`SCHED_NAME`, `ENTRY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Quartz 已触发记录表';

-- ------------------------------------------------------------
-- 初始化 Quartz 锁记录（必须）
-- ------------------------------------------------------------
INSERT INTO `QRTZ_LOCKS` (`SCHED_NAME`, `LOCK_NAME`) VALUES ('CampusPersistentScheduler', 'TRIGGER_ACCESS');
INSERT INTO `QRTZ_LOCKS` (`SCHED_NAME`, `LOCK_NAME`) VALUES ('CampusPersistentScheduler', 'JOB_ACCESS');
INSERT INTO `QRTZ_LOCKS` (`SCHED_NAME`, `LOCK_NAME`) VALUES ('CampusPersistentScheduler', 'CALENDAR_ACCESS');
INSERT INTO `QRTZ_LOCKS` (`SCHED_NAME`, `LOCK_NAME`) VALUES ('CampusPersistentScheduler', 'STATE_ACCESS');
INSERT INTO `QRTZ_LOCKS` (`SCHED_NAME`, `LOCK_NAME`) VALUES ('CampusPersistentScheduler', 'MISFIRE_ACCESS');
