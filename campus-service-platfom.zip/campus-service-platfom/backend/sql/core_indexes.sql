-- ============================================================
-- 校园生活服务平台核心表索引脚本
-- 说明：
--   1. 本脚本仅用于新建索引，不修改现有 Java 代码；
--   2. 执行前请确认相关列已存在，若索引已存在请忽略重复创建错误；
--   3. 索引命名规范：idx_表名_列名（单列）/ idx_表名_列1_列2（复合）。
-- ============================================================

-- -----------------------------
-- 1. user 用户表
-- -------------------------------
-- 登录时按学号/手机号/身份证号查询
ALTER TABLE `user` ADD INDEX idx_user_student_id (`student_id`);
ALTER TABLE `user` ADD INDEX idx_user_phone (`phone`);
ALTER TABLE `user` ADD INDEX idx_user_id_card (`id_card`);
-- 按角色和删除状态查询维修员/学生列表
ALTER TABLE `user` ADD INDEX idx_user_role_is_delete (`role`, `is_delete`);
-- 微信 openid 登录查询
ALTER TABLE `user` ADD INDEX idx_user_openid (`openid`);
-- 信用分排行榜
ALTER TABLE `user` ADD INDEX idx_user_credit_score (`credit_score` DESC);

-- -----------------------------
-- 2. service_order 服务订单表
-- -------------------------------
-- 按订单号查询详情
ALTER TABLE `service_order` ADD INDEX idx_service_order_order_no (`order_no`);
-- 用户查询自己的订单列表
ALTER TABLE `service_order` ADD INDEX idx_service_order_user_id (`user_id`);
-- 配送员查询自己的订单列表
ALTER TABLE `service_order` ADD INDEX idx_service_order_worker_id (`worker_id`);
-- 抢单大厅：按服务类型和状态查询待接单订单
ALTER TABLE `service_order` ADD INDEX idx_service_order_status_service_type (`status`, `service_type`);
-- 按订单状态查询（用于定时任务扫描超时订单）
ALTER TABLE `service_order` ADD INDEX idx_service_order_status_create_time (`status`, `create_time`);

-- -----------------------------
-- 3. second_order 二手交易订单表
-- -------------------------------
-- 买家/卖家查询自己的二手订单
ALTER TABLE `second_order` ADD INDEX idx_second_order_buyer_id (`buyer_id`);
ALTER TABLE `second_order` ADD INDEX idx_second_order_seller_id (`seller_id`);
-- 按商品 ID 查询相关订单
ALTER TABLE `second_order` ADD INDEX idx_second_order_product_id (`product_id`);
-- 按状态查询（用于超时取消定时任务）
ALTER TABLE `second_order` ADD INDEX idx_second_order_status_create_time (`status`, `create_time`);

-- -----------------------------
-- 4. second_product 二手商品表
-- -------------------------------
-- 按发布者查询商品
ALTER TABLE `second_product` ADD INDEX idx_second_product_user_id (`user_id`);
-- 按状态查询在售商品列表
ALTER TABLE `second_product` ADD INDEX idx_second_product_status (`status`);

-- -----------------------------
-- 5. activity 活动表
-- -------------------------------
-- 按社团查询活动
ALTER TABLE `activity` ADD INDEX idx_activity_club_id (`club_id`);
-- 查询可报名、待审核等活动列表（高频场景）
ALTER TABLE `activity` ADD INDEX idx_activity_audit_status_status (`audit_status`, `status`);
-- 按活动开始时间倒序查询
ALTER TABLE `activity` ADD INDEX idx_activity_start_time (`start_time` DESC);
-- 按报名截止时间查询
ALTER TABLE `activity` ADD INDEX idx_activity_enroll_deadline (`enroll_deadline`);

-- -----------------------------
-- 6. campus_notice 校园公告表
-- -------------------------------
-- 学生端查询已上线公告
ALTER TABLE `campus_notice` ADD INDEX idx_campus_notice_status_sort (`status`, `sort`);
-- 按公告类型查询已上线公告
ALTER TABLE `campus_notice` ADD INDEX idx_campus_notice_status_notice_type (`status`, `notice_type`);

-- -----------------------------
-- 7. repair_order 维修工单表
-- -------------------------------
-- 用户查询自己的报修工单
ALTER TABLE `repair_order` ADD INDEX idx_repair_order_user_id (`user_id`);
-- 维修员查询自己的工单
ALTER TABLE `repair_order` ADD INDEX idx_repair_order_worker_id (`worker_id`);
-- 按状态查询待处理工单
ALTER TABLE `repair_order` ADD INDEX idx_repair_order_status (`status`);

-- -----------------------------
-- 8. community_post 社区帖子表
-- -------------------------------
-- 按用户查询帖子
ALTER TABLE `community_post` ADD INDEX idx_community_post_user_id (`user_id`);
-- 按帖子类型和状态查询列表
ALTER TABLE `community_post` ADD INDEX idx_community_post_post_type_status (`post_type`, `status`);

-- -----------------------------
-- 9. comment 评论表
-- -------------------------------
-- 按帖子查询评论列表
ALTER TABLE `comment` ADD INDEX idx_comment_post_id (`post_id`);
-- 按用户查询评论
ALTER TABLE `comment` ADD INDEX idx_comment_user_id (`user_id`);

-- -----------------------------
-- 10. collect 收藏表
-- -------------------------------
-- 按用户查询收藏列表
ALTER TABLE `collect` ADD INDEX idx_collect_user_id (`user_id`);
-- 按帖子查询收藏（可用于判断用户是否收藏）
ALTER TABLE `collect` ADD INDEX idx_collect_post_id (`post_id`);

-- -----------------------------
-- 11. lost_found 失物招领表
-- -------------------------------
-- 按用户查询
ALTER TABLE `lost_found` ADD INDEX idx_lost_found_user_id (`user_id`);
-- 按类型和状态查询列表
ALTER TABLE `lost_found` ADD INDEX idx_lost_found_type_status (`type`, `status`);

-- -----------------------------
-- 12. club_member 社团成员表
-- -------------------------------
-- 按社团查询成员
ALTER TABLE `club_member` ADD INDEX idx_club_member_club_id (`club_id`);
-- 按用户查询加入的社团
ALTER TABLE `club_member` ADD INDEX idx_club_member_user_id (`user_id`);

-- -----------------------------
-- 13. activity_enroll 活动报名表
-- -------------------------------
-- 按活动查询报名列表
ALTER TABLE `activity_enroll` ADD INDEX idx_activity_enroll_activity_id (`activity_id`);
-- 按用户查询报名记录
ALTER TABLE `activity_enroll` ADD INDEX idx_activity_enroll_user_id (`user_id`);

-- -----------------------------
-- 14. library_book 图书表
-- -------------------------------
-- 按 ISBN 查询图书
ALTER TABLE `library_book` ADD INDEX idx_library_book_isbn (`isbn`);
-- 按图书名称模糊搜索
ALTER TABLE `library_book` ADD INDEX idx_library_book_title (`title`);

-- -----------------------------
-- 15. borrow_record 借阅记录表
-- -------------------------------
-- 按用户查询借阅记录
ALTER TABLE `borrow_record` ADD INDEX idx_borrow_record_user_id (`user_id`);
-- 按图书查询借阅记录
ALTER TABLE `borrow_record` ADD INDEX idx_borrow_record_book_id (`book_id`);
-- 按借阅状态查询逾期未还等记录
ALTER TABLE `borrow_record` ADD INDEX idx_borrow_record_status (`status`);

-- -----------------------------
-- 16. book_reservation 图书预约表
-- -------------------------------
ALTER TABLE `book_reservation` ADD INDEX idx_book_reservation_user_id (`user_id`);
ALTER TABLE `book_reservation` ADD INDEX idx_book_reservation_book_id (`book_id`);
ALTER TABLE `book_reservation` ADD INDEX idx_book_reservation_status (`status`);

-- -----------------------------
-- 17. seat_reservation 座位预约表
-- -------------------------------
ALTER TABLE `seat_reservation` ADD INDEX idx_seat_reservation_user_id (`user_id`);
ALTER TABLE `seat_reservation` ADD INDEX idx_seat_reservation_seat_id (`seat_id`);
ALTER TABLE `seat_reservation` ADD INDEX idx_seat_reservation_status (`status`);

-- -----------------------------
-- 18. wallet_record 钱包流水表
-- -------------------------------
-- 按用户查询钱包流水
ALTER TABLE `wallet_record` ADD INDEX idx_wallet_record_user_id (`user_id`);
-- 按业务类型查询流水
ALTER TABLE `wallet_record` ADD INDEX idx_wallet_record_biz_type (`biz_type`);

-- -----------------------------
-- 19. user_bank_card 用户银行卡表
-- -------------------------------
ALTER TABLE `user_bank_card` ADD INDEX idx_user_bank_card_user_id (`user_id`);

-- -----------------------------
-- 20. message 消息表
-- -------------------------------
-- 按接收用户查询消息列表
ALTER TABLE `message` ADD INDEX idx_message_to_user_id (`to_user_id`);
-- 按消息状态查询未读消息
ALTER TABLE `message` ADD INDEX idx_message_to_user_id_is_read (`to_user_id`, `is_read`);
