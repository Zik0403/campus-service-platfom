const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, HeadingLevel, ShadingType, LevelFormat } = require('docx');
const markdownIt = require('markdown-it');

const md = markdownIt();

async function convertFile(inputPath, outputPath, title) {
  const mdContent = fs.readFileSync(inputPath, 'utf-8');
  const tokens = md.parse(mdContent, {});

  const children = [];
  let currentListLevel = 0;

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];

    // 标题
    if (token.type === 'heading_open') {
      const level = parseInt(token.tag.replace('h', ''));
      i++;
      const text = tokens[i]?.content || '';
      i++; // heading_close
      const headingMap = { 1: HeadingLevel.HEADING_1, 2: HeadingLevel.HEADING_2, 3: HeadingLevel.HEADING_3, 4: HeadingLevel.HEADING_4 };
      children.push(new Paragraph({ text, heading: headingMap[level] || HeadingLevel.HEADING_2, spacing: { before: 240, after: 120 } }));
      continue;
    }

    // 分隔线
    if (token.type === 'hr') {
      children.push(new Paragraph({ text: '', spacing: { before: 200, after: 200 }, border: { bottom: { color: 'AAAAAA', space: 1, size: 6, style: 'single' } } }));
      continue;
    }

    // 表格
    if (token.type === 'table_open') {
      const rows = [];
      i++; // table_open
      
      // 解析thead
      if (tokens[i]?.type === 'thead_open') i++;
      if (tokens[i]?.type === 'tr_open') {
        const headerCells = [];
        i++; // tr_open
        while (tokens[i]?.type !== 'tr_close') {
          if (tokens[i]?.type === 'th_open') {
            i++; // th_open
            let cellText = '';
            while (tokens[i]?.type !== 'th_close') {
              if (tokens[i]?.type === 'inline') cellText = tokens[i].content || '';
              i++;
            }
            i++; // th_close
            headerCells.push(cellText);
          } else i++;
        }
        i++; // tr_close
        rows.push({ cells: headerCells, isHeader: true });
      }
      if (tokens[i]?.type === 'thead_close') i++;
      
      // 解析tbody
      if (tokens[i]?.type === 'tbody_open') i++;
      while (tokens[i]?.type === 'tr_open') {
        const bodyCells = [];
        i++; // tr_open
        while (tokens[i]?.type !== 'tr_close') {
          if (tokens[i]?.type === 'td_open') {
            i++; // td_open
            let cellText = '';
            while (tokens[i]?.type !== 'td_close') {
              if (tokens[i]?.type === 'inline') cellText = tokens[i].content || '';
              i++;
            }
            i++; // td_close
            bodyCells.push(cellText);
          } else i++;
        }
        i++; // tr_close
        rows.push({ cells: bodyCells, isHeader: false });
      }
      if (tokens[i]?.type === 'tbody_close') i++;
      if (tokens[i]?.type === 'table_close') i++;

      if (rows.length > 0) {
        const colCount = rows[0].cells.length;
        const docRows = rows.map((row, rowIdx) => new TableRow({
          children: row.cells.map(text => new TableCell({
            children: [new Paragraph({
              children: [new TextRun({ text, bold: row.isHeader, size: 20, font: '宋体' })],
              spacing: { before: 40, after: 40 },
            })],
            width: { size: Math.floor(9000 / colCount), type: WidthType.DXA },
            shading: row.isHeader ? { type: ShadingType.SOLID, color: 'D9E2F3', fill: 'D9E2F3' } : undefined,
          })),
        }));
        children.push(new Table({ rows: docRows, width: { size: 100, type: WidthType.PERCENTAGE } }));
        children.push(new Paragraph({ text: '', spacing: { after: 120 } }));
      }
      continue;
    }

    // 代码块
    if (token.type === 'code_block' || token.type === 'fence') {
      const code = token.content || '';
      code.split('\n').forEach(line => {
        children.push(new Paragraph({
          children: [new TextRun({ text: line || ' ', font: 'Consolas', size: 18 })],
          spacing: { before: 20, after: 20 },
          shading: { type: ShadingType.SOLID, color: 'F5F5F5', fill: 'F5F5F5' },
        }));
      });
      children.push(new Paragraph({ text: '', spacing: { after: 80 } }));
      continue;
    }

    // 有序/无序列表
    if (token.type === 'bullet_list_open' || token.type === 'ordered_list_open') {
      const isOrdered = token.type === 'ordered_list_open';
      let itemNum = 1;
      i++;
      while (tokens[i]?.type !== 'bullet_list_close' && tokens[i]?.type !== 'ordered_list_close') {
        if (tokens[i]?.type === 'list_item_open') {
          i++;
          let itemText = '';
          while (tokens[i]?.type !== 'list_item_close') {
            if (tokens[i]?.type === 'paragraph_open') i++;
            if (tokens[i]?.type === 'inline') { itemText = tokens[i].content || ''; i++; }
            if (tokens[i]?.type === 'paragraph_close') i++;
            if (tokens[i]?.type === 'code_inline') { itemText += ' ' + tokens[i].content; i++; }
            if (tokens[i]?.type !== 'list_item_close' && tokens[i]?.type !== 'paragraph_close' && tokens[i]?.type !== 'inline') i++;
          }
          i++; // list_item_close
          const prefix = isOrdered ? `${itemNum}. ` : '• ';
          children.push(new Paragraph({
            children: [new TextRun({ text: prefix + itemText, size: 21, font: '宋体' })],
            indent: { left: 360 },
            spacing: { before: 40, after: 40 },
          }));
          if (isOrdered) itemNum++;
        } else i++;
      }
      i++; // list_close
      continue;
    }

    // 段落
    if (token.type === 'paragraph_open') {
      i++; // paragraph_open
      if (tokens[i]?.type === 'inline') {
        const inlineContent = tokens[i].content || '';
        // 处理粗体和代码
        const parts = inlineContent.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).filter(Boolean);
        const runs = parts.map(part => {
          if (part.startsWith('**') && part.endsWith('**')) {
            return new TextRun({ text: part.slice(2, -2), bold: true, size: 21, font: '宋体' });
          } else if (part.startsWith('`') && part.endsWith('`')) {
            return new TextRun({ text: part.slice(1, -1), font: 'Consolas', size: 20 });
          } else {
            return new TextRun({ text: part, size: 21, font: '宋体' });
          }
        });
        children.push(new Paragraph({ children: runs, spacing: { before: 60, after: 60 } }));
        i++; // inline
      }
      i++; // paragraph_close
      continue;
    }

    // 引用块
    if (token.type === 'blockquote_open') {
      i++;
      while (tokens[i]?.type !== 'blockquote_close') {
        if (tokens[i]?.type === 'paragraph_open') i++;
        if (tokens[i]?.type === 'inline') {
          children.push(new Paragraph({
            children: [new TextRun({ text: tokens[i].content, italics: true, size: 21, font: '宋体' })],
            indent: { left: 720 },
            spacing: { before: 40, after: 40 },
          }));
          i++;
        }
        if (tokens[i]?.type === 'paragraph_close') i++;
        if (tokens[i]?.type !== 'blockquote_close') i++;
      }
      i++; // blockquote_close
      continue;
    }

    // 其他token跳过
  }

  const doc = new Document({
    creator: '校园生活服务小程序项目组',
    title: title,
    styles: {
      default: {
        document: { run: { size: 21, font: '宋体' } },
        heading1: { run: { size: 32, bold: true, font: '黑体', color: '1F4E79' }, paragraph: { spacing: { before: 360, after: 200 } } },
        heading2: { run: { size: 28, bold: true, font: '黑体', color: '2E75B6' }, paragraph: { spacing: { before: 280, after: 160 } } },
        heading3: { run: { size: 24, bold: true, font: '黑体', color: '404040' }, paragraph: { spacing: { before: 200, after: 120 } } },
      },
    },
    sections: [{
      properties: { page: { margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } } },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({ text: title, bold: true, size: 40, font: '黑体', color: '1F4E79' })],
          spacing: { after: 400 },
        }),
        ...children,
      ],
    }],
  });

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outputPath, buffer);
  console.log('生成: ' + outputPath);
}

async function main() {
  const base = 'e:\\校园生活服务小程序\\docs\\';
  await convertFile(base + '附件2-软件设计说明书.md', base + '附件2-软件设计说明书.docx', '附件2：软件设计说明书');
  await convertFile(base + '附件3-测试用例与测试报告.md', base + '附件3-测试用例与测试报告.docx', '附件3：测试用例与测试报告');
  await convertFile(base + '附件4-用户使用说明书.md', base + '附件4-用户使用说明书.docx', '附件4：用户使用说明书');
  console.log('全部完成!');
}

main().catch(err => { console.error(err); process.exit(1); });