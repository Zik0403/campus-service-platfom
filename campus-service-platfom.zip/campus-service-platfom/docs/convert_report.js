const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, HeadingLevel, ShadingType, BorderStyle, PageNumber, Footer, Header, LevelFormat, LineRuleType } = require('docx');

// 字号换算（单位：半磅）
// 小三号 = 15磅 = 30
// 四号 = 14磅 = 28
// 小四号 = 12磅 = 24
// 五号 = 10.5磅 = 21
const FONT_SIZE = {
  HEADING1: 30,    // 小三号
  HEADING2: 28,    // 四号
  HEADING3: 24,    // 小四号
  BODY: 24,        // 小四号
  FOOTER: 21,      // 五号
  TABLE: 21,       // 表格内容五号
  CAPTION: 21,     // 图表标题五号
};

function parseMarkdownToDocx(mdText) {
  const lines = mdText.split('\n');
  const elements = [];
  let i = 0;
  let tableCount = 0;
  let figureCount = 0;

  function parseTable(startIdx) {
    const tableData = [];
    let idx = startIdx;
    
    if (lines[idx] && lines[idx].startsWith('|')) {
      const headerCells = lines[idx].split('|').map(s => s.trim()).filter(s => s !== '');
      tableData.push({ cells: headerCells, isHeader: true });
      idx++;
    }
    
    while (lines[idx] && lines[idx].match(/^\|[-:\s|]+\|$/)) {
      idx++;
    }
    
    while (lines[idx] && lines[idx].startsWith('|')) {
      const rowCells = lines[idx].split('|').map(s => s.trim()).filter(s => s !== '');
      if (rowCells.length > 0) {
        tableData.push({ cells: rowCells, isHeader: false });
      }
      idx++;
    }
    
    return { tableData, nextIdx: idx };
  }

  function parseCodeBlock(startIdx) {
    const codeLines = [];
    let idx = startIdx;
    while (idx < lines.length && !lines[idx].startsWith('```')) {
      codeLines.push(lines[idx]);
      idx++;
    }
    if (idx < lines.length) idx++;
    return { code: codeLines.join('\n'), nextIdx: idx };
  }

  // 处理行内文本，区分英文数字和中文
  function parseInlineText(text, fontSize, bold) {
    const runs = [];
    let current = text;
    
    while (current.length > 0) {
      // 匹配英文/数字串
      const enMatch = current.match(/^[a-zA-Z0-9_@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?`~\s]+/);
      
      if (enMatch && enMatch[0].length > 0) {
        runs.push(new TextRun({
          text: enMatch[0],
          font: 'Times New Roman',
          size: fontSize,
          bold: bold,
        }));
        current = current.substring(enMatch[0].length);
      } else if (current.length > 0) {
        // 取一个中文字符
        const firstChar = current.charAt(0);
        runs.push(new TextRun({
          text: firstChar,
          font: '宋体',
          size: fontSize,
          bold: bold,
        }));
        current = current.substring(1);
      }
    }
    
    return runs;
  }

  function parseInlineFormatting(text) {
    const runs = [];
    let current = text;
    
    while (current.length > 0) {
      const boldMatch = current.match(/\*\*([^*]+)\*\*/);
      const codeMatch = current.match(/`([^`]+)`/);
      
      let earliestMatch = null;
      let matchType = null;
      
      if (boldMatch && (!codeMatch || boldMatch.index <= codeMatch.index)) {
        earliestMatch = boldMatch;
        matchType = 'bold';
      } else if (codeMatch) {
        earliestMatch = codeMatch;
        matchType = 'code';
      }
      
      if (earliestMatch && matchType) {
        if (earliestMatch.index > 0) {
          const beforeText = current.substring(0, earliestMatch.index);
          runs.push(...parseInlineText(beforeText, FONT_SIZE.BODY, false));
        }
        
        const matchedText = earliestMatch[1];
        if (matchType === 'code') {
          runs.push(new TextRun({
            text: matchedText,
            font: 'Consolas',
            size: FONT_SIZE.BODY - 2,
          }));
        } else {
          runs.push(...parseInlineText(matchedText, FONT_SIZE.BODY, true));
        }
        
        current = current.substring(earliestMatch.index + earliestMatch[0].length);
      } else {
        runs.push(...parseInlineText(current, FONT_SIZE.BODY, false));
        break;
      }
    }
    
    return runs;
  }

  while (i < lines.length) {
    const line = lines[i];
    
    if (line.trim() === '') {
      elements.push(new Paragraph({ 
        text: '', 
        spacing: { 
          after: 60,
          line: 360,
          lineRule: LineRuleType.MULTIPLE,
        } 
      }));
      i++;
      continue;
    }
    
    // 一级标题 （黑体小三号，不加粗，左对齐，首行无缩进）
    if (line.match(/^#\s+.+$/)) {
      const text = line.replace(/^#\s+/, '');
      elements.push(new Paragraph({
        children: [new TextRun({
          text: text,
          font: '黑体',
          size: FONT_SIZE.HEADING1,
          bold: false,
        })],
        heading: HeadingLevel.HEADING_1,
        spacing: { 
          before: 480, 
          after: 240,
          line: 360,
          lineRule: LineRuleType.MULTIPLE,
        },
        alignment: AlignmentType.LEFT,
        indent: { firstLine: 0 },
      }));
      i++;
      continue;
    }
    
    // 二级标题 （黑体四号，不加粗，左对齐，首行无缩进）
    if (line.match(/^##\s+.+$/)) {
      const text = line.replace(/^##\s+/, '');
      elements.push(new Paragraph({
        children: [new TextRun({
          text: text,
          font: '黑体',
          size: FONT_SIZE.HEADING2,
          bold: false,
        })],
        heading: HeadingLevel.HEADING_2,
        spacing: { 
          before: 360, 
          after: 180,
          line: 360,
          lineRule: LineRuleType.MULTIPLE,
        },
        alignment: AlignmentType.LEFT,
        indent: { firstLine: 0 },
      }));
      i++;
      continue;
    }
    
    // 三级标题 （黑体小四号，不加粗，左对齐，首行无缩进）
    if (line.match(/^###\s+.+$/)) {
      const text = line.replace(/^###\s+/, '');
      elements.push(new Paragraph({
        children: [new TextRun({
          text: text,
          font: '黑体',
          size: FONT_SIZE.HEADING3,
          bold: false,
        })],
        heading: HeadingLevel.HEADING_3,
        spacing: { 
          before: 240, 
          after: 120,
          line: 360,
          lineRule: LineRuleType.MULTIPLE,
        },
        alignment: AlignmentType.LEFT,
        indent: { firstLine: 0 },
      }));
      i++;
      continue;
    }
    
    // 四级标题 （黑体小四号，不加粗）
    if (line.match(/^####\s+.+$/)) {
      const text = line.replace(/^####\s+/, '');
      elements.push(new Paragraph({
        children: [new TextRun({
          text: text,
          font: '黑体',
          size: FONT_SIZE.HEADING3,
          bold: false,
        })],
        spacing: { 
          before: 200, 
          after: 100,
          line: 360,
          lineRule: LineRuleType.MULTIPLE,
        },
        alignment: AlignmentType.LEFT,
        indent: { firstLine: 0 },
      }));
      i++;
      continue;
    }
    
    // 分隔线
    if (line.match(/^---{3,}$/)) {
      elements.push(new Paragraph({
        border: {
          bottom: { color: 'CCCCCC', space: 1, size: 6, style: BorderStyle.SINGLE },
        },
        spacing: { before: 240, after: 240 },
      }));
      i++;
      continue;
    }
    
    // 代码块
    if (line.startsWith('```')) {
      const result = parseCodeBlock(i + 1);
      
      figureCount++;
      elements.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({
          text: `图 ${figureCount} 代码示例`,
          font: '宋体',
          size: FONT_SIZE.CAPTION,
          bold: false,
        })],
        spacing: { before: 120, after: 60 },
      }));
      
      result.code.split('\n').forEach(codeLine => {
        elements.push(new Paragraph({
          children: [new TextRun({
            text: codeLine || ' ',
            font: 'Consolas',
            size: 20,
          })],
          shading: {
            type: ShadingType.SOLID,
            color: 'F5F5F5',
          },
          spacing: { before: 20, after: 20 },
          indent: { left: 200 },
        }));
      });
      
      elements.push(new Paragraph({ text: '', spacing: { after: 120 } }));
      i = result.nextIdx;
      continue;
    }
    
    // 表格
    if (line.startsWith('|')) {
      const result = parseTable(i);
      
      if (result.tableData.length > 0 && result.tableData[0].cells.length > 0) {
        tableCount++;
        
        // 表标题（置于表上方，五号字，居中）
        elements.push(new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [new TextRun({
            text: `表 ${tableCount}`,
            font: '宋体',
            size: FONT_SIZE.CAPTION,
            bold: false,
          })],
          spacing: { before: 120, after: 60 },
        }));
        
        const colCount = result.tableData[0].cells.length;
        const colWidth = Math.floor(9500 / colCount);
        
        const tableRows = result.tableData.map(rowData => {
          return new TableRow({
            children: rowData.cells.map((cellText) => {
              const cellRuns = [];
              // 表格内容也区分中英文
              let cellCurrent = cellText;
              while (cellCurrent.length > 0) {
                const enMatch = cellCurrent.match(/^[a-zA-Z0-9_@#$%^&*()+\-=\[\]{};':"\\|,.<>\/?`~\s]+/);
                if (enMatch && enMatch[0].length > 0) {
                  cellRuns.push(new TextRun({
                    text: enMatch[0],
                    font: 'Times New Roman',
                    size: FONT_SIZE.TABLE,
                    bold: rowData.isHeader,
                  }));
                  cellCurrent = cellCurrent.substring(enMatch[0].length);
                } else if (cellCurrent.length > 0) {
                  cellRuns.push(new TextRun({
                    text: cellCurrent.charAt(0),
                    font: '宋体',
                    size: FONT_SIZE.TABLE,
                    bold: rowData.isHeader,
                  }));
                  cellCurrent = cellCurrent.substring(1);
                }
              }
              
              return new TableCell({
                children: [new Paragraph({
                  children: cellRuns,
                  spacing: { before: 60, after: 60 },
                  alignment: AlignmentType.CENTER,
                })],
                width: { size: colWidth, type: WidthType.DXA },
                shading: rowData.isHeader ? {
                  type: ShadingType.SOLID,
                  color: 'D9E2F3',
                } : undefined,
                borders: {
                  top: { style: BorderStyle.SINGLE, size: 6, color: '000000' },
                  bottom: { style: BorderStyle.SINGLE, size: 6, color: '000000' },
                  left: { style: BorderStyle.SINGLE, size: 6, color: '000000' },
                  right: { style: BorderStyle.SINGLE, size: 6, color: '000000' },
                },
              });
            }),
          });
        });
        
        elements.push(new Table({
          rows: tableRows,
          width: { size: 100, type: WidthType.PERCENTAGE },
        }));
        elements.push(new Paragraph({ text: '', spacing: { after: 140 } }));
      }
      
      i = result.nextIdx;
      continue;
    }
    
    // 有序列表
    const orderedListMatch = line.match(/^(\d+)\.\s+(.+)$/);
    if (orderedListMatch) {
      const number = orderedListMatch[1];
      const text = orderedListMatch[2];
      elements.push(new Paragraph({
        children: [
          ...parseInlineText(number + '. ', FONT_SIZE.BODY, false),
          ...parseInlineFormatting(text),
        ],
        indent: { left: 480 },
        spacing: { 
          before: 60, 
          after: 60,
          line: 360,
          lineRule: LineRuleType.MULTIPLE,
        },
        alignment: AlignmentType.JUSTIFIED,
      }));
      i++;
      continue;
    }
    
    // 无序列表
    if (line.startsWith('- ') || line.startsWith('* ')) {
      const text = line.substring(2);
      elements.push(new Paragraph({
        children: [
          ...parseInlineText('● ', FONT_SIZE.BODY, false),
          ...parseInlineFormatting(text),
        ],
        indent: { left: 480 },
        spacing: { 
          before: 60, 
          after: 60,
          line: 360,
          lineRule: LineRuleType.MULTIPLE,
        },
        alignment: AlignmentType.JUSTIFIED,
      }));
      i++;
      continue;
    }
    
    // 普通段落（小四号宋体，两端对齐，首行缩进2字符）
    elements.push(new Paragraph({
      children: parseInlineFormatting(line),
      spacing: { 
        before: 60, 
        after: 60,
        line: 360,
        lineRule: LineRuleType.MULTIPLE,
      },
      alignment: AlignmentType.JUSTIFIED,
      indent: { firstLine: 480 },
    }));
    i++;
  }
  
  return elements;
}

async function convertToDocx() {
  try {
    const mdPath = 'e:\\校园生活服务小程序\\docs\\课程设计报告_完整版.md';
    const docxPath = 'e:\\校园生活服务小程序\\docs\\课程设计报告_完整版_格式化.docx';
    
    console.log('读取Markdown文件...');
    const mdContent = fs.readFileSync(mdPath, 'utf-8');
    console.log('Markdown文件大小: ' + mdContent.length + ' 字符');
    console.log('总行数: ' + mdContent.split('\n').length);
    
    console.log('解析Markdown内容...');
    const bodyElements = parseMarkdownToDocx(mdContent);
    console.log('生成文档元素数量: ' + bodyElements.length);
    
    console.log('创建Word文档...');
    const doc = new Document({
      creator: '校园生活服务小程序项目组',
      title: '项目设计说明书',
      description: '晋中信息学院软件项目实践课程设计报告',
      styles: {
        default: {
          document: {
            run: {
              font: '宋体',
              size: FONT_SIZE.BODY,
            },
            paragraph: {
              spacing: {
                line: 360,
                lineRule: LineRuleType.MULTIPLE,
              },
            },
          },
        },
        paragraphStyles: [
          {
            id: 'Heading1',
            name: 'Heading 1',
            basedOn: 'Normal',
            next: 'Normal',
            run: {
              font: '黑体',
              size: FONT_SIZE.HEADING1,
              bold: false,
            },
            paragraph: {
              spacing: { before: 480, after: 240 },
              alignment: AlignmentType.LEFT,
            },
          },
          {
            id: 'Heading2',
            name: 'Heading 2',
            basedOn: 'Normal',
            next: 'Normal',
            run: {
              font: '黑体',
              size: FONT_SIZE.HEADING2,
              bold: false,
            },
            paragraph: {
              spacing: { before: 360, after: 180 },
              alignment: AlignmentType.LEFT,
            },
          },
          {
            id: 'Heading3',
            name: 'Heading 3',
            basedOn: 'Normal',
            next: 'Normal',
            run: {
              font: '黑体',
              size: FONT_SIZE.HEADING3,
              bold: false,
            },
            paragraph: {
              spacing: { before: 240, after: 120 },
              alignment: AlignmentType.LEFT,
            },
          },
        ],
      },
      sections: [{
        properties: {
          page: {
            margin: {
              top: 1440,      // 2.54cm = 1440 twips
              right: 1800,    // 3.18cm = 1800 twips
              bottom: 1440,
              left: 1800,
            },
            size: {
              width: 11906,
              height: 16838,
            },
          },
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    children: [PageNumber.CURRENT],
                    font: 'Times New Roman',
                    size: FONT_SIZE.FOOTER,
                  }),
                ],
              }),
            ],
          }),
        },
        children: bodyElements,
      }],
    });
    
    console.log('打包Word文档...');
    const buffer = await Packer.toBuffer(doc);
    
    console.log('写入文件...');
    fs.writeFileSync(docxPath, buffer);
    
    console.log('\n=== 转换成功 ===');
    console.log('输出文件: ' + docxPath);
    console.log('文件大小: ' + buffer.length + ' bytes');
    console.log('文档元素数: ' + bodyElements.length);
    console.log('');
    console.log('格式说明：');
    console.log('  一级标题：黑体小三号，不加粗，左对齐');
    console.log('  二级标题：黑体四号，不加粗，左对齐');
    console.log('  三级标题：黑体小四号，不加粗，左对齐');
    console.log('  正文：小四号宋体，两端对齐，首行缩进2字符');
    console.log('  英文数字：Times New Roman');
    console.log('  行间距：1.5倍');
    console.log('  页边距：上下2.54cm，左右3.18cm');
    console.log('  页码：底部居中，五号Times New Roman');
    console.log('  表格：表头浅蓝色背景，表标题在上方');
    
  } catch (err) {
    console.error('\n=== 转换失败 ===');
    console.error('错误信息: ' + err.message);
    console.error('错误堆栈: ' + err.stack);
    process.exit(1);
  }
}

convertToDocx();