const fs = require('fs');
const AdmZip = require('adm-zip');
const { DOMParser } = require('@xmldom/xmldom');

function extractDocxContent(docxPath) {
  const zip = new AdmZip(docxPath);
  const xmlContent = zip.readAsText('word/document.xml');
  
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlContent, 'text/xml');
  
  const paragraphs = doc.getElementsByTagName('w:p');
  const result = [];
  
  for (let i = 0; i < paragraphs.length; i++) {
    const p = paragraphs[i];
    const texts = p.getElementsByTagName('w:t');
    let paragraphText = '';
    
    for (let j = 0; j < texts.length; j++) {
      paragraphText += texts[j].textContent;
    }
    
    result.push(paragraphText);
  }
  
  return result;
}

const docxPath = 'e:\\校园生活服务小程序\\需求规格说明书.docx';
const lines = extractDocxContent(docxPath);

console.log('=== 需求规格说明书内容 ===');
console.log('总行数: ' + lines.length);
console.log('');
lines.forEach((line, idx) => {
  console.log(`${idx + 1}: ${line}`);
});

// 保存为文本文件
fs.writeFileSync('e:\\校园生活服务小程序\\docs\\需求规格说明书_提取.txt', lines.join('\n'), 'utf-8');
console.log('\n已保存到: docs\\需求规格说明书_提取.txt');