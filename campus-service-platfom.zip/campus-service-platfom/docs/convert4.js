const fs = require('fs');
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, HeadingLevel, ShadingType, BorderStyle } = require('docx');

function parseMarkdownToDocx(mdText) {
  const lines = mdText.split('\n');
  const elements = [];
  let i = 0;

  function parseTable(startIdx) {
    const tableData = [];
    let idx = startIdx;
    
    if (lines[idx] && lines[idx].startsWith('|')) {
      const headerCells = lines[idx].split('|').map(s => s.trim()).filter(s => s !== '');
      tableData.push({ cells: headerCells, isHeader: true });
      idx++;
    }
    
    while (lines[idx] && lines[idx].match(/^\|[-:\s|]+\|$/)) {
      idx++;
    }
    
    while (lines[idx] && lines[idx].startsWith('|')) {
      const rowCells = lines[idx].split('|').map(s => s.trim()).filter(s => s !== '');
      if (rowCells.length > 0) {
        tableData.push({ cells: rowCells, isHeader: false });
      }
      idx++;
    }
    
    return { tableData, nextIdx: idx };
  }

  function parseCodeBlock(startIdx, lang) {
    const codeLines = [];
    let idx = startIdx;
    while (idx < lines.length && !lines[idx].startsWith('```')) {
      codeLines.push(lines[idx]);
      idx++;
    }
    if (idx < lines.length) idx++;
    return { code: codeLines.join('\n'), nextIdx: idx };
  }

  function parseInlineFormatting(text) {
    const runs = [];
    let current = text;
    
    while (current.length > 0) {
      const boldMatch = current.match(/\*\*([^*]+)\*\*/);
      const codeMatch = current.match(/`([^`]+)`/);
      
      let earliestMatch = null;
      let matchType = null;
      
      if (boldMatch && (!codeMatch || boldMatch.index <= codeMatch.index)) {
        earliestMatch = boldMatch;
        matchType = 'bold';
      } else if (codeMatch) {
        earliestMatch = codeMatch;
        matchType = 'code';
      }
      
      if (earliestMatch && matchType) {
        if (earliestMatch.index > 0) {
          runs.push(new TextRun({
            text: current.substring(0, earliestMatch.index),
            font: '宋体',
            size: 21,
          }));
        }
        runs.push(new TextRun({
          text: earliestMatch[1],
          font: matchType === 'code' ? 'Consolas' : '宋体',
          size: matchType === 'code' ? 20 : 21,
          bold: matchType === 'bold',
        }));
        current = current.substring(earliestMatch.index + earliestMatch[0].length);
      } else {
        runs.push(new TextRun({
          text: current,
          font: '宋体',
          size: 21,
        }));
        break;
      }
    }
    
    return runs;
  }

  while (i < lines.length) {
    const line = lines[i];
    
    if (line.trim() === '') {
      elements.push(new Paragraph({ text: '', spacing: { after: 100 } }));
      i++;
      continue;
    }
    
    if (line.startsWith('#')) {
      const hashMatch = line.match(/^(#{1,6})\s+(.+)$/);
      if (hashMatch) {
        const level = hashMatch[1].length;
        const titleText = hashMatch[2];
        
        const headingMap = {
          1: HeadingLevel.HEADING_1,
          2: HeadingLevel.HEADING_2,
          3: HeadingLevel.HEADING_3,
          4: HeadingLevel.HEADING_4,
          5: HeadingLevel.HEADING_5,
          6: HeadingLevel.HEADING_6,
        };
        
        elements.push(new Paragraph({
          text: titleText,
          heading: headingMap[level] || HeadingLevel.HEADING_2,
          spacing: { before: level === 1 ? 400 : level === 2 ? 300 : 200, after: 100 },
        }));
      }
      i++;
      continue;
    }
    
    if (line.match(/^---{3,}$/)) {
      elements.push(new Paragraph({
        border: {
          bottom: { color: 'CCCCCC', space: 1, size: 6, style: BorderStyle.SINGLE },
        },
        spacing: { before: 200, after: 200 },
      }));
      i++;
      continue;
    }
    
    if (line.startsWith('```')) {
      const lang = line.substring(3).trim();
      const result = parseCodeBlock(i + 1, lang);
      
      result.code.split('\n').forEach(codeLine => {
        elements.push(new Paragraph({
          children: [new TextRun({
            text: codeLine || ' ',
            font: 'Consolas',
            size: 18,
          })],
          shading: {
            type: ShadingType.SOLID,
            color: 'F0F0F0',
          },
          spacing: { before: 20, after: 20 },
        }));
      });
      
      elements.push(new Paragraph({ text: '', spacing: { after: 100 } }));
      i = result.nextIdx;
      continue;
    }
    
    if (line.startsWith('|')) {
      const result = parseTable(i);
      
      if (result.tableData.length > 0 && result.tableData[0].cells.length > 0) {
        const colCount = result.tableData[0].cells.length;
        const colWidth = Math.floor(9500 / colCount);
        
        const tableRows = result.tableData.map(rowData => {
          return new TableRow({
            children: rowData.cells.map((cellText) => {
              return new TableCell({
                children: [new Paragraph({
                  children: [new TextRun({
                    text: cellText,
                    font: '宋体',
                    size: 20,
                    bold: rowData.isHeader,
                  })],
                  spacing: { before: 60, after: 60 },
                })],
                width: { size: colWidth, type: WidthType.DXA },
                shading: rowData.isHeader ? {
                  type: ShadingType.SOLID,
                  color: 'D9EAD3',
                } : undefined,
              });
            }),
          });
        });
        
        elements.push(new Table({
          rows: tableRows,
          width: { size: 100, type: WidthType.PERCENTAGE },
        }));
        elements.push(new Paragraph({ text: '', spacing: { after: 120 } }));
      }
      
      i = result.nextIdx;
      continue;
    }
    
    const orderedListMatch = line.match(/^(\d+)\.\s+(.+)$/);
    if (orderedListMatch) {
      const number = orderedListMatch[1];
      const text = orderedListMatch[2];
      elements.push(new Paragraph({
        children: [
          new TextRun({ text: number + '. ', font: '宋体', size: 21 }),
          ...parseInlineFormatting(text),
        ],
        indent: { left: 360 },
        spacing: { before: 40, after: 40 },
      }));
      i++;
      continue;
    }
    
    if (line.startsWith('- ') || line.startsWith('* ')) {
      const text = line.substring(2);
      elements.push(new Paragraph({
        children: [
          new TextRun({ text: '• ', font: '宋体', size: 21 }),
          ...parseInlineFormatting(text),
        ],
        indent: { left: 360 },
        spacing: { before: 40, after: 40 },
      }));
      i++;
      continue;
    }
    
    elements.push(new Paragraph({
      children: parseInlineFormatting(line),
      spacing: { before: 60, after: 60 },
    }));
    i++;
  }
  
  return elements;
}

async function convertToDocx() {
  try {
    const mdPath = 'e:\\校园生活服务小程序\\docs\\附件4-用户使用说明书.md';
    const docxPath = 'e:\\校园生活服务小程序\\docs\\附件4-用户使用说明书.docx';
    
    console.log('读取Markdown文件...');
    const mdContent = fs.readFileSync(mdPath, 'utf-8');
    console.log('Markdown文件大小: ' + mdContent.length + ' 字符');
    console.log('总行数: ' + mdContent.split('\n').length);
    
    console.log('解析Markdown内容...');
    const bodyElements = parseMarkdownToDocx(mdContent);
    console.log('生成文档元素数量: ' + bodyElements.length);
    
    console.log('创建Word文档...');
    const doc = new Document({
      creator: '校园生活服务小程序项目组',
      title: '附件4：用户使用说明书',
      description: '用于指导用户如何使用系统功能',
      styles: {
        default: {
          document: {
            run: {
              font: '宋体',
              size: 21,
            },
          },
        },
        paragraphStyles: [
          {
            id: 'Heading1',
            name: 'Heading 1',
            basedOn: 'Normal',
            next: 'Normal',
            run: {
              font: '黑体',
              size: 32,
              bold: true,
              color: '1F4E79',
            },
            paragraph: {
              spacing: { before: 400, after: 200 },
            },
          },
          {
            id: 'Heading2',
            name: 'Heading 2',
            basedOn: 'Normal',
            next: 'Normal',
            run: {
              font: '黑体',
              size: 28,
              bold: true,
              color: '2E75B6',
            },
            paragraph: {
              spacing: { before: 300, after: 150 },
            },
          },
        ],
      },
      sections: [{
        properties: {
          page: {
            margin: {
              top: 1440,
              right: 1440,
              bottom: 1440,
              left: 1440,
            },
            size: {
              width: 11906,
              height: 16838,
            },
          },
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 600, after: 400 },
            children: [
              new TextRun({
                text: '附件4：用户使用说明书',
                bold: true,
                size: 44,
                font: '黑体',
                color: '1F4E79',
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 200, after: 600 },
            children: [
              new TextRun({
                text: '用于指导用户如何使用系统功能',
                font: '宋体',
                size: 24,
                italics: true,
                color: '404040',
              }),
            ],
          }),
          new Paragraph({
            border: {
              bottom: { color: '1F4E79', space: 1, size: 12, style: BorderStyle.SINGLE },
            },
            spacing: { after: 400 },
          }),
          ...bodyElements,
        ],
      }],
    });
    
    console.log('打包Word文档...');
    const buffer = await Packer.toBuffer(doc);
    
    console.log('写入文件...');
    fs.writeFileSync(docxPath, buffer);
    
    console.log('\n=== 转换成功 ===');
    console.log('输出文件: ' + docxPath);
    console.log('文件大小: ' + buffer.length + ' bytes');
    console.log('文档元素数: ' + bodyElements.length);
    
  } catch (err) {
    console.error('\n=== 转换失败 ===');
    console.error('错误信息: ' + err.message);
    console.error('错误堆栈: ' + err.stack);
    process.exit(1);
  }
}

convertToDocx();