const api = require('./api/index');

App({
  globalData: {
    userInfo: null,
    token: null,
    isLogin: false
  },

  onLaunch() {
    // 保留用户配置的后端地址，不强制清除
    this.checkLogin();
    this.getSystemInfo();
  },

  checkLogin() {
    const token = wx.getStorageSync('token');
    const userInfo = wx.getStorageSync('userInfo');
    if (token && userInfo) {
      this.globalData.token = token;
      this.globalData.userInfo = userInfo;
      this.globalData.isLogin = true;
    }
  },

  login(callback) {
    // 跳转到账号密码登录页
    wx.navigateTo({
      url: '/pages/login/index',
      success: () => {
        callback && callback();
      }
    });
  },

  logout() {
    this.globalData.token = null;
    this.globalData.userInfo = null;
    this.globalData.isLogin = false;
    wx.removeStorageSync('token');
    wx.removeStorageSync('userInfo');
  },

  getSystemInfo() {
    wx.getSystemInfo({
      success: (res) => {
        this.globalData.systemInfo = res;
        this.globalData.statusBarHeight = res.statusBarHeight;
        this.globalData.screenWidth = res.screenWidth;
        this.globalData.screenHeight = res.screenHeight;
      }
    });
  },

  requireAuth(callback) {
    if (this.globalData.isLogin) {
      callback && callback();
    } else {
      this.login(callback);
    }
  },

  refreshUserInfo(callback) {
    if (!this.globalData.isLogin) {
      callback && callback(null);
      return;
    }
    api.get('/user/info', {}, { loading: false }).then(res => {
      if (res.code === 200 && res.data) {
        this.globalData.userInfo = res.data;
        wx.setStorageSync('userInfo', res.data);
        callback && callback(res.data);
      } else {
        callback && callback(null);
      }
    }).catch(() => {
      callback && callback(null);
    });
  }
});
