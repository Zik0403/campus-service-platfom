// 默认使用本地地址，电脑模拟器直接可用
// 手机真机预览时需将下面的 localhost 改为电脑的局域网IP（如 192.168.x.x）
const BASE_URL = 'http://localhost:8080/api';

const getBaseUrl = () => {
  // 优先读取用户在"我的"页面配置的后端地址
  const customUrl = wx.getStorageSync('serverBaseUrl');
  if (customUrl) {
    return customUrl;
  }
  return BASE_URL;
};

const setBaseUrl = (url) => {
  wx.setStorageSync('serverBaseUrl', url);
  const app = getApp();
  if (app && app.globalData) {
    app.globalData.baseUrl = url;
  }
};

const clearBaseUrl = () => {
  wx.removeStorageSync('serverBaseUrl');
};

const request = (options) => {
  return new Promise((resolve, reject) => {
    const app = getApp();
    const header = {
      'Content-Type': 'application/json'
    };

    if (app && app.globalData && app.globalData.token) {
      header['Authorization'] = 'Bearer ' + app.globalData.token;
    }

    const showLoading = options.loading !== false;
    if (showLoading) {
      wx.showLoading({ title: '加载中...', mask: true });
    }

    const baseUrl = getBaseUrl();
    const fullUrl = baseUrl + options.url;
    console.log('=== API请求URL:', fullUrl);
    wx.request({
      url: fullUrl,
      method: options.method || 'GET',
      data: options.data || {},
      header: header,
      success: (res) => {
        if (showLoading) wx.hideLoading();
        if (res.data && res.data.code === 200) {
          resolve(res.data);
        } else if (res.data && res.data.code === 401) {
          if (app && app.logout) app.logout();
          resolve({ code: 401, data: null, message: '请先登录' });
        } else {
          resolve({ code: 0, data: null, message: res.data?.message || '请求失败' });
        }
      },
      fail: (err) => {
        if (showLoading) wx.hideLoading();
        console.warn('API 请求失败:', options.url, err);
        resolve({ code: -1, data: null, message: '网络不可用' });
      }
    });
  });
};

const get = (url, data, options = {}) => {
  return request({ url, data, method: 'GET', ...options });
};

const post = (url, data, options = {}) => {
  return request({ url, data, method: 'POST', ...options });
};

const put = (url, data, options = {}) => {
  return request({ url, data, method: 'PUT', ...options });
};

const del = (url, data, options = {}) => {
  return request({ url, data, method: 'DELETE', ...options });
};

const uploadFile = (url, filePath, name = 'file') => {
  return new Promise((resolve, reject) => {
    const app = getApp();
    const baseUrl = getBaseUrl();
    const fullUrl = baseUrl + url;
    var header = {};
    if (app && app.globalData && app.globalData.token) {
      header['Authorization'] = 'Bearer ' + app.globalData.token;
    }
    wx.uploadFile({
      url: fullUrl,
      filePath: filePath,
      name: name,
      header: header,
      success: function(res) {
        try {
          var data = JSON.parse(res.data);
          resolve(data);
        } catch (e) {
          resolve({ code: -1, data: null, message: '解析响应失败' });
        }
      },
      fail: function(err) {
        console.warn('上传失败:', url, err);
        resolve({ code: -1, data: null, message: '网络不可用' });
      }
    });
  });
};

const getImageUrl = function(avatar) {
  if (!avatar) {
    return '';
  }
  if (avatar.indexOf('http://') === 0 || avatar.indexOf('https://') === 0 || avatar.indexOf('wxfile://') === 0 || avatar.indexOf('http://tmp/') === 0) {
    return avatar;
  }
  if (avatar.indexOf('/api/') === 0) {
    return getBaseUrl().replace(/\/api$/, '') + avatar;
  }
  if (avatar.indexOf('/uploads/') === 0) {
    return getBaseUrl().replace(/\/api$/, '') + '/api' + avatar;
  }
  if (avatar === 'default_avatar.png') {
    return getBaseUrl().replace(/\/api$/, '') + '/api/uploads/avatar/default_avatar.png';
  }
  return getBaseUrl().replace(/\/api$/, '') + '/api/uploads/avatar/' + avatar;
};

module.exports = {
  get,
  post,
  put,
  del,
  request,
  uploadFile,
  getImageUrl,
  getBaseUrl,
  setBaseUrl,
  clearBaseUrl,
  BASE_URL
};
