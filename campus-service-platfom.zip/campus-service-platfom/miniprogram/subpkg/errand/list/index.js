const api = require('../../../api/index');

Page({
  data: {
    list: [],
    loading: false
  },

  onLoad() {
    this.loadList();
  },

  async loadList() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/service/order/list');
      const list = (result.data || []).filter(o => o.serviceType === 2).map(item => ({
        ...item,
        statusClass: item.status === 1 ? 'tag-warning' : (item.status === 2 ? 'tag-primary' : (item.status === 3 ? 'tag-success' : 'tag-gray')),
        statusName: ['', '待付款', '待接单', '配送中', '已完成', '已取消'][item.status] || '未知'
      }));
      this.setData({ list });
    } catch (e) {
      console.error('加载失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  onItemTap(e) {
    wx.navigateTo({ url: '/subpkg/errand/detail/index?id=' + e.currentTarget.dataset.id });
  },

  onCreate() {
    wx.navigateTo({ url: '/subpkg/errand/create/index' });
  }
});
