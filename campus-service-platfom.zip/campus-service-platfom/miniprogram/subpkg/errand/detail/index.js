const api = require('../../../api/index');

Page({
  data: { order: null, statusName: '' },
  onLoad(options) {
    if (options.id) {
      api.get('/service/order/detail', { orderId: options.id }).then(result => {
        const order = result.data;
        if (!order) return;
        const statusNames = ['', '待付款', '待接单', '配送中', '已完成', '已取消'];
        this.setData({ order, statusName: statusNames[order.status] || '未知' });
      });
    }
  }
});
