const api = require('../../../api/index');

Page({
  data: {
    clubId: null,
    club: null,
    loading: true,
    submitting: false
  },

  onLoad(options) {
    this.setData({ clubId: options.clubId });
    this.loadClubDetail();
  },

  async loadClubDetail() {
    try {
      const result = await api.get('/club/detail', { clubId: this.data.clubId });
      if (result && result.code === 200 && result.data) {
        this.setData({
          club: result.data,
          loading: false
        });
      } else {
        this.setData({ loading: false });
        wx.showToast({ title: '社团不存在', icon: 'none' });
      }
    } catch (e) {
      console.error('加载社团详情失败', e);
      this.setData({ loading: false });
    }
  },

  async onJoin() {
    if (this.data.submitting) return;
    this.setData({ submitting: true });
    wx.showLoading({ title: '申请中...' });
    try {
      const result = await api.post('/member/join', { clubId: this.data.clubId });
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '申请已提交' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        wx.showToast({ title: (result && result.message) || '申请失败', icon: 'none' });
      }
    } catch (e) {
      wx.hideLoading();
      wx.showToast({ title: '网络不可用', icon: 'none' });
    }
    this.setData({ submitting: false });
  }
});