const api = require('../../../api/index');

Page({
  data: {
    clubId: null,
    members: [],
    loading: true
  },

  onLoad(options) {
    this.setData({ clubId: options.clubId });
    this.loadMembers();
  },

  async loadMembers() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/member/list', { clubId: this.data.clubId });
      if (result && result.code === 200 && result.data) {
        this.setData({
          members: result.data,
          loading: false
        });
      } else {
        this.setData({ members: [], loading: false });
      }
    } catch (e) {
      console.error('加载社团成员列表失败', e);
      this.setData({ members: [], loading: false });
    }
  },

  onManage(e) {
    const member = e.currentTarget.dataset.member;
    wx.navigateTo({
      url: `/subpkg/member/manage/index?memberId=${member.id}`
    });
  }
});