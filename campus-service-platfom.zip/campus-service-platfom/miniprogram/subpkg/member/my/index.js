const api = require('../../../api/index');

Page({
  data: {
    loading: false,
    applications: [],
    joinedCount: 0,
    maxCount: 3
  },

  onLoad() {
    this.loadData();
  },

  onShow() {
    if (getApp().globalData.isLogin) {
      this.loadData();
    }
  },

  async loadData() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/member/my/applications');
      const list = result.data || [];
      const joinedCount = list.filter(item => item.status === 1).length;
      this.setData({
        applications: this.formatList(list),
        joinedCount
      });
    } catch (e) {
      console.error('加载我的社团失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  formatList(list) {
    return list.map(item => {
      let statusText = '';
      let statusClass = '';
      if (item.status === 0) {
        statusText = '待审核';
        statusClass = 'status-pending';
      } else if (item.status === 1) {
        statusText = '已加入';
        statusClass = 'status-joined';
      } else if (item.status === 2) {
        statusText = '已退出';
        statusClass = 'status-exit';
      }
      let roleText = '成员';
      if (item.identity === 1) roleText = '社长';
      else if (item.identity === 2) roleText = '副社长';
      else if (item.identity === 3) roleText = '管理员';
      return {
        ...item,
        statusText,
        statusClass,
        roleText
      };
    });
  },

  onClubTap(e) {
    const clubId = e.currentTarget.dataset.clubid;
    wx.navigateTo({ url: '/subpkg/club/detail/index?id=' + clubId });
  },

  onJoinMore() {
    wx.navigateTo({ url: '/subpkg/club/list/index' });
  },

  onQuit(e) {
    const item = e.currentTarget.dataset.item;
    wx.showModal({
      title: '提示',
      content: '确定要退出这个社团吗？',
      success: (res) => {
        if (res.confirm) {
          this.doQuit(item.clubId);
        }
      }
    });
  },

  async doQuit(clubId) {
    wx.showLoading({ title: '操作中...' });
    try {
      await api.post('/member/quit', { clubId });
      wx.showToast({ title: '已退出社团' });
      this.loadData();
    } catch (e) {
      wx.showToast({ title: e.message || '操作失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  }
});
