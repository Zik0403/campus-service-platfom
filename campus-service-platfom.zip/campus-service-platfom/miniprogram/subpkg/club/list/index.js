const api = require('../../../api/index');

Page({
  data: {
    list: [],
    loading: false
  },

  onLoad() {
    this.loadList();
  },

  async loadList() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/club/list');
      this.setData({ list: result.data || [] });
    } catch (e) {
      console.error('加载社团列表失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  onItemTap(e) {
    wx.navigateTo({ url: '/subpkg/club/detail/index?id=' + e.currentTarget.dataset.id });
  }
});
