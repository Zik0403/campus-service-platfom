const api = require('../../../api/index');

Page({
  data: { 
    club: null,
    clubId: null,
    isMember: false,
    isApplied: false,
    memberInfo: null,
    applyStatusText: '',
    applyStatusClass: ''
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ clubId: options.id });
      this.loadDetail(options.id);
      this.checkMemberStatus(options.id);
    }
  },

  async loadDetail(id) {
    try {
      const result = await api.get('/club/detail', { clubId: id });
      this.setData({ club: result.data });
    } catch (e) {
      console.error('加载社团详情失败', e);
    }
  },

  async checkMemberStatus(clubId) {
    if (!getApp().globalData.isLogin) {
      return;
    }
    try {
      const result = await api.get('/member/check', { clubId });
      if (result.data) {
        const member = result.data;
        if (member.status === 1) {
          this.setData({
            isMember: true,
            isApplied: false,
            memberInfo: member,
            applyStatusText: '已加入',
            applyStatusClass: 'status-joined'
          });
        } else if (member.status === 0) {
          this.setData({
            isMember: false,
            isApplied: true,
            memberInfo: member,
            applyStatusText: '待审核',
            applyStatusClass: 'status-pending'
          });
        } else if (member.status === 2) {
          this.setData({
            isMember: false,
            isApplied: false,
            memberInfo: null,
            applyStatusText: '已退出',
            applyStatusClass: 'status-exit'
          });
        }
      }
    } catch (e) {
      console.error('检查成员状态失败', e);
    }
  },

  onJoin() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.doJoin();
      });
      return;
    }
    this.doJoin();
  },

  async doJoin() {
    wx.showLoading({ title: '申请中...' });
    try {
      const result = await api.post('/member/join?clubId=' + this.data.clubId, {});
      if (result.code === 200) {
        this.setData({ 
          isApplied: true,
          applyStatusText: '待审核',
          applyStatusClass: 'status-pending'
        });
        wx.showToast({ title: '申请成功，等待审核' });
      } else {
        wx.showToast({ title: result.message || '申请失败', icon: 'none' });
      }
    } catch (e) {
      console.error('申请加入失败', e);
      wx.showToast({ title: e.message || '申请失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  onQuit() {
    wx.showModal({
      title: '提示',
      content: '确定要退出这个社团吗？',
      success: (res) => {
        if (res.confirm) {
          this.doQuit();
        }
      }
    });
  },

  onCancelApply() {
    wx.showModal({
      title: '提示',
      content: '确定要取消入社申请吗？',
      success: (res) => {
        if (res.confirm) {
          this.doCancelApply();
        }
      }
    });
  },

  async doQuit() {
    wx.showLoading({ title: '操作中...' });
    try {
      await api.post('/member/quit?clubId=' + this.data.clubId, {});
      this.setData({
        isMember: false,
        isApplied: false,
        memberInfo: null,
        applyStatusText: '',
        applyStatusClass: ''
      });
      wx.showToast({ title: '已退出社团' });
    } catch (e) {
      wx.showToast({ title: e.message || '操作失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  async doCancelApply() {
    wx.showLoading({ title: '操作中...' });
    try {
      await api.post('/member/cancel?clubId=' + this.data.clubId, {});
      this.setData({
        isMember: false,
        isApplied: false,
        memberInfo: null,
        applyStatusText: '',
        applyStatusClass: ''
      });
      wx.showToast({ title: '已取消申请' });
    } catch (e) {
      wx.showToast({ title: e.message || '操作失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  }
});
