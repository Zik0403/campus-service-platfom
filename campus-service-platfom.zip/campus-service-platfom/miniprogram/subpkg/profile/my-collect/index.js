const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    activeTab: 'all',
    collections: [],
    loading: false
  },

  onLoad() {
    this.loadCollections();
  },

  onTabChange(e) {
    this.setData({ activeTab: e.currentTarget.dataset.tab });
    this.loadCollections();
  },

  loadCollections() {
    this.setData({ loading: true });
    api.get('/collect/my/list').then(res => {
      this.setData({ loading: false });
      if (res.code === 200 && res.data) {
        const collections = res.data.map(item => ({
          id: item.id,
          type: this.getTypeLabel(item.targetType),
          targetId: item.targetId,
          targetType: item.targetType,
          time: item.createTime ? item.createTime.split(' ')[0] : ''
        }));
        this.setData({ collections });
        this.loadCollectionDetails(collections);
      }
    }).catch(() => {
      this.setData({ loading: false });
    });
  },

  getTypeLabel(type) {
    const labels = {
      1: '二手商品',
      2: '活动',
      3: '失物招领',
      4: '社区帖子'
    };
    return labels[type] || '其他';
  },

  loadCollectionDetails(collections) {
    if (collections.length === 0) return;
    
    collections.forEach(c => {
      this.loadDetail(c);
    });
  },

  loadDetail(collection) {
    const urlMap = {
      1: '/product/detail',
      2: '/activity/detail',
      3: '/lostfound/detail',
      4: '/post/detail'
    };
    const url = urlMap[collection.targetType];
    if (!url) return;

    api.get(url, { id: collection.targetId }).then(res => {
      if (res.code === 200 && res.data) {
        const data = res.data;
        const index = this.data.collections.findIndex(c => c.id === collection.id);
        if (index !== -1) {
          const collections = [...this.data.collections];
          collections[index] = {
            ...collections[index],
            title: data.name || data.title || data.goodsName || '未知',
            price: data.price ? data.price.toString() : ''
          };
          this.setData({ collections });
        }
      }
    });
  },

  onCancelCollect(e) {
    const { id, targetType, targetId } = e.currentTarget.dataset;
    wx.showModal({
      title: '取消收藏',
      content: '确定要取消收藏吗？',
      success: (res) => {
        if (res.confirm) {
          api.post('/collect/remove', { targetType, targetId }).then(res => {
            if (res.code === 200) {
              wx.showToast({ title: '取消成功', icon: 'success' });
              this.loadCollections();
            }
          });
        }
      }
    });
  }
});