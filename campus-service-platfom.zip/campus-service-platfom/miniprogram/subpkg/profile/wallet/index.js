const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    balance: '0.00',
    creditScore: 100,
    records: [],
    showRechargeModal: false,
    showWithdrawModal: false,
    rechargeAmount: '',
    withdrawAmount: '',
    showPayModal: false,
    rechargeCard: null,
    withdrawCard: null,
    rechargeCardPassword: '',
    showCardPasswordModal: false
  },

  onLoad() {
    this.loadUserInfo();
    this.loadWalletRecords();
    this.loadDefaultCard();
  },

  onShow() {
    this.loadUserInfo();
    this.loadWalletRecords();
    this.loadDefaultCard();
  },

  loadUserInfo() {
    const userInfo = app.globalData.userInfo;
    if (userInfo) {
      this.setData({
        balance: userInfo.balance ? userInfo.balance.toString() : '0.00',
        creditScore: userInfo.creditScore || 100
      });
    } else {
      api.get('/user/info', {}, { loading: false }).then(res => {
        if (res.code === 200 && res.data) {
          app.globalData.userInfo = res.data;
          wx.setStorageSync('userInfo', res.data);
          this.setData({
            balance: res.data.balance ? res.data.balance.toString() : '0.00',
            creditScore: res.data.creditScore || 100
          });
        }
      });
    }
  },

  loadWalletRecords() {
    api.get('/user/wallet/records').then(res => {
      if (res.code === 200 && res.data) {
        const records = res.data.map(item => ({
          id: item.id,
          type: item.changeType,
          amount: (item.changeType === 1 ? '+' : '-') + item.amount.toString(),
          description: this.getDescription(item.bizType, item.remark),
          time: item.createTime ? item.createTime.split(' ')[0] + ' ' + item.createTime.split(' ')[1] : ''
        }));
        this.setData({ records });
      }
    });
  },

  loadDefaultCard() {
    if (!app.globalData.isLogin) return;
    api.get('/user/bank-card/list', {}, { loading: false }).then(res => {
      if (res.code === 200 && res.data && res.data.length > 0) {
        const defaultCard = res.data.find(c => c.isDefault === 1) || res.data[0];
        this.setData({
          rechargeCard: defaultCard,
          withdrawCard: defaultCard
        });
      }
    }).catch(() => {});
  },

  getDescription(bizType, remark) {
    const descriptions = {
      1: '充值',
      2: '消费',
      3: '提现',
      4: '退款',
      5: '配送收入',
      6: '交易收入',
      7: '平台佣金'
    };
    return remark || descriptions[bizType] || '其他';
  },

  onRecharge() {
    this.setData({ showRechargeModal: true, rechargeAmount: '' });
  },

  onWithdraw() {
    this.setData({ showWithdrawModal: true, withdrawAmount: '' });
  },

  onRechargeAmountInput(e) {
    this.setData({ rechargeAmount: e.detail.value });
  },

  onWithdrawAmountInput(e) {
    this.setData({ withdrawAmount: e.detail.value });
  },

  onSelectRechargeCard() {
    this.setData({ showRechargeModal: false });
    wx.navigateTo({ url: '/subpkg/profile/bank-card/index' });
  },

  onSelectWithdrawCard() {
    this.setData({ showWithdrawModal: false });
    wx.navigateTo({ url: '/subpkg/profile/bank-card/index' });
  },

  onBankCardSelected(card) {
    if (this.data.showRechargeModal) {
      this.setData({ rechargeCard: card, showRechargeModal: true });
    } else if (this.data.showWithdrawModal) {
      this.setData({ withdrawCard: card, showWithdrawModal: true });
    }
  },

  onCardPasswordInput(e) {
    const val = e.detail.value.replace(/\D/g, '').slice(0, 6);
    this.setData({ rechargeCardPassword: val });
  },

  onConfirmRecharge() {
    const amount = parseFloat(this.data.rechargeAmount);
    if (!amount || amount <= 0) {
      wx.showToast({ title: '请输入正确的充值金额', icon: 'none' });
      return;
    }
    if (!this.data.rechargeCard) {
      wx.showToast({ title: '请选择充值银行卡', icon: 'none' });
      return;
    }
    this.setData({ showCardPasswordModal: true, rechargeCardPassword: '' });
  },

  onCardPasswordConfirm() {
    const amount = parseFloat(this.data.rechargeAmount);
    const cardPassword = this.data.rechargeCardPassword;
    if (!cardPassword || cardPassword.length !== 6) {
      wx.showToast({ title: '请输入6位银行卡密码', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '充值中...' });
    api.post('/user/wallet/recharge', {
      amount: amount.toFixed(2),
      cardId: this.data.rechargeCard.id,
      cardPassword: cardPassword
    }, { loading: false }).then(res => {
      wx.hideLoading();
      if (res.code === 200) {
        wx.showToast({ title: '充值成功', icon: 'success' });
        this.setData({ 
          showCardPasswordModal: false,
          showRechargeModal: false 
        });
        app.refreshUserInfo(() => {
          this.loadUserInfo();
          this.loadWalletRecords();
        });
      } else {
        if (res.message && res.message.includes('银行卡密码')) {
          wx.showToast({ title: res.message, icon: 'none' });
        } else {
          wx.showToast({ title: res.message || '充值失败', icon: 'none' });
        }
      }
    }).catch(() => {
      wx.hideLoading();
      wx.showToast({ title: '充值失败，请重试', icon: 'none' });
    });
  },

  onConfirmWithdraw() {
    const amount = parseFloat(this.data.withdrawAmount);
    if (!amount || amount <= 0) {
      wx.showToast({ title: '请输入正确的提现金额', icon: 'none' });
      return;
    }
    if (amount > parseFloat(this.data.balance)) {
      wx.showToast({ title: '余额不足', icon: 'none' });
      return;
    }
    if (!this.data.withdrawCard) {
      wx.showToast({ title: '请选择提现银行卡', icon: 'none' });
      return;
    }
    this.setData({
      showWithdrawModal: false,
      showPayModal: true
    });
  },

  onPayModalCancel() {
    this.setData({ showPayModal: false });
  },

  async onPayModalConfirm(e) {
    const { password } = e.detail;
    const amount = this.data.withdrawAmount;
    wx.showLoading({ title: '提现中...' });
    try {
      const res = await api.post('/user/wallet/withdraw', { 
        amount: amount,
        payPassword: password,
        cardId: this.data.withdrawCard.id
      }, { loading: false });
      wx.hideLoading();
      if (res.code === 200) {
        this.setData({ showPayModal: false });
        wx.showToast({ title: '提现成功', icon: 'success' });
        app.refreshUserInfo(() => {
          this.loadUserInfo();
          this.loadWalletRecords();
        });
      } else {
        if (res.message && res.message.includes('支付密码')) {
          this.selectComponent('pay-password-modal')?.showError(res.message);
        } else {
          wx.showToast({ title: res.message || '提现失败', icon: 'none' });
        }
      }
    } catch (e) {
      wx.hideLoading();
      wx.showToast({ title: '提现失败，请重试', icon: 'none' });
    }
  },

  onCloseModal() {
    this.setData({ 
      showRechargeModal: false, 
      showWithdrawModal: false,
      showCardPasswordModal: false
    });
  },

  onManageCards() {
    wx.navigateTo({ url: '/subpkg/profile/bank-card/index' });
  },

  stopPropagation() {}
});
