const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    avatar: '',
    avatarUrl: '',
    studentId: '',
    realName: '',
    phone: '',
    isAuth: false,
    submitting: false
  },

  onLoad() {
    this.loadUserInfo();
  },

  loadUserInfo() {
    const userInfo = app.globalData.userInfo;
    if (userInfo) {
      this.setData({
        avatar: userInfo.avatar || '',
        avatarUrl: api.getImageUrl(userInfo.avatar),
        studentId: userInfo.studentId || '',
        realName: userInfo.realName || '',
        phone: userInfo.phone || '',
        isAuth: userInfo.isAuth === 1
      });
    }
  },

  onChooseAvatar() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath;
        this.uploadAvatar(tempFilePath);
      }
    });
  },

  uploadAvatar(filePath) {
    var that = this;
    wx.showLoading({ title: '上传中...' });
    api.uploadFile('/user/avatar/upload', filePath).then(function(res) {
      wx.hideLoading();
      if (res.code === 200) {
        that.setData({
          avatar: res.data,
          avatarUrl: api.getImageUrl(res.data)
        });
        wx.showToast({ title: '上传成功', icon: 'success' });
      } else {
        wx.showToast({ title: res.message || '上传失败', icon: 'none' });
      }
    });
  },

  onStudentIdInput(e) {
    this.setData({ studentId: e.detail.value });
  },

  onRealNameInput(e) {
    this.setData({ realName: e.detail.value });
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  onSubmit() {
    const { studentId, realName, phone, avatar } = this.data;
    if (!studentId || studentId.length < 8) {
      wx.showToast({ title: '请输入正确的学号', icon: 'none' });
      return;
    }
    if (!realName || realName.length < 2) {
      wx.showToast({ title: '请输入真实姓名', icon: 'none' });
      return;
    }
    if (phone && !/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({ title: '请输入正确的手机号', icon: 'none' });
      return;
    }

    const title = this.data.isAuth ? '确认修改认证信息？' : '确认提交认证信息？';
    wx.showModal({
      title: '提示',
      content: title,
      success: (res) => {
        if (res.confirm) {
          this.doSubmit();
        }
      }
    });
  },

  doSubmit() {
    const { studentId, realName, phone, avatar } = this.data;
    this.setData({ submitting: true });
    const params = { studentId, realName, phone };
    if (avatar) params.avatar = avatar;
    
    api.post('/user/auth', params).then(res => {
      this.setData({ submitting: false });
      if (res.code === 200) {
        wx.showToast({ title: this.data.isAuth ? '修改成功' : '认证成功', icon: 'success' });
        if (res.data) {
          app.globalData.userInfo = res.data;
          wx.setStorageSync('userInfo', res.data);
          this.setData({ isAuth: true });
        }
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        wx.showToast({ title: res.message || '操作失败', icon: 'none' });
      }
    }).catch(() => {
      this.setData({ submitting: false });
    });
  }
});