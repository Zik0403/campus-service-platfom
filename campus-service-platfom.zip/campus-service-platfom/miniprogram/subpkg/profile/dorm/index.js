const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    dormBuild: '',
    dormRoom: '',
    submitting: false
  },

  onLoad() {
    this.loadUserInfo();
  },

  loadUserInfo() {
    const userInfo = app.globalData.userInfo;
    if (userInfo) {
      this.setData({
        dormBuild: userInfo.dormBuild || '',
        dormRoom: userInfo.dormRoom || ''
      });
    }
  },

  onBuildInput(e) {
    this.setData({ dormBuild: e.detail.value });
  },

  onRoomInput(e) {
    this.setData({ dormRoom: e.detail.value });
  },

  onBuildSelect(e) {
    const index = e.currentTarget.dataset.index;
    const builds = ['1号楼', '2号楼', '3号楼', '4号楼', '5号楼', '6号楼', '7号楼', '8号楼'];
    this.setData({ dormBuild: builds[index] });
  },

  onSubmit() {
    const { dormBuild, dormRoom } = this.data;
    if (!dormBuild) {
      wx.showToast({ title: '请选择宿舍楼栋', icon: 'none' });
      return;
    }
    if (!dormRoom) {
      wx.showToast({ title: '请输入宿舍房间号', icon: 'none' });
      return;
    }

    this.setData({ submitting: true });
    api.put('/user/dorm', { dormBuild, dormRoom }).then(res => {
      this.setData({ submitting: false });
      if (res.code === 200) {
        wx.showToast({ title: '保存成功', icon: 'success' });
        if (res.data) {
          app.globalData.userInfo = res.data;
          wx.setStorageSync('userInfo', res.data);
        }
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        wx.showToast({ title: res.message || '保存失败', icon: 'none' });
      }
    });
  }
});
