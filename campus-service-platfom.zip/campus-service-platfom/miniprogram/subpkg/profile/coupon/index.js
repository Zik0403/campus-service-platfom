Page({
  data: {
    coupons: [
      { id: 1, name: '新用户优惠券', amount: 5, condition: '满10元可用', expireTime: '2025-12-31', status: 1 },
      { id: 2, name: '快递代取券', amount: 3, condition: '满5元可用', expireTime: '2025-06-30', status: 1 },
      { id: 3, name: '跑腿服务券', amount: 10, condition: '满20元可用', expireTime: '2025-03-31', status: 2 }
    ],
    activeTab: 'available'
  },

  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
  }
});
