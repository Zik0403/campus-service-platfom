Page({
  data: {
    faqs: [
      {
        question: '如何进行实名认证？',
        answer: '点击「我的」-「实名认证」，输入学号和真实姓名即可完成认证。'
      },
      {
        question: '如何修改宿舍信息？',
        answer: '点击「我的」-「宿舍信息」，输入您的楼栋和房间号保存即可。'
      },
      {
        question: '报修后多久能处理？',
        answer: '一般工作日24小时内会安排维修人员上门处理，节假日可能延后。'
      },
      {
        question: '快递代取怎么收费？',
        answer: '小件3元/件，大件5元/件，费用根据距离和重量可能有所调整。'
      }
    ],
    expandedIndex: -1
  },

  onFaqTap(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      expandedIndex: this.data.expandedIndex === index ? -1 : index
    });
  },

  onContactService() {
    wx.showModal({
      title: '联系客服',
      content: '客服电话：400-123-4567\n工作时间：9:00-21:00',
      showCancel: false
    });
  }
});
