const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    cards: [],
    showAddModal: false,
    bankName: '',
    cardNumber: '',
    cardPassword: '',
    confirmPassword: '',
    submitting: false
  },

  onLoad() {
    this.loadCards();
  },

  onShow() {
    this.loadCards();
  },

  loadCards() {
    if (!app.globalData.isLogin) return;
    api.get('/user/bank-card/list', {}, { loading: false }).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ cards: res.data });
      }
    }).catch(() => {});
  },

  onAddCard() {
    this.setData({
      showAddModal: true,
      bankName: '',
      cardNumber: '',
      cardPassword: '',
      confirmPassword: ''
    });
  },

  onCloseModal() {
    this.setData({ showAddModal: false });
  },

  onBankNameInput(e) {
    this.setData({ bankName: e.detail.value });
  },

  onCardNumberInput(e) {
    let val = e.detail.value.replace(/\D/g, '');
    let formatted = '';
    for (let i = 0; i < val.length; i++) {
      if (i > 0 && i % 4 === 0) formatted += ' ';
      formatted += val[i];
    }
    this.setData({ cardNumber: formatted });
  },

  onCardPasswordInput(e) {
    const val = e.detail.value.replace(/\D/g, '').slice(0, 6);
    this.setData({ cardPassword: val });
  },

  onConfirmPasswordInput(e) {
    const val = e.detail.value.replace(/\D/g, '').slice(0, 6);
    this.setData({ confirmPassword: val });
  },

  onConfirmAdd() {
    const { bankName, cardNumber, cardPassword, confirmPassword } = this.data;
    if (!bankName) {
      wx.showToast({ title: '请输入银行名称', icon: 'none' });
      return;
    }
    const plainNumber = cardNumber.replace(/\s/g, '');
    if (plainNumber.length < 13 || plainNumber.length > 19) {
      wx.showToast({ title: '请输入正确的银行卡号', icon: 'none' });
      return;
    }
    if (!cardPassword || cardPassword.length !== 6) {
      wx.showToast({ title: '请设置6位数字银行卡密码', icon: 'none' });
      return;
    }
    if (cardPassword !== confirmPassword) {
      wx.showToast({ title: '两次密码不一致', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    api.post('/user/bank-card/add', {
      bankName: bankName,
      cardNumber: plainNumber,
      cardPassword: cardPassword
    }).then(res => {
      this.setData({ submitting: false });
      if (res.code === 200) {
        wx.showToast({ title: '添加成功', icon: 'success' });
        this.setData({ showAddModal: false });
        this.loadCards();
      } else {
        wx.showToast({ title: res.message || '添加失败', icon: 'none' });
      }
    }).catch(() => {
      this.setData({ submitting: false });
    });
  },

  onSetDefault(e) {
    const cardId = e.currentTarget.dataset.id;
    wx.showModal({
      title: '设为默认',
      content: '确定设为默认银行卡吗？',
      success: (res) => {
        if (res.confirm) {
          api.post('/user/bank-card/set-default', { cardId }).then(r => {
            if (r.code === 200) {
              wx.showToast({ title: '设置成功', icon: 'success' });
              this.loadCards();
            } else {
              wx.showToast({ title: r.message || '设置失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  onStopPropagation() {
    // 阻止事件冒泡
  },

  onDeleteCard(e) {
    const cardId = e.currentTarget.dataset.id;
    console.log('[删除银行卡] cardId=', cardId, '类型=', typeof cardId);
    wx.showModal({
      title: '删除银行卡',
      content: '确定删除该银行卡吗？',
      confirmColor: '#ff4d4f',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '删除中...', mask: true });
          const body = { cardId: parseInt(cardId) };
          console.log('[删除银行卡] 请求body=', JSON.stringify(body));
          api.post('/user/bank-card/delete', body).then(r => {
            wx.hideLoading();
            console.log('[删除银行卡] 响应=', JSON.stringify(r));
            if (r.code === 200) {
              wx.showToast({ title: '删除成功', icon: 'success' });
              const newCards = this.data.cards.filter(c => c.id != cardId);
              this.setData({ cards: newCards });
              setTimeout(() => this.loadCards(), 500);
            } else {
              wx.showModal({
                title: '删除失败',
                content: r.message || '请稍后重试',
                showCancel: false
              });
            }
          }).catch(err => {
            wx.hideLoading();
            console.error('[删除银行卡] 异常=', err);
            wx.showModal({
              title: '删除失败',
              content: '网络异常，请检查网络后重试',
              showCancel: false
            });
          });
        }
      }
    });
  },

  onSelectCard(e) {
    const cardId = e.currentTarget.dataset.id;
    const pages = getCurrentPages();
    if (pages.length > 1) {
      const prevPage = pages[pages.length - 2];
      if (prevPage && prevPage.onBankCardSelected) {
        const card = this.data.cards.find(c => c.id === cardId);
        prevPage.onBankCardSelected(card);
      }
      wx.navigateBack();
    }
  },

  stopPropagation() {}
});
