const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    activeTab: 'all',
    posts: [],
    loading: false
  },

  onLoad() {
    this.loadPosts();
  },

  onTabChange(e) {
    this.setData({ activeTab: e.currentTarget.dataset.tab });
    this.loadPosts();
  },

  loadPosts() {
    this.setData({ loading: true });
    api.get('/post/my/list').then(res => {
      this.setData({ loading: false });
      if (res.code === 200 && res.data) {
        const posts = res.data.map(item => ({
          id: item.id,
          type: item.postType === 1 ? '二手' : item.postType === 2 ? '失物' : '活动',
          title: item.title || '未命名',
          price: item.price ? item.price.toString() : '',
          status: item.auditStatus === 2 ? (item.status === 1 ? '进行中' : '已结束') : '审核中',
          time: item.createTime ? item.createTime.split(' ')[0] : ''
        }));
        this.setData({ posts });
      }
    }).catch(() => {
      this.setData({ loading: false });
    });
  }
});