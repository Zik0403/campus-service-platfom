const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    loading: true,
    hasPayPassword: false,
    currentTab: 'set',
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
    studentId: '',
    realName: '',
    phone: '',
    submitting: false
  },

  onLoad() {
    this.checkPayPassword();
  },

  checkPayPassword() {
    if (!app.globalData.isLogin) {
      this.setData({ loading: false, currentTab: 'set' });
      return;
    }
    api.get('/user/pay-password/status', {}, { loading: false }).then(res => {
      if (res.code === 200) {
        const hasPayPassword = res.data;
        this.setData({ 
          loading: false,
          hasPayPassword,
          currentTab: hasPayPassword ? 'main' : 'set'
        });
      } else {
        this.setData({ loading: false, currentTab: 'set' });
      }
    }).catch(() => {
      this.setData({ loading: false, currentTab: 'set' });
    });
  },

  onSwitchTab(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({
      currentTab: tab,
      oldPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
  },

  onOldPasswordInput(e) {
    const val = e.detail.value.replace(/\D/g, '').slice(0, 6);
    this.setData({ oldPassword: val });
  },

  onNewPasswordInput(e) {
    const val = e.detail.value.replace(/\D/g, '').slice(0, 6);
    this.setData({ newPassword: val });
  },

  onConfirmPasswordInput(e) {
    const val = e.detail.value.replace(/\D/g, '').slice(0, 6);
    this.setData({ confirmPassword: val });
  },

  onStudentIdInput(e) {
    this.setData({ studentId: e.detail.value });
  },

  onRealNameInput(e) {
    this.setData({ realName: e.detail.value });
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  onSetPassword() {
    const { newPassword, confirmPassword } = this.data;
    if (!newPassword || newPassword.length !== 6) {
      wx.showToast({ title: '请设置6位数字支付密码', icon: 'none' });
      return;
    }
    if (newPassword !== confirmPassword) {
      wx.showToast({ title: '两次密码不一致', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    api.post('/user/pay-password/set', { payPassword: newPassword }).then(res => {
      this.setData({ submitting: false });
      if (res.code === 200) {
        wx.showToast({ title: '设置成功', icon: 'success' });
        this.setData({ hasPayPassword: true, currentTab: 'main' });
      } else {
        wx.showToast({ title: res.message || '设置失败', icon: 'none' });
      }
    }).catch(() => {
      this.setData({ submitting: false });
    });
  },

  onModifyPassword() {
    const { oldPassword, newPassword, confirmPassword } = this.data;
    if (!oldPassword || oldPassword.length !== 6) {
      wx.showToast({ title: '请输入原支付密码', icon: 'none' });
      return;
    }
    if (!newPassword || newPassword.length !== 6) {
      wx.showToast({ title: '请设置6位数字新密码', icon: 'none' });
      return;
    }
    if (newPassword !== confirmPassword) {
      wx.showToast({ title: '两次新密码不一致', icon: 'none' });
      return;
    }
    if (oldPassword === newPassword) {
      wx.showToast({ title: '新密码不能与原密码相同', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    api.post('/user/pay-password/update', { 
      oldPassword: oldPassword,
      newPassword: newPassword
    }).then(res => {
      this.setData({ submitting: false });
      if (res.code === 200) {
        wx.showToast({ title: '修改成功', icon: 'success' });
        this.setData({ 
          currentTab: 'main',
          oldPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
      } else {
        wx.showToast({ title: res.message || '修改失败', icon: 'none' });
      }
    }).catch(() => {
      this.setData({ submitting: false });
    });
  },

  onResetPassword() {
    const { studentId, realName, phone, newPassword, confirmPassword } = this.data;
    if (!studentId) {
      wx.showToast({ title: '请输入学号', icon: 'none' });
      return;
    }
    if (!realName) {
      wx.showToast({ title: '请输入真实姓名', icon: 'none' });
      return;
    }
    if (!phone) {
      wx.showToast({ title: '请输入手机号', icon: 'none' });
      return;
    }
    if (!newPassword || newPassword.length !== 6) {
      wx.showToast({ title: '请设置6位数字新密码', icon: 'none' });
      return;
    }
    if (newPassword !== confirmPassword) {
      wx.showToast({ title: '两次新密码不一致', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    api.post('/user/pay-password/reset', { 
      studentId: studentId,
      realName: realName,
      phone: phone,
      newPassword: newPassword
    }).then(res => {
      this.setData({ submitting: false });
      if (res.code === 200) {
        wx.showToast({ title: '重置成功', icon: 'success' });
        this.setData({ 
          hasPayPassword: true,
          currentTab: 'main',
          studentId: '',
          realName: '',
          phone: '',
          newPassword: '',
          confirmPassword: ''
        });
      } else {
        wx.showToast({ title: res.message || '重置失败', icon: 'none' });
      }
    }).catch(() => {
      this.setData({ submitting: false });
    });
  }
});
