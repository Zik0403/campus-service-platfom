const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    userInfo: null,
    nickname: '',
    avatar: '',
    avatarUrl: '',
    phone: '',
    studentId: '',
    realName: '',
    isAuth: false,
    submitting: false
  },

  onLoad() {
    this.loadUserInfo();
  },

  loadUserInfo() {
    const userInfo = app.globalData.userInfo;
    if (userInfo) {
      this.setData({
        userInfo,
        nickname: userInfo.nickname || '',
        avatar: userInfo.avatar || '',
        avatarUrl: api.getImageUrl(userInfo.avatar),
        phone: userInfo.phone || '',
        studentId: userInfo.studentId || '',
        realName: userInfo.realName || '',
        isAuth: userInfo.isAuth === 1
      });
    }
  },

  onNicknameInput(e) {
    this.setData({ nickname: e.detail.value });
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  onChooseAvatar() {
    var that = this;
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sizeType: ['compressed'],
      success: function(res) {
        var tempFilePath = res.tempFiles[0].tempFilePath;
        that.setData({ avatarUrl: tempFilePath });
        wx.showLoading({ title: '上传中...' });
        api.uploadFile('/user/avatar/upload', tempFilePath).then(function(uploadRes) {
          wx.hideLoading();
          if (uploadRes.code === 200) {
            that.setData({
              avatar: uploadRes.data,
              avatarUrl: api.getImageUrl(uploadRes.data)
            });
            wx.showToast({ title: '上传成功', icon: 'success' });
          } else {
            wx.showToast({ title: uploadRes.message || '上传失败', icon: 'none' });
          }
        });
      }
    });
  },

  onSave() {
    const { nickname, avatar, phone } = this.data;
    if (!nickname) {
      wx.showToast({ title: '请输入昵称', icon: 'none' });
      return;
    }

    this.setData({ submitting: true });

    const saveUser = () => {
      api.put('/user/update', { nickname, avatar }).then(res => {
        if (res.code === 200) {
          return api.get('/user/info').then(infoRes => {
            if (infoRes.code === 200 && infoRes.data) {
              app.globalData.userInfo = infoRes.data;
              wx.setStorageSync('userInfo', infoRes.data);
            }
          });
        }
        return res;
      });
    };

    const savePhone = () => {
      if (phone && phone !== this.data.userInfo?.phone) {
        return api.put('/user/phone', { phone });
      }
      return Promise.resolve({ code: 200 });
    };

    Promise.all([saveUser(), savePhone()]).then((results) => {
      this.setData({ submitting: false });
      const userRes = results[0];
      if (userRes.code === 200) {
        wx.showToast({ title: '保存成功', icon: 'success' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        wx.showToast({ title: userRes.message || '保存失败', icon: 'none' });
      }
    });
  },

  onAuthTap() {
    wx.navigateTo({ url: '/subpkg/profile/auth/index' });
  }
});
