const app = getApp();
const api = require('../../../api/index.js');

Page({
  data: {
    addresses: [],
    showAddModal: false,
    newAddress: {
      name: '',
      address: '',
      isDefault: false
    },
    hasPayPassword: false
  },

  onLoad() {
    this.loadAddresses();
    this.checkPayPassword();
  },

  onShow() {
    this.checkPayPassword();
  },

  checkPayPassword() {
    if (!getApp().globalData.isLogin) return;
    api.get('/user/pay-password/status').then(res => {
      if (res.code === 200) {
        this.setData({ hasPayPassword: res.data });
      }
    }).catch(() => {});
  },

  loadAddresses() {
    const addresses = wx.getStorageSync('campusAddresses') || [];
    if (addresses.length === 0) {
      const defaultAddresses = [
        { id: 1, name: '宿舍', address: '3号楼502室', isDefault: true },
        { id: 2, name: '教学楼', address: '第一教学楼301教室', isDefault: false },
        { id: 3, name: '图书馆', address: '图书馆二楼自习区', isDefault: false }
      ];
      wx.setStorageSync('campusAddresses', defaultAddresses);
      this.setData({ addresses: defaultAddresses });
    } else {
      this.setData({ addresses });
    }
  },

  onAddAddress() {
    this.setData({ 
      showAddModal: true,
      newAddress: { name: '', address: '', isDefault: false }
    });
  },

  onAddressNameInput(e) {
    this.setData({ 'newAddress.name': e.detail.value });
  },

  onAddressDetailInput(e) {
    this.setData({ 'newAddress.address': e.detail.value });
  },

  onDefaultChange(e) {
    this.setData({ 'newAddress.isDefault': e.detail.value });
  },

  onSaveAddress() {
    const { name, address, isDefault } = this.data.newAddress;
    if (!name || !address) {
      wx.showToast({ title: '请填写完整信息', icon: 'none' });
      return;
    }

    let addresses = this.data.addresses;
    if (isDefault) {
      addresses = addresses.map(item => ({ ...item, isDefault: false }));
    }

    const newId = addresses.length > 0 ? Math.max(...addresses.map(a => a.id)) + 1 : 1;
    addresses.push({ id: newId, name, address, isDefault });

    wx.setStorageSync('campusAddresses', addresses);
    this.setData({ 
      addresses,
      showAddModal: false,
      newAddress: { name: '', address: '', isDefault: false }
    });
    wx.showToast({ title: '保存成功', icon: 'success' });
  },

  onDeleteAddress(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个地址吗？',
      success: (res) => {
        if (res.confirm) {
          let addresses = this.data.addresses.filter(item => item.id !== id);
          wx.setStorageSync('campusAddresses', addresses);
          this.setData({ addresses });
          wx.showToast({ title: '删除成功', icon: 'success' });
        }
      }
    });
  },

  onCloseModal() {
    this.setData({ showAddModal: false });
  },

  stopPropagation() {},

  onClearCache() {
    wx.showModal({
      title: '提示',
      content: '确定要清除缓存吗？',
      success: (res) => {
        if (res.confirm) {
          wx.clearStorageSync();
          app.logout();
          wx.showToast({ title: '缓存已清除', icon: 'success' });
        }
      }
    });
  },

  onAbout() {
    wx.showModal({
      title: '关于',
      content: '校园生活服务小程序 v1.0\n为大学生提供便捷的校园生活服务',
      showCancel: false
    });
  },

  onPayPassword() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.checkPayPassword();
      });
      return;
    }
    wx.navigateTo({ url: '/subpkg/profile/pay-password/index' });
  }
});