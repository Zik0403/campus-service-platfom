Page({
  data: {
    borrowList: [],
    activeTab: 'borrowing'
  },

  onLoad() {
    this.loadBorrowRecords();
  },

  onShow() {
    this.loadBorrowRecords();
  },

  loadBorrowRecords() {
    const api = require('../../../api/index.js');
    api.get('/library/borrow/list').then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ borrowList: res.data });
      }
    });
  },

  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
  },

  onRenew(e) {
    const recordId = e.currentTarget.dataset.id;
    const api = require('../../../api/index.js');
    wx.showModal({
      title: '确认续借',
      content: '确定要续借这本书吗？可续借30天',
      success: (res) => {
        if (res.confirm) {
          api.post('/library/borrow/renew', { recordId }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '续借成功', icon: 'success' });
              this.loadBorrowRecords();
            } else {
              wx.showToast({ title: result.message || '续借失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  onReturn(e) {
    const recordId = e.currentTarget.dataset.id;
    const api = require('../../../api/index.js');
    wx.showModal({
      title: '确认归还',
      content: '确定要归还这本书吗？',
      success: (res) => {
        if (res.confirm) {
          api.post('/library/borrow/return', { recordId }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '归还成功', icon: 'success' });
              this.loadBorrowRecords();
            } else {
              wx.showToast({ title: result.message || '归还失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  getStatusText(status) {
    const statusMap = { 1: '借阅中', 2: '已归还', 3: '已逾期' };
    return statusMap[status] || '未知';
  }
});
