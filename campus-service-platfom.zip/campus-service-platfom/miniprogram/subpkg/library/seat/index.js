Page({
  data: {
    activeTab: 'seat',
    seatList: [],
    myReservations: [],
    floor: null,
    hasSocket: '',
    hasWindow: '',
    floors: [
      { label: '全部', value: null },
      { label: '1楼', value: 1 },
      { label: '2楼', value: 2 },
      { label: '3楼', value: 3 }
    ]
  },

  onLoad() {
    this.loadSeats();
    this.loadMyReservations();
  },

  onShow() {
    this.loadMyReservations();
  },

  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
  },

  loadSeats() {
    const api = require('../../../api/index.js');
    const params = {};
    if (this.data.floor !== null) params.floor = this.data.floor;
    if (this.data.hasSocket) params.hasSocket = this.data.hasSocket;
    if (this.data.hasWindow) params.hasWindow = this.data.hasWindow;
    api.get('/library/seat/list', params).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ seatList: res.data });
      }
    });
  },

  loadMyReservations() {
    const api = require('../../../api/index.js');
    api.get('/library/seat/my-reservations').then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ myReservations: res.data });
      }
    });
  },

  onFloorChange(e) {
    const index = e.detail.value;
    const floor = this.data.floors[index].value;
    this.setData({ floor }, () => {
      this.loadSeats();
    });
  },

  onFilterSocket(e) {
    const value = e.detail.value ? '1' : '';
    this.setData({ hasSocket: value }, () => {
      this.loadSeats();
    });
  },

  onFilterWindow(e) {
    const value = e.detail.value ? '1' : '';
    this.setData({ hasWindow: value }, () => {
      this.loadSeats();
    });
  },

  onReserve(e) {
    const seatId = e.currentTarget.dataset.id;
    const today = new Date();
    const dateStr = today.toISOString().split('T')[0];
    const startTime = '08:00';
    const endTime = '12:00';
    
    wx.showModal({
      title: '预约座位',
      content: `确定预约该座位吗？\n日期：${dateStr}\n时间：${startTime} - ${endTime}`,
      success: (res) => {
        if (res.confirm) {
          const api = require('../../../api/index.js');
          api.post('/library/seat/reserve', {
            seatId,
            reserveDate: dateStr,
            startTime,
            endTime
          }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '预约成功', icon: 'success' });
              this.loadSeats();
              this.loadMyReservations();
            } else {
              wx.showToast({ title: result.message || '预约失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  onCancel(e) {
    const reservationId = e.currentTarget.dataset.id;
    wx.showModal({
      title: '取消预约',
      content: '确定要取消该预约吗？',
      success: (res) => {
        if (res.confirm) {
          const api = require('../../../api/index.js');
          api.post('/library/seat/cancel', { reservationId }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '取消成功', icon: 'success' });
              this.loadMyReservations();
            } else {
              wx.showToast({ title: result.message || '取消失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  onCheckin(e) {
    const reservationId = e.currentTarget.dataset.id;
    const api = require('../../../api/index.js');
    api.post('/library/seat/checkin', { reservationId }).then(result => {
      if (result.code === 200) {
        wx.showToast({ title: '签到成功', icon: 'success' });
        this.loadMyReservations();
      } else {
        wx.showToast({ title: result.message || '签到失败', icon: 'none' });
      }
    });
  },

  onCheckout(e) {
    const reservationId = e.currentTarget.dataset.id;
    const api = require('../../../api/index.js');
    api.post('/library/seat/checkout', { reservationId }).then(result => {
      if (result.code === 200) {
        wx.showToast({ title: '签退成功', icon: 'success' });
        this.loadMyReservations();
      } else {
        wx.showToast({ title: result.message || '签退失败', icon: 'none' });
      }
    });
  }
});
