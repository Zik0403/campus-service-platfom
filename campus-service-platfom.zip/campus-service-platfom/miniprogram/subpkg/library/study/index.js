Page({
  data: {
    statistics: null,
    checkinList: [],
    todayChecked: false
  },

  onLoad() {
    this.loadStatistics();
    this.loadCheckinList();
    this.checkTodayStatus();
  },

  onShow() {
    this.loadStatistics();
    this.loadCheckinList();
    this.checkTodayStatus();
  },

  checkTodayStatus() {
    const api = require('../../../api/index.js');
    api.get('/library/study/list').then(res => {
      if (res.code === 200 && res.data && res.data.length > 0) {
        const today = new Date().toISOString().split('T')[0];
        const todayCheckin = res.data.find(item => item.checkinDate === today);
        this.setData({ todayChecked: !!todayCheckin });
      }
    });
  },

  loadStatistics() {
    const api = require('../../../api/index.js');
    api.get('/library/study/statistics').then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ statistics: res.data });
      }
    });
  },

  loadCheckinList() {
    const api = require('../../../api/index.js');
    api.get('/library/study/list').then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ checkinList: res.data });
      }
    });
  },

  onCheckin() {
    if (this.data.todayChecked) {
      wx.showToast({ title: '今日已打卡', icon: 'none' });
      return;
    }
    wx.showModal({
      title: '自习打卡',
      content: '确定完成今日自习打卡吗？',
      success: (res) => {
        if (res.confirm) {
          const api = require('../../../api/index.js');
          api.post('/library/study/checkin', {
            location: '图书馆',
            note: ''
          }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '打卡成功', icon: 'success' });
              this.setData({ todayChecked: true });
              this.loadStatistics();
              this.loadCheckinList();
            } else {
              wx.showToast({ title: result.message || '打卡失败', icon: 'none' });
            }
          });
        }
      }
    });
  }
});
