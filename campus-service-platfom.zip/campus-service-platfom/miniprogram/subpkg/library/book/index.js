Page({
  data: {
    keyword: '',
    category: '',
    categoryList: ['全部', '数学', '计算机', '文学', '英语', '经济', '管理', '物理', '化学'],
    bookList: []
  },

  onLoad() {
    this.searchBooks();
  },

  onKeywordInput(e) {
    this.setData({ keyword: e.detail.value });
  },

  onSearch() {
    this.searchBooks();
  },

  onCategoryTap(e) {
    const index = e.currentTarget.dataset.index;
    const category = index === 0 ? '' : this.data.categoryList[index];
    this.setData({ category }, () => {
      this.searchBooks();
    });
  },

  searchBooks() {
    const api = require('../../../api/index.js');
    const params = {};
    if (this.data.keyword) {
      params.keyword = this.data.keyword;
    }
    if (this.data.category) {
      params.category = this.data.category;
    }
    api.get('/library/book/search', params).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ bookList: res.data });
      }
    });
  },

  onBookTap(e) {
    const id = e.currentTarget.dataset.id;
    const book = this.data.bookList.find(b => b.id === id);
    if (!book) return;
    const that = this;
    wx.showModal({
      title: book.title,
      content: `作者：${book.author || '无'}\n出版社：${book.publisher || '无'}\n馆藏位置：${book.location || '无'}\n可借数量：${book.availableCount}/${book.totalCount}\n\n简介：${book.description || '暂无'}`,
      showCancel: true,
      cancelText: '关闭',
      confirmText: book.availableCount > 0 ? '立即借阅' : '预约',
      success: (res) => {
        if (res.confirm) {
          if (book.availableCount > 0) {
            that.borrowBook(id);
          } else {
            that.reserveBook(id);
          }
        }
      }
    });
  },

  borrowBook(bookId) {
    const api = require('../../../api/index.js');
    api.post('/library/borrow/add', { bookId }).then(res => {
      if (res.code === 200) {
        wx.showToast({ title: '借阅成功', icon: 'success' });
        this.searchBooks();
      } else {
        wx.showToast({ title: res.message || '借阅失败', icon: 'none' });
      }
    });
  },

  reserveBook(bookId) {
    const api = require('../../../api/index.js');
    api.post('/library/reservation/add', { bookId }).then(res => {
      if (res.code === 200) {
        wx.showToast({ title: '预约成功', icon: 'success' });
      } else {
        wx.showToast({ title: res.message || '预约失败', icon: 'none' });
      }
    });
  }
});
