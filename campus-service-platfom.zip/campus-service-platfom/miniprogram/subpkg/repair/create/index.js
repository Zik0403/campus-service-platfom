const api = require('../../../api/index');

Page({
  data: {
    faultTypes: [
      { id: 1, name: '水管维修' },
      { id: 2, name: '电灯维修' },
      { id: 3, name: '门窗维修' },
      { id: 4, name: '空调维修' },
      { id: 5, name: '家具维修' },
      { id: 6, name: '其他维修' }
    ],
    faultTypeIndex: -1,
    faultType: '',
    address: '',
    description: '',
    images: [],
    priority: 1
  },

  onFaultTypeChange(e) {
    const index = e.detail.value;
    this.setData({
      faultTypeIndex: index,
      faultType: this.data.faultTypes[index].name
    });
  },

  onAddressInput(e) {
    this.setData({ address: e.detail.value });
  },

  onDescInput(e) {
    this.setData({ description: e.detail.value });
  },

  onPriorityChange(e) {
    this.setData({ priority: parseInt(e.detail.value) });
  },

  onChooseImage() {
    wx.chooseMedia({
      count: 3 - this.data.images.length,
      mediaType: ['image'],
      success: (res) => {
        const tempFiles = res.tempFiles.map(f => f.tempFilePath);
        this.setData({
          images: [...this.data.images, ...tempFiles]
        });
      }
    });
  },

  onRemoveImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = [...this.data.images];
    images.splice(index, 1);
    this.setData({ images });
  },

  onSubmit() {
    if (!this.data.faultType) {
      wx.showToast({ title: '请选择故障类型', icon: 'none' });
      return;
    }
    if (!this.data.address) {
      wx.showToast({ title: '请填写楼栋房间', icon: 'none' });
      return;
    }
    // 地址校验：必须同时包含中文和数字（如"3号楼502"），纯数字或纯英文不允许
    const addr = this.data.address.trim();
    const hasChinese = /[\u4e00-\u9fa5]/.test(addr);
    const hasNumber = /\d/.test(addr);
    if (!hasChinese || !hasNumber) {
      wx.showToast({ title: '地址需包含楼栋名和房间号，如"3号楼502"', icon: 'none', duration: 2500 });
      return;
    }
    if (!this.data.description) {
      wx.showToast({ title: '请描述故障情况', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '提交中...' });
    api.post('/repair/create', {
      faultType: this.data.faultType,
      address: this.data.address,
      description: this.data.description,
      images: JSON.stringify(this.data.images),
      priority: this.data.priority
    }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '提交成功' });
        setTimeout(() => { wx.navigateBack(); }, 1500);
      } else {
        wx.showToast({ title: (result && result.message) || '提交失败', icon: 'none' });
      }
    });
  }
});
