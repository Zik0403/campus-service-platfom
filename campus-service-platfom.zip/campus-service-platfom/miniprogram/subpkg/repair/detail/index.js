const api = require('../../../api/index');

Page({
  data: {
    order: null,
    statusIcon: '',
    statusName: '',
    isEditing: false,
    isEvaluating: false,
    faultTypes: [
      { id: 1, name: '水管维修' },
      { id: 2, name: '电灯维修' },
      { id: 3, name: '门窗维修' },
      { id: 4, name: '空调维修' },
      { id: 5, name: '家具维修' },
      { id: 6, name: '其他维修' }
    ],
    faultTypeIndex: -1,
    editForm: {
      faultType: '',
      address: '',
      description: '',
      images: '',
      priority: 1
    },
    evaluateStar: 5,
    evaluateContent: ''
  },

  onLoad(options) {
    if (options.id) {
      this.loadDetail(options.id);
    }
  },

  async loadDetail(id) {
    try {
      const result = await api.get('/repair/detail', { orderId: id });
      if (!result || result.code !== 200 || !result.data) {
        return;
      }
      const order = result.data;
      if (order.images) {
        try {
          order.images = JSON.parse(order.images);
        } catch (e) {
          order.images = [];
        }
      }
      const statusMap = {
        1: { icon: '⏳', name: '待派单' },
        2: { icon: '🔧', name: '维修中' },
        3: { icon: '✅', name: '已解决' },
        4: { icon: '❌', name: '已驳回' },
        5: { icon: '🚫', name: '已取消' }
      };
      const status = statusMap[order.status] || { icon: '❓', name: '未知' };
      this.setData({
        order: order,
        statusIcon: status.icon,
        statusName: status.name
      });
    } catch (e) {
      console.error('加载报修详情失败', e);
    }
  },

  onEdit() {
    const order = this.data.order;
    const faultTypeIndex = this.data.faultTypes.findIndex(f => f.name === order.faultType);
    this.setData({
      isEditing: true,
      faultTypeIndex: faultTypeIndex >= 0 ? faultTypeIndex : -1,
      editForm: {
        faultType: order.faultType || '',
        address: order.address || '',
        description: order.description || '',
        images: order.images || [],
        priority: order.priority || 1
      }
    });
  },

  onCancelEdit() {
    this.setData({ isEditing: false });
  },

  onFaultTypeChange(e) {
    const index = e.detail.value;
    this.setData({
      faultTypeIndex: index,
      'editForm.faultType': this.data.faultTypes[index].name
    });
  },

  onAddressInput(e) {
    this.setData({ 'editForm.address': e.detail.value });
  },

  onDescInput(e) {
    this.setData({ 'editForm.description': e.detail.value });
  },

  onPriorityChange(e) {
    this.setData({ 'editForm.priority': parseInt(e.detail.value) });
  },

  onSaveEdit() {
    const form = this.data.editForm;
    if (!form.faultType) {
      wx.showToast({ title: '请选择故障类型', icon: 'none' });
      return;
    }
    if (!form.address) {
      wx.showToast({ title: '请填写楼栋房间', icon: 'none' });
      return;
    }
    const addr = form.address.trim();
    const hasChinese = /[\u4e00-\u9fa5]/.test(addr);
    const hasNumber = /\d/.test(addr);
    if (!hasChinese || !hasNumber) {
      wx.showToast({ title: '地址需包含楼栋名和房间号', icon: 'none' });
      return;
    }
    if (!form.description) {
      wx.showToast({ title: '请描述故障情况', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '保存中...' });
    api.post('/repair/update', {
      orderId: this.data.order.id,
      faultType: form.faultType,
      address: form.address,
      description: form.description,
      images: JSON.stringify(form.images),
      priority: form.priority
    }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '修改成功' });
        this.setData({ isEditing: false });
        this.loadDetail(this.data.order.id);
      } else {
        wx.showToast({ title: (result && result.message) || '修改失败', icon: 'none' });
      }
    });
  },

  onEvaluate() {
    this.setData({ isEvaluating: true, evaluateStar: 5, evaluateContent: '' });
  },

  onCancelEvaluate() {
    this.setData({ isEvaluating: false });
  },

  onStarTap(e) {
    this.setData({ evaluateStar: parseInt(e.currentTarget.dataset.star) });
  },

  onEvaluateContentInput(e) {
    this.setData({ evaluateContent: e.detail.value });
  },

  onSubmitEvaluate() {
    const { evaluateStar, evaluateContent, order } = this.data;
    wx.showLoading({ title: '提交中...' });
    api.post('/repair/evaluate', {
      orderId: order.id,
      star: evaluateStar,
      content: evaluateContent
    }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '评价成功', icon: 'success' });
        this.setData({ isEvaluating: false });
        this.loadDetail(order.id);
      } else {
        wx.showToast({ title: (result && result.message) || '评价失败', icon: 'none' });
      }
    }).catch(() => {
      wx.hideLoading();
      wx.showToast({ title: '评价失败', icon: 'none' });
    });
  }
});
