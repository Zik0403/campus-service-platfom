const api = require('../../../api/index');

Page({
  data: {
    list: [],
    loading: false
  },

  onLoad() {
    this.loadList();
  },

  onShow() {
    if (getApp().globalData.isLogin) {
      this.loadList();
    }
  },

  onPullDownRefresh() {
    this.loadList();
    wx.stopPullDownRefresh();
  },

  async loadList() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/repair/list');
      let list = [];
      if (result && result.code === 200 && result.data) {
        list = result.data.map(item => ({
          ...item,
          statusClass: item.status === 1 ? 'tag-warning' : (item.status === 2 ? 'tag-primary' : (item.status === 3 ? 'tag-success' : 'tag-gray')),
          statusName: ['', '待派单', '维修中', '已解决', '已驳回', '已取消'][item.status] || '未知'
        }));
      }
      this.setData({ list });
    } catch (e) {
      console.error('加载报修列表失败', e);
      this.setData({ list: [] });
    } finally {
      this.setData({ loading: false });
    }
  },

  onItemTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/subpkg/repair/detail/index?id=' + id });
  },

  onCreate() {
    wx.navigateTo({ url: '/subpkg/repair/create/index' });
  }
});
