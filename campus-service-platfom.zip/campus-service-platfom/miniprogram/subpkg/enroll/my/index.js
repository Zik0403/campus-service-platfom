const api = require('../../../api/index');

Page({
  data: {
    list: [],
    loading: true
  },

  onLoad() {
    this.loadList();
  },

  async loadList() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/enroll/my/list');
      if (result && result.code === 200 && result.data) {
        this.setData({
          list: result.data,
          loading: false
        });
      } else {
        this.setData({ list: [], loading: false });
      }
    } catch (e) {
      console.error('加载我的报名列表失败', e);
      this.setData({ list: [], loading: false });
    }
  },

  onDetail(e) {
    const enroll = e.currentTarget.dataset.enroll;
    wx.navigateTo({
      url: `/subpkg/activity/detail/index?id=${enroll.activityId}`
    });
  },

  onCheckin(e) {
    const enroll = e.currentTarget.dataset.enroll;
    if (enroll.checkinStatus === 1) {
      wx.showToast({ title: '您已签到', icon: 'none' });
      return;
    }
    wx.showModal({
      title: '确认签到',
      content: '确认要进行活动签到吗？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '签到中...' });
          const result = await api.post('/enroll/checkin', { enrollId: enroll.id });
          wx.hideLoading();
          if (result && result.code === 200) {
            wx.showToast({ title: '签到成功' });
            this.loadList();
          } else {
            wx.showToast({ title: (result && result.message) || '签到失败', icon: 'none' });
          }
        }
      }
    });
  },

  onCancel(e) {
    const enroll = e.currentTarget.dataset.enroll;
    wx.showModal({
      title: '取消报名',
      content: '确认要取消报名吗？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '取消中...' });
          const result = await api.post('/enroll/cancel', { enrollId: enroll.id });
          wx.hideLoading();
          if (result && result.code === 200) {
            wx.showToast({ title: '已取消报名' });
            this.loadList();
          } else {
            wx.showToast({ title: (result && result.message) || '取消失败', icon: 'none' });
          }
        }
      }
    });
  }
});