const api = require('../../../api/index.js');
const app = getApp();

Page({
  data: {
    userRole: 0,
    activeTab: 'express',
    orders: []
  },

  onLoad() {
    const userInfo = app.globalData.userInfo || wx.getStorageSync('userInfo');
    const userRole = userInfo ? userInfo.role : 1;
    let activeTab = 'express';
    if (userRole === 2) {
      activeTab = 'repair';
    }
    this.setData({ userRole, activeTab }, () => {
      this.loadOrders();
    });
  },

  onShow() {
    this.loadOrders();
  },

  onPullDownRefresh() {
    this.loadOrders().finally(() => {
      wx.stopPullDownRefresh();
    });
  },

  switchTab(e) {
    this.setData({ activeTab: e.currentTarget.dataset.tab, orders: [] }, () => {
      this.loadOrders();
    });
  },

  loadOrders() {
    const { activeTab, userRole } = this.data;
    if (userRole === 2) {
      return this.loadRepairOrders();
    }
    if (activeTab === 'secondhand') {
      return this.loadSecondhandOrders();
    }
    return this.loadServiceOrders(activeTab);
  },

  loadRepairOrders() {
    return api.get('/repair/pending').then(res => {
      if (res.code === 200) {
        const orders = (res.data || []).map(item => ({
          ...item,
          id: item.id,
          typeName: '维修单'
        }));
        this.setData({ orders });
      }
    });
  },

  loadServiceOrders(type) {
    const typeMap = { express: 1, errand: 2, food: 3 };
    const serviceType = typeMap[type];
    return api.get('/service/order/pending', { serviceType }).then(res => {
      if (res.code === 200) {
        const typeNameMap = { express: '快递', errand: '跑腿', food: '外卖' };
        const orders = (res.data || []).map(item => ({
          ...item,
          id: item.id,
          typeName: typeNameMap[type] || '服务单'
        }));
        this.setData({ orders });
      }
    });
  },

  loadSecondhandOrders() {
    return api.get('/second/order/pending').then(res => {
      if (res.code === 200) {
        const orders = (res.data || []).map(item => ({
          ...item,
          id: item.id,
          typeName: '二手交易',
          orderContent: item.product ? item.product.title : '',
          totalFee: item.payAmount || 0,
          targetAddr: '线下交易'
        }));
        this.setData({ orders });
      }
    });
  },

  onAccept(e) {
    const orderId = e.currentTarget.dataset.id;
    const { userRole, activeTab } = this.data;
    let url;
    if (userRole === 2) {
      url = '/repair/accept';
    } else if (activeTab === 'secondhand') {
      url = '/second/order/accept';
    } else {
      url = '/service/order/accept';
    }
    wx.showModal({
      title: '确认接单',
      content: '接单后请尽快完成订单',
      success: (res) => {
        if (res.confirm) {
          api.post(url, { orderId: String(orderId) }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '接单成功', icon: 'success' });
              this.loadOrders();
            } else {
              wx.showToast({ title: result.message || '接单失败', icon: 'none' });
            }
          });
        }
      }
    });
  }
});
