const api = require('../../../api/index.js');
const app = getApp();

Page({
  data: {
    userRole: 0,
    activeTab: 'unfinished',
    serviceType: 'express',
    orders: []
  },

  onLoad() {
    const userInfo = app.globalData.userInfo || wx.getStorageSync('userInfo');
    const userRole = userInfo ? userInfo.role : 1;
    this.setData({ userRole }, () => {
      this.loadOrders();
    });
  },

  onShow() {
    this.loadOrders();
  },

  onPullDownRefresh() {
    this.loadOrders().finally(() => {
      wx.stopPullDownRefresh();
    });
  },

  switchStatusTab(e) {
    this.setData({ activeTab: e.currentTarget.dataset.tab, orders: [] }, () => {
      this.loadOrders();
    });
  },

  switchServiceTab(e) {
    this.setData({ serviceType: e.currentTarget.dataset.tab, orders: [] }, () => {
      this.loadOrders();
    });
  },

  loadOrders() {
    const { userRole } = this.data;
    if (userRole === 2) {
      return this.loadRepairOrders();
    }
    return this.loadAllWorkerOrders();
  },

  loadRepairOrders() {
    return api.get('/repair/worker/pending').then(res => {
      if (res.code === 200) {
        const { activeTab } = this.data;
        const statusMap = { 1: '待派单', 2: '维修中', 3: '已完成', 4: '已驳回', 5: '已取消' };
        let orders = (res.data || []).map(item => {
          return {
            ...item,
            id: item.id,
            typeName: '维修单',
            statusName: statusMap[item.status] || '未知',
            canComplete: item.status === 2,
            canReturn: item.status === 2
          };
        });
        if (activeTab === 'unfinished') {
          orders = orders.filter(o => o.status === 1 || o.status === 2);
        } else {
          orders = orders.filter(o => o.status === 3 || o.status === 4 || o.status === 5);
        }
        this.setData({ orders });
      }
    });
  },

  loadAllWorkerOrders() {
    const { activeTab, serviceType } = this.data;
    const typeMap = { express: 1, errand: 2, food: 3 };
    return Promise.all([
      api.get('/service/order/worker/list'),
      api.get('/second/order/seller/list')
    ]).then(([serviceResult, secondhandResult]) => {
      let allOrders = [];
      if (serviceResult.code === 200) {
        const statusMap = { 1: '待付款', 2: '待接单', 3: '配送中', 4: '已完成', 5: '已取消' };
        const typeNameMap = { 1: '快递', 2: '跑腿', 3: '外卖' };
        allOrders = allOrders.concat((serviceResult.data || []).map(item => ({
          ...item,
          id: item.id,
          type: 'service',
          typeName: typeNameMap[item.serviceType] || '服务单',
          statusName: statusMap[item.status] || '未知',
          canComplete: item.status === 3,
          canReturn: item.status === 3
        })));
      }
      if (secondhandResult.code === 200) {
        const statusMap = { 1: '待支付', 2: '已支付', 3: '已交付', 4: '已完成', 5: '已退款' };
        allOrders = allOrders.concat((secondhandResult.data || []).map(item => ({
          ...item,
          id: item.id,
          type: 'secondhand',
          typeName: '二手交易',
          statusName: statusMap[item.payStatus] || '未知',
          canComplete: item.payStatus === 3,
          canReturn: item.payStatus === 2
        })));
      }
      if (serviceType && typeMap[serviceType]) {
        allOrders = allOrders.filter(o => o.type !== 'secondhand' && (!o.serviceType || o.serviceType === typeMap[serviceType]));
      } else if (serviceType === 'secondhand') {
        allOrders = allOrders.filter(o => o.type === 'secondhand');
      }
      if (activeTab === 'unfinished') {
        allOrders = allOrders.filter(o => {
          if (o.type === 'secondhand') {
            return o.payStatus === 2 || o.payStatus === 3;
          }
          return o.status === 2 || o.status === 3;
        });
      } else {
        allOrders = allOrders.filter(o => {
          if (o.type === 'secondhand') {
            return o.payStatus === 4 || o.payStatus === 5;
          }
          return o.status === 4 || o.status === 5;
        });
      }
      this.setData({ orders: allOrders });
    });
  },

  onComplete(e) {
    const orderId = e.currentTarget.dataset.id;
    const order = this.data.orders.find(o => o.id == orderId);
    const { userRole } = this.data;
    let url;
    if (userRole === 2) {
      url = '/repair/complete';
    } else if (order && order.type === 'secondhand') {
      url = '/second/order/confirm/receive';
    } else {
      url = '/service/order/complete';
    }
    wx.showModal({
      title: '确认完成',
      content: '确认该订单已完成？',
      success: (res) => {
        if (res.confirm) {
          api.post(url, { orderId: String(orderId) }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '已完成', icon: 'success' });
              this.loadOrders();
              getApp().refreshUserInfo();
            } else {
              wx.showToast({ title: result.message || '操作失败', icon: 'none' });
            }
          });
        }
      }
    });
  },

  onReturn(e) {
    const orderId = e.currentTarget.dataset.id;
    const order = this.data.orders.find(o => o.id == orderId);
    wx.showModal({
      title: '确认退回',
      content: '确认退回该订单？退回后订单将重新进入待接单状态',
      confirmColor: '#ff4d4f',
      success: (res) => {
        if (res.confirm) {
          let url;
          if (order && order.type === 'secondhand') {
            url = '/second/order/refund';
          } else {
            url = '/service/order/worker/return';
          }
          api.post(url, { orderId: String(orderId) }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '已退回', icon: 'success' });
              this.loadOrders();
            } else {
              wx.showToast({ title: result.message || '退回失败', icon: 'none' });
            }
          }).catch(() => {
            wx.showToast({ title: '网络异常', icon: 'none' });
          });
        }
      }
    });
  }
});
