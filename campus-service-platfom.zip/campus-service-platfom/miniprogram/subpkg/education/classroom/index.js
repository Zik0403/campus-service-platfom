Page({
  data: {
    activeTab: 'empty',
    classroomList: [],
    occupiedList: [],
    myReservations: [],
    building: '',
    weekDay: 1,
    section: 1,
    buildings: ['全部', '教1楼', '教2楼', '教3楼', '实验楼'],
    weekDays: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    sections: ['第1-2节', '第3-4节', '第5-6节', '第7-8节']
  },

  onLoad() {
    this.loadData();
  },

  onShow() {
    this.loadData();
  },

  loadData() {
    this.loadClassrooms();
    this.loadOccupied();
    this.loadMyReservations();
  },

  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab });
  },

  loadClassrooms() {
    const api = require('../../../api/index.js');
    const section = (this.data.section - 1) * 2 + 1;
    const params = {
      weekDay: this.data.weekDay,
      section: section
    };
    if (this.data.building && this.data.building !== '全部') {
      params.building = this.data.building;
    }
    api.get('/education/classroom/empty', params).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ classroomList: res.data });
      }
    });
  },

  loadOccupied() {
    const api = require('../../../api/index.js');
    const section = (this.data.section - 1) * 2 + 1;
    const params = {
      weekDay: this.data.weekDay,
      section: section
    };
    if (this.data.building && this.data.building !== '全部') {
      params.building = this.data.building;
    }
    api.get('/education/classroom/occupied', params).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ occupiedList: res.data });
      }
    });
  },

  loadMyReservations() {
    const api = require('../../../api/index.js');
    api.get('/education/classroom/reservation/list').then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ myReservations: res.data });
      }
    });
  },

  onBuildingChange(e) {
    const index = e.detail.value;
    const building = this.data.buildings[index];
    this.setData({ building }, () => {
      this.loadClassrooms();
      this.loadOccupied();
    });
  },

  onWeekDayChange(e) {
    const weekDay = parseInt(e.currentTarget.dataset.day);
    this.setData({ weekDay }, () => {
      this.loadClassrooms();
      this.loadOccupied();
    });
  },

  onSectionChange(e) {
    const section = parseInt(e.currentTarget.dataset.section);
    this.setData({ section }, () => {
      this.loadClassrooms();
      this.loadOccupied();
    });
  },

  onReserve(e) {
    const classroomId = e.currentTarget.dataset.id;
    const classroom = this.data.classroomList.find(c => c.id === classroomId);
    if (!classroom) return;
    const that = this;
    wx.showModal({
      title: '预约教室',
      editable: true,
      placeholderText: '请输入使用目的',
      content: `教室：${classroom.building}${classroom.roomNo}\n容量：${classroom.capacity}人\n节次：${this.data.sections[this.data.section - 1]}`,
      success: (res) => {
        if (res.confirm) {
          that.doReserve(classroomId, res.content || '');
        }
      }
    });
  },

  doReserve(classroomId, purpose) {
    const api = require('../../../api/index.js');
    const sectionStart = (this.data.section - 1) * 2 + 1;
    const sectionEnd = sectionStart + 1;
    const today = new Date();
    const dayOfWeek = today.getDay() === 0 ? 7 : today.getDay();
    const diff = this.data.weekDay - dayOfWeek;
    const targetDate = new Date(today.getTime() + diff * 24 * 60 * 60 * 1000);
    const dateStr = targetDate.toISOString().split('T')[0];
    api.post('/education/classroom/reserve', {
      classroomId,
      reserveDate: dateStr,
      sectionStart,
      sectionEnd,
      purpose
    }).then(res => {
      if (res.code === 200) {
        wx.showToast({ title: '预约成功', icon: 'success' });
        this.loadData();
      } else {
        wx.showToast({ title: res.message || '预约失败', icon: 'none' });
      }
    });
  },

  onCancelReservation(e) {
    const reservationId = e.currentTarget.dataset.id;
    wx.showModal({
      title: '取消预约',
      content: '确定要取消该预约吗？',
      success: (res) => {
        if (res.confirm) {
          const api = require('../../../api/index.js');
          api.post('/education/classroom/cancel', { reservationId }).then(result => {
            if (result.code === 200) {
              wx.showToast({ title: '取消成功', icon: 'success' });
              this.loadData();
            } else {
              wx.showToast({ title: result.message || '取消失败', icon: 'none' });
            }
          });
        }
      }
    });
  }
});
