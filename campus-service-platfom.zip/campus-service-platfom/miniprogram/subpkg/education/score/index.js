Page({
  data: {
    scoreList: [],
    summary: null,
    semester: '2023-2024-2',
    semesters: ['2023-2024-2', '2023-2024-1', '2022-2023-2']
  },

  onLoad() {
    this.loadScoreSummary();
    this.loadScoreList();
  },

  loadScoreSummary() {
    const api = require('../../../api/index.js');
    api.get('/education/score/summary').then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ summary: res.data });
      }
    });
  },

  loadScoreList() {
    const api = require('../../../api/index.js');
    api.get('/education/score/list', { semester: this.data.semester }).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ scoreList: res.data });
      }
    });
  },

  onSemesterChange(e) {
    const index = e.detail.value;
    const semester = this.data.semesters[index];
    this.setData({ semester }, () => {
      this.loadScoreList();
    });
  }
});
