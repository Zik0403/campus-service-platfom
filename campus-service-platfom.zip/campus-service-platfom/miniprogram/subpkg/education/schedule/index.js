Page({
  data: {
    weekDays: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    sections: ['第1节', '第2节', '第3节', '第4节', '第5节', '第6节', '第7节', '第8节'],
    currentWeek: 1,
    semester: '2024-2025-1',
    courseList: [],
    weekCourses: {}
  },

  onLoad() {
    this.loadCourseSchedule();
  },

  loadCourseSchedule() {
    const api = require('../../../api/index.js');
    api.get('/education/course/list', { semester: this.data.semester }).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ courseList: res.data });
        this.processWeekCourses();
      }
    });
  },

  processWeekCourses() {
    const { courseList, currentWeek } = this.data;
    const weekCourses = {};
    for (let i = 1; i <= 7; i++) {
      weekCourses[i] = [];
    }
    courseList.forEach(course => {
      if (currentWeek >= course.weekStart && currentWeek <= course.weekEnd) {
        weekCourses[course.weekDay].push(course);
      }
    });
    this.setData({ weekCourses });
  },

  onWeekChange(e) {
    const week = parseInt(e.currentTarget.dataset.week);
    this.setData({ currentWeek: week }, () => {
      this.processWeekCourses();
    });
  },

  onCourseTap(e) {
    const course = e.currentTarget.dataset.course;
    wx.showModal({
      title: course.courseName,
      content: `教师：${course.teacher || '无'}\n教室：${course.classroom || '无'}\n周次：第${course.weekStart}-${course.weekEnd}周`,
      showCancel: false
    });
  }
});
