Page({
  data: {
    examList: [],
    semester: '2024-2025-1'
  },

  onLoad() {
    this.loadExamList();
  },

  loadExamList() {
    const api = require('../../../api/index.js');
    api.get('/education/exam/list', { semester: this.data.semester }).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ examList: res.data });
      }
    });
  },

  formatDate(dateStr) {
    const date = new Date(dateStr);
    const weekDays = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    return {
      date: `${date.getMonth() + 1}月${date.getDate()}日`,
      weekDay: weekDays[date.getDay()]
    };
  }
});
