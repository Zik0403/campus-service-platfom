const api = require('../../../api/index');

Page({
  data: { 
    activity: null,
    activityId: null,
    hasEnrolled: false,
    enrollId: null,
    checkinStatus: false,
    checkoutStatus: false,
    isOrganizer: false,  // 是否是活动发起人
    enrollList: [],      // 报名人员列表
    showManagePanel: false,  // 是否显示管理面板
    checkinEnabled: true,    // 签到是否开启
    selectedUsers: []        // 选中的用户ID
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ activityId: options.id });
      this.loadDetail(options.id);
      this.checkEnrollStatus(options.id);
    }
  },

  async loadDetail(id) {
    try {
      const result = await api.get('/activity/detail', { activityId: id });
      const activity = result.data;
      // 判断是否是发起人（个人活动）
      const userInfo = getApp().globalData.userInfo;
      const isOrganizer = activity.activityType === 2 && userInfo && activity.organizerId === userInfo.id;
      this.setData({ activity, isOrganizer });
      // 如果是发起人，加载报名列表
      if (isOrganizer) {
        this.loadEnrollList(id);
      }
    } catch (e) {
      console.error('加载活动详情失败', e);
    }
  },

  async loadEnrollList(activityId) {
    try {
      const result = await api.get('/enroll/activity/list', { activityId });
      this.setData({ enrollList: result.data || [] });
    } catch (e) {
      console.error('加载报名列表失败', e);
    }
  },

  async checkEnrollStatus(activityId) {
    if (!getApp().globalData.isLogin) {
      return;
    }
    try {
      const result = await api.get('/enroll/check', { activityId });
      if (result.data) {
        this.setData({ 
          hasEnrolled: true,
          enrollId: result.data.id,
          checkinStatus: result.data.checkinStatus === 1,
          checkoutStatus: result.data.checkoutStatus === 1
        });
      }
    } catch (e) {
      console.error('检查报名状态失败', e);
    }
  },

  // 显示/隐藏管理面板
  toggleManagePanel() {
    this.setData({ showManagePanel: !this.data.showManagePanel });
  },

  // 开启/关闭签到
  toggleCheckin() {
    const newStatus = !this.data.checkinEnabled;
    this.setData({ checkinEnabled: newStatus });
    api.post('/enroll/checkin/toggle?activityId=' + this.data.activityId + '&enabled=' + newStatus, {}).then(() => {
      wx.showToast({ title: newStatus ? '签到已开启' : '签到已关闭' });
    }).catch(e => {
      wx.showToast({ title: e.message || '操作失败', icon: 'none' });
      this.setData({ checkinEnabled: !newStatus });
    });
  },

  // 选择用户
  onSelectUser(e) {
    const userId = e.currentTarget.dataset.userId;
    let selected = this.data.selectedUsers;
    if (selected.includes(userId)) {
      selected = selected.filter(id => id !== userId);
    } else {
      selected.push(userId);
    }
    this.setData({ selectedUsers: selected });
  },

  // 批量签到
  onBatchCheckin() {
    if (this.data.selectedUsers.length === 0) {
      wx.showToast({ title: '请先选择人员', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '批量签到...' });
    api.post('/enroll/batch/checkin?activityId=' + this.data.activityId, this.data.selectedUsers).then(() => {
      wx.hideLoading();
      wx.showToast({ title: '签到成功' });
      this.setData({ selectedUsers: [] });
      this.loadEnrollList(this.data.activityId);
    }).catch(e => {
      wx.hideLoading();
      wx.showToast({ title: e.message || '签到失败', icon: 'none' });
    });
  },

  // 批量签退
  onBatchCheckout() {
    if (this.data.selectedUsers.length === 0) {
      wx.showToast({ title: '请先选择人员', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '批量签退...' });
    api.post('/enroll/batch/checkout?activityId=' + this.data.activityId, this.data.selectedUsers).then(() => {
      wx.hideLoading();
      wx.showToast({ title: '签退成功' });
      this.setData({ selectedUsers: [] });
      this.loadEnrollList(this.data.activityId);
    }).catch(e => {
      wx.hideLoading();
      wx.showToast({ title: e.message || '签退失败', icon: 'none' });
    });
  },

  onEnroll() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.doEnroll();
      });
      return;
    }
    this.doEnroll();
  },

  async doEnroll() {
    wx.showLoading({ title: '报名中...' });
    try {
      const result = await api.post('/enroll/create?activityId=' + this.data.activityId, {});
      if (result.code === 200 && result.data) {
        this.setData({ 
          hasEnrolled: true,
          enrollId: result.data.id,
          checkinStatus: false,
          checkoutStatus: false
        });
        wx.showToast({ title: '报名成功' });
      } else {
        wx.showToast({ title: result.message || '报名失败', icon: 'none' });
      }
    } catch (e) {
      console.error('报名失败', e);
      wx.showToast({ title: e.message || '报名失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  onCheckin() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {});
      return;
    }
    this.doCheckin();
  },

  async doCheckin() {
    if (!this.data.checkinEnabled) {
      wx.showToast({ title: '签到未开启', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '签到中...' });
    try {
      await api.post('/enroll/checkin?enrollId=' + this.data.enrollId, {});
      this.setData({ checkinStatus: true });
      wx.showToast({ title: '签到成功' });
    } catch (e) {
      console.error('签到失败', e);
      wx.showToast({ title: e.message || '签到失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  onCheckout() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {});
      return;
    }
    this.doCheckout();
  },

  async doCheckout() {
    wx.showLoading({ title: '签退中...' });
    try {
      await api.post('/enroll/checkout?enrollId=' + this.data.enrollId, {});
      this.setData({ checkoutStatus: true });
      wx.showToast({ title: '签退成功，获得积分奖励' });
    } catch (e) {
      console.error('签退失败', e);
      wx.showToast({ title: e.message || '签退失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  }
});
