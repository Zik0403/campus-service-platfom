const api = require('../../../api/index');

Page({
  data: {
    list: [],
    loading: false
  },

  onLoad() {
    this.loadList();
  },

  async loadList() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/activity/list');
      this.setData({ list: result.data || [] });
    } catch (e) {
      console.error('加载活动列表失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  onItemTap(e) {
    wx.navigateTo({ url: '/subpkg/activity/detail/index?id=' + e.currentTarget.dataset.id });
  },

  onCreateActivity() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        wx.navigateTo({ url: '/subpkg/activity/create/index' });
      });
      return;
    }
    wx.navigateTo({ url: '/subpkg/activity/create/index' });
  }
});
