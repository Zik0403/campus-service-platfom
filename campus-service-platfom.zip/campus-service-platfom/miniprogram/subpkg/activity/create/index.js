const api = require('../../../api/index');

Page({
  data: {
    name: '',
    location: '',
    startTime: '',
    endTime: '',
    enrollDeadline: '',
    description: '',
    maxPeople: '50',
    creditPoints: '10',
    activityType: 2,
    startTimeDate: '',
    startTimeHour: '09',
    startTimeMinute: '00',
    endTimeDate: '',
    endTimeHour: '12',
    endTimeMinute: '00',
    deadlineDate: '',
    deadlineHour: '18',
    deadlineMinute: '00'
  },

  onNameInput(e) { this.setData({ name: e.detail.value }); },
  onLocationInput(e) { this.setData({ location: e.detail.value }); },
  
  onStartTimeDateChange(e) {
    this.setData({ startTimeDate: e.detail.value });
  },
  
  onStartTimeHourChange(e) {
    this.setData({ startTimeHour: e.detail.value });
  },
  
  onStartTimeMinuteChange(e) {
    this.setData({ startTimeMinute: e.detail.value });
  },
  
  onEndTimeDateChange(e) {
    this.setData({ endTimeDate: e.detail.value });
  },
  
  onEndTimeHourChange(e) {
    this.setData({ endTimeHour: e.detail.value });
  },
  
  onEndTimeMinuteChange(e) {
    this.setData({ endTimeMinute: e.detail.value });
  },
  
  onDeadlineDateChange(e) {
    this.setData({ deadlineDate: e.detail.value });
  },
  
  onDeadlineHourChange(e) {
    this.setData({ deadlineHour: e.detail.value });
  },
  
  onDeadlineMinuteChange(e) {
    this.setData({ deadlineMinute: e.detail.value });
  },
  
  getFormattedDateTime(date, hour, minute) {
    if (!date) return '';
    return `${date} ${hour}:${minute}:00`;
  },
  
  onDescInput(e) { this.setData({ description: e.detail.value }); },
  onMaxPeopleInput(e) { this.setData({ maxPeople: e.detail.value || '50' }); },
  onCreditPointsInput(e) { this.setData({ creditPoints: e.detail.value || '10' }); },

  onSubmit() {
    if (!this.data.name) { wx.showToast({ title: '请输入活动名称', icon: 'none' }); return; }
    if (!this.data.location) { wx.showToast({ title: '请输入活动地点', icon: 'none' }); return; }
    if (!this.data.startTimeDate) { wx.showToast({ title: '请选择开始日期', icon: 'none' }); return; }
    if (!this.data.endTimeDate) { wx.showToast({ title: '请选择结束日期', icon: 'none' }); return; }
    if (!this.data.deadlineDate) { wx.showToast({ title: '请选择报名截止日期', icon: 'none' }); return; }

    const startTime = this.getFormattedDateTime(this.data.startTimeDate, this.data.startTimeHour, this.data.startTimeMinute);
    const endTime = this.getFormattedDateTime(this.data.endTimeDate, this.data.endTimeHour, this.data.endTimeMinute);
    const enrollDeadline = this.getFormattedDateTime(this.data.deadlineDate, this.data.deadlineHour, this.data.deadlineMinute);

    wx.showLoading({ title: '发布中...' });
    const formData = {
      name: this.data.name,
      location: this.data.location,
      startTime: startTime,
      endTime: endTime,
      enrollDeadline: enrollDeadline,
      description: this.data.description,
      maxPeople: parseInt(this.data.maxPeople) || 50,
      creditPoints: parseInt(this.data.creditPoints) || 10,
      activityType: 2
    };
    api.post('/activity/create', formData, { loading: false }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '发布成功' });
        setTimeout(() => { wx.navigateBack(); }, 1500);
      } else {
        wx.showToast({ title: (result && result.message) || '发布失败', icon: 'none' });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '网络错误，请重试', icon: 'none' });
    });
  }
});