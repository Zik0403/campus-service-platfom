const api = require('../../../api/index');

Page({
  data: {
    code: '',
    company: '',
    address: '',
    tip: '2',
    showPayModal: false,
    payAmount: '',
    currentOrderId: ''
  },

  onCodeInput(e) { this.setData({ code: e.detail.value }); },
  onCompanyInput(e) { this.setData({ company: e.detail.value }); },
  onAddressInput(e) { this.setData({ address: e.detail.value }); },
  onTipInput(e) { this.setData({ tip: e.detail.value || '2' }); },

  onSubmit() {
    if (!this.data.code) { wx.showToast({ title: '请输入取件码', icon: 'none' }); return; }
    if (!this.data.address) { wx.showToast({ title: '请输入送达地址', icon: 'none' }); return; }
    wx.showLoading({ title: '提交中...' });
    api.post('/service/order/create', {
      serviceType: 1,
      targetAddr: this.data.address,
      orderContent: this.data.code + ' ' + this.data.company,
      tipFee: this.data.tip,
      totalFee: '5'
    }, { loading: false }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        const orderId = result.data.id;
        wx.showModal({
          title: '下单成功',
          content: '是否立即支付订单？',
          success: (res) => {
            if (res.confirm) {
              const totalAmount = parseFloat('5') + parseFloat(this.data.tip || '0');
              this.setData({
                showPayModal: true,
                payAmount: totalAmount.toFixed(2),
                currentOrderId: orderId
              });
            } else {
              wx.navigateBack();
            }
          }
        });
      } else {
        wx.showToast({ title: (result && result.message) || '提交失败', icon: 'none' });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '网络错误，请重试', icon: 'none' });
    });
  },

  onPayModalCancel() {
    this.setData({ showPayModal: false });
  },

  onPayModalConfirm(e) {
    const { password } = e.detail;
    const { currentOrderId } = this.data;
    const app = getApp();
    wx.showLoading({ title: '支付中...' });
    api.post('/service/order/pay?orderId=' + currentOrderId + '&wxPayNo=mock_pay_' + Date.now() + '&payPassword=' + password, {}, { loading: false }).then(res => {
      wx.hideLoading();
      if (res && res.code === 200) {
        this.setData({ showPayModal: false });
        wx.showToast({ title: '支付成功' });
        app.refreshUserInfo();
        setTimeout(() => {
          wx.switchTab({ url: '/pages/order/index' });
        }, 1500);
      } else {
        if (res && res.message && res.message.includes('支付密码')) {
          this.selectComponent('pay-password-modal')?.showError(res.message);
        } else {
          wx.showToast({ title: (res && res.message) || '支付失败', icon: 'none' });
        }
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '支付失败，请重试', icon: 'none' });
    });
  }
});
