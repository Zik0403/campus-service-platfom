Page({
  data: {
    cert: null
  },

  onLoad(options) {
    const id = options.id;
    if (id) {
      this.loadCertDetail(id);
    }
  },

  loadCertDetail(id) {
    const api = require('../../../api/index.js');
    api.get('/career/cert/detail', { id }).then(res => {
      if (res.code === 200 && res.data) {
        wx.setNavigationBarTitle({ title: res.data.certName });
        this.setData({ cert: res.data });
      }
    });
  }
});
