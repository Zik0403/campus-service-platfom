Page({
  data: {
    certList: [],
    certType: '',
    types: [
      { label: '全部', value: '' },
      { label: '语言类', value: '语言类' },
      { label: '计算机类', value: '计算机类' },
      { label: '职业资格', value: '职业资格' },
      { label: '财经类', value: '财经类' }
    ]
  },

  onLoad() {
    this.loadCertList();
  },

  onTypeTap(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({ certType: type }, () => {
      this.loadCertList();
    });
  },

  loadCertList() {
    const api = require('../../../api/index.js');
    const params = {};
    if (this.data.certType) {
      params.certType = this.data.certType;
    }
    api.get('/career/cert/list', params).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ certList: res.data });
      }
    });
  },

  onCertTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/subpkg/career/cert-detail/index?id=${id}`
    });
  }
});
