Page({
  data: {
    activeTab: 'all',
    scoreList: [],
    tabs: [
      { label: '全部', value: 'all' },
      { label: '四级', value: '四级' },
      { label: '六级', value: '六级' }
    ]
  },

  onLoad() {
    this.loadScores();
  },

  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ activeTab: tab }, () => {
      this.loadScores();
    });
  },

  loadScores() {
    const api = require('../../../api/index.js');
    const params = {};
    if (this.data.activeTab !== 'all') {
      params.cetType = this.data.activeTab;
    }
    api.get('/career/cet/list', params).then(res => {
      if (res.code === 200 && res.data) {
        this.setData({ scoreList: res.data });
      }
    });
  }
});
