var api = require('../../../api/index');

Page({
  data: {
    notice: null,
    loading: true
  },

  onLoad: function(options) {
    if (options.id) {
      this.loadDetail(options.id);
    }
  },

  loadDetail: function(id) {
    var that = this;
    that.setData({ loading: true });
    api.get('/notice/detail', { id: id }).then(function(result) {
      if (result.code === 200 && result.data) {
        var notice = result.data;
        var typeName = '公告';
        var typeClass = 'tag-primary';
        if (notice.noticeType == 2) {
          typeName = '活动';
          typeClass = 'tag-warning';
        } else if (notice.noticeType == 3) {
          typeName = '优惠';
          typeClass = 'tag-danger';
        }
        notice.typeName = typeName;
        notice.typeClass = typeClass;
        notice.formatTime = notice.createTime ? notice.createTime.substring(0, 16) : '';
        that.setData({ notice: notice, loading: false });
      } else {
        wx.showToast({ title: result.message || '公告不存在', icon: 'none' });
        that.setData({ loading: false });
      }
    }).catch(function(e) {
      wx.showToast({ title: '加载失败', icon: 'none' });
      that.setData({ loading: false });
    });
  },

  onShare: function() {
    if (this.data.notice) {
      wx.shareAppMessage({
        title: this.data.notice.title,
        path: '/subpkg/notice/detail/index?id=' + this.data.notice.id
      });
    }
  },

  onCopyLink: function() {
    if (this.data.notice && this.data.notice.linkUrl) {
      wx.setClipboardData({
        data: this.data.notice.linkUrl,
        success: function() {
          wx.showToast({ title: '链接已复制', icon: 'success' });
        }
      });
    }
  }
});