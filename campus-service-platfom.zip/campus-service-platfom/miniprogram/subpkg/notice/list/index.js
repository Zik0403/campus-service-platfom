var api = require('../../../api/index');

Page({
  data: {
    notices: [],
    loading: false,
    currentType: 0
  },

  onLoad: function() {
    this.loadNotices();
  },

  onPullDownRefresh: function() {
    this.loadNotices();
    wx.stopPullDownRefresh();
  },

  loadNotices: function() {
    var that = this;
    that.setData({ loading: true });
    var url = '/notice/list';
    if (that.data.currentType !== 0) {
      url = '/notice/listByType?noticeType=' + that.data.currentType;
    }
    api.get(url).then(function(result) {
      var notices = [];
      if (result.data && result.data.length > 0) {
        notices = result.data.map(function(item) {
          var typeName = '公告';
          var typeClass = 'tag-primary';
          if (item.noticeType == 2) {
            typeName = '活动';
            typeClass = 'tag-warning';
          } else if (item.noticeType == 3) {
            typeName = '优惠';
            typeClass = 'tag-danger';
          }
          return {
            id: item.id,
            title: item.title,
            content: item.content,
            noticeType: item.noticeType,
            createTime: item.createTime,
            typeName: typeName,
            typeClass: typeClass,
            timeAgo: that.formatTime(item.createTime)
          };
        });
      }
      that.setData({ notices: notices });
    }).catch(function(e) {
      that.setData({ notices: [] });
    }).finally(function() {
      that.setData({ loading: false });
    });
  },

  formatTime: function(time) {
    if (!time) return '';
    var date = new Date(time);
    var now = new Date();
    var diff = now - date;
    var days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return '今天';
    if (days === 1) return '昨天';
    if (days < 7) return days + '天前';
    return time.substring(0, 10);
  },

  onTypeChange: function(e) {
    var type = parseInt(e.currentTarget.dataset.type);
    this.setData({ currentType: type, notices: [] });
    this.loadNotices();
  },

  onNoticeTap: function(e) {
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/subpkg/notice/detail/index?id=' + id });
  }
});