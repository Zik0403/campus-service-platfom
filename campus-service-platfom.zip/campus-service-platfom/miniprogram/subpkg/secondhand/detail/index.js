const api = require('../../../api/index');

const categoryMap = {
  book: { name: '教材', icon: '📚', bgColor: '#e6f7ff' },
  教材: { name: '教材', icon: '📚', bgColor: '#e6f7ff' },
  digital: { name: '数码', icon: '📱', bgColor: '#fff7e6' },
  数码: { name: '数码', icon: '📱', bgColor: '#fff7e6' },
  clothing: { name: '服饰', icon: '👕', bgColor: '#f6ffed' },
  服饰: { name: '服饰', icon: '👕', bgColor: '#f6ffed' },
  life: { name: '生活', icon: '🏠', bgColor: '#fff1f0' },
  生活: { name: '生活', icon: '🏠', bgColor: '#fff1f0' },
  bike: { name: '电动车', icon: '🛵', bgColor: '#e6f7ff' },
  电动车: { name: '电动车', icon: '🛵', bgColor: '#e6f7ff' },
  beauty: { name: '美妆', icon: '💄', bgColor: '#fff7e6' },
  美妆: { name: '美妆', icon: '💄', bgColor: '#fff7e6' },
  sports: { name: '运动', icon: '⚽', bgColor: '#f6ffed' },
  运动: { name: '运动', icon: '⚽', bgColor: '#f6ffed' },
  default: { name: '商品', icon: '📦', bgColor: '#f5f5f5' }
};

Page({
  data: {
    product: null,
    images: [],
    categoryInfo: categoryMap.default,
    hasPurchased: false,
    orderId: null,
    orderStatus: null,
    orderStatusText: '',
    balance: 0,
    showPayModal: false,
    payAmount: ''
  },

  onLoad(options) {
    if (options.id) {
      this.loadDetail(options.id);
      this.loadBalance();
    }
  },

  async loadBalance() {
    if (!getApp().globalData.isLogin) return;
    try {
      const result = await api.get('/user/info', {}, { loading: false });
      if (result.data) {
        this.setData({ balance: result.data.balance || 0 });
      }
    } catch (e) {
      console.error('加载余额失败', e);
    }
  },

  async loadDetail(id) {
    try {
      const result = await api.get('/product/detail', { productId: id });
      const product = result.data;
      if (!product) return;
      let images = [];
      if (product.images) {
        try {
          images = typeof product.images === 'string' ? JSON.parse(product.images) : product.images;
        } catch (e) {
          images = [];
        }
      }
      images = (images || []).filter(img => img && img.trim() && img.trim() !== 'null');
      this.setData({ product, images, categoryInfo: categoryMap[product.category] || categoryMap.default });
      this.checkOrderStatus(id);
    } catch (e) {
      console.error('加载商品详情失败', e);
    }
  },

  async checkOrderStatus(productId) {
    if (!getApp().globalData.isLogin) return;
    try {
      const result = await api.get('/second/order/buyer/list');
      const orders = result.data || [];
      const order = orders.find(o => o.productId == productId);
      if (order) {
        this.setData({
          hasPurchased: true,
          orderId: order.id,
          orderStatus: order.payStatus,
          orderStatusText: this.getStatusText(order.payStatus)
        });
      }
    } catch (e) {
      console.error('检查订单状态失败', e);
    }
  },

  getStatusText(status) {
    const statusMap = {
      1: '待支付',
      2: '已支付',
      3: '已交付',
      4: '已完成',
      5: '已退款'
    };
    return statusMap[status] || '未知';
  },

  onBuy() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.doBuy();
      });
      return;
    }
    this.doBuy();
  },

  async doBuy() {
    wx.showLoading({ title: '下单中...' });
    try {
      const result = await api.post('/second/order/create', { productId: this.data.product.id });
      wx.hideLoading();
      if (result.code === 200) {
        const orderId = result.data.id;
        wx.showModal({
          title: '下单成功',
          content: '是否立即支付？',
          success: (res) => {
            if (res.confirm) {
              this.onPayWithOrderId(orderId);
            } else {
              this.setData({
                hasPurchased: true,
                orderId: orderId,
                orderStatus: 1,
                orderStatusText: '待支付'
              });
            }
          }
        });
      } else {
        wx.showToast({ title: result.message || '下单失败', icon: 'none' });
      }
    } catch (e) {
      wx.hideLoading();
      wx.showToast({ title: e.message || '下单失败', icon: 'none' });
    }
  },

  onPay() {
    this.onPayWithOrderId(this.data.orderId);
  },

  onPayWithOrderId(orderId) {
    const price = this.data.product.price || 0;
    if (price > this.data.balance) {
      wx.showModal({
        title: '余额不足',
        content: '当前余额：¥' + this.data.balance + '，需要：¥' + price + '，请先充值',
        showCancel: false
      });
      return;
    }
    this.setData({
      showPayModal: true,
      payAmount: price.toFixed(2),
      orderId: orderId
    });
  },

  onPayModalCancel() {
    this.setData({ showPayModal: false });
  },

  async onPayModalConfirm(e) {
    const { password } = e.detail;
    const { orderId } = this.data;
    wx.showLoading({ title: '支付中...' });
    try {
      const url = '/second/order/pay?orderId=' + orderId + '&wxPayNo=mock_pay_' + Date.now() + '&payPassword=' + password;
      const result = await api.post(url, {});
      wx.hideLoading();
      if (result.code === 200) {
        this.setData({ 
          showPayModal: false,
          orderStatus: 2,
          orderStatusText: '已支付'
        });
        wx.showToast({ title: '支付成功' });
        getApp().refreshUserInfo();
        setTimeout(() => {
          wx.navigateTo({ url: '/pages/order/index' });
        }, 1500);
      } else {
        if (result.message && result.message.includes('支付密码')) {
          this.selectComponent('pay-password-modal')?.showError(result.message);
        } else {
          wx.showToast({ title: result.message || '支付失败', icon: 'none' });
        }
      }
    } catch (e) {
      wx.hideLoading();
      if (e.message && e.message.includes('支付密码')) {
        this.selectComponent('pay-password-modal')?.showError(e.message);
      } else {
        wx.showToast({ title: e.message || '支付失败', icon: 'none' });
      }
    }
  },

  onConfirmDelivery() {
    wx.showModal({
      title: '确认交付',
      content: '确认已收到商品？',
      success: (res) => {
        if (res.confirm) {
          this.doConfirmDelivery();
        }
      }
    });
  },

  async doConfirmDelivery() {
    wx.showLoading({ title: '确认中...' });
    try {
      await api.post('/second/order/confirm/delivery', { orderId: this.data.orderId });
      wx.showToast({ title: '已确认交付' });
      this.setData({
        orderStatus: 3,
        orderStatusText: '已交付'
      });
    } catch (e) {
      wx.showToast({ title: e.message || '操作失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  }
});
