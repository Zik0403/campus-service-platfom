const api = require('../../../api/index');

Page({
  data: {
    title: '',
    categoryIndex: null,
    category: '',
    categoryLabel: '',
    price: '',
    desc: '',
    images: [],
    categoryLabels: ['教材', '数码', '服饰', '生活', '电动车', '美妆', '运动'],
    categoryValues: ['book', 'digital', 'clothing', 'life', 'bike', 'beauty', 'sports']
  },

  onTitleInput(e) { this.setData({ title: e.detail.value }); },
  onCategoryChange(e) {
    const idx = e.detail.value;
    this.setData({
      categoryIndex: idx,
      category: this.data.categoryValues[idx],
      categoryLabel: this.data.categoryLabels[idx]
    });
  },
  onPriceInput(e) { this.setData({ price: e.detail.value }); },
  onDescInput(e) { this.setData({ desc: e.detail.value }); },

  onChooseImage() {
    const that = this;
    wx.chooseImage({
      count: 9 - this.data.images.length,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        that.setData({ images: that.data.images.concat(res.tempFilePaths) });
      }
    });
  },

  onDeleteImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = this.data.images.slice();
    images.splice(index, 1);
    this.setData({ images });
  },

  onSubmit() {
    if (!this.data.title) { wx.showToast({ title: '请输入标题', icon: 'none' }); return; }
    if (!this.data.category) { wx.showToast({ title: '请选择分类', icon: 'none' }); return; }
    if (!this.data.price) { wx.showToast({ title: '请输入价格', icon: 'none' }); return; }
    wx.showLoading({ title: '提交中...' });
    api.post('/product/create', {
      title: this.data.title,
      category: this.data.category,
      price: this.data.price,
      desc: this.data.desc,
      images: JSON.stringify(this.data.images),
      allowBargain: 1,
      validDay: 15
    }, { loading: false }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '发布成功' });
        setTimeout(() => { wx.navigateBack(); }, 1500);
      } else {
        wx.showToast({ title: (result && result.message) || '发布失败', icon: 'none' });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '网络错误，请重试', icon: 'none' });
    });
  }
});
