const api = require('../../../api/index');

const categoryMap = {
  book: { name: '教材', icon: '📚', bgColor: '#e6f7ff' },
  教材: { name: '教材', icon: '📚', bgColor: '#e6f7ff' },
  digital: { name: '数码', icon: '📱', bgColor: '#fff7e6' },
  数码: { name: '数码', icon: '📱', bgColor: '#fff7e6' },
  clothing: { name: '服饰', icon: '👕', bgColor: '#f6ffed' },
  服饰: { name: '服饰', icon: '👕', bgColor: '#f6ffed' },
  life: { name: '生活', icon: '🏠', bgColor: '#fff1f0' },
  生活: { name: '生活', icon: '🏠', bgColor: '#fff1f0' },
  bike: { name: '电动车', icon: '🛵', bgColor: '#e6f7ff' },
  电动车: { name: '电动车', icon: '🛵', bgColor: '#e6f7ff' },
  beauty: { name: '美妆', icon: '💄', bgColor: '#fff7e6' },
  美妆: { name: '美妆', icon: '💄', bgColor: '#fff7e6' },
  sports: { name: '运动', icon: '⚽', bgColor: '#f6ffed' },
  运动: { name: '运动', icon: '⚽', bgColor: '#f6ffed' },
  default: { name: '商品', icon: '📦', bgColor: '#f5f5f5' }
};

Page({
  data: {
    currentCategory: '',
    products: [],
    loading: false
  },

  getCategoryInfo(category) {
    return categoryMap[category] || categoryMap.default;
  },

  onLoad() {
    this.loadProducts();
  },

  onCategoryChange(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({ currentCategory: category });
    this.loadProducts();
  },

  async loadProducts() {
    this.setData({ loading: true });
    try {
      const data = this.data.currentCategory
        ? await api.get('/product/list', { category: this.data.currentCategory })
        : await api.get('/product/list');
      let products = data.data || [];
      products = products.map(function (item) {
        if (typeof item.images === 'string') {
          try { item.images = JSON.parse(item.images); } catch (e) { item.images = []; }
        }
        if (!item.images || item.images.length === 0) {
          item.images = [];
          item.hasImage = false;
        } else {
          const first = item.images[0];
          item.hasImage = !!(first && first.trim() && first.trim() !== 'null');
        }
        const catInfo = categoryMap[item.category] || categoryMap.default;
        item.categoryIcon = catInfo.icon;
        item.categoryBgColor = catInfo.bgColor;
        item.categoryName = catInfo.name;
        return item;
      });
      this.setData({ products: products });
    } catch (e) {
      console.error('加载商品失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  onProductTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/subpkg/secondhand/detail/index?id=' + id });
  },

  onPublish() {
    wx.navigateTo({ url: '/subpkg/secondhand/create/index' });
  }
});
