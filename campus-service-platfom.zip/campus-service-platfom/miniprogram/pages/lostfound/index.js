const api = require('../../api/index');

Page({
  data: {
    currentType: 1,
    list: [],
    loading: false
  },

  onLoad() {
    this.loadList();
  },

  onShow() {
    if (getApp().globalData.isLogin) {
      this.loadList();
    }
  },

  onTypeChange(e) {
    const type = parseInt(e.currentTarget.dataset.type);
    this.setData({ currentType: type });
    this.loadList();
  },

  async loadList() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/lostfound/list', { type: this.data.currentType });
      const list = (result.data || []).map(item => ({
        ...item,
        statusClass: item.status === 1 ? 'tag-warning' : (item.status === 2 ? 'tag-success' : 'tag-gray'),
        statusName: item.status === 1 ? '待匹配' : (item.status === 2 ? '已找到' : '已过期')
      }));
      this.setData({ list });
    } catch (e) {
      console.error('加载失物列表失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  onPublish() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        wx.navigateTo({ url: '/pages/lostfound/publish?type=' + this.data.currentType });
      });
      return;
    }
    wx.navigateTo({ url: '/pages/lostfound/publish?type=' + this.data.currentType });
  },

  onItemTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/pages/lostfound/detail?id=' + id });
  }
});
