const api = require('../../api/index');

Page({
  data: {
    id: null,
    item: null,
    comments: [],
    liked: false,
    commentContent: ''
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ id: options.id });
      this.loadItem();
      this.loadComments();
    }
  },

  async loadItem() {
    try {
      const result = await api.get('/lostfound/detail', { id: this.data.id });
      let item = result.data;
      if (item.images) {
        try {
          item.images = JSON.parse(item.images);
        } catch (e) {
          item.images = [];
        }
      }
      this.setData({ item });
    } catch (e) {
      console.error('加载失物详情失败', e);
      wx.showToast({ title: '加载失败', icon: 'none' });
    }
  },

  async loadComments() {
    try {
      const result = await api.get('/comment/list', { targetType: 2, targetId: this.data.id });
      this.setData({ comments: result.data || [] });
    } catch (e) {
      console.error('加载评论失败', e);
    }
  },

  onLike() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.doLike();
      });
      return;
    }
    this.doLike();
  },

  async doLike() {
    wx.showLoading({ title: '点赞中...' });
    try {
      await api.post('/lostfound/like', { id: this.data.id });
      this.setData({
        liked: true,
        'item.likeNum': (this.data.item.likeNum || 0) + 1
      });
      wx.showToast({ title: '点赞成功' });
    } catch (e) {
      wx.showToast({ title: '点赞失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  onComment() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {});
    }
  },

  onContact() {
    const contact = this.data.item.contact;
    if (contact) {
      wx.showModal({
        title: '联系方式',
        content: contact,
        showCancel: false
      });
    }
  },

  onCommentInput(e) {
    this.setData({ commentContent: e.detail.value });
  },

  onSubmitComment() {
    if (!this.data.commentContent.trim()) {
      wx.showToast({ title: '请输入评论内容', icon: 'none' });
      return;
    }
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.doSubmitComment();
      });
      return;
    }
    this.doSubmitComment();
  },

  async doSubmitComment() {
    wx.showLoading({ title: '发送中...' });
    try {
      await api.post('/comment/add', {
        targetType: 2,
        targetId: this.data.id,
        content: this.data.commentContent
      });
      this.setData({
        commentContent: '',
        'item.commentNum': (this.data.item.commentNum || 0) + 1
      });
      this.loadComments();
      wx.showToast({ title: '评论成功' });
    } catch (e) {
      wx.showToast({ title: '评论失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  }
});
