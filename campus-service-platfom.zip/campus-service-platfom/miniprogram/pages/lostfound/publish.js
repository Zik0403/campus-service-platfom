const api = require('../../api/index');

Page({
  data: {
    type: 1,
    goodsName: '',
    goodsTypeIndex: -1,
    goodsType: '',
    goodsTypes: ['证件卡片', '电子产品', '钱包现金', '钥匙配饰', '书籍文具', '衣物鞋帽', '其他'],
    location: '',
    feature: '',
    contact: '',
    images: []
  },

  onLoad(options) {
    if (options.type) {
      this.setData({ type: parseInt(options.type) });
      wx.setNavigationBarTitle({
        title: this.data.type === 1 ? '发布寻物' : '发布拾物'
      });
    }
  },

  onGoodsNameInput(e) {
    this.setData({ goodsName: e.detail.value });
  },

  onGoodsTypeChange(e) {
    const idx = e.detail.value;
    this.setData({
      goodsTypeIndex: idx,
      goodsType: this.data.goodsTypes[idx]
    });
  },

  onLocationInput(e) {
    this.setData({ location: e.detail.value });
  },

  onFeatureInput(e) {
    this.setData({ feature: e.detail.value });
  },

  onContactInput(e) {
    this.setData({ contact: e.detail.value });
  },

  onChooseImage() {
    const that = this;
    wx.chooseMedia({
      count: 3 - this.data.images.length,
      mediaType: ['image'],
      success(res) {
        const tempFiles = res.tempFiles.map(f => f.tempFilePath);
        that.setData({
          images: that.data.images.concat(tempFiles)
        });
      }
    });
  },

  onDeleteImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = this.data.images.slice();
    images.splice(index, 1);
    this.setData({ images });
  },

  onSubmit() {
    if (!this.data.goodsName) {
      wx.showToast({ title: '请输入物品名称', icon: 'none' });
      return;
    }
    if (!this.data.goodsType) {
      wx.showToast({ title: '请选择物品分类', icon: 'none' });
      return;
    }
    if (!this.data.location) {
      wx.showToast({ title: '请输入' + (this.data.type === 1 ? '丢失' : '拾取') + '地点', icon: 'none' });
      return;
    }
    if (!this.data.feature) {
      wx.showToast({ title: '请描述物品特征', icon: 'none' });
      return;
    }
    if (!this.data.contact) {
      wx.showToast({ title: '请输入联系方式', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '提交中...' });
    api.post('/lostfound/create', {
      type: this.data.type,
      goodsName: this.data.goodsName,
      goodsType: this.data.goodsType,
      location: this.data.location,
      feature: this.data.feature,
      contact: this.data.contact,
      images: JSON.stringify(this.data.images)
    }, { loading: false }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '发布成功' });
        setTimeout(() => { wx.navigateBack(); }, 1500);
      } else {
        wx.showToast({ title: (result && result.message) || '发布失败', icon: 'none' });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '网络错误，请重试', icon: 'none' });
    });
  }
});
