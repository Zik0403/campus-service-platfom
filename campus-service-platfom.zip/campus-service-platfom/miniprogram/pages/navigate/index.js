Page({
  data: {
    activeCategory: 'teaching',
    searchKeyword: '',
    categories: [
      { key: 'teaching', name: '教学楼', icon: '🏫' },
      { key: 'dorm', name: '宿舍', icon: '🏠' },
      { key: 'canteen', name: '食堂', icon: '🍽️' },
      { key: 'library', name: '图书馆', icon: '📚' },
      { key: 'sports', name: '运动场', icon: '⚽' },
      { key: 'service', name: '服务点', icon: '🛎️' },
      { key: 'scenic', name: '校园景点', icon: '🌳' }
    ],
    locations: {
      teaching: [
        { id: 1, name: '第一教学楼', desc: '公共课教室，共6层120间教室，设有空调和多媒体设备', building: 'A区', floor: '1-6层', openTime: '6:00-22:30' },
        { id: 2, name: '第二教学楼', desc: '专业课教室，含多媒体教室和阶梯教室', building: 'B区', floor: '1-8层', openTime: '6:00-22:30' },
        { id: 3, name: '实验楼', desc: '物理、化学、生物实验室，配备专业实验设备', building: 'C区', floor: '1-5层', openTime: '8:00-21:00' },
        { id: 4, name: '计算机楼', desc: '机房、编程实验室，高配电脑200台', building: 'D区', floor: '1-6层', openTime: '8:00-22:00' },
        { id: 5, name: '行政楼', desc: '教务处、学工处、财务处办公', building: 'A区东侧', floor: '1-10层', openTime: '8:30-17:30' },
        { id: 6, name: '外语楼', desc: '外语专业教室，配有语音室', building: 'B区西侧', floor: '1-5层', openTime: '6:00-22:00' }
      ],
      dorm: [
        { id: 1, name: '1号宿舍楼', desc: '男生宿舍，6人间，独立卫浴', building: '东苑', floor: '1-6层', openTime: '24小时' },
        { id: 2, name: '2号宿舍楼', desc: '男生宿舍，4人间，上床下桌', building: '东苑', floor: '1-6层', openTime: '24小时' },
        { id: 3, name: '3号宿舍楼', desc: '女生宿舍，6人间，独立卫浴', building: '西苑', floor: '1-6层', openTime: '24小时' },
        { id: 4, name: '4号宿舍楼', desc: '女生宿舍，4人间，上床下桌', building: '西苑', floor: '1-6层', openTime: '24小时' },
        { id: 5, name: '5号宿舍楼', desc: '研究生宿舍，2人间，条件优越', building: '南苑', floor: '1-8层', openTime: '24小时' },
        { id: 6, name: '留学生公寓', desc: '留学生宿舍，单人间，设施齐全', building: '北苑', floor: '1-10层', openTime: '24小时' }
      ],
      canteen: [
        { id: 1, name: '第一食堂', desc: '家常菜、面食，性价比高，学生首选', building: '东苑', floor: '1-2层', openTime: '6:30-21:00' },
        { id: 2, name: '第二食堂', desc: '各地特色小吃，品种丰富', building: '西苑', floor: '1-2层', openTime: '6:30-21:30' },
        { id: 3, name: '第三食堂', desc: '清真餐厅、教工餐厅，环境优雅', building: '南苑', floor: '1层', openTime: '6:30-20:30' },
        { id: 4, name: '美食广场', desc: '奶茶、汉堡、麻辣烫等网红美食', building: '商业街', floor: '1-2层', openTime: '10:00-22:00' },
        { id: 5, name: '学生餐厅', desc: '自选餐，称重计费，品种多样', building: '东苑', floor: '3层', openTime: '11:00-20:00' }
      ],
      library: [
        { id: 1, name: '图书馆主馆', desc: '馆藏图书300万册，阅览座位5000个，空调全覆盖', building: '校园中心', floor: '1-8层', openTime: '8:00-22:00' },
        { id: 2, name: '电子阅览室', desc: '电脑200台，电子资源数据库，知网、万方等', building: '图书馆3层', floor: '3层', openTime: '8:00-22:00' },
        { id: 3, name: '自习室', desc: '24小时开放自习区，考研考公必备', building: '图书馆1层', floor: '1层', openTime: '24小时' },
        { id: 4, name: '报刊阅览室', desc: '期刊杂志500余种，报纸100余种', building: '图书馆2层', floor: '2层', openTime: '8:00-22:00' }
      ],
      sports: [
        { id: 1, name: '田径场', desc: '标准400米跑道，足球场，草坪质量优良', building: '东区', floor: '室外', openTime: '6:00-22:00' },
        { id: 2, name: '体育馆', desc: '篮球馆、羽毛球馆、乒乓球馆，可容纳3000人', building: '东区', floor: '1-3层', openTime: '8:00-22:00' },
        { id: 3, name: '游泳馆', desc: '标准50米泳池，水质优良，配备救生员', building: '东区', floor: '1层', openTime: '10:00-21:00' },
        { id: 4, name: '篮球场', desc: '室外篮球场10块，灯光球场，夜场开放', building: '西区', floor: '室外', openTime: '6:00-22:00' },
        { id: 5, name: '网球场', desc: '室外网球场4块，专业场地，需预约', building: '南区', floor: '室外', openTime: '8:00-22:00' },
        { id: 6, name: '健身房', desc: '器材齐全，有氧无氧分区，有专业教练', building: '体育馆B1层', floor: '负1层', openTime: '9:00-22:00' }
      ],
      service: [
        { id: 1, name: '校医院', desc: '全科门诊、急诊24小时，医保定点', building: '南门', floor: '1-3层', openTime: '24小时急诊' },
        { id: 2, name: '快递中心', desc: '顺丰、圆通、中通、韵达等快递点', building: '商业街', floor: '1层', openTime: '9:00-20:00' },
        { id: 3, name: '超市', desc: '生活用品、零食饮料、学习用品', building: '商业街', floor: '1层', openTime: '8:00-22:00' },
        { id: 4, name: '银行ATM', desc: '工行、建行、中行ATM，24小时服务', building: '商业街', floor: '1层', openTime: '24小时' },
        { id: 5, name: '理发店', desc: '美发、烫染、造型，学生价优惠', building: '商业街', floor: '1层', openTime: '10:00-21:00' },
        { id: 6, name: '文印店', desc: '打印、复印、装订、海报制作', building: '一教一楼', floor: '1层', openTime: '8:00-22:00' },
        { id: 7, name: '移动营业厅', desc: '手机卡办理、宽带安装、缴费服务', building: '商业街', floor: '1层', openTime: '9:00-18:00' }
      ],
      scenic: [
        { id: 1, name: '人工湖', desc: '校园中心湖泊，风景优美，适合散步约会', building: '图书馆南侧', floor: '室外', openTime: '全天开放' },
        { id: 2, name: '樱花大道', desc: '春季樱花盛开，网红打卡地', building: '行政楼前', floor: '室外', openTime: '全天开放' },
        { id: 3, name: '校训石', desc: '校园标志性建筑，合影留念必去', building: '正门广场', floor: '室外', openTime: '全天开放' },
        { id: 4, name: '晨读花园', desc: '环境清幽，适合晨读和放松', building: '外语楼旁', floor: '室外', openTime: '全天开放' },
        { id: 5, name: '银杏林', desc: '秋季金黄一片，美不胜收', building: '西苑宿舍旁', floor: '室外', openTime: '全天开放' }
      ]
    },
    currentList: []
  },

  onLoad() {
    this.filterLocations('teaching');
  },

  onSearchInput(e) {
    const keyword = e.detail.value;
    this.setData({ searchKeyword: keyword });
    this.filterLocations(this.data.activeCategory, keyword);
  },

  onCategoryTap(e) {
    const key = e.currentTarget.dataset.key;
    this.setData({ activeCategory: key, searchKeyword: '' });
    this.filterLocations(key);
  },

  filterLocations(category, keyword) {
    let list = this.data.locations[category] || [];
    if (keyword && keyword.trim()) {
      const kw = keyword.toLowerCase();
      list = list.filter(item => 
        item.name.toLowerCase().includes(kw) ||
        item.desc.toLowerCase().includes(kw) ||
        item.building.toLowerCase().includes(kw)
      );
    }
    this.setData({ currentList: list });
  },

  onLocationTap(e) {
    const item = e.currentTarget.dataset.item;
    wx.showModal({
      title: item.name,
      content: `${item.desc}\n📍 位置：${item.building}\n🏢 楼层：${item.floor}\n🕐 开放时间：${item.openTime || '全天'}`,
      showCancel: false,
      confirmText: '知道了'
    });
  },

  onNavigate(e) {
    const item = e.currentTarget.dataset.item;
    wx.showToast({
      title: '正在为您导航到' + item.name,
      icon: 'none'
    });
  }
});
