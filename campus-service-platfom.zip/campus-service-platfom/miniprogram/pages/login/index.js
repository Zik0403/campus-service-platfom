const app = getApp();
const api = require('../../api/index.js');

Page({
  data: {
    account: '',
    password: '',
    showPassword: false,
    loading: false
  },

  onLoad() {
    if (app.globalData.isLogin) {
      wx.switchTab({ url: '/pages/index/index' });
    }
  },

  onAccountInput(e) {
    this.setData({ account: e.detail.value });
  },

  onPasswordInput(e) {
    this.setData({ password: e.detail.value });
  },

  onTogglePassword() {
    this.setData({ showPassword: !this.data.showPassword });
  },

  onLogin() {
    const { account, password } = this.data;
    if (!account) {
      wx.showToast({ title: '请输入学号或手机号', icon: 'none' });
      return;
    }
    const isStudentId = /^\d{10}$/.test(account);
    const isPhone = /^1[3-9]\d{9}$/.test(account);
    if (!isStudentId && !isPhone) {
      wx.showToast({ title: '学号为10位数字，手机号为11位', icon: 'none' });
      return;
    }
    if (!password || password.length !== 6) {
      wx.showToast({ title: '密码必须是6位', icon: 'none' });
      return;
    }
    const hasNumber = /\d/.test(password);
    const hasLetter = /[a-zA-Z]/.test(password);
    if (!hasNumber || !hasLetter) {
      wx.showToast({ title: '密码必须包含数字和英文', icon: 'none' });
      return;
    }

    this.setData({ loading: true });
    api.post('/user/login', { account, password }).then(res => {
      this.setData({ loading: false });
      if (res.code === 200 && res.data) {
        const data = res.data;
        app.globalData.token = data.token;
        app.globalData.isLogin = true;
        app.globalData.userInfo = data.userInfo;
        wx.setStorageSync('token', data.token);
        wx.setStorageSync('userInfo', data.userInfo);
        // 维修人员跳转到接单页面，学生跳转到首页
        if (data.userInfo && data.userInfo.role === 2) {
          wx.reLaunch({ url: '/subpkg/worker/pending/index' });
        } else {
          wx.switchTab({ url: '/pages/index/index' });
        }
      } else {
        wx.showToast({ title: res.message || '登录失败', icon: 'none' });
      }
    });
  },

  onRegister() {
    wx.navigateTo({ url: '/pages/register/index' });
  },

  onForgotPassword() {
    wx.navigateTo({ url: '/pages/reset-password/index' });
  }
});
