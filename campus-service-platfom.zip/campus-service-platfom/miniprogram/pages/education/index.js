Page({
  data: {},

  onServiceTap(e) {
    const type = e.currentTarget.dataset.type;
    const routes = {
      schedule: '/subpkg/education/schedule/index',
      classroom: '/subpkg/education/classroom/index',
      score: '/subpkg/education/score/index',
      exam: '/subpkg/education/exam/index',
      library: '/subpkg/library/book/index',
      borrow: '/subpkg/library/borrow/index',
      seat: '/subpkg/library/seat/index',
      checkin: '/subpkg/library/study/index',
      cet: '/subpkg/career/cet/index',
      cert: '/subpkg/career/cert/index'
    };
    const url = routes[type];
    if (url) {
      wx.navigateTo({ url });
    } else {
      wx.showToast({ title: '功能开发中', icon: 'none' });
    }
  }
});
