const api = require('../../api/index');

Page({
  data: {
    currentCategory: '',
    products: [],
    loading: false
  },

  onLoad() {
    this.loadProducts();
  },

  onShow() {
    if (getApp().globalData.isLogin) {
      this.loadProducts();
    }
  },

  onPullDownRefresh() {
    this.loadProducts();
    wx.stopPullDownRefresh();
  },

  onCategoryChange(e) {
    const category = e.currentTarget.dataset.category;
    this.setData({ currentCategory: category });
    this.loadProducts();
  },

  async loadProducts() {
    this.setData({ loading: true });
    try {
      const data = this.data.currentCategory
        ? await api.get('/product/list', { category: this.data.currentCategory })
        : await api.get('/product/list');
      this.setData({ products: data.data || [] });
    } catch (e) {
      console.error('加载商品失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  onProductTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/subpkg/secondhand/detail/index?id=' + id });
  },

  onPublish() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        wx.navigateTo({ url: '/subpkg/secondhand/create/index' });
      });
      return;
    }
    wx.navigateTo({ url: '/subpkg/secondhand/create/index' });
  }
});
