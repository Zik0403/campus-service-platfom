const api = require('../../api/index');

Page({
  data: {
    postType: 1,
    title: '',
    content: '',
    images: [],
    isAnon: false
  },

  onLoad(options) {
    if (options.type) {
      this.setData({ postType: parseInt(options.type) });
      const titles = { 1: '发布表白', 2: '发布帖子', 3: '发布兼职' };
      wx.setNavigationBarTitle({
        title: titles[this.data.postType] || '发布'
      });
    }
  },

  onTitleInput(e) {
    this.setData({ title: e.detail.value });
  },

  onContentInput(e) {
    this.setData({ content: e.detail.value });
  },

  onAnonChange(e) {
    this.setData({ isAnon: e.detail.value });
  },

  onChooseImage() {
    const that = this;
    wx.chooseMedia({
      count: 9 - this.data.images.length,
      mediaType: ['image'],
      success(res) {
        const tempFiles = res.tempFiles.map(f => f.tempFilePath);
        that.setData({
          images: that.data.images.concat(tempFiles)
        });
      }
    });
  },

  onDeleteImage(e) {
    const index = e.currentTarget.dataset.index;
    const images = this.data.images.slice();
    images.splice(index, 1);
    this.setData({ images });
  },

  onSubmit() {
    if (this.data.postType !== 1 && !this.data.title) {
      wx.showToast({ title: '请输入标题', icon: 'none' });
      return;
    }
    if (!this.data.content) {
      wx.showToast({ title: '请输入内容', icon: 'none' });
      return;
    }
    wx.showLoading({ title: '发布中...' });
    api.post('/post/create', {
      postType: this.data.postType,
      title: this.data.title,
      content: this.data.content,
      images: JSON.stringify(this.data.images),
      isAnon: this.data.isAnon ? 1 : 0
    }, { loading: false }).then(result => {
      wx.hideLoading();
      if (result && result.code === 200) {
        wx.showToast({ title: '发布成功' });
        setTimeout(() => { wx.navigateBack(); }, 1500);
      } else {
        wx.showToast({ title: (result && result.message) || '发布失败', icon: 'none' });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '网络错误，请重试', icon: 'none' });
    });
  }
});
