const api = require('../../api/index');

Page({
  data: {
    currentType: 1,
    list: [],
    loading: false
  },

  onLoad(options) {
    if (options.type) {
      this.setData({ currentType: parseInt(options.type) });
    }
    this.loadList();
  },

  onShow() {
    if (getApp().globalData.isLogin) {
      this.loadList();
    }
  },

  onPullDownRefresh() {
    this.loadList();
    wx.stopPullDownRefresh();
  },

  onTypeChange(e) {
    const type = parseInt(e.currentTarget.dataset.type);
    this.setData({ currentType: type });
    this.loadList();
  },

  async loadList() {
    this.setData({ loading: true });
    try {
      const result = await api.get('/post/list', { postType: this.data.currentType });
      this.setData({ list: result.data || [] });
    } catch (e) {
      console.error('加载帖子列表失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  onItemTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/pages/social/detail?id=' + id });
  },

  onPublish() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        wx.navigateTo({ url: '/pages/social/publish?type=' + this.data.currentType });
      });
      return;
    }
    wx.navigateTo({ url: '/pages/social/publish?type=' + this.data.currentType });
  }
});
