const api = require('../../api/index');

Page({
  data: {
    postId: null,
    post: null,
    comments: [],
    liked: false,
    commentContent: ''
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ postId: options.id });
      this.loadPost();
      this.loadComments();
    }
  },

  async loadPost() {
    try {
      const result = await api.get('/post/detail', { postId: this.data.postId });
      let post = result.data;
      if (post.images) {
        try {
          post.images = JSON.parse(post.images);
        } catch (e) {
          post.images = [];
        }
      }
      this.setData({ post });
    } catch (e) {
      console.error('加载帖子详情失败', e);
      wx.showToast({ title: '加载失败', icon: 'none' });
    }
  },

  async loadComments() {
    try {
      const result = await api.get('/comment/list', { targetType: 1, targetId: this.data.postId });
      this.setData({ comments: result.data || [] });
    } catch (e) {
      console.error('加载评论失败', e);
    }
  },

  onLike() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.doLike();
      });
      return;
    }
    this.doLike();
  },

  async doLike() {
    wx.showLoading({ title: '点赞中...' });
    try {
      await api.post('/post/like', { postId: this.data.postId });
      this.setData({
        liked: true,
        'post.likeNum': this.data.post.likeNum + 1
      });
      wx.showToast({ title: '点赞成功' });
    } catch (e) {
      wx.showToast({ title: '点赞失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  onComment() {
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {});
    }
  },

  onShare() {
    wx.showToast({ title: '分享功能开发中', icon: 'none' });
  },

  onCommentInput(e) {
    this.setData({ commentContent: e.detail.value });
  },

  onSubmitComment() {
    if (!this.data.commentContent.trim()) {
      wx.showToast({ title: '请输入评论内容', icon: 'none' });
      return;
    }
    if (!getApp().globalData.isLogin) {
      getApp().login(() => {
        this.doSubmitComment();
      });
      return;
    }
    this.doSubmitComment();
  },

  async doSubmitComment() {
    wx.showLoading({ title: '发送中...' });
    try {
      await api.post('/comment/add', {
        targetType: 1,
        targetId: this.data.postId,
        content: this.data.commentContent
      });
      this.setData({
        commentContent: '',
        'post.commentNum': this.data.post.commentNum + 1
      });
      this.loadComments();
      wx.showToast({ title: '评论成功' });
    } catch (e) {
      wx.showToast({ title: '评论失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  }
});
