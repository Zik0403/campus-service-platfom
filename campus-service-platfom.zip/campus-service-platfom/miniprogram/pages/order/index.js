const api = require('../../api/index');

Page({
  data: {
    currentTab: 'all',
    orders: [],
    loading: false,
    balance: 0,
    showPayModal: false,
    payAmount: '',
    currentOrderId: '',
    currentOrderType: ''
  },

  onLoad(options) {
    if (options.type) {
      this.setData({ currentTab: options.type });
    }
    this.loadOrders();
    this.loadBalance();
  },

  onShow() {
    if (getApp().globalData.isLogin) {
      this.loadOrders();
      this.loadBalance();
    }
  },

  async loadBalance() {
    if (!getApp().globalData.isLogin) return;
    try {
      const result = await api.get('/user/info', {}, { loading: false });
      if (result.data) {
        this.setData({ balance: result.data.balance || 0 });
        // 同步更新全局用户信息
        const app = getApp();
        if (app.globalData.userInfo) {
          app.globalData.userInfo.balance = result.data.balance;
          wx.setStorageSync('userInfo', result.data);
        }
      }
    } catch (e) {
      console.error('加载余额失败', e);
    }
  },

  onTabChange(e) {
    const tab = e.currentTarget.dataset.tab;
    this.setData({ currentTab: tab, orders: [] });
    this.loadOrders();
  },

  async loadOrders() {
    if (!getApp().globalData.isLogin) {
      return;
    }
    this.setData({ loading: true });
    try {
      let orders = [];
      switch (this.data.currentTab) {
        case 'repair':
          {
            const result = await api.get('/repair/list');
            orders = (result.data || []).map(o => ({ ...o, type: 'repair' }));
          }
          break;
        case 'express':
          {
            const result = await api.get('/service/order/list', { serviceType: 1 });
            orders = (result.data || []).map(o => ({ ...o, type: 'express' }));
          }
          break;
        case 'errand':
          {
            const result = await api.get('/service/order/list', { serviceType: 2 });
            orders = (result.data || []).map(o => ({ ...o, type: 'errand' }));
          }
          break;
        case 'food':
          {
            const result = await api.get('/service/order/list', { serviceType: 3 });
            orders = (result.data || []).map(o => ({ ...o, type: 'food' }));
          }
          break;
        case 'secondhand':
          {
            const result = await api.get('/second/order/buyer/list');
            orders = (result.data || []).map(o => ({ ...o, type: 'secondhand' }));
          }
          break;
        default:
          {
            const [repairResult, serviceResult, secondhandResult] = await Promise.all([
              api.get('/repair/list'),
              api.get('/service/order/list'),
              api.get('/second/order/buyer/list')
            ]);
            orders = [
              ...((repairResult.data || []).map(o => ({ ...o, type: 'repair' }))),
              ...((serviceResult.data || []).map(o => {
                const types = ['', 'express', 'errand', 'food'];
                return { ...o, type: types[o.serviceType] || 'express' };
              })),
              ...((secondhandResult.data || []).map(o => ({ ...o, type: 'secondhand' })))
            ];
          }
      }
      this.setData({ orders: this.formatOrders(orders) });
    } catch (e) {
      console.error('加载订单失败', e);
    } finally {
      this.setData({ loading: false });
    }
  },

  formatOrders(orders) {
    const typeMap = {
      'repair': { icon: '🔧', name: '报修', class: 'tag-warning' },
      'express': { icon: '📮', name: '快递', class: 'tag-primary' },
      'errand': { icon: '🏃', name: '跑腿', class: 'tag-primary' },
      'food': { icon: '🍔', name: '外卖', class: 'tag-success' },
      'secondhand': { icon: '📦', name: '二手', class: 'tag-gray' }
    };
    const serviceStatusMap = {
      1: { name: '待付款', class: 'tag-warning' },
      2: { name: '待接单', class: 'tag-primary' },
      3: { name: '配送中', class: 'tag-primary' },
      4: { name: '已完成', class: 'tag-success' },
      5: { name: '已取消', class: 'tag-gray' }
    };
    const repairStatusMap = {
      1: { name: '待派单', class: 'tag-warning' },
      2: { name: '维修中', class: 'tag-primary' },
      3: { name: '已解决', class: 'tag-success' },
      4: { name: '已驳回', class: 'tag-danger' },
      5: { name: '已取消', class: 'tag-gray' }
    };
    const secondhandStatusMap = {
      1: { name: '待支付', class: 'tag-warning' },
      2: { name: '已支付', class: 'tag-primary' },
      3: { name: '已交付', class: 'tag-primary' },
      4: { name: '已完成', class: 'tag-success' },
      5: { name: '已退款', class: 'tag-gray' }
    };
    return orders.map(order => {
      const type = order.type || (order.serviceType ? ['', 'express', 'errand', 'food'][order.serviceType] : 'repair');
      const typeInfo = typeMap[type] || typeMap.repair;
      let statusInfo;
      if (type === 'repair') {
        statusInfo = repairStatusMap[order.status] || { name: '未知', class: 'tag-gray' };
      } else if (type === 'secondhand') {
        statusInfo = secondhandStatusMap[order.payStatus] || { name: '未知', class: 'tag-gray' };
      } else {
        statusInfo = serviceStatusMap[order.status] || { name: '未知', class: 'tag-gray' };
      }
      let totalAmount = 0;
      if (order.totalFee) {
        totalAmount += parseFloat(order.totalFee);
      }
      if (order.tipFee) {
        totalAmount += parseFloat(order.tipFee);
      }
      if (order.payAmount) {
        totalAmount += parseFloat(order.payAmount);
      }
      let content = order.desc || order.orderContent || order.title || '订单详情';
      if (type === 'repair' && order.faultType) {
        content = order.faultType + (order.description ? ' - ' + order.description : '');
      }
      if (type === 'secondhand' && order.product && order.product.title) {
        content = order.product.title;
      }
      let canCancel = false;
      if (type === 'secondhand') {
        canCancel = order.payStatus === 1 || order.payStatus === 2;
      } else if (type === 'repair') {
        canCancel = order.status === 1 || order.status === 2;
      } else {
        canCancel = order.status === 1 || order.status === 2;
      }
      return {
        ...order,
        id: order.id || order.orderId,
        type: type,
        typeIcon: typeInfo.icon,
        typeName: typeInfo.name,
        statusName: statusInfo.name,
        statusClass: statusInfo.class,
        content: content,
        amount: totalAmount || order.payAmount || order.totalFee || 0,
        canCancel: canCancel
      };
    });
  },

  onOrderTap(e) {
    const { id, type } = e.currentTarget.dataset;
    const routes = {
      'repair': '/subpkg/repair/detail/index?id=' + id,
      'express': '/subpkg/express/detail/index?id=' + id,
      'errand': '/subpkg/errand/detail/index?id=' + id,
      'food': '/subpkg/food/detail/index?id=' + id,
      'secondhand': '/subpkg/secondhand/order/index?id=' + id
    };
    wx.navigateTo({ url: routes[type] || '/pages/order/index' });
  },

  onPay(e) {
    const orderId = e.currentTarget.dataset.id;
    const amount = parseFloat(e.currentTarget.dataset.amount);
    const type = e.currentTarget.dataset.type;
    if (amount > this.data.balance) {
      wx.showModal({
        title: '余额不足',
        content: '当前余额：¥' + this.data.balance + '，需要：¥' + amount + '，请先充值',
        showCancel: false
      });
      return;
    }
    this.setData({
      showPayModal: true,
      payAmount: amount.toFixed(2),
      currentOrderId: orderId,
      currentOrderType: type
    });
  },

  onPayModalCancel() {
    this.setData({ showPayModal: false });
  },

  async onPayModalConfirm(e) {
    const { password } = e.detail;
    const { currentOrderId, currentOrderType } = this.data;
    wx.showLoading({ title: '支付中...' });
    try {
      let url;
      if (currentOrderType === 'secondhand') {
        url = '/second/order/pay?orderId=' + currentOrderId + '&wxPayNo=mock_pay_' + Date.now() + '&payPassword=' + password;
      } else {
        url = '/service/order/pay?orderId=' + currentOrderId + '&wxPayNo=mock_pay_' + Date.now() + '&payPassword=' + password;
      }
      const result = await api.post(url, {});
      wx.hideLoading();
      if (result.code === 200) {
        this.setData({ showPayModal: false });
        wx.showToast({ title: '支付成功' });
        setTimeout(() => {
          this.loadOrders();
          this.loadBalance();
        }, 500);
      } else {
        if (result.message && result.message.includes('支付密码')) {
          this.selectComponent('pay-password-modal')?.showError(result.message);
        } else {
          wx.showToast({ title: result.message || '支付失败', icon: 'none' });
        }
      }
    } catch (err) {
      wx.hideLoading();
      if (err.message && err.message.includes('支付密码')) {
        this.selectComponent('pay-password-modal')?.showError(err.message);
      } else {
        wx.showToast({ title: err.message || '支付失败，请重试', icon: 'none' });
      }
    }
  },

  onCancelOrder(e) {
    const orderId = e.currentTarget.dataset.id;
    const type = e.currentTarget.dataset.type;
    wx.showModal({
      title: '撤回订单',
      content: '确认撤回该订单？已支付的金额将自动退还到账户余额',
      confirmColor: '#ff4d4f',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' });
          try {
            let url;
            if (type === 'secondhand') {
              url = '/second/order/refund?orderId=' + orderId;
            } else if (type === 'repair') {
              url = '/repair/cancel?orderId=' + orderId;
            } else {
              url = '/service/order/cancel?orderId=' + orderId;
            }
            const result = await api.post(url, {});
            wx.hideLoading();
            if (result.code === 200) {
              wx.showToast({ title: '撤回成功', icon: 'success' });
              setTimeout(() => {
                this.loadOrders();
                this.loadBalance();
              }, 500);
            } else {
              wx.showToast({ title: result.message || '撤回失败', icon: 'none' });
            }
          } catch (err) {
            wx.hideLoading();
            wx.showToast({ title: err.message || '撤回失败', icon: 'none' });
          }
        }
      }
    });
  }
});
