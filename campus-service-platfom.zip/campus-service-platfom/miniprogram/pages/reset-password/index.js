const api = require('../../api/index.js');

Page({
  data: {
    studentId: '',
    phone: '',
    newPassword: '',
    confirmPassword: '',
    showPassword: false,
    loading: false
  },

  onStudentIdInput(e) {
    this.setData({ studentId: e.detail.value });
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  onNewPasswordInput(e) {
    this.setData({ newPassword: e.detail.value });
  },

  onConfirmPasswordInput(e) {
    this.setData({ confirmPassword: e.detail.value });
  },

  onTogglePassword() {
    this.setData({ showPassword: !this.data.showPassword });
  },

  onReset() {
    const { studentId, phone, newPassword, confirmPassword } = this.data;
    if (!studentId || !/^\d{10}$/.test(studentId)) {
      wx.showToast({ title: '学号必须是10位数字', icon: 'none' });
      return;
    }
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({ title: '请输入正确的手机号', icon: 'none' });
      return;
    }
    if (!newPassword || newPassword.length !== 6) {
      wx.showToast({ title: '新密码必须是6位', icon: 'none' });
      return;
    }
    const hasNumber = /\d/.test(newPassword);
    const hasLetter = /[a-zA-Z]/.test(newPassword);
    if (!hasNumber || !hasLetter) {
      wx.showToast({ title: '密码必须包含数字和英文', icon: 'none' });
      return;
    }
    if (newPassword !== confirmPassword) {
      wx.showToast({ title: '两次密码不一致', icon: 'none' });
      return;
    }

    this.setData({ loading: true });
    api.post('/user/reset-password', { studentId, phone, newPassword }).then(res => {
      this.setData({ loading: false });
      if (res.code === 200) {
        wx.showToast({ title: '重置成功，请重新登录', icon: 'success' });
        setTimeout(() => {
          wx.redirectTo({ url: '/pages/login/index' });
        }, 1500);
      } else {
        wx.showToast({ title: res.message || '重置失败', icon: 'none' });
      }
    });
  }
});
