const api = require('../../api/index');

Page({
  data: {
    banners: [],
    notices: [],
    hotServices: [],
    creditTop: [],
    gridItems: [
      { id: 'schedule', name: '课表查询', icon: '📅', bgColor: '#e6f7ff' },
      { id: 'repair', name: '宿舍报修', icon: '🔧', bgColor: '#fff7e6' },
      { id: 'secondhand', name: '二手市场', icon: '📦', bgColor: '#f6ffed' },
      { id: 'lostfound', name: '失物招领', icon: '🔍', bgColor: '#fff1f0' },
      { id: 'express', name: '快递代取', icon: '📮', bgColor: '#e6f7ff' },
      { id: 'errand', name: '校园跑腿', icon: '🏃', bgColor: '#fff7e6' },
      { id: 'food', name: '校园外卖', icon: '🍔', bgColor: '#f6ffed' },
      { id: 'confession', name: '表白墙', icon: '💕', bgColor: '#fff1f0' },
      { id: 'activity', name: '社团活动', icon: '🎉', bgColor: '#e6f7ff' },
      { id: 'club', name: '社团中心', icon: '👥', bgColor: '#fff7e6' },
      { id: 'classroom', name: '空教室', icon: '🏫', bgColor: '#f6ffed' },
      { id: 'navigator', name: '校园导航', icon: '🗺️', bgColor: '#fff1f0' }
    ]
  },

  onLoad() {
    this.loadData();
  },

  onShow() {
    if (getApp().globalData.isLogin) {
      this.loadData();
    }
  },

  onPullDownRefresh() {
    this.loadData();
    wx.stopPullDownRefresh();
  },

  loadData() {
    this.loadBanners();
    this.loadNotices();
    this.loadHotServices();
    this.loadCreditTop();
  },

  async loadBanners() {
    this.setData({
      banners: [
        { id: 1, image: '/imajes/微信图片_20260706204726_146_6.jpg' }
      ]
    });
  },

  async loadNotices() {
    try {
      const result = await api.get('/notice/list');
      this.setData({ notices: (result.data || []).slice(0, 3) });
    } catch (e) {
      this.setData({ notices: [] });
    }
  },

  async loadHotServices() {
    this.setData({
      hotServices: [
        { id: 1, name: '宿舍报修', icon: '🔧', bgColor: '#fff7e6', orderCount: 1256 },
        { id: 2, name: '快递代取', icon: '📮', bgColor: '#e6f7ff', orderCount: 2341 },
        { id: 3, name: '校园跑腿', icon: '🏃', bgColor: '#fff7e6', orderCount: 1892 }
      ]
    });
  },

  async loadCreditTop() {
    try {
      const result = await api.get('/user/credit/top', { limit: 5 });
      const list = (result.data || []).map((item, index) => ({
        ...item,
        rank: index + 1,
        avatarUrl: api.getImageUrl(item.avatar)
      }));
      this.setData({ creditTop: list });
    } catch (e) {
      this.setData({ creditTop: [] });
    }
  },

  onGridTap(e) {
    const id = e.currentTarget.dataset.id;
    const app = getApp();
    if (!app.globalData.isLogin) {
      app.login(() => {
        this.navigateToPage(id);
      });
      // 同时也直接允许跳转，避免登录回调未触发时阻塞
      this.navigateToPage(id);
      return;
    }
    this.navigateToPage(id);
  },

  navigateToPage(id) {
    const routes = {
      'schedule': '/pages/education/index',
      'repair': '/subpkg/repair/list/index',
      'secondhand': '/subpkg/secondhand/list/index',
      'lostfound': '/pages/lostfound/index',
      'express': '/subpkg/express/list/index',
      'errand': '/subpkg/errand/list/index',
      'food': '/subpkg/food/list/index',
      'confession': '/pages/social/index?type=1',
      'activity': '/subpkg/activity/list/index',
      'club': '/subpkg/club/list/index',
      'classroom': '/pages/education/index',
      'navigator': '/pages/navigate/index'
    };
    const url = routes[id];
    if (url) {
      wx.navigateTo({ url });
    } else {
      wx.showToast({ title: '功能开发中', icon: 'none' });
    }
  },

  onMoreNotice() {
    wx.navigateTo({ url: '/subpkg/notice/list/index' });
  },

  onNoticeTap(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/subpkg/notice/detail/index?id=' + id });
  },

  onHotServiceTap(e) {
    const id = e.currentTarget.dataset.id;
    if (id === 1) {
      wx.navigateTo({ url: '/subpkg/repair/list/index' });
    } else if (id === 2) {
      wx.navigateTo({ url: '/subpkg/express/list/index' });
    } else if (id === 3) {
      wx.navigateTo({ url: '/subpkg/errand/list/index' });
    }
  }
});
