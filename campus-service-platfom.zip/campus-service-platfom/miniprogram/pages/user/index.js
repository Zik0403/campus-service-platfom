const app = getApp();
const api = require('../../api/index.js');

Page({
  data: {
    hasLogin: false,
    userInfo: null,
    userRole: 0,
    avatarUrl: ''
  },

  onLoad() {
    this.checkLoginStatus();
  },

  onShow() {
    this.checkLoginStatus();
    this.refreshUserInfo();
  },

  checkLoginStatus() {
    const hasLogin = app.globalData.isLogin;
    const userInfo = app.globalData.userInfo;
    const userRole = userInfo ? userInfo.role : 0;
    const avatarUrl = userInfo ? api.getImageUrl(userInfo.avatar) : '';
    this.setData({ hasLogin, userInfo, userRole, avatarUrl });
  },

  refreshUserInfo() {
    if (app.globalData.isLogin && app.globalData.token && app.globalData.token !== 'guest') {
      api.get('/user/info', {}, { loading: false }).then(res => {
        if (res.code === 200 && res.data) {
          app.globalData.userInfo = res.data;
          wx.setStorageSync('userInfo', res.data);
          const userRole = res.data.role || 0;
          const avatarUrl = api.getImageUrl(res.data.avatar);
          this.setData({ userInfo: res.data, userRole, avatarUrl });
        }
      });
    }
  },

  onLogin() {
    app.login(() => {
      this.checkLoginStatus();
    });
  },

  onUserInfoTap() {
    if (!app.globalData.isLogin) {
      this.onLogin();
      return;
    }
    wx.navigateTo({ url: '/subpkg/profile/info/index' });
  },

  onLogout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          app.logout();
          this.checkLoginStatus();
          wx.showToast({ title: '已退出登录' });
        }
      }
    });
  },

  onAllOrders() {
    if (!app.globalData.isLogin) {
      app.login();
      return;
    }
    wx.switchTab({ url: '/pages/order/index' });
  },

  onTakeOrder() {
    if (!app.globalData.isLogin) {
      app.login();
      return;
    }
    wx.navigateTo({ url: '/subpkg/worker/pending/index' });
  },

  onMyOrders() {
    if (!app.globalData.isLogin) {
      app.login();
      return;
    }
    wx.navigateTo({ url: '/subpkg/worker/order/index' });
  },

  onOrderTap(e) {
    const type = e.currentTarget.dataset.type;
    if (!app.globalData.isLogin) {
      app.login();
      return;
    }
    const routes = {
      'repair': '/subpkg/repair/list/index',
      'express': '/subpkg/express/list/index',
      'errand': '/subpkg/errand/list/index',
      'food': '/subpkg/food/list/index',
      'secondhand': '/subpkg/secondhand/list/index'
    };
    if (routes[type]) {
      wx.navigateTo({ url: routes[type] });
    } else {
      wx.switchTab({ url: '/pages/order/index' });
    }
  },

  onMenuTap(e) {
    const type = e.currentTarget.dataset.type;
    if (!app.globalData.isLogin && type !== 'help' && type !== 'service' && type !== 'setting') {
      app.login();
      return;
    }
    const routes = {
      'myPost': '/subpkg/profile/my-post/index',
      'myTakeOrder': '/subpkg/worker/order/index',
      'myCollect': '/subpkg/profile/my-collect/index',
      'myClub': '/subpkg/member/my/index',
      'coupon': '/subpkg/profile/coupon/index',
      'wallet': '/subpkg/profile/wallet/index',
      'auth': '/subpkg/profile/auth/index',
      'dorm': '/subpkg/profile/dorm/index',
      'setting': '/subpkg/profile/setting/index',
      'help': '/subpkg/profile/help/index',
      'service': '/subpkg/profile/help/index'
    };
    if (routes[type]) {
      wx.navigateTo({ url: routes[type] });
    } else {
      wx.showToast({ title: '功能开发中', icon: 'none' });
    }
  }
});
