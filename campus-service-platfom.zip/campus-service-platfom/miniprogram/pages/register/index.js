const app = getApp();
const api = require('../../api/index.js');

Page({
  data: {
    role: 1,
    studentId: '',
    idCard: '',
    realName: '',
    phone: '',
    password: '',
    confirmPassword: '',
    dormBuild: '',
    dormRoom: '',
    showPassword: false,
    loading: false
  },

  onRoleChange(e) {
    this.setData({ role: parseInt(e.currentTarget.dataset.role) });
  },

  onStudentIdInput(e) {
    this.setData({ studentId: e.detail.value });
  },

  onIdCardInput(e) {
    this.setData({ idCard: e.detail.value });
  },

  onRealNameInput(e) {
    this.setData({ realName: e.detail.value });
  },

  onPhoneInput(e) {
    this.setData({ phone: e.detail.value });
  },

  onPasswordInput(e) {
    this.setData({ password: e.detail.value });
  },

  onConfirmPasswordInput(e) {
    this.setData({ confirmPassword: e.detail.value });
  },

  onDormBuildInput(e) {
    this.setData({ dormBuild: e.detail.value });
  },

  onDormRoomInput(e) {
    this.setData({ dormRoom: e.detail.value });
  },

  onTogglePassword() {
    this.setData({ showPassword: !this.data.showPassword });
  },

  onRegister() {
    const { role, studentId, idCard, realName, phone, password, confirmPassword, dormBuild, dormRoom } = this.data;

    if (role === 1) {
      if (!studentId || !/^\d{10}$/.test(studentId)) {
        wx.showToast({ title: '学号必须是10位数字', icon: 'none' });
        return;
      }
    } else {
      if (!idCard || !/^\d{17}[\dXx]$/.test(idCard)) {
        wx.showToast({ title: '请输入正确的身份证号', icon: 'none' });
        return;
      }
    }

    if (!realName || realName.length < 2) {
      wx.showToast({ title: '请输入真实姓名', icon: 'none' });
      return;
    }
    if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
      wx.showToast({ title: '请输入正确的手机号', icon: 'none' });
      return;
    }
    if (!password || password.length !== 6) {
      wx.showToast({ title: '密码必须是6位', icon: 'none' });
      return;
    }
    const hasNumber = /\d/.test(password);
    const hasLetter = /[a-zA-Z]/.test(password);
    if (!hasNumber || !hasLetter) {
      wx.showToast({ title: '密码必须包含数字和英文', icon: 'none' });
      return;
    }
    if (password !== confirmPassword) {
      wx.showToast({ title: '两次密码不一致', icon: 'none' });
      return;
    }

    const params = { role, realName, phone, password };
    if (role === 1) {
      params.studentId = studentId;
      params.dormBuild = dormBuild;
      params.dormRoom = dormRoom;
    } else {
      params.idCard = idCard;
    }

    this.setData({ loading: true });
    api.post('/user/register', params).then(res => {
      this.setData({ loading: false });
      if (res.code === 200 && res.data) {
        wx.showToast({ title: '注册成功', icon: 'success' });
        const data = res.data;
        app.globalData.token = data.token;
        app.globalData.isLogin = true;
        app.globalData.userInfo = data.userInfo;
        wx.setStorageSync('token', data.token);
        wx.setStorageSync('userInfo', data.userInfo);
        setTimeout(() => {
          if (role === 2) {
            wx.reLaunch({ url: '/subpkg/worker/pending/index' });
          } else {
            wx.switchTab({ url: '/pages/index/index' });
          }
        }, 1500);
      } else {
        wx.showToast({ title: res.message || '注册失败', icon: 'none' });
      }
    });
  }
});
