const app = getApp();

Page({
  data: {},

  onServiceTap(e) {
    const type = e.currentTarget.dataset.type;
    if (!app.globalData.isLogin && ['repair', 'express', 'errand', 'food', 'secondhand', 'lostfound'].includes(type)) {
      app.login(() => {
        this.navigateToService(type);
      });
      return;
    }
    this.navigateToService(type);
  },

  navigateToService(type) {
    const routes = {
      'repair': '/subpkg/repair/create/index',
      'express': '/subpkg/express/create/index',
      'errand': '/subpkg/errand/create/index',
      'food': '/subpkg/food/list/index',
      'secondhand': '/subpkg/secondhand/list/index',
      'lostfound': '/pages/lostfound/index',
      'notice': '/pages/index/index',
      'activity': '/subpkg/activity/list/index',
      'navigate': '/pages/navigate/index'
    };
    const url = routes[type];
    if (url) {
      wx.navigateTo({ url });
    } else {
      wx.showToast({ title: '功能开发中', icon: 'none' });
    }
  }
});
