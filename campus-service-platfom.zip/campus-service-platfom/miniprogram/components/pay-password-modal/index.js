Component({
  properties: {
    visible: {
      type: Boolean,
      value: false
    },
    amount: {
      type: String,
      value: ''
    }
  },

  data: {
    password: '',
    errorMsg: '',
    inputFocus: false
  },

  observers: {
    'visible'(val) {
      if (val) {
        this.setData({ password: '', errorMsg: '' });
        setTimeout(() => {
          this.setData({ inputFocus: true });
        }, 300);
      } else {
        this.setData({ inputFocus: false });
      }
    }
  },

  methods: {
    stopPropagation() {},

    onFocusInput() {
      this.setData({ inputFocus: true });
    },

    onInput(e) {
      const val = e.detail.value.replace(/\D/g, '').slice(0, 6);
      this.setData({ 
        password: val,
        errorMsg: ''
      });
    },

    onBlur() {
      this.setData({ inputFocus: false });
    },

    onCancel() {
      this.setData({ password: '', errorMsg: '', inputFocus: false });
      this.triggerEvent('cancel');
    },

    onConfirm() {
      const { password } = this.data;
      if (password.length !== 6) {
        this.setData({ errorMsg: '请输入6位支付密码' });
        return;
      }
      this.triggerEvent('confirm', { password });
    },

    showError(msg) {
      this.setData({ errorMsg: msg, password: '' });
      setTimeout(() => {
        this.setData({ inputFocus: true });
      }, 100);
    },

    clear() {
      this.setData({ password: '', errorMsg: '' });
    }
  }
});
